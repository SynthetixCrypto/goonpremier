# Goon Client: new directions

Research and proposals — 2026-10-09. This document mixes implemented first slices (marked below) and future ideas. Future scope is **not released**.
Individual issue reports are useful design inputs, not evidence of how common a complaint is.

## What players are asking for

- Easier mod troubleshooting: [Prism #1924](https://github.com/PrismLauncher/PrismLauncher/issues/1924) requests an automated mod bisect. Dependencies and inconsistent reproduction make a naive disable-half approach unreliable.
- Smoothness beyond an FPS number: [Sodium #3004](https://github.com/CaffeineMC/sodium/issues/3004) describes erratic Intel frame presentation, with a lower cap reportedly feeling smoother. This is a specific hardware report, not a universal fix.
- Easier setup reuse: [Prism #2205](https://github.com/PrismLauncher/PrismLauncher/issues/2205) asks for copying settings between instances. Goon already has setups and per-server links; a portable, reviewed share format would extend those.
- Easier screenshot browsing: [Prism #1027](https://github.com/PrismLauncher/PrismLauncher/issues/1027) asks for a screenshot browser. Goon already has a manager; event tagging and albums would add something beyond another folder shortcut.
- Baseline troubleshooting should explain the Java/runtime requirements: [official Prism troubleshooting](https://prismlauncher.org/wiki/overview/troubleshooting/).

## Implemented first slices — 0.18.3

- **Performance Notebook:** bounded 60-second window, frame intervals and p95/p99/max, long-frame counts, start settings, local CSV/summary, explicit exclusions and provisional warnings. No diagnosis, setting-change annotations or A/B comparison yet.
- **Launch Checkup:** bounded, read-only Fabric archive/ID inventory, nested jars and aliases, duplicate/missing-ID advisories and a local report without paths/accounts. Not a full version resolver, malicious-code scanner, rollback or bisect.
- **Expedition Planner:** saved packing lists, actual carried inventory, manual tasks and waypoint snapshots. No trip-file exchange, shared tracking or new breadcrumb feature.

## Original proposals and future extensions

### 1. “Why did that stutter?”

A local performance notebook with frame-time percentiles, long-frame count, memory pressure and the active render/shader settings. Mark when settings changed and compare two short runs in the same scene. Explain that storage, drivers, chunk generation and presentation may need separate investigation.

First slice: a 60-second capture and readable local report. Use a fixed-size ring buffer, no per-frame disk writes, and no automatic uploads. Do not claim a diagnosis from correlation or promise an FPS gain.

### 2. Launch Checkup + known-good rollback

Before launch, explain duplicate mod IDs, wrong Minecraft/Java versions and missing dependencies. After a failed update, offer the last working pack/config snapshot with a preview of what will be restored. Never roll back worlds automatically.

First slice: read-only preflight and redacted local error report. A future dependency-aware bisect must account for nested mods in the combined jar, required dependencies and player confirmation after each test.

### 3. Expedition planner

A trip sheet with a destination waypoint, food/repair supplies, optional boss checklist and a return-home marker. Track what is in your actual inventory; let friends exchange a small trip file. No background friend tracking or hidden world scanning.

First slice: reusable packing lists and manual waypoint links. A later local breadcrumb trail records only places the player has actually travelled, with a storage cap and clear-history button.

## More original additions

4. **Supply watch.** Set minimum stock for items remembered by Container Bookmarks. Every result shows its last-observed age; opening a container refreshes it. No claim of live remote chest contents.
5. **Co-op project board.** A build's material checklist, stages and assigned roles, shared by an explicit file export/copy action. Start without an account service; later consider an opt-in hosted sync.
6. **Session postcards.** Bundle selected screenshots, captions and Adventure Log milestones into a local album. Ask before including player names/server details in an export.
7. **Portable setup cards.** Export a named setup with a preview/diff on import and version checks. Exclude tokens, server addresses, local paths and private waypoint/container histories by default.
8. **Comfort modes.** Color-vision-friendly warning symbols, reduced motion, smaller fire overlays where permitted, readable chat and stronger sound/subtitle cues. Keep meaning visible without relying only on accent color.
9. **Farm experiment notebook.** Annotate a farm change, compare observed pickup/XP reports across equal-length sessions, and show rate uncertainty for short sessions. Avoid claiming server-wide production.
10. **Focus HUD.** Optional context rules such as exploration/building/combat, with hysteresis and a manual lock. Preview resulting layout before applying; preserve personal positions and keep transitions out of the aiming area.

## Suggested order

Launch Checkup → performance notebook → expedition planner → supply watch → setup sharing.
Each should ship as a small working slice with startup, no-world, disconnect and persistence checks.

## This release's groundwork (0.18.2)

Installation status is now a background snapshot rather than paint-time filesystem work. Launcher timers are owned by the view and stop on removal. Idle redraws are reduced; active decorative motion remains optional. Container lists reuse immutable snapshots and identical slot updates do not dirty data. Startup recovery resets HUD positions before applying the pre-server snapshot.

This is reduced housekeeping work, not a measured game-FPS improvement. No upstream feature code was copied in this batch.

## Additional research directions

- **Keyboard and narrated settings:** [Minecraft Access #204](https://github.com/minecraft-access/minecraft-access/issues/204), [Forge #9793](https://github.com/MinecraftForge/MinecraftForge/issues/9793), and [Controlify](https://github.com/isXander/Controlify). These are design examples, not proof of a Fabric 26.3 defect. Audit Goon's existing card/settings keyboard flow before building a shared focus model; preserve pointer controls and viewport clipping.
- **Protected comfort preferences:** [Default Options documentation](https://mods.twelveiterations.com/minecraft/default-options). Explore a narrowly scoped allow-list of personal comfort settings that survive a setup load. Preview affected values and retain exact undo; do not silently preserve gameplay toggles across every preset.
- **Selective sound levels:** [Sound Controller](https://github.com/BVengo/sound-controller#readme). Consider per-event attenuation with search, preserving master/category levels, distance cues and subtitles; handle loops, unknown IDs and resource reloads. Not implemented.

No upstream source was copied for the 0.18.3 tools. Individual issue reports remain examples, not a measure of complaint prevalence.
