"""
Builds the website's images from fresh client captures.

Inputs: a folder of per-theme menu-preview captures (<theme>/goon-menu-*.png from `runClient -PmenuPreview -PdevAccent=<theme>`)
and a folder of Noir dev-snapshot captures (goon-title.png, goon-pause.png, ...). Writes WebP screenshots (themed ones once
per theme: shot-hud-1600.webp for Noir, shot-hud-mint-1600.webp, ...), the hero backdrop, the HUD showcase background, the
social card, favicons and the HUD icons into <site>/assets/img.

Usage: python marketing/brand/site_images.py <themeshots dir> <snapshots dir> <site dir>
"""
import os
import sys
from PIL import Image, ImageDraw, ImageFilter, ImageFont

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, '..', '..'))
THEMES = ['Noir', 'Classic', 'Legacy', 'Amber', 'Purple', 'Blue', 'Azure', 'Nitro', 'Sunset', 'Aurora', 'Mint', 'Sky', 'Violet',
          'Rose', 'Red', 'White']
# Site key -> menu-preview capture, rendered once per theme
THEMED = {'hud': 'ingame', 'menu': 'modules', 'settings': 'hud', 'themes': 'themes'}
# Site key -> Noir capture (menu preview or dev snapshots)
NOIR_PREVIEW = {'module': 'module-settings', 'editor': 'editor', 'configs': 'configs'}
NOIR_SNAPSHOTS = {'title': 'goon-title.png', 'pause': 'goon-pause.png', 'log': 'goon-log.png', 'options': 'goon-options.png',
                  'wardrobe': 'goon-wardrobe.png'}


def webp_pair(image, out_dir, key, suffix=''):
    image = image.convert('RGB')
    for width, quality in ((1600, 80), (800, 78)):
        scaled = image if image.width == width else image.resize((width, round(image.height * width / image.width)), Image.LANCZOS)
        scaled.save(os.path.join(out_dir, f'shot-{key}{suffix}-{width}.webp'), 'WEBP', quality=quality, method=6)


def main(theme_dir, snap_dir, site_dir):
    img = os.path.join(site_dir, 'assets', 'img')
    os.makedirs(os.path.join(img, 'hud'), exist_ok=True)
    written = set()

    for theme in THEMES:
        suffix = '' if theme == 'Noir' else '-' + theme.lower()
        for key, capture in THEMED.items():
            path = os.path.join(theme_dir, theme, f'goon-menu-{capture}.png')
            if not os.path.isfile(path):
                print('missing', path)
                continue
            webp_pair(Image.open(path), img, key, suffix)
            written.update({f'shot-{key}{suffix}-1600.webp', f'shot-{key}{suffix}-800.webp'})
    for key, capture in NOIR_PREVIEW.items():
        webp_pair(Image.open(os.path.join(theme_dir, 'Noir', f'goon-menu-{capture}.png')), img, key)
        written.update({f'shot-{key}-1600.webp', f'shot-{key}-800.webp'})
    for key, name in NOIR_SNAPSHOTS.items():
        webp_pair(Image.open(os.path.join(snap_dir, name)), img, key)
        written.update({f'shot-{key}-1600.webp', f'shot-{key}-800.webp'})

    ingame = Image.open(os.path.join(theme_dir, 'Noir', 'goon-menu-ingame.png')).convert('RGB')
    # Hero backdrop: small and pre-softened; the page blurs it further
    ingame.resize((960, 540), Image.LANCZOS).filter(ImageFilter.GaussianBlur(4)).save(os.path.join(img, 'hero-bg.jpg'), quality=72)
    # HUD showcase background: a clean patch of world left of centre, with no HUD on it
    ingame.crop((228, 46, 778, 596)).resize((720, 720), Image.LANCZOS).save(os.path.join(img, 'hud-stage.jpg'), quality=82)
    written.update({'hero-bg.jpg', 'hud-stage.jpg'})

    # Logo, favicons
    out = os.path.join(HERE, 'out')
    for name in ('goon-mark.svg',):
        with open(os.path.join(out, name), encoding='utf-8') as f:
            svg = f.read()
        with open(os.path.join(img, 'mark.svg'), 'w', encoding='utf-8') as f:
            f.write(svg)
    Image.open(os.path.join(out, 'goon-mark-64.png')).save(os.path.join(img, 'favicon.png'))
    Image.open(os.path.join(out, 'goon-mark-180.png')).save(os.path.join(img, 'apple-touch-icon.png'))
    Image.open(os.path.join(out, 'goon-mark-256.png')).save(os.path.join(img, 'icon.png'))
    ico = [Image.open(os.path.join(out, f'goon-mark-{s}.png')) for s in (16, 32, 48, 64)]
    ico[-1].save(os.path.join(site_dir, 'favicon.ico'), sizes=[(i.width, i.height) for i in ico], append_images=ico[:-1])
    written.update({'mark.svg', 'favicon.png', 'apple-touch-icon.png', 'icon.png'})

    # HUD icons for the HTML replicas (Combatant's element icons, white on transparent)
    for name in ('fps', 'memory', 'speedometer', 'coords'):
        src = os.path.join(ROOT, 'src/main/resources/assets/goonclient/textures/hud/elements', name + '.png')
        Image.open(src).resize((64, 64), Image.LANCZOS).save(os.path.join(img, 'hud', name + '.png'))

    # Social card: backdrop, mark + wordmark, tagline and the in-game shot in a glass frame
    card = Image.new('RGB', (1200, 630), (8, 9, 12))
    bg = ingame.resize((1200, 675), Image.LANCZOS).crop((0, 0, 1200, 630)).filter(ImageFilter.GaussianBlur(18))
    card = Image.blend(card, bg, 0.42)
    glow = Image.new('RGBA', (1200, 630), (0, 0, 0, 0))
    ImageDraw.Draw(glow).ellipse((620, 120, 1300, 760), fill=(225, 107, 120, 70))
    card.paste(Image.alpha_composite(card.convert('RGBA'), glow.filter(ImageFilter.GaussianBlur(90))).convert('RGB'))
    card = card.convert('RGBA')
    mark = Image.open(os.path.join(out, 'goon-mark-128.png'))
    card.alpha_composite(mark, (64, 70))
    bold = ImageFont.truetype(os.path.join(ROOT, 'src/main/resources/assets/goonclient/font/inter-bold.ttf'), 58)
    regular = ImageFont.truetype(os.path.join(ROOT, 'src/main/resources/assets/goonclient/font/inter-regular.ttf'), 27)
    d = ImageDraw.Draw(card)
    d.text((212, 134), 'GOON ', font=bold, fill=(244, 244, 244), anchor='lm')
    d.text((212 + d.textlength('GOON ', font=bold), 134), 'CLIENT', font=bold, fill=(225, 107, 120), anchor='lm')
    d.multiline_text((66, 236), 'The PvE client for\nMinecraft 26.3.\nFree and open source.', font=regular, fill=(199, 203, 211), spacing=14)
    shot = ingame.resize((640, 360), Image.LANCZOS)
    frame = Image.new('RGBA', (656, 376), (0, 0, 0, 0))
    ImageDraw.Draw(frame).rounded_rectangle((0, 0, 655, 375), 18, fill=(30, 32, 40, 200), outline=(255, 255, 255, 40))
    mask = Image.new('L', shot.size, 0)
    ImageDraw.Draw(mask).rounded_rectangle((0, 0, 639, 359), 12, fill=255)
    frame.paste(shot, (8, 8), mask)
    card.alpha_composite(frame, (500, 196))
    card.convert('RGB').save(os.path.join(img, 'og.jpg'), quality=86)
    written.add('og.jpg')
    print(f'wrote {len(written)} images into {img}')
    return written


if __name__ == '__main__':
    main(*sys.argv[1:4])
