import dev.goonclient.client.cosmetics.CapeCatalog;
import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.RadialGradientPaint;
import java.awt.RenderingHints;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

/**
 * Renders every Goon cape's back face side by side, using the client's own CapeArt drawing (no game needed), for the
 * website's Wardrobe section. Run after compiling the client:
 * java -cp "build/classes/java/client;src/main/resources" marketing/brand/CapeLineup.java out.png
 */
public final class CapeLineup {
	public static void main(String[] args) throws Exception {
		var capes = CapeCatalog.CAPES.stream().filter(c -> !c.id().equals("none")).toList();
		int faceW = 160, faceH = 256, scale = 2, gap = 34, pad = 70;
		int cw = faceW * scale, ch = faceH * scale;
		int width = pad * 2 + capes.size() * cw + (capes.size() - 1) * gap, height = ch + pad * 2 + 70;
		BufferedImage out = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
		Graphics2D g = out.createGraphics();
		g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
		g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
		g.setPaint(new GradientPaint(0, 0, new Color(0x14161B), 0, height, new Color(0x08090C)));
		g.fillRect(0, 0, width, height);
		for (int i = 0; i < capes.size(); i++) {
			var cape = capes.get(i);
			BufferedImage art = new BufferedImage(1024, 512, BufferedImage.TYPE_INT_ARGB);
			Graphics2D ag = art.createGraphics();
			ag.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
			ag.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
			dev.goonclient.client.cosmetics.CapeArt.face(ag, cape, 0, true);
			ag.dispose();
			int x = pad + i * (cw + gap), y = pad;
			// Accent glow behind each cape
			float cx = x + cw / 2f, cy = y + ch / 2f;
			Color accent = new Color(cape.color());
			g.setPaint(new RadialGradientPaint(cx, cy, cw * 0.9f, new float[]{0, 1},
				new Color[]{new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 70), new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 0)}));
			g.fillRect(x - cw, y - ch / 2, cw * 3, ch * 2);
			// Soft drop shadow, then the cloth with rounded corners
			for (int s = 14; s > 0; s -= 2) {
				g.setColor(new Color(0, 0, 0, 10));
				g.fill(new RoundRectangle2D.Float(x - s + 6, y - s + 14, cw + s * 2 - 12, ch + s * 2 - 12, 18 + s, 18 + s));
			}
			Graphics2D clip = (Graphics2D) g.create();
			clip.clip(new RoundRectangle2D.Float(x, y, cw, ch, 14, 14));
			clip.drawImage(art.getSubimage(0, 16, faceW, faceH), x, y, cw, ch, null);
			clip.dispose();
			g.setColor(new Color(255, 255, 255, 30));
			g.draw(new RoundRectangle2D.Float(x + .5f, y + .5f, cw - 1, ch - 1, 14, 14));
			// Name under the cape
			g.setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 26));
			int tw = g.getFontMetrics().stringWidth(cape.name());
			g.setColor(new Color(0xE6E7EA));
			g.drawString(cape.name(), x + (cw - tw) / 2, y + ch + 52);
		}
		g.dispose();
		ImageIO.write(out, "png", new File(args[0]));
		System.out.println("wrote " + args[0] + " " + width + "x" + height);
	}
}
