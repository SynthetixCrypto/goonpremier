"""Original cut-corner Goon mark. Shared geometry with gui/render/LogoArt.java.
Run from any folder: python marketing/brand/logo.py.
Generates vector masters and antialiased PNG/ICO assets; no generated artwork dependencies.
"""
import os
from PIL import Image, ImageDraw, ImageFont

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, '..', '..'))
ACCENT = (225, 107, 120)
POINTS = [(31,20),(70,20),(80,30),(71,39),(65,33),(36,33),(32,37),(32,64),
          (37,69),(64,69),(68,65),(68,57),(49,57),(49,45),(81,45),(81,70),
          (69,82),(30,82),(19,71),(19,31)]
PATH = 'M' + ' L'.join(f'{x} {y}' for x,y in POINTS) + ' Z'

def render(size, tile=True, accent=ACCENT):
    high = max(400, size * 4)
    s = high / 100
    image = Image.new('RGBA',(high,high))
    d = ImageDraw.Draw(image)
    if tile:
        mask = Image.new('L',image.size)
        ImageDraw.Draw(mask).rounded_rectangle((3*s,3*s,97*s,97*s),19*s,fill=255)
        surface = Image.new('RGBA',image.size)
        sd = ImageDraw.Draw(surface)
        for y in range(high):
            t = min(1,max(0,(y/s-3)/94))
            rgb = tuple(round(a*(1-t)+b*t) for a,b in zip((36,38,46),(17,18,23)))
            sd.line((0,y,high,y),fill=rgb+(255,))
        image.paste(surface,(0,0),mask)
        d = ImageDraw.Draw(image)
        rim = Image.new('RGBA',image.size)
        ImageDraw.Draw(rim).rounded_rectangle((3.5*s,3.5*s,96.5*s,96.5*s),18.5*s,outline=(255,255,255,45),width=max(1,round(s)))
        image = Image.alpha_composite(image,rim)
        d = ImageDraw.Draw(image)
    d.polygon([(x*s,y*s) for x,y in POINTS],fill=accent+(255,))
    return image.resize((size,size),Image.Resampling.LANCZOS)

def wordmark(height,out_path):
    font = ImageFont.truetype(os.path.join(ROOT,'src/main/resources/assets/goonclient/font/inter-bold.ttf'),round(height*.54))
    probe = ImageDraw.Draw(Image.new('RGBA',(1,1)))
    gap = round(height*.25)
    first = probe.textlength('GOON ',font)
    width = round(height+gap+first+probe.textlength('CLIENT',font)+4)
    image = Image.new('RGBA',(width,height))
    image.alpha_composite(render(height))
    d = ImageDraw.Draw(image)
    d.text((height+gap,height*.5),'GOON ',font=font,fill=(244,244,247),anchor='lm')
    d.text((height+gap+first,height*.5),'CLIENT',font=font,fill=ACCENT,anchor='lm')
    image.save(out_path)

def main():
    out = os.path.join(HERE,'out')
    os.makedirs(out,exist_ok=True)
    defs = '<defs><linearGradient id="tile" x2="0" y2="1"><stop stop-color="#24262e"/><stop offset="1" stop-color="#111217"/></linearGradient></defs>'
    tile = '<rect x="3" y="3" width="94" height="94" rx="19" fill="url(#tile)"/><rect x="3.5" y="3.5" width="93" height="93" rx="18.5" fill="none" stroke="#fff" stroke-opacity=".18"/>'
    for name,background in [('goon-mark.svg',defs+tile),('goon-glyph.svg','')]:
        svg = f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" role="img" aria-label="Goon Client">{background}<path d="{PATH}" fill="#e16b78"/></svg>'
        with open(os.path.join(out,name),'w',encoding='utf-8') as f: f.write(svg+'\n')
    for size in (16,24,32,48,64,128,180,256,512,1024):
        render(size).save(os.path.join(out,f'goon-mark-{size}.png'))
    render(512,False).save(os.path.join(out,'goon-glyph-512.png'))
    render(256).save(os.path.join(out,'goonclient.ico'),sizes=[(s,s) for s in (16,24,32,48,64,128,256)])
    wordmark(160,os.path.join(out,'goon-wordmark-160.png'))
    print('Generated original Goon mark:',out)

if __name__ == '__main__': main()
