package dev.goonclient;

import net.minecraft.resources.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class Goon {
	public static final String MOD_ID = "goonclient";
	public static final Logger LOGGER = LoggerFactory.getLogger("Goon Client");

	private Goon() {
	}

	public static Identifier id(String path) {
		return Identifier.fromNamespaceAndPath(MOD_ID, path);
	}
}
