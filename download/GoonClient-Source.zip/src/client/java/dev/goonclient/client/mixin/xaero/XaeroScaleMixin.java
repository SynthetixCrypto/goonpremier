package dev.goonclient.client.mixin.xaero;

import dev.goonclient.client.modules.hud.MinimapHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(targets = "xaero.hud.gui.util.GuiUtils", remap = false)
public class XaeroScaleMixin {
	@Inject(method = "getMinimapScale", at = @At("RETURN"), cancellable = true)
	private static void goonclient$scale(CallbackInfoReturnable<Float> cir) {
		cir.setReturnValue(cir.getReturnValueF() * MinimapHud.mapScale());
	}
}
