package dev.goonclient.client.gui;

import dev.goonclient.client.GoonChat;
import dev.goonclient.client.tracker.AdventureLog;
import dev.goonclient.client.waypoint.Waypoint;
import dev.goonclient.client.waypoint.WaypointManager;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;

/** Everything the Adventure Log recorded in this world, newest first, grouped by day and filterable. */
public class AdventureLogScreen extends Screen implements GoonScreen {
	private static final int ROW = 30;
	private static final int DAY_HEADER = 18;
	private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("HH:mm");
	private static final DateTimeFormatter DAY = DateTimeFormatter.ofPattern("d MMMM yyyy");

	private final Screen parent;
	private final List<Hit> hits = new ArrayList<>();
	private AdventureLog.Type filter;
	private float scroll;
	private float scrollTarget;
	private int contentHeight;
	private long openedAt;

	private float s = 1;
	private int px;
	private int py;
	private int pw;
	private int ph;
	private int listTop;
	private int listBottom;

	public AdventureLogScreen(Screen parent) {
		super(Component.literal("Adventure Log"));
		this.parent = parent;
	}

	@Override
	protected void init() {
		s = Ui.menuScale(width, height);
		int vw = (int) (width / s);
		int vh = (int) (height / s);
		pw = Math.min(580, vw - 40);
		ph = Math.min(360, vh - 30);
		px = (vw - pw) / 2;
		py = (vh - ph) / 2;
		listTop = py + 74;
		listBottom = py + ph - 24;
		if (openedAt == 0) {
			openedAt = System.currentTimeMillis();
		}
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor g, int realMouseX, int realMouseY, float partialTick) {
		hits.clear();
		int mouseX = (int) (realMouseX / s);
		int mouseY = (int) (realMouseY / s);
		g.pose().pushMatrix();
		g.pose().scale(s, s);
		float open = Ui.easeOutCubic((System.currentTimeMillis() - openedAt) / 220f);
		g.pose().pushMatrix();
		g.pose().translate(0, (1 - open) * 8);

		Ui.shadow(g, px, py, px + pw, py + ph, 8, 10, open);
		Ui.roundOutline(g, px, py, px + pw, py + ph, 8, Ui.withAlpha(Ui.glass(Ui.BORDER), open), Ui.withAlpha(Ui.glass(Ui.PANEL), open));

		// Header
		int x = px + 16;
		Ui.logoMark(g, font, x, py + 14, 18, open);
		Ui.scaledBold(g, font, "Adventure Log", x + 26, py + 13, 1.25f, Ui.withAlpha(Ui.TEXT, open));
		List<AdventureLog.Entry> all = AdventureLog.entries();
		String subtitle = AdventureLog.active() ? AdventureLog.worldName() + "   " + all.size() + (all.size() == 1 ? " entry" : " entries") : "Not in a world";
		Ui.text(g, font, subtitle, x + 26, py + 27, Ui.withAlpha(Ui.MUTED, open));
		drawStats(g, all, open);

		// Filters
		int fx = x;
		int fy = py + 46;
		fx = chip(g, "All", null, fx, fy, mouseX, mouseY, open);
		for (AdventureLog.Type type : AdventureLog.Type.values()) {
			fx = chip(g, type.label(), type, fx, fy, mouseX, mouseY, open);
		}
		g.fill(px + 1, listTop - 4, px + pw - 1, listTop - 3, Ui.withAlpha(Ui.BORDER, open));

		// Entries
		scroll = Ui.animate("adventurelog:scroll", scrollTarget, 0.6f);
		g.enableScissor(px + 1, listTop, px + pw - 1, listBottom);
		contentHeight = drawEntries(g, all, x, listTop + 4 - Math.round(scroll), px + pw - 16, mouseX, mouseY, open);
		g.disableScissor();
		drawScrollbar(g, px + pw - 8, open);

		String hint = "Click an entry to save its location as a waypoint";
		Ui.text(g, font, hint, x, py + ph - 16, Ui.withAlpha(Ui.FAINT, open));
		String close = "Esc to close";
		Ui.text(g, font, close, px + pw - 16 - Ui.width(font, close), py + ph - 16, Ui.withAlpha(Ui.FAINT, open));

		g.pose().popMatrix();
		g.pose().popMatrix();
		super.extractRenderState(g, realMouseX, realMouseY, partialTick);
	}

	private void drawStats(GuiGraphicsExtractor g, List<AdventureLog.Entry> all, float alpha) {
		int deaths = 0;
		int bosses = 0;
		int finds = 0;
		for (AdventureLog.Entry entry : all) {
			switch (entry.type()) {
				case DEATH -> deaths++;
				case BOSS -> bosses++;
				case DROP -> finds++;
				default -> {
				}
			}
		}
		String[][] stats = {{Integer.toString(deaths), deaths == 1 ? "death" : "deaths"}, {Integer.toString(bosses), bosses == 1 ? "boss" : "bosses"},
			{Integer.toString(finds), finds == 1 ? "rare find" : "rare finds"}};
		int right = px + pw - 16;
		for (int i = stats.length - 1; i >= 0; i--) {
			String label = " " + stats[i][1];
			int lw = Ui.width(font, label);
			int vw = Ui.boldWidth(font, stats[i][0]);
			Ui.text(g, font, label, right - lw, py + 18, Ui.withAlpha(Ui.MUTED, alpha));
			Ui.bold(g, font, stats[i][0], right - lw - vw, py + 18, Ui.withAlpha(Ui.TEXT, alpha));
			right -= lw + vw + 14;
		}
	}

	private int chip(GuiGraphicsExtractor g, String label, AdventureLog.Type type, int x, int y, int mouseX, int mouseY, float alpha) {
		boolean selected = filter == type;
		int w = (selected ? Ui.boldWidth(font, label) : Ui.width(font, label)) + 16;
		boolean hover = Ui.inside(mouseX, mouseY, x, y, x + w, y + 17);
		float h = Ui.animate("adventurelog:chip:" + label, selected ? 1f : hover ? 0.5f : 0f, 0.5f);
		if (h > 0.01f) {
			Ui.roundRect(g, x, y, x + w, y + 17, 5, Ui.withAlpha(selected ? Ui.CONTROL : 0x14FFFFFF, Math.min(1f, h) * alpha));
		}
		if (selected) {
			Ui.bold(g, font, label, x + 8, y + 5, Ui.withAlpha(Ui.TEXT, alpha));
		} else {
			Ui.text(g, font, label, x + 8, y + 5, Ui.withAlpha(Ui.lerp(h * 2, Ui.MUTED, Ui.TEXT), alpha));
		}
		hits.add(new Hit(x, y, x + w, y + 17, () -> {
			filter = type;
			scrollTarget = 0;
		}));
		return x + w + 4;
	}

	private int drawEntries(GuiGraphicsExtractor g, List<AdventureLog.Entry> all, int left, int top, int right, int mouseX, int mouseY, float alpha) {
		if (!AdventureLog.active()) {
			Ui.text(g, font, "Join a world to see its Adventure Log.", left, top + 6, Ui.withAlpha(Ui.MUTED, alpha));
			return 20;
		}
		List<AdventureLog.Entry> shown = new ArrayList<>();
		for (int i = all.size() - 1; i >= 0; i--) {
			if (filter == null || all.get(i).type() == filter) {
				shown.add(all.get(i));
			}
		}
		if (shown.isEmpty()) {
			String empty = filter == null ? "Nothing logged yet. Deaths, bosses, rare finds and advancements will show up here."
				: "No " + filter.label().toLowerCase() + " logged yet.";
			Ui.text(g, font, empty, left, top + 6, Ui.withAlpha(Ui.MUTED, alpha));
			return 20;
		}
		boolean mouseInList = mouseY >= listTop && mouseY < listBottom;
		LocalDate today = LocalDate.now();
		LocalDate currentDay = null;
		int y = top;
		for (AdventureLog.Entry entry : shown) {
			LocalDate day = Instant.ofEpochMilli(entry.time()).atZone(ZoneId.systemDefault()).toLocalDate();
			if (!day.equals(currentDay)) {
				currentDay = day;
				String label = day.equals(today) ? "Today" : day.equals(today.minusDays(1)) ? "Yesterday" : day.format(DAY);
				if (y + DAY_HEADER > listTop && y < listBottom) {
					Ui.bold(g, font, label, left, y + 6, Ui.withAlpha(Ui.FAINT, alpha));
				}
				y += DAY_HEADER;
			}
			if (y + ROW > listTop && y < listBottom) {
				drawRow(g, entry, left - 6, y, right, mouseX, mouseY, mouseInList, alpha);
			}
			y += ROW + 2;
		}
		return y - top;
	}

	private void drawRow(GuiGraphicsExtractor g, AdventureLog.Entry entry, int x1, int y1, int x2, int mouseX, int mouseY, boolean mouseInList, float alpha) {
		boolean hover = mouseInList && Ui.inside(mouseX, mouseY, x1, y1, x2, y1 + ROW);
		String key = "adventurelog:row:" + entry.time() + entry.title();
		float h = Ui.animate(key, hover && entry.hasPosition() ? 1f : 0f, 0.5f);
		if (h > 0.01f) {
			Ui.roundRect(g, x1, y1, x2, y1 + ROW, 5, Ui.withAlpha(Ui.RAISED, h * alpha));
		}
		Ui.roundRect(g, x1 + 8, y1 + 8, x1 + 14, y1 + 14, 3, Ui.withAlpha(entry.type().color(), alpha));
		int textX = x1 + 22;
		String time = Instant.ofEpochMilli(entry.time()).atZone(ZoneId.systemDefault()).format(TIME);
		String place = entry.place();
		int rightColumn = Math.max(Ui.width(font, time), Ui.width(font, place));
		int maxText = x2 - 12 - rightColumn - textX - 12;
		Ui.bold(g, font, Ui.ellipsize(font, entry.title(), maxText, true), textX, y1 + 5, Ui.withAlpha(Ui.TEXT, alpha));
		if (!entry.detail().isEmpty() && !entry.detail().equals(entry.title())) {
			Ui.text(g, font, Ui.ellipsize(font, entry.detail(), maxText, false), textX, y1 + 17, Ui.withAlpha(Ui.MUTED, alpha));
		}
		Ui.text(g, font, time, x2 - 8 - Ui.width(font, time), y1 + 5, Ui.withAlpha(Ui.FAINT, alpha));
		if (!place.isEmpty()) {
			Ui.text(g, font, place, x2 - 8 - Ui.width(font, place), y1 + 17, Ui.withAlpha(Ui.MUTED, alpha));
		}
		if (entry.hasPosition() && mouseInList) {
			int top = Math.max(y1, listTop);
			int bottom = Math.min(y1 + ROW, listBottom);
			if (bottom > top) {
				hits.add(new Hit(x1, top, x2, bottom, () -> saveWaypoint(entry)));
			}
		}
	}

	private void saveWaypoint(AdventureLog.Entry entry) {
		String name = entry.title().replaceAll("[^A-Za-z0-9]+", "_").replaceAll("^_|_$", "");
		if (name.isEmpty()) {
			name = "Log";
		}
		WaypointManager.add(new Waypoint(name, entry.x(), entry.y(), entry.z(), entry.dimension(), entry.type().color(), false, System.currentTimeMillis()));
		GoonChat.info("Saved '" + name + "' as a waypoint (" + entry.x() + " " + entry.y() + " " + entry.z() + ")");
	}

	private void drawScrollbar(GuiGraphicsExtractor g, int x, float alpha) {
		int view = listBottom - listTop;
		int maxScroll = Math.max(0, contentHeight - view + 8);
		scrollTarget = Math.max(0, Math.min(maxScroll, scrollTarget));
		if (maxScroll <= 0) {
			return;
		}
		int thumb = Math.max(24, view * view / (contentHeight + 8));
		int thumbY = listTop + Math.round((view - thumb) * (scroll / maxScroll));
		Ui.roundRect(g, x, thumbY, x + 3, thumbY + thumb, 2, Ui.withAlpha(0x33FFFFFF, alpha));
	}

	@Override
	public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
		double mx = event.x() / s;
		double my = event.y() / s;
		for (int i = hits.size() - 1; i >= 0; i--) {
			Hit hit = hits.get(i);
			if (Ui.inside(mx, my, hit.x1, hit.y1, hit.x2, hit.y2)) {
				minecraft.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, 1.0f));
				hit.action.run();
				return true;
			}
		}
		return super.mouseClicked(event, doubleClick);
	}

	@Override
	public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
		scrollTarget -= (float) scrollY * 30f;
		return true;
	}

	@Override
	public void onClose() {
		minecraft.gui.setScreen(parent);
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}

	private record Hit(int x1, int y1, int x2, int y2, Runnable action) {
	}
}
