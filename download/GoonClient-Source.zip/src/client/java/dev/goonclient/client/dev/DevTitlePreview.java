package dev.goonclient.client.dev;

import com.mojang.blaze3d.platform.InputConstants;
import dev.goonclient.Goon;
import dev.goonclient.client.config.ConfigManager;
import dev.goonclient.client.gui.GoonTitleScreen;
import dev.goonclient.client.gui.HudEditorScreen;
import dev.goonclient.client.module.ModuleManager;
import dev.goonclient.client.module.setting.ModeSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import net.minecraft.client.input.KeyEvent;

/** Opt-in, muted title tour; never activated for normal players. */
public final class DevTitlePreview {
    private static int ticks, originalScale;
    private static com.google.gson.JsonObject original;
    private static volatile boolean pending;
    private static int siteIndex=-1;
    private static long siteNext;
    private static boolean siteCaptured;
    private DevTitlePreview() { }

    static void tick(Minecraft mc) {
        if (!mc.isGameLoadFinished() || mc.gui.overlay() != null || pending) return;
        if(Boolean.getBoolean("goonclient.siteTitleTour")){siteTick(mc);return;}
        mc.getFramerateLimitTracker().onInputReceived();
        ticks++;
        switch (ticks) {
            case 30 -> {
                original = ConfigManager.capture(); originalScale = mc.options.guiScale().get();
                theme("Noir"); open(mc, 2);
            }
            case 55 -> shot(mc, "noir-scale2");
            case 60 -> {
                var title = mc.gui.screen();
                key(mc, InputConstants.KEY_TAB); key(mc, InputConstants.KEY_RETURN);
                if (!(mc.gui.screen() instanceof net.minecraft.client.gui.screens.worldselection.SelectWorldScreen)) throw new IllegalStateException("Singleplayer action failed");
                mc.gui.screen().onClose();
                if (mc.gui.screen() != title) throw new IllegalStateException("World list didn't return to Goon title");
            }
            case 65 -> {
                mc.gui.setScreen(new GoonTitleScreen());
                key(mc, InputConstants.KEY_TAB); key(mc, InputConstants.KEY_TAB); key(mc, InputConstants.KEY_RETURN);
                if (!(mc.gui.screen() instanceof net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen)
                    && !(mc.gui.screen() instanceof net.minecraft.client.gui.screens.multiplayer.SafetyScreen)) throw new IllegalStateException("Multiplayer action failed");
                mc.gui.screen().onClose();
                if (!(mc.gui.screen() instanceof GoonTitleScreen)) throw new IllegalStateException("Multiplayer didn't return to Goon title");
                open(mc, 3);
            }
            case 90 -> shot(mc, "noir-scale3");
            case 95 -> open(mc, 4);
            case 120 -> shot(mc, "noir-scale4");
            case 125 -> { theme("Sky"); open(mc, 2); }
            case 150 -> shot(mc, "sky-scale2");
            case 155 -> {
                mc.gui.setScreen(new GoonTitleScreen());
                for (int i = 0; i < 5; i++) key(mc, InputConstants.KEY_TAB);
                key(mc, InputConstants.KEY_RETURN);
                if (!(mc.gui.screen() instanceof HudEditorScreen)) throw new IllegalStateException("Title HUD action failed");
            }
            case 175 -> { shot(mc, "hud-preview"); mc.gui.screen().onClose(); }
            case 180 -> {
                if (!(mc.gui.screen() instanceof GoonTitleScreen)) throw new IllegalStateException("HUD preview didn't return to Goon title");
                Goon.LOGGER.info("Dev title: keyboard actions, world/server return, no-world HUD and GUI scales 2/3/4 passed");
                ConfigManager.apply(original, true, false);
                mc.options.guiScale().set(originalScale); mc.resizeGui(); mc.stop();
            }
        }
    }

    /** Refresh website images from the actual current menu, all themes in one isolated run. */
    private static void siteTick(Minecraft mc){
        mc.getFramerateLimitTracker().onInputReceived();long now=System.nanoTime();
        if(siteIndex<0){original=ConfigManager.capture();originalScale=mc.options.guiScale().get();siteIndex=0;
            ModuleManager.all().stream().filter(m->m.id().equals("interface")).findFirst().orElseThrow().settings().stream().filter(s->s.id().equals("menu_background")).findFirst().ifPresent(s->((ModeSetting)s).set("Goon"));
            theme(dev.goonclient.client.gui.Themes.ALL.get(siteIndex).name());open(mc,2);siteNext=now+700_000_000L;return;}
        if(now<siteNext)return;
        if(!siteCaptured){Goon.LOGGER.info("SITE MENU MEMORY pid={} {}",ProcessHandle.current().pid(),dev.goonclient.client.util.MemoryStats.sample());shot(mc,"site-"+dev.goonclient.client.gui.Themes.ALL.get(siteIndex).name().toLowerCase(java.util.Locale.ROOT));siteCaptured=true;siteNext=now+100_000_000L;return;}
        if(++siteIndex==dev.goonclient.client.gui.Themes.ALL.size()){
            ConfigManager.apply(original,true,false);mc.options.guiScale().set(originalScale);mc.resizeGui();
            Goon.LOGGER.info("SITE TITLE TOUR PASSED: all {} current theme menus captured",siteIndex);mc.stop();return;}
        theme(dev.goonclient.client.gui.Themes.ALL.get(siteIndex).name());open(mc,2);siteCaptured=false;siteNext=now+700_000_000L;
    }

    private static void open(Minecraft mc, int scale) {
        mc.options.guiScale().set(scale); mc.resizeGui(); mc.gui.setScreen(new GoonTitleScreen());
    }
    private static void key(Minecraft mc, int key) { mc.gui.screen().keyPressed(new KeyEvent(key, 0, 0)); }
    private static void theme(String name) {
        ModuleManager.all().stream().filter(m -> m.id().equals("interface")).findFirst().ifPresent(m -> {
            m.loadEnabled(true);
            m.settings().stream().filter(s -> s.id().equals("theme")).findFirst().ifPresent(s -> ((ModeSetting)s).set(name));
        });
    }
    private static void shot(Minecraft mc, String name) {
        pending = true;
        Screenshot.grab(mc.gameDirectory, "goon-title-0176-" + name + ".png", mc.gameRenderer.mainRenderTarget(), 1, message -> pending = false);
    }
}
