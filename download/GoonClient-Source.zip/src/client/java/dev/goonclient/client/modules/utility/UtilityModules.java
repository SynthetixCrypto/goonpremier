package dev.goonclient.client.modules.utility;

import dev.goonclient.client.hud.HudPosition;
import dev.goonclient.client.gui.Ui;
import dev.goonclient.client.hud.TextHudModule;
import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.Module;
import dev.goonclient.client.module.setting.BooleanSetting;
import dev.goonclient.client.tracker.SessionStats;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

public final class UtilityModules {
	private UtilityModules() {
	}

	/** Keeps you sprinting while you move forward. */
	public static class ToggleSprint extends Module {
		public ToggleSprint() {
			super("toggle_sprint", "Toggle Sprint", "Always sprint when moving forward", Category.UTILITY, false);
		}

		@Override
		public void onTick(Minecraft mc) {
			if (mc.player != null && mc.gui.screen() == null) {
				mc.options.keySprint.setDown(true);
			}
		}

		@Override
		protected void onDisable() {
			Minecraft.getInstance().options.keySprint.setDown(false);
		}
	}

	/** Press sneak once to start sneaking and again to stop (switches the game's own toggle option). */
	public static class ToggleSneak extends Module {
		public ToggleSneak() {
			super("toggle_sneak", "Toggle Sneak", "Tap sneak to start sneaking, tap again to stop", Category.UTILITY, false);
		}

		@Override
		public void onTick(Minecraft mc) {
			if (!mc.options.toggleCrouch().get()) {
				mc.options.toggleCrouch().set(true);
			}
		}

		@Override
		protected void onDisable() {
			Minecraft mc = Minecraft.getInstance();
			mc.options.toggleCrouch().set(false);
			mc.options.keyShift.setDown(false);
		}
	}

	/** Prefixes every chat line with the time it arrived. */
	public static class ChatTimestamps extends Module {
		private static ChatTimestamps instance;
		private static final DateTimeFormatter H24 = DateTimeFormatter.ofPattern("HH:mm");
		private static final DateTimeFormatter H24_SECONDS = DateTimeFormatter.ofPattern("HH:mm:ss");

		private final BooleanSetting seconds = add(new BooleanSetting("seconds", "Show seconds", false));

		public ChatTimestamps() {
			super("chat_timestamps", "Chat Timestamps", "Adds the time to every chat message", Category.UTILITY, false);
			instance = this;
		}

		/** Called from the ChatComponent mixin. */
		public static Component decorate(Component message) {
			if (instance == null || !instance.isEnabled()) {
				return message;
			}
			String time = LocalTime.now().format(instance.seconds.isOn() ? H24_SECONDS : H24);
			MutableComponent stamp = Component.literal("[" + time + "] ").withStyle(style -> style.withColor(Ui.MUTED & 0xFFFFFF));
			return stamp.append(message);
		}
	}

	/** Folds repeated messages into one line with a counter, and keeps more chat history. */
	public static class BetterChat extends Module {
		private static final int VANILLA_HISTORY = 100;
		private static BetterChat instance;

		private final BooleanSetting stackRepeats = add(new BooleanSetting("stack_repeats", "Stack repeated messages", true));
		private final BooleanSetting longHistory = add(new BooleanSetting("long_history", "Keep 1000 messages", true));

		public BetterChat() {
			super("better_chat", "Better Chat", "Repeated messages stack into one line with a counter, and chat keeps 1000 messages",
				Category.UTILITY, true);
			instance = this;
		}

		/** How many messages chat keeps; called from the ChatComponent mixin. */
		public static int historySize() {
			return instance != null && instance.isEnabled() && instance.longHistory.isOn() ? 1000 : VANILLA_HISTORY;
		}

		/** Whether a message that repeats the previous one should replace it with a counter. */
		public static boolean stacksRepeats() {
			return instance != null && instance.isEnabled() && instance.stackRepeats.isOn();
		}

		/** "Message (x3)" with the counter in grey. */
		public static Component withCount(Component message, int count) {
			return message.copy().append(Component.literal(" (x" + count + ")").withStyle(style -> style.withColor(Ui.MUTED & 0xFFFFFF)));
		}
	}

	public static class SessionStatsHud extends TextHudModule {
		public SessionStatsHud() {
			super("session_stats", "Session Stats", "Playtime, kills, deaths, blocks, distance, XP and items this session", Category.UTILITY, false, HudPosition.leftColumn(160));
		}

		@Override
		protected void collect(Minecraft mc, List<Line> lines, boolean editing) {
			lines.add(new Line("Session", SessionStats.formatDuration(SessionStats.durationMs())));
			lines.add(new Line("Kills", Integer.toString(SessionStats.mobsKilled())));
			lines.add(new Line("Deaths", Integer.toString(SessionStats.deaths()), SessionStats.deaths() > 0 ? Ui.BAD : Ui.TEXT));
			lines.add(new Line("Blocks", Integer.toString(SessionStats.blocksMined())));
			lines.add(new Line("Travelled", SessionStats.formatDistance(SessionStats.distance())));
			lines.add(new Line("XP gained", Integer.toString(SessionStats.xpGained())));
			lines.add(new Line("Items", Integer.toString(SessionStats.itemsPickedUp())));
		}
	}
}
