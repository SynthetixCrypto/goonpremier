package dev.goonclient.client.gui.render;

import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.pipeline.TextureTarget;
import com.mojang.blaze3d.resource.CrossFrameResourcePool;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.renderpearl.api.pipeline.RenderPipeline;
import com.mojang.renderpearl.api.textures.FilterMode;
import dev.goonclient.Goon;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.navigation.ScreenRectangle;
import net.minecraft.client.gui.render.TextureSetup;
import net.minecraft.client.renderer.PostChain;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.state.gui.GuiElementRenderState;
import org.joml.Matrix3x2f;
import java.util.Set;

/** A single frame capture and separable blur, shared by all visible glass panels. No framebuffer readback. */
public final class BackdropBlur {
    private static final CrossFrameResourcePool POOL=new CrossFrameResourcePool(2);
    private static TextureTarget blurred;
    private static boolean requested, failed, captured;
    private static long frames, regions;
    /** Built once: this hook runs every frame, so no Identifier, string or Set is created per frame. */
    private static final net.minecraft.resources.Identifier[] CHAINS=java.util.stream.IntStream.rangeClosed(1,10).mapToObj(n->Goon.id("hud_blur_"+n)).toArray(net.minecraft.resources.Identifier[]::new);
    private static final Set<net.minecraft.resources.Identifier> MAIN_ONLY=Set.of(PostChain.MAIN_TARGET_ID);
    private BackdropBlur() { }

    public static void beginFrame() { requested=false; captured=false; POOL.endFrame(); }

    public static boolean available() { return !failed && Minecraft.getInstance().level!=null && dev.goonclient.client.modules.utility.Interface.blur()>0; }

    private static boolean ensureTarget() {
        var mc=Minecraft.getInstance();
        if(!available())return false;
        RenderTarget source=mc.gameRenderer.mainRenderTarget();
        if(source.width<=0 || source.height<=0)return false;
        if(blurred==null || blurred.width!=source.width || blurred.height!=source.height) {
            if(blurred!=null)blurred.destroyBuffers();
            POOL.clear();
            blurred=new TextureTarget("Goon shared HUD blur",source.width,source.height,source.getColorTexture().getFormat(),null);
        }
        return true;
    }

    /** Called after world/panorama rendering, before native GUI meshes are prepared or submitted. */
    public static void capture() {
        if(!requested || captured || blurred==null || failed)return;
        captured=true;
        var mc=Minecraft.getInstance();
        try {
            blurred.copyColorFrom(mc.gameRenderer.mainRenderTarget());
            PostChain chain=mc.getShaderManager().getPostChain(CHAINS[Math.clamp(dev.goonclient.client.modules.utility.Interface.blur(),1,10)-1],MAIN_ONLY);
            if(chain==null)throw new IllegalStateException("HUD blur post effect unavailable");
            chain.process(blurred,POOL);
            frames++;
            if(frames==1 && Boolean.getBoolean("goonclient.menuPreview"))Goon.LOGGER.info("HUD backdrop blur active: shared {}x{} target",blurred.width,blurred.height);
        } catch(RuntimeException error) {
            // Never take the client down over a cosmetic effect; a failed frame still holds a valid copy.
            failed=true;
            Goon.LOGGER.error("HUD blur disabled after a render failure; using panel tint",error);
        }
    }

    public static void draw(GuiGraphicsExtractor g,float x,float y,float w,float h,float radius,float alpha) {
        draw(g,x,y,w,h,radius,radius,alpha);
    }

    /** Separate radii for the top and bottom corners (0 = square), e.g. the halves of a split panel. */
    public static void draw(GuiGraphicsExtractor g,float x,float y,float w,float h,float radiusTop,float radiusBottom,float alpha) {
        if(alpha<=.001f || w<=0 || h<=0 || !ensureTarget())return;
        int[] rect=Px.rect(g,x,y,x+w,y+h);
        float max=Math.min(rect[2]-rect[0],rect[3]-rect[1])/2f;
        float rt=Math.max(0,Math.min(Px.length(g,radiusTop),max)),rb=Math.max(0,Math.min(Px.length(g,radiusBottom),max));
        if(rect[2]<=rect[0] || rect[3]<=rect[1])return;
        requested=true;regions++;
        Px.begin(g);
        Matrix3x2f pose=new Matrix3x2f(g.pose());
        ScreenRectangle clip=g.scissorStack.peek();
        ScreenRectangle bounds=new ScreenRectangle(rect[0],rect[1],rect[2]-rect[0],rect[3]-rect[1]).transformMaxBounds(pose);
        if(clip!=null)bounds=bounds.intersection(clip);
        if(bounds!=null)g.guiRenderState.addGuiElement(new Panel(pose,rect[0],rect[1],rect[2],rect[3],rt,rb,Math.min(1,alpha),
            blurred.width,blurred.height,TextureSetup.singleTexture(blurred.getColorTextureView(),RenderSystem.getSamplerCache().getClampToEdge(FilterMode.LINEAR)),clip,bounds));
        Px.end(g);
    }

    public static void close() {
        if(blurred!=null){blurred.destroyBuffers();blurred=null;}POOL.close();
        if(Boolean.getBoolean("goonclient.menuPreview"))Goon.LOGGER.info("HUD blur captured {} frames for {} panel regions",frames,regions);
    }

    private static final int ARC_STEPS=8,POINTS_PER_CORNER=ARC_STEPS+1,EDGE_POINTS=4*POINTS_PER_CORNER;
    private static final float[] EDGE_X=new float[EDGE_POINTS],EDGE_Y=new float[EDGE_POINTS];
    static {
        for(int i=0;i<EDGE_POINTS;i++) {
            double angle=Math.PI+(i/POINTS_PER_CORNER*Math.PI/2)+(i%POINTS_PER_CORNER*Math.PI/2/ARC_STEPS);
            EDGE_X[i]=(float)Math.cos(angle);EDGE_Y[i]=(float)Math.sin(angle);
        }
    }

    /** A rounded triangle fan plus a one-pixel alpha fringe, encoded as native GUI quads. */
    private record Panel(Matrix3x2f pose,float left,float top,float right,float bottom,float radiusTop,float radiusBottom,float opacity,
                         int textureWidth,int textureHeight,TextureSetup textureSetup,ScreenRectangle scissorArea,ScreenRectangle bounds) implements GuiElementRenderState {
        @Override public RenderPipeline pipeline(){return RenderPipelines.GUI_TEXTURED;}
        @Override public void buildVertices(VertexConsumer out) {
            float cx=(left+right)/2,cy=(top+bottom)/2;
            int color=(Math.round(255*opacity)<<24)|0xFFFFFF;
            // Unit arc directions are shared: no per-panel trigonometry or temporary edge array.
            for(int i=0;i<EDGE_POINTS;i++) {
                int j=(i+1)%EDGE_POINTS,a=i/POINTS_PER_CORNER,b=j/POINTS_PER_CORNER;
                float ar=a<2?radiusTop:radiusBottom,br=b<2?radiusTop:radiusBottom;
                float ax=a==0||a==3?left+ar:right-ar,ay=a<2?top+ar:bottom-ar;
                float bx=b==0||b==3?left+br:right-br,by=b<2?top+br:bottom-br;
                float ai=Math.max(0,ar-1),bi=Math.max(0,br-1);
                float aix=ax+EDGE_X[i]*ai,aiy=ay+EDGE_Y[i]*ai;
                float bix=bx+EDGE_X[j]*bi,biy=by+EDGE_Y[j]*bi;
                vertex(out,cx,cy,color);vertex(out,bix,biy,color);vertex(out,aix,aiy,color);vertex(out,cx,cy,color);
                vertex(out,aix,aiy,color);vertex(out,bix,biy,color);
                vertex(out,bx+EDGE_X[j]*br,by+EDGE_Y[j]*br,0xFFFFFF);
                vertex(out,ax+EDGE_X[i]*ar,ay+EDGE_Y[i]*ar,0xFFFFFF);
            }
        }

        private void vertex(VertexConsumer out,float x,float y,int color){
            out.addVertexWith2DPose(pose,x,y).setUv(x/textureWidth,1-y/textureHeight).setColor(color);
        }
    }
}
