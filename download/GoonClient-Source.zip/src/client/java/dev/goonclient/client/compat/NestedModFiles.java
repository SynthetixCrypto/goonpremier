package dev.goonclient.client.compat;

import java.io.IOException;
import java.net.JarURLConnection;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Optional;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;
import net.fabricmc.loader.api.metadata.ModOrigin;

/**
 * Xaero's mods find their own jar through {@code ModOrigin.getPaths()}, which only works for jars sitting in the mods
 * folder. Goon Client embeds them, so Fabric reports a NESTED origin and Xaero gets null and crashes on startup. This
 * finds the archive Fabric actually loaded the nested jar from (its cached copy), never the enclosing Goon jar.
 */
public final class NestedModFiles {
	private NestedModFiles() {
	}

	/** The loaded archive of a nested mod, or empty if the mod isn't nested (let the mod's own code handle it). */
	public static Optional<Path> locate(String modId) {
		ModContainer container = FabricLoader.getInstance().getModContainer(modId).orElse(null);
		if (container == null || container.getOrigin().getKind() != ModOrigin.Kind.NESTED) {
			return Optional.empty();
		}
		for (Path root : container.getRootPaths()) {
			try {
				var uri = root.toUri();
				Path source;
				if ("jar".equalsIgnoreCase(uri.getScheme())) {
					var archive = ((JarURLConnection) uri.toURL().openConnection()).getJarFileURL();
					if (!"file".equalsIgnoreCase(archive.getProtocol())) {
						continue;
					}
					source = Path.of(archive.toURI());
				} else if ("file".equalsIgnoreCase(uri.getScheme())) {
					source = root;
				} else {
					continue;
				}
				if (source.getFileName() != null && Files.exists(source)) {
					return Optional.of(source);
				}
			} catch (IOException | URISyntaxException | IllegalArgumentException | ClassCastException ignored) {
				// A container can expose several roots; try the next local archive
			}
		}
		throw new IllegalStateException("Couldn't find the bundled " + modId + " archive. Repair Goon Client from the launcher.");
	}
}
