package dev.goonclient.client.gui;

import com.mojang.blaze3d.platform.InputConstants;
import dev.goonclient.client.expedition.*;
import dev.goonclient.client.gui.render.GoonFont;
import dev.goonclient.client.gui.render.Shapes;
import dev.goonclient.client.modules.inventory.ExpeditionPlanner;
import dev.goonclient.client.waypoint.*;
import java.util.*;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.*;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

/** Local trip sheet in the companion screens' glass material. Editing works from the main menu. */
public final class ExpeditionScreen extends Screen implements GoonScreen {
    private record Hit(String key, float x1, float y1, float x2, float y2, Runnable action) {}
    private final Screen parent;
    private final ExpeditionStore store;
    private final List<Hit> hits = new ArrayList<>();
    private final Map<String, String> itemNames = new HashMap<>();
    private ExpeditionPlan draft, saved;
    private ExpeditionInventory.Snapshot stock = new ExpeditionInventory.Snapshot(false, Map.of());
    private String name = "", entry = "", field = "", focus = "", status = "", armed = "";
    private long armedAt;
    private boolean taskMode, picking;
    private Runnable pending;
    private float scale, x, y, w, h, split, top, bottom, scroll, planScroll;

    public ExpeditionScreen(Screen parent) { this(parent, ExpeditionPlanner.store(), false); }
    public ExpeditionScreen(Screen parent, ExpeditionStore store, boolean clear) {
        super(Component.literal("Expedition planner"));
        this.parent = parent;
        this.store = store;
        if (!store.plans().isEmpty()) load(store.plans().getFirst());
        else newPlan(ExpeditionPlan.Template.EXPLORATION);
        if (clear) { armed = "all"; armedAt = System.currentTimeMillis(); status = "Clear all saved plans? Choose Confirm clear below."; }
    }

    @Override protected void init() {
        GlassUi.hideHud(minecraft);
        scale = Math.max(.01f, Math.min(Ui.menuScale(width, height), Math.min(width / 730f, height / 470f)));
        w = 700; h = 440; x = (width / scale - w) / 2; y = (height / scale - h) / 2;
        split = x + 190; top = y + 173; bottom = y + h - 101;
    }

    @Override public void tick() { stock = ExpeditionInventory.capture(minecraft); }
    private boolean dirty() { return saved == null || !draft.equals(saved) || !name.equals(saved.name()); }
    private void load(ExpeditionPlan plan) {
        draft = saved = plan; name = plan.name(); entry = ""; scroll = 0; field = ""; picking = false;
        armed = ""; armedAt = 0;
    }
    private void newPlan(ExpeditionPlan.Template template) {
        draft = ExpeditionPlan.starter(template); saved = null;
        String base = template.label; name = base;
        for (int n = 2; nameUsed(name); n++) name = base + " " + n;
        entry = ""; scroll = 0; field = ""; picking = false;
        armed = ""; armedAt = 0;
    }
    private boolean nameUsed(String value) { return store.plans().stream().anyMatch(p -> p.name().equalsIgnoreCase(value)); }
    private void selectPlan(String id) {
        if (draft.id().equals(id)) { pending = null; return; }
        // Deferred navigation must resolve after Save, rather than capture an obsolete list snapshot.
        guard(() -> store.plans().stream().filter(plan -> plan.id().equals(id)).findFirst().ifPresent(this::load));
    }
    private void deleteSelected() {
        if (saved == null) return;
        String id = saved.id();
        guard(() -> confirm("delete:" + id, () -> {
            if (saved == null || !saved.id().equals(id)) return;
            if (store.remove(id)) {
                if (store.plans().isEmpty()) newPlan(ExpeditionPlan.Template.EXPLORATION);
                else load(store.plans().getFirst());
                status = "Saved plan deleted.";
            }
        }));
    }
    private void clearSavedPlans() {
        confirm("all", () -> {
            if (store.clear()) {
                pending = null;
                saved = null;
                status = "Saved plans cleared. Current draft kept; Save to keep it.";
            }
        });
    }
    private void guard(Runnable action) {
        if (dirty()) { pending = action; status = "Unsaved changes. Save to continue, or choose Discard."; }
        else { pending = null; action.run(); }
    }
    private void discard() {
        Runnable next = pending; pending = null;
        if (saved != null) load(saved); else if (!store.plans().isEmpty()) load(store.plans().getFirst());
        else newPlan(ExpeditionPlan.Template.EXPLORATION);
        status = "Draft discarded.";
        if (next != null) next.run();
    }
    private void save() {
        try {
            ExpeditionPlan next = new ExpeditionPlan(draft.id(), name, draft.supplies(), draft.tasks(), draft.destination());
            if (!store.save(next)) { status = store.error(); return; }
            draft = saved = next; name = next.name(); status = "Plan saved on this device.";
            Runnable action = pending; pending = null;
            if (action != null) action.run();
        } catch (IllegalArgumentException e) { status = e.getMessage(); }
    }
    private void change(List<ExpeditionPlan.Supply> supplies, List<ExpeditionPlan.Task> tasks, ExpeditionPlan.Destination destination) {
        try { draft = new ExpeditionPlan(draft.id(), draft.name(), supplies, tasks, destination); }
        catch (IllegalArgumentException e) { status = e.getMessage(); }
    }
    private void addEntry() {
        try {
            if (taskMode) {
                var tasks = new ArrayList<>(draft.tasks()); tasks.add(new ExpeditionPlan.Task(entry, false));
                draft = new ExpeditionPlan(draft.id(), draft.name(), draft.supplies(), tasks, draft.destination());
            } else {
                String[] parts = entry.strip().split("\\s+");
                if (parts.length != 2) throw new IllegalArgumentException("Enter an item ID and count, for example minecraft:torch 64.");
                String id = parts[0].contains(":") ? parts[0] : "minecraft:" + parts[0];
                Identifier key = Identifier.tryParse(id);
                if (key == null || BuiltInRegistries.ITEM.getOptional(key).isEmpty() || id.equals("minecraft:air"))
                    throw new IllegalArgumentException("Unknown item ID. Example: minecraft:torch 64.");
                var supply = new ExpeditionPlan.Supply(id, Integer.parseInt(parts[1]));
                var supplies = new ArrayList<>(draft.supplies());
                int at = -1;
                for (int i = 0; i < supplies.size(); i++) if (supplies.get(i).item().equals(id)) at = i;
                if (at >= 0) supplies.set(at, supply); else supplies.add(supply);
                draft = new ExpeditionPlan(draft.id(), draft.name(), supplies, draft.tasks(), draft.destination());
            }
            entry = ""; status = "Checklist updated. Save to keep your changes.";
            scroll = Float.MAX_VALUE;
        } catch (IllegalArgumentException e) { status = e instanceof NumberFormatException ? "Count must be a whole number from 1 to 4096." : e.getMessage(); }
    }
    private void adjust(int index, int delta) {
        var supplies = new ArrayList<>(draft.supplies()); var old = supplies.get(index);
        supplies.set(index, new ExpeditionPlan.Supply(old.item(), Math.clamp(old.target() + delta, 1, 4096)));
        change(supplies, draft.tasks(), draft.destination());
    }
    private void removeSupply(int index) { var rows = new ArrayList<>(draft.supplies()); rows.remove(index); change(rows, draft.tasks(), draft.destination()); }
    private void removeTask(int index) { var rows = new ArrayList<>(draft.tasks()); rows.remove(index); change(draft.supplies(), rows, draft.destination()); }
    private void toggleTask(int index) {
        var rows = new ArrayList<>(draft.tasks()); var task = rows.get(index);
        rows.set(index, new ExpeditionPlan.Task(task.label(), !task.done())); change(draft.supplies(), rows, draft.destination());
    }
    private void confirm(String action, Runnable run) {
        if (armed.equals(action) && System.currentTimeMillis() - armedAt < 10_000) { armed = ""; run.run(); }
        else { armed = action; armedAt = System.currentTimeMillis(); status = "Choose Confirm again within 10 seconds. This removes saved plans."; }
    }
    private String itemName(String id) {
        return itemNames.computeIfAbsent(id, key -> BuiltInRegistries.ITEM.getOptional(Identifier.parse(key))
                .map(item -> item.getName(item.getDefaultInstance()).getString()).orElse(key));
    }
    private static void text(GuiGraphicsExtractor g, String value, float x, float y, float size, boolean bold, int color) {
        GoonFont.draw(g, value, x, y, size, bold ? GoonFont.Weight.BOLD : GoonFont.Weight.REGULAR,
                color == Ui.MUTED ? GlassUi.LABEL : color, false);
    }
    private static String fit(String value, float width, float size) { return Ui.ellipsize(value, width, size, GoonFont.Weight.REGULAR); }
    private void hit(String key, float bx, float by, float bw, float bh, Runnable action) { hits.add(new Hit(key,bx,by,bx+bw,by+bh,action)); }
    private void button(GuiGraphicsExtractor g, String key, String label, float bx, float by, float bw, int mx, int my, boolean enabled, Runnable action) {
        boolean hover = enabled && Ui.inside(mx,my,bx,by,bx+bw,by+24);
        Shapes.panel(g,bx,by,bx+bw,by+24,5,hover ? Ui.RAISED_HOVER : Ui.RAISED,Ui.BORDER);
        String shown = fit(label,bw-10,8);
        text(g,shown,bx+(bw-GoonFont.width(shown,8,GoonFont.Weight.REGULAR))/2,by+8,8,false,enabled ? Ui.TEXT : Ui.FAINT);
        if (enabled) hit(key,bx,by,bw,24,() -> { field = ""; action.run(); });
    }
    private void input(GuiGraphicsExtractor g, String key, String value, String hint, float bx, float by, float bw) {
        Shapes.panel(g,bx,by,bx+bw,by+24,5,Ui.FIELD,field.equals(key) ? Ui.accent() : Ui.BORDER);
        // Show the tail while typing; the caret always corresponds to the editing position.
        String shown = value.isEmpty() ? hint : value;
        if (field.equals(key)) while (shown.length() > 1 && GoonFont.width(shown,8,GoonFont.Weight.REGULAR) > bw-20)
            shown = shown.substring(shown.offsetByCodePoints(0,1));
        else shown = fit(shown,bw-16,8);
        text(g,shown,bx+7,by+8,8,false,value.isEmpty() ? Ui.MUTED : Ui.TEXT);
        if (field.equals(key) && (System.currentTimeMillis()/530)%2 == 0) {
            float cx = bx+7+(value.isEmpty() ? 0 : GoonFont.width(shown,8,GoonFont.Weight.REGULAR));
            Shapes.rect(g,cx,by+5,cx+.7f,by+19,Ui.accent());
        }
        hit(key,bx,by,bw,24,() -> field=key);
    }

    @Override public void extractRenderState(GuiGraphicsExtractor g, int realX, int realY, float dt) {
        hits.clear(); int mx = (int)(realX/scale), my = (int)(realY/scale);
        if (!armed.isEmpty() && System.currentTimeMillis()-armedAt >= 10_000) armed="";
        g.pose().pushMatrix(); g.pose().scale(scale,scale); GlassUi.panel(g,x,y,w,h,1);
        text(g,"Expedition planner",x+18,y+17,15,true,Ui.TEXT);
        button(g,"done","Done",x+w-70,y+15,52,mx,my,true,this::onClose);
        text(g,"Local trip sheets · "+store.plans().size()+" / 32 saved",x+18,y+42,8,false,Ui.MUTED);
        Shapes.rect(g,split,y+64,split+.5f,y+h-45,Ui.BORDER);
        text(g,"Start a packing list",x+18,y+66,9,true,Ui.TEXT);
        int ti=0;
        for (var template : ExpeditionPlan.Template.values()) {
            button(g,"new-"+template.name(),template.label,x+18,y+84+ti++*29,155,mx,my,true,() -> guard(() -> newPlan(template)));
        }
        text(g,"Saved plans",x+18,y+182,9,true,Ui.TEXT);
        float pt=y+202,pb=y+h-108;
        planScroll=Math.clamp(planScroll,0,Math.max(0,store.plans().size()*29-(pb-pt)));
        g.enableScissor((int)(x+17),(int)pt,(int)(split-12),(int)pb);
        for (int i=0;i<store.plans().size();i++) {
            var plan=store.plans().get(i); float py=pt+i*29-planScroll;
            if (py<pt || py+25>pb) continue;
            if (plan.id().equals(draft.id())) Shapes.roundRect(g,x+18,py,split-17,py+25,5,Ui.withAlpha(Ui.accent(),.16f));
            button(g,"plan-"+plan.id(),plan.name(),x+18,py,155,mx,my,true,() -> selectPlan(plan.id()));
        }
        if(store.plans().isEmpty()) text(g,"Save a plan to reuse it here.",x+21,pt+9,7.5f,false,Ui.MUTED);
        g.disableScissor(); scrollbar(g,split-11,planScroll,Math.max(0,store.plans().size()*29-(pb-pt)),pt,pb);
        button(g,"delete",saved!=null&&armed.equals("delete:"+saved.id())?"Confirm delete":"Delete saved plan",x+18,y+h-94,155,mx,my,saved!=null&&store.writable(),this::deleteSelected);
        button(g,"clear",armed.equals("all")?"Confirm clear":"Clear all saved plans",x+18,y+h-65,155,mx,my,!store.plans().isEmpty()&&store.writable(),
                this::clearSavedPlans);
        float dx=split+16,dw=x+w-18-dx;
        input(g,"name",name,"Plan name",dx,y+65,dw-136);
        button(g,"save",dirty()?"Save *":"Saved",dx+dw-130,y+65,62,mx,my,store.writable(),this::save);
        button(g,"discard","Discard",dx+dw-62,y+65,62,mx,my,dirty()||pending!=null,this::discard);
        button(g,"destination",picking?"Back to list":"Choose waypoint",dx,y+98,116,mx,my,true,() -> {picking=!picking;scroll=0;});
        button(g,"unlink","Unlink",dx+121,y+98,52,mx,my,draft.destination()!=null,() -> change(draft.supplies(),draft.tasks(),null));
        var destination=draft.destination();
        text(g,destination==null?"No destination selected":fit(destination.name(),dw-182,8),dx+181,y+106,8,false,Ui.TEXT);
        String destNote=destination==null?"Waypoints come from the current world. Selection stores a local snapshot.":
                destination.x()+" "+destination.y()+" "+destination.z()+" · "+destination.dimension()+
                (destination.world().equals(WaypointManager.worldKey())?" · saved location":" · from another world");
        text(g,fit(destNote,dw,7.5f),dx,y+132,7.5f,false,Ui.MUTED);
        long ready=draft.supplies().stream().filter(r -> stock.available()&&stock.count(r.item())>=r.target()).count()+draft.tasks().stream().filter(ExpeditionPlan.Task::done).count();
        text(g,picking?"Select a destination waypoint":(stock.available()?ready+" / "+(draft.supplies().size()+draft.tasks().size())+" checks ready · carried inventory live":"Preview · join a world for inventory counts"),dx,y+153,8.5f,true,Ui.TEXT);
        if(picking) drawWaypoints(g,dx,dw,mx,my); else drawRows(g,dx,dw,mx,my);
        button(g,"mode",taskMode?"Manual task":"Item + count",dx,y+h-90,85,mx,my,true,() -> {taskMode=!taskMode;entry="";});
        input(g,"entry",entry,taskMode?"Add a manual check":"minecraft:torch 64 (add or update)",dx+91,y+h-90,dw-143);
        button(g,"add","Add",dx+dw-46,y+h-90,46,mx,my,!entry.isBlank(),this::addEntry);
        button(g,"reset","Reset ticks",dx,y+h-60,85,mx,my,draft.tasks().stream().anyMatch(ExpeditionPlan.Task::done),
                () -> change(draft.supplies(),draft.tasks().stream().map(t -> new ExpeditionPlan.Task(t.label(),false)).toList(),draft.destination()));
        button(g,"reload","Re-read",dx+91,y+h-60,65,mx,my,true,() -> guard(() -> {store.reload();status=store.error().isEmpty()?"Saved plans re-read.":store.error();if(store.writable()){if(store.plans().isEmpty())newPlan(ExpeditionPlan.Template.EXPLORATION);else load(store.plans().getFirst());}}));
        text(g,"Exact items · hotbar, inventory, offhand + armor",dx+164,y+h-52,7.4f,false,Ui.MUTED);
        String note=!store.error().isEmpty()?store.error():status.isEmpty()?"Starter lists are editable suggestions. Bags, cursor and chest contents are excluded. Tab / Enter to navigate.":status;
        text(g,fit(note,w-36,7.5f),x+18,y+h-25,7.5f,false,!store.error().isEmpty()?Ui.WARN:Ui.MUTED);
        hits.stream().filter(hit -> hit.key().equals(focus)).findFirst().ifPresent(hit -> Shapes.outline(g,hit.x1()-1,hit.y1()-1,hit.x2()+1,hit.y2()+1,5,Ui.accent()));
        g.pose().popMatrix(); super.extractRenderState(g,realX,realY,dt);
    }

    private void drawRows(GuiGraphicsExtractor g,float dx,float dw,int mx,int my) {
        int total=draft.supplies().size()+draft.tasks().size();float max=Math.max(0,total*30-(bottom-top));scroll=Math.clamp(scroll,0,max);
        g.enableScissor((int)dx,(int)top,(int)(dx+dw),(int)bottom);
        for(int i=0;i<total;i++) {
            float ry=top+i*30-scroll;if(ry<top||ry+26>bottom)continue;
            Shapes.rect(g,dx,ry+28,dx+dw,ry+28.5f,Ui.BORDER);
            if(i<draft.supplies().size()) {
                final int index=i;var row=draft.supplies().get(i);int count=stock.count(row.item());
                text(g,fit(itemName(row.item()),dw-235,8.5f),dx+2,ry+3,8.5f,false,Ui.TEXT);
                text(g,fit(row.item(),dw-235,6.8f),dx+2,ry+16,6.8f,false,Ui.MUTED);
                text(g,stock.available()?count+" / "+row.target()+" · "+(count>=row.target()?"ready":"need "+(row.target()-count)):"-- / "+row.target()+" · unavailable",dx+dw-225,ry+10,7.6f,false,stock.available()&&count>=row.target()?Ui.GOOD:Ui.MUTED);
                button(g,"minus-"+i,"-",dx+dw-78,ry,22,mx,my,true,() -> adjust(index,-1));
                button(g,"plus-"+i,"+",dx+dw-52,ry,22,mx,my,true,() -> adjust(index,1));
                button(g,"remove-"+i,"x",dx+dw-26,ry,22,mx,my,true,() -> removeSupply(index));
            } else {
                final int index=i-draft.supplies().size();var task=draft.tasks().get(index);
                button(g,"task-"+index,task.done()?"Done":"Check",dx,ry,45,mx,my,true,() -> toggleTask(index));
                text(g,fit(task.label(),dw-85,8),dx+53,ry+9,8,false,task.done()?Ui.GOOD:Ui.TEXT);
                button(g,"remove-task-"+index,"x",dx+dw-26,ry,22,mx,my,true,() -> removeTask(index));
            }
        }
        if(total==0)text(g,"Add an item target or a manual task below.",dx+2,top+12,8,false,Ui.MUTED);
        g.disableScissor();scrollbar(g,dx+dw+3,scroll,max,top,bottom);
    }
    private void drawWaypoints(GuiGraphicsExtractor g,float dx,float dw,int mx,int my) {
        var points=WaypointManager.worldKey()==null?List.<Waypoint>of():List.copyOf(WaypointManager.all());
        scroll=Math.clamp(scroll,0,Math.max(0,points.size()*35-(bottom-top)));
        g.enableScissor((int)dx,(int)top,(int)(dx+dw),(int)bottom);
        for(int i=0;i<points.size();i++) {
            var point=points.get(i);float py=top+i*35-scroll;if(py<top||py+25>bottom)continue;
            String world=WaypointManager.worldKey();
            button(g,"waypoint-"+i,point.name()+" · "+point.x()+" "+point.y()+" "+point.z()+" · "+point.dimension(),dx,py,dw-5,mx,my,true,() -> {
                if(!Objects.equals(world,WaypointManager.worldKey())){status="World changed. Choose the destination again.";return;}
                try {change(draft.supplies(),draft.tasks(),new ExpeditionPlan.Destination(world,point.name(),point.dimension(),point.x(),point.y(),point.z()));picking=false;scroll=0;status="Destination snapshot added. Save to keep it.";}
                catch(IllegalArgumentException e){status=e.getMessage();}
            });
        }
        if(points.isEmpty())text(g,"Join a world with saved waypoints. Add one with /wp add <name>.",dx+2,top+12,8,false,Ui.MUTED);
        g.disableScissor();scrollbar(g,dx+dw+3,scroll,Math.max(0,points.size()*35-(bottom-top)),top,bottom);
    }
    private static void scrollbar(GuiGraphicsExtractor g,float x,float scroll,float max,float top,float bottom) {
        if(max<=0)return;float height=bottom-top,thumb=Math.max(16,height*height/(height+max));float yy=top+(height-thumb)*scroll/max;
        Shapes.roundRect(g,x,yy,x+2,yy+thumb,1,Ui.BORDER_STRONG);
    }
    @Override public boolean mouseClicked(MouseButtonEvent event,boolean twice) {
        if(event.button()!=InputConstants.MOUSE_BUTTON_LEFT)return true;
        for(var hit:List.copyOf(hits))if(Ui.inside(event.x()/scale,event.y()/scale,hit.x1(),hit.y1(),hit.x2(),hit.y2())){focus=hit.key();hit.action().run();return true;}
        field="";return true;
    }
    @Override public boolean mouseScrolled(double mx,double my,double dx,double dy) {
        mx/=scale;my/=scale;
        if(Ui.inside(mx,my,split+16,top,x+w-18,bottom)){scroll=Math.max(0,scroll-(float)dy*30);focus="";return true;}
        if(Ui.inside(mx,my,x+18,y+202,split-12,y+h-108)){planScroll=Math.max(0,planScroll-(float)dy*29);focus="";return true;}
        return false;
    }
    private void append(String value) {
        int max=field.equals("name")?48:taskMode?96:140;
        String current=field.equals("name")?name:entry;
        String clean=value.codePoints().filter(c -> !Character.isISOControl(c)&&Character.getType(c)!=Character.SURROGATE)
                .collect(StringBuilder::new,StringBuilder::appendCodePoint,StringBuilder::append).toString();
        int room=max-current.length();if(clean.length()>room){int end=room;if(end>0&&Character.isHighSurrogate(clean.charAt(end-1)))end--;clean=clean.substring(0,end);}
        if(field.equals("name"))name=current+clean;else entry=current+clean;
    }
    @Override public boolean charTyped(CharacterEvent event) {
        if(!field.isEmpty()&&event.isAllowedChatCharacter()){append(event.codepointAsString());return true;}return super.charTyped(event);
    }
    @Override public boolean keyPressed(KeyEvent event) {
        if(event.key()==InputConstants.KEY_ESCAPE){if(picking){picking=false;scroll=0;}else if(!field.isEmpty())field="";else onClose();return true;}
        if(event.hasControlDown()&&event.key()==InputConstants.KEY_S){save();return true;}
        if(event.key()==InputConstants.KEY_TAB&&!hits.isEmpty()) {
            int at=-1;for(int i=0;i<hits.size();i++)if(hits.get(i).key().equals(focus))at=i;
            at=Math.floorMod(at+(event.hasShiftDown()?-1:1),hits.size());focus=hits.get(at).key();
            field=focus.equals("name")||focus.equals("entry")?focus:"";return true;
        }
        if(event.key()==InputConstants.KEY_RETURN) {
            if(field.equals("entry"))addEntry();else if(field.equals("name"))save();else hits.stream().filter(hit -> hit.key().equals(focus)).findFirst().ifPresent(hit -> hit.action().run());return true;
        }
        if(!field.isEmpty()&&event.hasControlDown()&&event.key()==InputConstants.KEY_V){append(minecraft.keyboardHandler.getClipboard());return true;}
        if(!field.isEmpty()&&event.key()==InputConstants.KEY_BACKSPACE) {
            String value=field.equals("name")?name:entry;value=event.hasControlDown()?"":value.isEmpty()?"":value.substring(0,value.offsetByCodePoints(value.length(),-1));
            if(field.equals("name"))name=value;else entry=value;return true;
        }
        if(field.isEmpty()&&(event.key()==InputConstants.KEY_UP||event.key()==InputConstants.KEY_DOWN)){scroll=Math.max(0,scroll+(event.key()==InputConstants.KEY_UP?-30:30));focus="";return true;}
        return super.keyPressed(event);
    }
    @Override public void removed(){GlassUi.restoreHud(minecraft);}
    @Override public void onClose(){guard(() -> minecraft.gui.setScreen(parent));}
    @Override public boolean isPauseScreen(){return false;}
}
