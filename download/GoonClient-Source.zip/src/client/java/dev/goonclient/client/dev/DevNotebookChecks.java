package dev.goonclient.client.dev;

import com.mojang.blaze3d.platform.InputConstants;
import dev.goonclient.Goon;
import dev.goonclient.client.gui.PerformanceNotebookScreen;
import dev.goonclient.client.tracker.NotebookCapture;
import dev.goonclient.client.tracker.PerformanceNotebook;
import java.lang.reflect.Field;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.input.MouseButtonInfo;

/** Opt-in, development-only real-render tour. Requires the wrapper's disposable game directory. */
public final class DevNotebookChecks {
    private static int step, originalScale, pausedSamples, exports;
    private static boolean failed, originalHud, completionFocusArmed;
    private static long next, began, captureBegan, progressAt;
    private static PerformanceNotebook.Snapshot retained;
    private static Screen parent;
    private DevNotebookChecks() {}
    public static void init() {
        if (Boolean.getBoolean("goonclient.notebookChecks") && FabricLoader.getInstance().isDevelopmentEnvironment())
            ClientTickEvents.END_CLIENT_TICK.register(DevNotebookChecks::tick);
    }
    private static void require(boolean condition, String message) { if (!condition) throw new IllegalStateException(message); }
    private static Object field(Object object, String name) throws Exception {
        Field f = object.getClass().getDeclaredField(name); f.setAccessible(true); return f.get(object);
    }
    private static void later(int to, long milliseconds) { step = to; next = System.nanoTime() + milliseconds * 1_000_000L; }
    private static void open(Minecraft mc) { mc.gui.setScreen(new PerformanceNotebookScreen(mc.level == null ? parent : null)); }
    private static void key(Minecraft mc, int key) { mc.gui.screen().keyPressed(new KeyEvent(key, 0, 0)); }
    /** Real input dispatch at the rendered button centre, including the disabled-button check. */
    private static void click(Minecraft mc, int column) throws Exception {
        var screen = (PerformanceNotebookScreen)mc.gui.screen();
        float s = (float)field(screen, "s"), x = (float)field(screen, "x"), y = (float)field(screen, "y");
        float w = (float)field(screen, "w"), h = (float)field(screen, "h"), bw = (w - 51) / 4;
        screen.mouseClicked(new MouseButtonEvent((x + 18 + column * (bw + 5) + bw / 2) * s,
            (y + h - 53) * s, new MouseButtonInfo(InputConstants.MOUSE_BUTTON_LEFT, 0)), false);
    }
    private static void shot(Minecraft mc, String name) {
        Screenshot.grab(mc.gameDirectory, "goon-notebook-" + name + ".png", mc.gameRenderer.mainRenderTarget(), 1, message -> {});
    }
    /** Actual callback Mixins, followed by one explicit core frame to prove the next endpoint only anchors. */
    private static void eventBoundaries(Minecraft mc) throws Exception {
        Field captureField = PerformanceNotebook.class.getDeclaredField("capture"); captureField.setAccessible(true);
        var capture = (NotebookCapture)captureField.get(null);
        require((boolean)field(capture, "anchored"), "No real frame anchor before boundary probes");
        int before = capture.count();
        var onFocus = mc.getWindow().getClass().getDeclaredMethod("onFocus", boolean.class); onFocus.setAccessible(true);
        boolean focused = mc.getWindow().isFocused();
        try { onFocus.invoke(mc.getWindow(), false); onFocus.invoke(mc.getWindow(), true); }
        finally { onFocus.invoke(mc.getWindow(), focused); }
        require(!(boolean)field(capture, "anchored"), "Focus loss/regain in one tick did not invalidate anchor (Mixin absent)");
        capture.frame(System.nanoTime(), true, true);
        require(capture.count() == before && (boolean)field(capture, "anchored"), "Next focus endpoint bridged excluded interval");
        open(mc); mc.gui.setScreen(null);
        require(!(boolean)field(capture, "anchored"), "Screen open/close in one tick did not invalidate anchor (Mixin absent)");
        capture.frame(System.nanoTime(), true, true);
        require(capture.count() == before && (boolean)field(capture, "anchored"), "Next screen endpoint bridged excluded interval");
        require(!mc.gui.hud.isHidden(), "Same-tick screen probe did not restore HUD");
        Goon.LOGGER.info("NOTEBOOK CHECK: actual focus callback + Gui screen Mixins invalidate same-tick loss/regain/open/close; both next anchors dropped, original focus restored={}", focused);
    }
    private static void verifyExport() throws Exception {
        var expected = PerformanceNotebook.snapshot();
        List<Path> csv;
        try (var paths = Files.list(PerformanceNotebook.folder())) { csv = paths.filter(p -> p.toString().endsWith(".csv")).sorted().toList(); }
        require(csv.size() == ++exports, "Export click did not produce exactly one new CSV");
        Path last = csv.getLast();
        String text = Files.readString(last);
        require(text.lines().count() == expected.result().samples() + 1L, "CSV sample count mismatch");
        require(text.equals(PerformanceNotebook.csv(expected)), "CSV differs from immutable reviewed samples");
        Path summary = last.resolveSibling(last.getFileName().toString().replace(".csv", ".md"));
        require(Files.readString(summary).equals(PerformanceNotebook.summary(expected)), "Summary differs from reviewed result");
        Goon.LOGGER.info("NOTEBOOK CHECK: export {} rows={} active={} s", exports, expected.result().samples(), expected.result().activeSeconds());
    }
    private static void tick(Minecraft mc) {
        if (failed || !mc.isGameLoadFinished()) return;
        long now = System.nanoTime();
        if (began == 0) began = now;
        try {
            require(now - began < 240_000_000_000L, "Tour timed out (focus, loading or export may be stalled)");
            if (now < next) return;
            if (mc.gui.screen() instanceof PerformanceNotebookScreen screen && ((List<?>)field(screen, "hits")).isEmpty()) return;
            next = now + 100_000_000L;
            mc.getFramerateLimitTracker().onInputReceived();
            switch (step) {
                case 0 -> {
                    if (mc.level == null || mc.player == null || mc.gui.overlay() != null) return;
                    require(mc.getSingleplayerServer() != null, "Use a disposable singleplayer world");
                    String scratch = System.getProperty("goonclient.notebookScratch", "");
                    require(!scratch.isBlank() && mc.gameDirectory.toPath().toRealPath().equals(Path.of(scratch).toRealPath()), "Wrapper scratch-directory guard failed");
                    require(!Files.exists(PerformanceNotebook.folder()), "Use a fresh runtime with no reports");
                    originalScale = mc.options.guiScale().get(); originalHud = mc.gui.hud.isHidden();
                    if (originalHud) mc.gui.hud.toggle();
                    mc.options.guiScale().set(2); mc.resizeGui(); open(mc); later(1, 1000);
                }
                case 1 -> {
                    require(mc.gui.hud.isHidden(), "Notebook did not hide visible HUD"); click(mc, 0);
                    require(PerformanceNotebook.running() && mc.gui.screen() == null && !mc.gui.hud.isHidden(), "Start click / HUD restore failed");
                    captureBegan = now; progressAt = now;
                    Goon.LOGGER.info("NOTEBOOK CHECK: real 60-second capture started; default production deadline unchanged"); later(2, 100);
                }
                case 2 -> {
                    if (PerformanceNotebook.running() && now-captureBegan >= 58_000_000_000L && !completionFocusArmed) {
                        open(mc); completionFocusArmed = true; later(20, 600); return;
                    }
                    if (now - progressAt >= 10_000_000_000L) {
                        Goon.LOGGER.info("NOTEBOOK CHECK: real capture wall={} active={} samples={} focused={}", (now-captureBegan)/1e9, PerformanceNotebook.activeSeconds(), PerformanceNotebook.samples(), mc.isWindowActive()); progressAt = now;
                    }
                    if (PerformanceNotebook.running()) { require(now-captureBegan < 75_000_000_000L, "Actual Mixin failed to finish capture at 60 s"); return; }
                    var r = PerformanceNotebook.snapshot().result();
                    require(r.stop() == NotebookCapture.Stop.COMPLETE && r.elapsedSeconds() == 60 && now-captureBegan >= 59_900_000_000L, "Real deadline / completion reason mismatch");
                    require(r.activeSeconds() >= 5 && r.samples() >= 120 && !r.provisional(), "Insufficient real render samples (window must be focused)");
                    Goon.LOGGER.info("NOTEBOOK CHECK: real COMPLETE wall=60 active={} samples={} p95={} p99={} max={}", r.activeSeconds(), r.samples(), r.p95Ms(), r.p99Ms(), r.maxMs());
                    if (!completionFocusArmed) open(mc); later(3, 800);
                }
                case 20 -> {
                    key(mc, InputConstants.KEY_TAB); key(mc, InputConstants.KEY_TAB);
                    require(field(mc.gui.screen(), "focus").toString().equals("CANCEL"), "Cancel was not focused before completion"); later(2, 100);
                }
                case 3 -> {
                    key(mc, InputConstants.KEY_RETURN);
                    require(!PerformanceNotebook.running() && mc.gui.screen() instanceof PerformanceNotebookScreen, "Focused Cancel changed to Start when capture finished");
                    require(field(mc.gui.screen(), "focus").toString().equals("CANCEL"), "Disabled Cancel focus lost its identity");
                    shot(mc, "complete-scale2"); click(mc, 2); later(4, 300);
                }
                case 4 -> {
                    if ((boolean)field(mc.gui.screen(), "working")) return;
                    require(!(boolean)field(mc.gui.screen(), "error"), "Export worker reported failure"); verifyExport();
                    mc.options.guiScale().set(4); mc.resizeGui(); later(5, 800);
                }
                case 5 -> { shot(mc, "complete-scale4"); key(mc, InputConstants.KEY_ESCAPE); require(mc.gui.screen() == null && !mc.gui.hud.isHidden(), "Escape/HUD restore failed"); open(mc); later(6, 600); }
                case 6 -> { click(mc, 0); require(PerformanceNotebook.running(), "Second start click failed"); later(7, 100); }
                case 7 -> {
                    if (PerformanceNotebook.activeSeconds() < 5) return;
                    eventBoundaries(mc);
                    mc.gui.setScreen(new PauseScreen(true)); later(8, 1000);
                }
                case 8 -> { require(mc.isPaused(), "Integrated world did not pause"); pausedSamples = PerformanceNotebook.samples(); later(9, 2000); }
                case 9 -> { require(PerformanceNotebook.samples() == pausedSamples, "Paused menu added frame samples"); mc.gui.setScreen(null); later(10, 700); }
                case 10 -> { open(mc); later(11, 600); }
                case 11 -> {
                    click(mc, 1); retained = PerformanceNotebook.snapshot();
                    require(retained.result().stop() == NotebookCapture.Stop.CANCELLED && retained.result().early() && retained.result().activeSeconds() >= 5, "Real >=5 s cancel did not preserve metrics");
                    later(21, 600);
                }
                case 21 -> { shot(mc, "cancel-scale4"); click(mc, 2); later(12, 300); }
                case 12 -> {
                    if ((boolean)field(mc.gui.screen(), "working")) return;
                    require(!(boolean)field(mc.gui.screen(), "error"), "Partial export worker failed"); verifyExport();
                    key(mc, InputConstants.KEY_ESCAPE); require(!mc.gui.hud.isHidden(), "Cancelled-result close did not restore HUD");
                    mc.gui.hud.toggle(); open(mc); later(13, 600);
                }
                case 13 -> {
                    key(mc, InputConstants.KEY_ESCAPE); require(mc.gui.hud.isHidden(), "Pre-hidden HUD was unhidden on close"); mc.gui.hud.toggle();
                    mc.disconnectFromWorld(net.minecraft.client.multiplayer.ClientLevel.DEFAULT_QUIT_MESSAGE); later(14, 2500);
                }
                case 14 -> {
                    if (mc.level != null || mc.player != null || mc.gui.overlay() != null) return;
                    require(PerformanceNotebook.snapshot() == retained, "Finished report lost on disconnect");
                    parent = mc.gui.screen(); mc.options.guiScale().set(2); mc.resizeGui(); open(mc); later(15, 800);
                }
                case 15 -> {
                    require(!PerformanceNotebook.canStart(mc), "No-world Start enabled");
                    require(((List<?>)field(mc.gui.screen(), "hits")).size() == 3, "Disabled Start/Cancel remain keyboard actions");
                    click(mc, 0); require(!PerformanceNotebook.running() && PerformanceNotebook.snapshot() == retained, "Disabled Start changed retained report");
                    shot(mc, "no-world-scale2"); mc.options.guiScale().set(4); mc.resizeGui(); later(16, 800);
                }
                case 16 -> {
                    shot(mc, "no-world-scale4"); key(mc, InputConstants.KEY_TAB); key(mc, InputConstants.KEY_RETURN);
                    require(mc.gui.screen() == parent, "No-world Tab/Enter Done failed"); open(mc); later(17, 600);
                }
                case 17 -> {
                    key(mc, InputConstants.KEY_ESCAPE); require(mc.gui.screen() == parent, "No-world Escape parent restore failed");
                    mc.options.guiScale().set(originalScale); mc.resizeGui();
                    if (mc.gui.hud.isHidden() != originalHud) mc.gui.hud.toggle();
                    Goon.LOGGER.info("NOTEBOOK CHECKS PASSED: actual Mixin 60s completion; >=5s real capture/cancel; paused menu excludes samples; same-tick focus/screen callbacks and dropped next anchors; stable disabled Cancel identity; CSV/summary click counts; HUD restore visible/hidden; no-world disabled Start; disconnect retention; Tab/Enter/Escape; scale2/4 screenshots. Deterministic gap/statistics fixtures separately passed.");
                    later(18, 100); mc.stop();
                }
                default -> {}
            }
        } catch (Exception e) { failed = true; Goon.LOGGER.error("NOTEBOOK CHECKS FAILED at step " + step, e); mc.stop(); }
    }
}
