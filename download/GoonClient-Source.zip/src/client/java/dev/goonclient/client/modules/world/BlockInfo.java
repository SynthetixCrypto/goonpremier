package dev.goonclient.client.modules.world;

import dev.goonclient.client.gui.render.Icons;
import dev.goonclient.client.gui.Ui;
import dev.goonclient.client.hud.HudPosition;
import dev.goonclient.client.hud.TextHudModule;
import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.setting.BooleanSetting;
import java.util.List;
import java.util.Locale;
import net.minecraft.client.Minecraft;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.GameType;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;

/** Information from the ordinary crosshair target; never searches hidden blocks. */
public final class BlockInfo extends TextHudModule {
    private final BooleanSetting identifier = add(new BooleanSetting("identifier", "Block identifier", false));
    private final BooleanSetting properties = add(new BooleanSetting("properties", "State properties (up to four)", false));
    public BlockInfo() {
        super("block_info", "Block Info", "Looked-at block, coordinates, tool suitability and estimated break time", Category.WORLD, false, HudPosition.topRight(2, 64));
    }

    @Override
    protected Icons.Icon icon() {
    	return Icons.Icon.CUBE;
    }
    @Override public boolean isVisible(Minecraft mc) {
        return mc.level != null && mc.player != null && mc.hitResult instanceof BlockHitResult hit && hit.getType() == HitResult.Type.BLOCK;
    }
    @Override protected void collect(Minecraft mc, List<Line> lines, boolean editing) {
        if (!isVisible(mc)) {
            if (editing) {
                lines.add(new Line("", "Stone"));
                lines.add(new Line("XYZ", "128 64 -256"));
                lines.add(new Line("Tool", "Suitable for drops", Ui.GOOD));
                lines.add(new Line("Break time", "~0.30 s"));
            }
            return;
        }
        var pos = ((BlockHitResult)mc.hitResult).getBlockPos();
        var state = mc.level.getBlockState(pos);
        lines.add(new Line("", Ui.ellipsize(mc.font, state.getBlock().getName().getString(), 200, true)));
        if (identifier.isOn()) lines.add(new Line("", Ui.ellipsize(mc.font, BuiltInRegistries.BLOCK.getKey(state.getBlock()).toString(), 220, false), Ui.MUTED));
        lines.add(new Line("XYZ", pos.getX() + " " + pos.getY() + " " + pos.getZ()));
        boolean suitable = mc.player.hasCorrectToolForDrops(state);
        lines.add(new Line("Tool", suitable ? "Suitable for drops" : "Needs a different tool", suitable ? Ui.GOOD : Ui.WARN));
        float hardness = state.getDestroySpeed(mc.level, pos);
        float progress = state.getDestroyProgress(mc.player, mc.level, pos);
        String time = mc.gameMode != null && mc.gameMode.getPlayerMode() == GameType.CREATIVE ? "Creative" :
            hardness < 0 ? "Unbreakable" : progress >= 1 ? "Instant" : progress <= 0 ? "Unavailable" :
            String.format(Locale.ROOT, "~%.2f s", Math.ceil(1.0 / progress) / 20.0);
        lines.add(new Line("Break time", time));
        if (properties.isOn()) state.getValues().sorted(java.util.Comparator.comparing(e -> e.property().getName())).limit(4)
            .forEach(e -> lines.add(new Line(e.property().getName(), String.valueOf(e.value()), Ui.MUTED)));
    }
}
