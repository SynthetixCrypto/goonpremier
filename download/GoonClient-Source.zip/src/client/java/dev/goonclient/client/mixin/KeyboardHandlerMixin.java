package dev.goonclient.client.mixin;

import dev.goonclient.client.input.ModuleBindings;
import net.minecraft.client.KeyboardHandler;
import net.minecraft.client.Minecraft;
import net.minecraft.client.input.KeyEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(KeyboardHandler.class)
public class KeyboardHandlerMixin {
    @Inject(method="keyPress",at=@At("HEAD"))
    private void goon$activity(long window,int action,KeyEvent event,CallbackInfo ci){dev.goonclient.client.input.InputActivity.record(Minecraft.getInstance(),window);}
    @Inject(method="charTyped",at=@At("HEAD"))
    private void goon$typingActivity(long window,net.minecraft.client.input.CharacterEvent event,CallbackInfo ci){dev.goonclient.client.input.InputActivity.record(Minecraft.getInstance(),window);}

    @Inject(method = "keyPress", at = @At("TAIL"))
    private void goon$moduleShortcut(long window, int action, KeyEvent event, CallbackInfo ci) {
        ModuleBindings.press(Minecraft.getInstance(), window, action, event);
    }
}
