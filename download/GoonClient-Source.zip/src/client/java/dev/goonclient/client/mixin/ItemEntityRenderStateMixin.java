package dev.goonclient.client.mixin;

import dev.goonclient.client.modules.visual.ItemPhysics;
import net.minecraft.client.renderer.entity.state.ItemEntityRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(ItemEntityRenderState.class)
public class ItemEntityRenderStateMixin implements ItemPhysics.State {
	@Unique private boolean goonclient$grounded;
	@Unique private boolean goonclient$liquid;
	@Unique private float goonclient$yaw;

	@Override
	public void goonclient$physics(boolean grounded, boolean liquid, float yaw) {
		goonclient$grounded = grounded;
		goonclient$liquid = liquid;
		goonclient$yaw = yaw;
	}

	@Override public boolean goonclient$grounded() { return goonclient$grounded; }
	@Override public boolean goonclient$liquid() { return goonclient$liquid; }
	@Override public float goonclient$yaw() { return goonclient$yaw; }
}
