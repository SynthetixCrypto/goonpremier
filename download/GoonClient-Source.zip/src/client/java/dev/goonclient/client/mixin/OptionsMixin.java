package dev.goonclient.client.mixin;

import dev.goonclient.client.gui.GoonScreen;
import dev.goonclient.client.modules.utility.Interface;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Options.class)
public class OptionsMixin {
	@Shadow public boolean onboardAccessibility;

	/** Skip Minecraft's first-run narrator welcome page, including on a clean launcher install. */
	@Inject(method = "<init>", at = @At("RETURN"))
	private void goonclient$skipWelcome(CallbackInfo ci) {
		onboardAccessibility = false;
	}

	/** Restoring exact saved values must not trigger a second bulk graphics preset over them. */
	@Inject(method = {"setGraphicsPresetToCustom", "applyGraphicsPreset"}, at = @At("HEAD"), cancellable = true)
	private void goonclient$restoreGraphics(CallbackInfo ci) {
		if (dev.goonclient.client.config.PerformancePreset.restoring()) ci.cancel();
	}

	/** Both the blur shader and Screen#extractBlurredBackground read this, so Goon Client screens get their own strength. */
	@Inject(method = "getMenuBackgroundBlurriness", at = @At("RETURN"), cancellable = true)
	private void goonclient$blur(CallbackInfoReturnable<Integer> cir) {
		Minecraft mc = Minecraft.getInstance();
		if (mc != null && mc.gui != null && mc.gui.screen() instanceof GoonScreen) {
			boolean panelGlass = mc.gui.screen() instanceof dev.goonclient.client.gui.ClickGuiScreen || mc.gui.screen() instanceof dev.goonclient.client.gui.StudioScreen;
			cir.setReturnValue(panelGlass && dev.goonclient.client.gui.render.BackdropBlur.available() ? 0 : Interface.blur());
		}
	}
}
