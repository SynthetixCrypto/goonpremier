package dev.goonclient.client.dev;

import dev.goonclient.Goon;
import dev.goonclient.client.module.Module;
import dev.goonclient.client.module.ModuleManager;
import dev.goonclient.client.cosmetics.Cosmetics;
import dev.goonclient.client.hud.HudModule;
import dev.goonclient.client.hud.HudPosition;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import net.minecraft.client.CameraType;
import net.minecraft.client.tutorial.TutorialSteps;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;
import java.util.*;

/** Opt-in camera rig. Runs exclusively in the copied run-cinematic game directory. */
public final class DevFilmCapture {
    private static final String[] NAMES={"explore","combat","build","cave","farm","overlay","cape"};
    private static final int[] XS={-160,60,240,120,360,400,240}, ZS={220,120,60,300,100,300,60};
    private static int scene=-1, frame, warmup, startup;
    private static volatile boolean ready, pending;
    private static volatile int ground;
    private static int frames=Integer.getInteger("goonclient.filmFrames",80);
    private static final Set<String> SELECTED=new HashSet<>(Arrays.asList(System.getProperty("goonclient.filmScenes",String.join(",",NAMES)).split(",")));
    private static int next(int from){while(from<NAMES.length&&!SELECTED.contains(NAMES[from]))from++;return from;}
    public static void init() {
        if(Boolean.getBoolean("goonclient.filmCapture")) ClientTickEvents.END_CLIENT_TICK.register(DevFilmCapture::tick);
    }
    private static void tick(Minecraft mc) {
        if(!mc.gameDirectory.getName().equals("run-cinematic")) throw new IllegalStateException("Film capture requires its isolated directory");
        if(mc.player==null||mc.level==null)return;
        mc.getFramerateLimitTracker().onInputReceived();
        mc.options.pauseOnLostFocus=false;
        if(scene<0) {if(++startup<80)return;mc.options.guiScale().set(2);mc.resizeGui();mc.getTutorial().setStep(TutorialSteps.NONE);mc.options.tutorialStep=TutorialSteps.NONE;scene=next(0);prepare(mc);return;}
        if(!ready||pending)return;
        mc.gui.hud.getChat().clearMessages(false);mc.gui.toastManager().clear();
        if(warmup++<80) { camera(mc,0);return; }
        camera(mc,frame/(double)(frames-1));
        if(scene==1&&(frame==12||frame==35||frame==59)) {
            run(mc,"damage @e[type=husk,limit=1,sort=nearest] 3");
            mc.player.swing(net.minecraft.world.InteractionHand.MAIN_HAND,net.minecraft.world.item.component.SwingAnimation.DEFAULT,false);
        }
        if(scene==3&&frame==24)enabled("fullbright",true);
        if(scene==6&&(frame==27||frame==54))Cosmetics.equip(frame==27?"after_hours":"nation_gold");
        if(scene==4&&(frame==12||frame==35||frame==57)){
            run(mc,"summon item ~ ~ ~ {Item:{id:\"minecraft:wheat\",count:16}}");
            run(mc,"summon item ~ ~ ~ {Item:{id:\"minecraft:carrot\",count:12}}");
        }
        String name=String.format(Locale.ROOT,"film-%s-%04d.png",NAMES[scene],frame);
        pending=true;
        Screenshot.grab(mc.gameDirectory,name,mc.gameRenderer.mainRenderTarget(),1,message->pending=false);
        if(frame%20==0)Goon.LOGGER.info("Film {} frame {}/{}",NAMES[scene],frame,frames);
        frame++;
        if(frame==frames) {
            scene=next(scene+1);
            if(scene==NAMES.length){Goon.LOGGER.info("FILM CAPTURE COMPLETE");mc.stop();return;}
            prepare(mc);
        }
    }
    private static void enabled(String id,boolean value){for(Module m:ModuleManager.all())if(m.id().equals(id))m.setEnabled(value);}
    private static void prepare(Minecraft mc) {
        ready=false;frame=0;warmup=0;
        Set<String> active=new HashSet<>(List.of("interface","crosshair"));
        switch(scene){
            case 0->active.addAll(List.of("minimap","coordinates","compass"));
            case 1->active.addAll(List.of("armor","health_bars","damage_numbers","target","attack_indicator"));
            case 2->active.addAll(List.of("minimap","coordinates","inventory_hud"));
            case 3->active.addAll(List.of("coordinates","inventory_hud"));
            case 4->active.addAll(List.of("minimap","loot_tracker","pickup_notifier","inventory_hud"));
            case 5->active.addAll(List.of("spawn_overlay","chunk_borders","light_level","fullbright"));
            case 6->active.addAll(List.of("compass","fullbright"));
        }
        for(Module m:ModuleManager.all())m.setEnabled(active.contains(m.id()));
        for(HudModule h:ModuleManager.hudModules()){h.resetPosition();h.scale.set(.85);if(h.id().equals("target"))h.setPosition(HudPosition.bottomRight(12,90));}
        mc.options.setCameraType(scene==6?CameraType.THIRD_PERSON_BACK:CameraType.FIRST_PERSON);
        Cosmetics.equip(scene==6?"nation_mint":"none");
        mc.gui.setScreen(null);
        final int current=scene, x=XS[scene],z=ZS[scene];
        var server=mc.getSingleplayerServer();
        server.execute(()->{
            var level=server.overworld();
            int y=current==3?36:level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,x+28,z+28)+2;
            if(current==6)y=level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,x+10,z+12)+1;
            ground=y;
            for(String s:List.of("gamemode creative","weather clear","time set "+(current==5?18000:current==6?23000:current==2?11000:3000),"clear @s","effect clear @s","tp @s "+x+" "+(y+5)+" "+(z+8),"kill @e[type=!player,distance=..35]"))command(mc,s);
            if(current==1){
                command(mc,"fill "+(x-13)+" "+y+" "+(z-13)+" "+(x+13)+" "+y+" "+(z+13)+" polished_deepslate");
                command(mc,"fill "+(x-12)+" "+(y+1)+" "+(z-12)+" "+(x+12)+" "+(y+8)+" "+(z+12)+" air");
                for(int px:new int[]{-11,11})for(int pz:new int[]{-11,11}){
                    command(mc,"fill "+(x+px)+" "+(y+1)+" "+(z+pz)+" "+(x+px)+" "+(y+5)+" "+(z+pz)+" chiseled_stone_bricks");
                    command(mc,"setblock "+(x+px)+" "+(y+6)+" "+(z+pz)+" soul_lantern");
                }
                for(int offset:new int[]{0,-4,4})command(mc,"summon husk "+(x+offset)+" "+(y+1)+" "+(z-(offset==0?0:3))+" {NoAI:1b,PersistenceRequired:1b}");
                command(mc,"item replace entity @s weapon.mainhand with diamond_sword");command(mc,"item replace entity @s armor.chest with diamond_chestplate");
            }
            if(current==2){
                command(mc,"fill "+(x-15)+" "+y+" "+(z-15)+" "+(x+15)+" "+y+" "+(z+15)+" grass_block");
                command(mc,"fill "+(x-20)+" "+(y+1)+" "+(z-20)+" "+(x+20)+" "+(y+19)+" "+(z+20)+" air");
                command(mc,"fill "+(x-5)+" "+(y+1)+" "+(z-6)+" "+(x+5)+" "+(y+5)+" "+(z+3)+" white_concrete hollow");
                for(int px:new int[]{-5,5})for(int pz:new int[]{-6,3})command(mc,"fill "+(x+px)+" "+(y+1)+" "+(z+pz)+" "+(x+px)+" "+(y+6)+" "+(z+pz)+" stripped_spruce_log");
                for(int k=0;k<4;k++)command(mc,"fill "+(x-6+k)+" "+(y+6+k)+" "+(z-7)+" "+(x+6-k)+" "+(y+6+k)+" "+(z+4)+" dark_oak_planks");
                command(mc,"fill "+(x-3)+" "+(y+2)+" "+(z+3)+" "+(x-1)+" "+(y+3)+" "+(z+3)+" glass");
                command(mc,"fill "+(x+1)+" "+(y+1)+" "+(z+3)+" "+(x+2)+" "+(y+3)+" "+(z+3)+" air");
                command(mc,"fill "+(x+1)+" "+y+" "+(z+4)+" "+(x+3)+" "+y+" "+(z+14)+" dirt_path");
                for(int px:new int[]{-10,10}){
                    command(mc,"fill "+(x+px)+" "+(y+4)+" "+(z-5)+" "+(x+px+3)+" "+(y+7)+" "+(z-1)+" cherry_leaves[persistent=true]");
                    command(mc,"fill "+(x+px+1)+" "+(y+1)+" "+(z-3)+" "+(x+px+1)+" "+(y+5)+" "+(z-3)+" cherry_log");
                }
                for(int px=-12;px<=12;px+=3)command(mc,"setblock "+(x+px)+" "+(y+1)+" "+(z+8)+" pink_petals");
                command(mc,"give @s oak_planks 64");command(mc,"give @s glass 32");command(mc,"give @s lantern 16");command(mc,"give @s cherry_log 64");
                String[] blocks={"oak_planks","glass","lantern","cherry_log","white_concrete","dark_oak_planks","stone_bricks","spruce_log","cherry_leaves"};
                for(int k=0;k<blocks.length;k++)command(mc,"item replace entity @s inventory."+k+" with "+blocks[k]+" 64");
            }
            if(current==3){
                command(mc,"fill "+(x-7)+" "+y+" "+(z-27)+" "+(x+7)+" "+(y+9)+" "+(z+15)+" deepslate");
                command(mc,"fill "+(x-5)+" "+(y+1)+" "+(z-25)+" "+(x+5)+" "+(y+7)+" "+(z+13)+" air");
                for(int pz=-24;pz<=12;pz+=6){
                    for(int px:new int[]{-4,4})command(mc,"fill "+(x+px)+" "+(y+1)+" "+(z+pz)+" "+(x+px)+" "+(y+6)+" "+(z+pz)+" spruce_log");
                    command(mc,"fill "+(x-4)+" "+(y+6)+" "+(z+pz)+" "+(x+4)+" "+(y+6)+" "+(z+pz)+" spruce_planks");
                    command(mc,"setblock "+x+" "+(y+5)+" "+(z+pz)+" lantern[hanging=true]");
                    command(mc,"fill "+(x-5)+" "+(y+2)+" "+(z+pz-1)+" "+(x-5)+" "+(y+4)+" "+(z+pz+1)+" deepslate_diamond_ore");
                    command(mc,"fill "+(x+5)+" "+(y+1)+" "+(z+pz)+" "+(x+5)+" "+(y+3)+" "+(z+pz+2)+" deepslate_redstone_ore");
                }
                command(mc,"fill "+x+" "+(y+1)+" "+(z-24)+" "+x+" "+(y+1)+" "+(z+12)+" rail[shape=north_south]");
                command(mc,"item replace entity @s weapon.mainhand with diamond_pickaxe");command(mc,"give @s diamond 12");command(mc,"give @s redstone 36");
                command(mc,"item replace entity @s inventory.0 with diamond 12");command(mc,"item replace entity @s inventory.1 with redstone 36");command(mc,"item replace entity @s inventory.2 with raw_iron 32");command(mc,"item replace entity @s inventory.3 with coal 64");
            }
            if(current==4){
                command(mc,"fill "+(x-16)+" "+y+" "+(z-16)+" "+(x+16)+" "+y+" "+(z+16)+" grass_block");
                command(mc,"fill "+(x-15)+" "+(y+1)+" "+(z-15)+" "+(x+15)+" "+(y+7)+" "+(z+15)+" air");
                for(int px=-12;px<=12;px+=4){
                    command(mc,"fill "+(x+px)+" "+y+" "+(z-12)+" "+(x+px+2)+" "+y+" "+(z+12)+" farmland[moisture=7]");
                    command(mc,"fill "+(x+px)+" "+(y+1)+" "+(z-12)+" "+(x+px+2)+" "+(y+1)+" "+(z+12)+" "+(px<0?"wheat[age=7]":"carrots[age=7]"));
                    command(mc,"fill "+(x+px+3)+" "+y+" "+(z-12)+" "+(x+px+3)+" "+y+" "+(z+12)+" water");
                }
                command(mc,"fill "+(x-16)+" "+y+" "+(z+14)+" "+(x+16)+" "+y+" "+(z+16)+" dirt_path");
                for(int px=-12;px<=12;px+=8){command(mc,"setblock "+(x+px)+" "+(y+1)+" "+(z+14)+" hay_block");command(mc,"setblock "+(x+px)+" "+(y+2)+" "+(z+14)+" lantern");}
                command(mc,"give @s wheat 64");command(mc,"give @s carrot 64");command(mc,"give @s potato 32");command(mc,"give @s golden_carrot 16");
                command(mc,"item replace entity @s inventory.0 with wheat 64");command(mc,"item replace entity @s inventory.1 with carrot 64");command(mc,"item replace entity @s inventory.2 with potato 32");command(mc,"item replace entity @s inventory.3 with wheat_seeds 64");
            }
            if(current==5){
                command(mc,"fill "+(x-20)+" "+y+" "+(z-20)+" "+(x+20)+" "+y+" "+(z+20)+" stone_bricks");
                command(mc,"fill "+(x-18)+" "+(y+1)+" "+(z-18)+" "+(x+18)+" "+(y+20)+" "+(z+18)+" air");
                for(int px:new int[]{-9,9})for(int pz:new int[]{-9,9}){command(mc,"setblock "+(x+px)+" "+(y+1)+" "+(z+pz)+" cobblestone_wall");command(mc,"setblock "+(x+px)+" "+(y+2)+" "+(z+pz)+" lantern");}
            }
            if(current==6){command(mc,"item replace entity @s armor.chest with air");command(mc,"item replace entity @s armor.head with air");command(mc,"item replace entity @s armor.legs with netherite_leggings");command(mc,"item replace entity @s armor.feet with netherite_boots");}
            ready=true;
        });
    }
    private static void camera(Minecraft mc,double t){
        double x=XS[scene],y=ground,z=ZS[scene],cx,cy,cz,tx=x,ty=y+2,tz=z;
        switch(scene){
            case 0->{cx=x+28-26*t;cy=y+25-5*t;cz=z+38-24*t;ty=y+3;tz=z-15;}
            case 1->{cx=x+1.2-2.4*t;cy=y+1.15;cz=z+3.65;ty=y+2.2;}
            case 2->{cx=x+16-10*t;cy=y+10-2*t;cz=z+19-5*t;ty=y+4;}
            case 3->{cx=x+1.6;cy=y+1.3;cz=z+10-22*t;tz=cz-15;ty=y+2.8;}
            case 4->{cx=x-11+21*t;cy=y+2.6;cz=z+13;tz=z-5;ty=y+.6;}
            case 5->{cx=x+9-17*t;cy=y+4;cz=z+16-4*t;ty=y;}
            default->{cx=x+4;cy=y+1;cz=z+12-4*t;tz=z-30;ty=y+1;}
        }
        mc.player.getAbilities().flying=true;
        mc.player.setDeltaMovement(Vec3.ZERO);
        mc.player.setPos(cx,cy,cz);
        double dx=tx-cx,dy=ty-(cy+mc.player.getEyeHeight()),dz=tz-cz;
        mc.player.setYRot((float)Math.toDegrees(Math.atan2(-dx,dz)));
        mc.player.setXRot((float)-Math.toDegrees(Math.atan2(dy,Math.sqrt(dx*dx+dz*dz))));
    }
    private static void run(Minecraft mc,String s){mc.getSingleplayerServer().execute(()->command(mc,s));}
    private static void command(Minecraft mc,String s){var server=mc.getSingleplayerServer();server.getCommands().performPrefixedCommand(server.createCommandSourceStack().withSuppressedOutput(),"execute as @p at @p run "+s);}
}
