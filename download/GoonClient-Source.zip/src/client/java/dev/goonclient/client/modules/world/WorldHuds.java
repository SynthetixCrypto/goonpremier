package dev.goonclient.client.modules.world;

import dev.goonclient.client.hud.HudPosition;
import dev.goonclient.client.gui.Ui;
import dev.goonclient.client.hud.TextHudModule;
import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.setting.BooleanSetting;
import dev.goonclient.client.module.setting.NumberSetting;
import dev.goonclient.client.modules.hud.Text;
import dev.goonclient.client.tracker.SessionStats;
import dev.goonclient.client.waypoint.Waypoint;
import dev.goonclient.client.waypoint.WaypointManager;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.phys.AABB;

public final class WorldHuds {
	private static final String[] ARROWS = {"↑", "↗", "→", "↘", "↓", "↙", "←", "↖"};

	private WorldHuds() {
	}

	/** Arrow pointing from the player's view toward a world position. */
	static String arrowTo(Minecraft mc, double x, double z) {
		double dx = x - mc.player.getX();
		double dz = z - mc.player.getZ();
		float bearing = (float) (Mth.atan2(dz, dx) * Mth.RAD_TO_DEG) - 90f;
		float diff = Mth.wrapDegrees(bearing - mc.player.getYRot());
		return ARROWS[Math.floorMod(Math.round(diff / 45f), 8)];
	}

	public static class LightLevel extends TextHudModule {
		private final BooleanSetting sky = add(new BooleanSetting("sky", "Show sky light", true));

		public LightLevel() {
			super("light_level", "Light Level", "Block light where you stand and whether mobs can spawn there", Category.WORLD, false, HudPosition.topCenter(0, 30));
		}

		@Override
		protected void collect(Minecraft mc, List<Line> lines, boolean editing) {
			if (mc.player == null || mc.level == null) {
				lines.add(new Line("Light", "7"));
				return;
			}
			BlockPos pos = mc.player.blockPosition();
			int block = mc.level.getBrightness(LightLayer.BLOCK, pos);
			String value = Integer.toString(block);
			if (sky.isOn()) {
				value += "  (sky " + mc.level.getBrightness(LightLayer.SKY, pos) + ")";
			}
			lines.add(new Line("Light", value));
			// Hostile mobs need block light 0 and a dark enough sky (sky light minus the current darkening)
			int effective = mc.level.getRawBrightness(pos, mc.level.getSkyDarken());
			if (block > 0) {
				lines.add(new Line("", "Too bright for mobs", Ui.GOOD));
			} else if (effective <= 7) {
				lines.add(new Line("", "Mobs can spawn here", Ui.BAD));
			} else {
				lines.add(new Line("", "Mobs can spawn here at night", Ui.WARN));
			}
		}
	}

	public static class NearbyEntities extends TextHudModule {
		private final NumberSetting radius = add(new NumberSetting("radius", "Radius", 32, 8, 64, 4, " blocks"));
		private final NumberSetting maxTypes = add(new NumberSetting("max_types", "Mob types shown", 5, 1, 10, 1));
		private final BooleanSetting players = add(new BooleanSetting("players", "Include players", false));

        private final List<Line> snapshot=new java.util.ArrayList<>();
        private net.minecraft.client.multiplayer.ClientLevel sampledWorld;
        private long sampledAt,scans;
        private double sampledRadius=-1;
        private int sampledTypes;
        private boolean sampledPlayers;
        private double sx,sy,sz;
        @Override public void loadEnabled(boolean enabled){if(isEnabled()!=enabled)onDisable();super.loadEnabled(enabled);}
        @Override protected void onDisable(){snapshot.clear();sampledWorld=null;sampledAt=0;}
        @Override public void onTick(Minecraft mc){refresh(mc);}
        private void refresh(Minecraft mc){
            if(mc.player==null||mc.level==null){onDisable();return;}
            long now=System.nanoTime();double dx=mc.player.getX()-sx,dy=mc.player.getY()-sy,dz=mc.player.getZ()-sz;
            if(sampledWorld==mc.level&&sampledRadius==radius.get()&&sampledTypes==maxTypes.intValue()&&sampledPlayers==players.isOn()
                &&now-sampledAt<500_000_000L&&dx*dx+dy*dy+dz*dz<16)return;
            sampledWorld=mc.level;sampledAt=now;sampledRadius=radius.get();sampledTypes=maxTypes.intValue();sampledPlayers=players.isOn();
            sx=mc.player.getX();sy=mc.player.getY();sz=mc.player.getZ();snapshot.clear();scan(mc,snapshot);scans++;
        }
        @Override protected void collect(Minecraft mc,List<Line> lines,boolean editing){
            if(mc.player==null||mc.level==null){lines.add(new Line("Zombie","x3",Ui.BAD));return;}
            refresh(mc);lines.addAll(snapshot);
        }
        private void scan(Minecraft mc,List<Line> lines) {
			AABB area = mc.player.getBoundingBox().inflate(radius.get());
			Map<String, Integer> hostile = new HashMap<>();
			int passive = 0;
			int items = 0;
			int playerCount = 0;
			for (Entity entity : mc.level.getEntities(mc.player, area, Entity::isAlive)) {
				if (entity instanceof Enemy) {
					hostile.merge(entity.getType().getDescription().getString(), 1, Integer::sum);
				} else if (entity instanceof ItemEntity item) {
					items += item.getItem().getCount();
				} else if (entity instanceof Player) {
					playerCount++;
				} else if (entity instanceof net.minecraft.world.entity.LivingEntity) {
					passive++;
				}
			}
			int total = hostile.values().stream().mapToInt(Integer::intValue).sum();
			lines.add(new Line("Hostile", Integer.toString(total), total > 0 ? Ui.BAD : Ui.GOOD));
			hostile.entrySet().stream()
				.sorted(Map.Entry.<String, Integer>comparingByValue().reversed())
				.limit(maxTypes.intValue())
				.forEach(e -> lines.add(new Line("  " + e.getKey(), "x" + e.getValue(), Ui.MUTED)));
			lines.add(new Line("Animals", Integer.toString(passive)));
			lines.add(new Line("Items", Integer.toString(items)));
			if (players.isOn()) {
				lines.add(new Line("Players", Integer.toString(playerCount)));
			}
        }

		public NearbyEntities() {
			super("nearby_entities", "Nearby Entities", "Hostile mobs, animals and dropped items around you", Category.WORLD, false, HudPosition.rightMiddle(2, 30));
		}

	}

	public static class Mining extends TextHudModule {
		public Mining() {
			super("mining", "Mining Stats", "Blocks mined, blocks per minute, ores found and tool wear", Category.WORLD, false, HudPosition.bottomRight(2, 80));
		}

		@Override
		protected void collect(Minecraft mc, List<Line> lines, boolean editing) {
			lines.add(new Line("Mined", Integer.toString(SessionStats.blocksMined())));
			lines.add(new Line("Rate", SessionStats.blocksPerMinute() + " /min"));
			SessionStats.ores().entrySet().stream()
				.sorted(Map.Entry.<String, Integer>comparingByValue().reversed())
				.limit(4)
				.forEach(e -> lines.add(new Line("  " + e.getKey(), "x" + e.getValue(), Ui.TEXT)));
			if (mc.player != null) {
				ItemStack tool = mc.player.getMainHandItem();
				if (tool.isDamageableItem()) {
					int left = tool.getMaxDamage() - tool.getDamageValue();
					lines.add(new Line("Tool", left + " uses left", Ui.healthColor(left / (float) tool.getMaxDamage())));
				}
			}
		}
	}

	public static class WaypointList extends TextHudModule {
		private final NumberSetting count = add(new NumberSetting("count", "Waypoints shown", 5, 1, 10, 1));

		public WaypointList() {
			super("waypoint_list", "Waypoint List", "Closest waypoints with distance and direction", Category.WORLD, false, HudPosition.topRight(2, 110));
		}

		@Override
		protected void collect(Minecraft mc, List<Line> lines, boolean editing) {
			if (mc.player == null || mc.level == null) {
				lines.add(new Line("Base", "↑ 120m"));
				return;
			}
			List<Waypoint> waypoints = WaypointManager.inDimension(mc.level.dimension().identifier().toString());
			if (waypoints.isEmpty()) {
				if (editing) {
					lines.add(new Line("", "No waypoints yet (/wp add <name>)", Ui.MUTED));
				}
				return;
			}
			double px = mc.player.getX();
			double py = mc.player.getY();
			double pz = mc.player.getZ();
			waypoints.stream()
				.sorted(Comparator.comparingDouble(w -> w.distanceTo(px, py, pz)))
				.limit(count.intValue())
				.forEach(w -> lines.add(new Line(w.name(), arrowTo(mc, w.x() + 0.5, w.z() + 0.5) + " " + (int) w.distanceTo(px, py, pz) + "m", w.color())));
		}
	}

	/** Prettified name of a dimension id, e.g. "minecraft:the_nether" -> "The Nether". */
	public static String dimensionName(String id) {
		int colon = id.indexOf(':');
		return Text.prettify(colon >= 0 ? id.substring(colon + 1) : id);
	}
}
