package dev.goonclient.client.gui.render;

import com.mojang.blaze3d.platform.NativeImage;
import dev.goonclient.Goon;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.resources.Identifier;
import org.joml.Matrix3x2f;

/**
 * The Goon Client mark drawn in the GUI: {@link LogoArt} rasterised at the exact pixel size and cached per accent.
 */
public final class Logo {
	private static final int MAX_CACHED = 12;
	private static final Map<Long, Cached> CACHE = new LinkedHashMap<>(8, .75f, true);
	private static final List<Identifier> RETIRED = new ArrayList<>();
	private static int nextId;

	private record Cached(Identifier id, SmoothTexture texture) {
	}

	private Logo() {
	}

	/** Releases textures evicted last frame (they may still have been queued for drawing). */
	public static void beginFrame() {
		RETIRED.forEach(id -> Minecraft.getInstance().getTextureManager().release(id));
		RETIRED.clear();
	}

	/** Draws the mark with its top-left at (x, y), {@code size} GUI units square. */
	public static void draw(GuiGraphicsExtractor g, float x, float y, float size, int accent, float alpha) {
		if (alpha <= .01f || size <= 0) {
			return;
		}
		Matrix3x2f pose = g.pose();
		int guiScale = Px.guiScale();
		int pixels = Math.max(8, Math.round(size * pose.m00 * guiScale));
		long key = ((long) (accent & 0xFFFFFF) << 16) | pixels;
		Cached cached = CACHE.get(key);
		if (cached == null) {
			cached = register(LogoArt.image(pixels, accent));
			CACHE.put(key, cached);
			if (CACHE.size() > MAX_CACHED) {
				var eldest = CACHE.entrySet().iterator();
				RETIRED.add(eldest.next().getValue().id());
				eldest.remove();
			}
		}
		int px = Math.round((pose.m00 * x + pose.m20) * guiScale);
		int py = Math.round((pose.m11 * y + pose.m21) * guiScale);
		QuadBatch batch = new QuadBatch(1);
		batch.add(px, py, px + pixels, py + pixels, 0, 0, 1, 1);
		Px.begin(g);
		batch.submit(g, cached.texture(), (Math.round(alpha * 255) << 24) | 0xFFFFFF);
		Px.end(g);
	}

	private static Cached register(BufferedImage image) {
		int w = image.getWidth(), h = image.getHeight();
		NativeImage pixels = new NativeImage(w, h, false);
		for (int y = 0; y < h; y++) {
			for (int x = 0; x < w; x++) {
				pixels.setPixel(x, y, image.getRGB(x, y));
			}
		}
		Identifier id = Goon.id("dynamic/logo_" + w + "_" + nextId++);
		SmoothTexture texture = new SmoothTexture(id.toString(), pixels);
		Minecraft.getInstance().getTextureManager().register(id, texture);
		return new Cached(id, texture);
	}
}
