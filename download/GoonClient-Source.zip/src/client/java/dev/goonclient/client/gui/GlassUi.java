/*
 * This file incorporates values from the Combatant Client distribution.
 * Copyright (c) 2026 pivosos2007.
 * Licensed under the GNU General Public License v3.0.
 * Modified for Goon Client, 2026-10-04: SettingsGlassMaterial.workspace layers and SettingsGuiPalette (Noir)
 * colours for the settings window, panels and controls, drawn with Goon's renderer.
 */
package dev.goonclient.client.gui;

import dev.goonclient.client.gui.render.GoonFont;
import dev.goonclient.client.gui.render.Icons;
import dev.goonclient.client.gui.render.Shapes;
import dev.goonclient.client.modules.utility.Interface;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/**
 * Shared frosted surfaces for the module workspace and its companion screens. Menus lay out on a fixed
 * {@link #CANVAS_W} x {@link #CANVAS_H} canvas scaled to the screen, so they keep the same proportions at every
 * resolution and GUI scale.
 */
public final class GlassUi {
    public static final float CANVAS_W = 676, CANVAS_H = 380;
    public static final int LABEL = 0xFFD4D2DC;
    public static final int MUTED = 0xFFA9A5B2;
    public static final int EDGE = 0x557E7A89;
    private static final DateTimeFormatter CLOCK = DateTimeFormatter.ofPattern("HH:mm");
    private GlassUi() { }

    private static boolean hidHud;

    /** Menus hide the in-game HUD (as F1 does) while they're open, so only the world shows behind the glass. */
    public static void hideHud(net.minecraft.client.Minecraft mc) {
        if (mc.level == null || hidHud || mc.gui.hud.isHidden()) return;
        mc.gui.hud.toggle();
        hidHud = true;
    }

    public static void restoreHud(net.minecraft.client.Minecraft mc) {
        if (hidHud) {
            if (mc.gui.hud.isHidden()) mc.gui.hud.toggle();
            hidHud = false;
        }
    }

    /** Scale from canvas units to GUI units for a screen of this GUI size. */
    public static float canvasScale(int width, int height) {
        return Math.max(.01f, Math.min(width / CANVAS_W, height / CANVAS_H));
    }

    /** The light frosted panel the module columns use: the world shows through, softly lifted. */
    public static void panel(GuiGraphicsExtractor g, float x, float y, float w, float h, float alpha) {
        Shapes.shadow(g, x, y, x + w, y + h, 8, 18, 3, .30f * alpha);
        boolean glass = Interface.glassMenu();
        float opacity = Interface.panelOpacity();
        if (glass) dev.goonclient.client.gui.render.BackdropBlur.draw(g, x, y, w, h, 8, alpha);
        Shapes.panel(g, x, y, x + w, y + h, 8,
            Ui.withAlpha(glass ? 0xFFB9B4C6 : Ui.PANEL, alpha * (glass ? .26f * opacity : opacity)),
            Ui.withAlpha(0xFFFFFFFF, alpha * .16f));
        // A soft sheen across the top, like light catching frosted glass
        Shapes.roundRect(g, x + 1, y + 1, x + w - 1, y + Math.min(46, h * .25f), 7, Ui.withAlpha(0xFFFFFFFF, .045f * alpha));
    }

    /**
     * The settings window, as Combatant's SettingsGlassMaterial.workspace: blurred world, a faint liquid-glass haze,
     * the window tint at 30% of its 205 alpha (so the world stays visible), a soft edge and the menu shadow.
     * Colours are SettingsGuiPalette's Noir values (menuWindowBg, glassEdgeSoft, menuShadow).
     */
    public static void window(GuiGraphicsExtractor g, float x, float y, float w, float h, float alpha) {
        Shapes.glow(g, x, y, x + w, y + h, 7, 20, .37f * alpha, .08f);
        // Without a world to blur (title screen) the tint carries the panel instead
        boolean glass = Interface.glassMenu() && dev.goonclient.client.gui.render.BackdropBlur.available();
        if (glass) dev.goonclient.client.gui.render.BackdropBlur.draw(g, x, y, w, h, 7, alpha);
        float tint = glass ? .30f : .30f + .55f * Interface.panelOpacity();
        // Liquid-glass haze: brighter at the top, fading down
        if (glass) Shapes.gradientRect(g, x, y, x + w, y + h, 7, 7, Ui.withAlpha(0xFFFFFFFF, .07f * alpha), Ui.withAlpha(0xFFFFFFFF, .02f * alpha));
        Shapes.gradientRect(g, x, y, x + w, y + h, 7, 7, Ui.withAlpha(0xCD0D0F12, tint * alpha), Ui.withAlpha(0xCD0B0C0F, tint * alpha));
        Shapes.outline(g, x, y, x + w, y + h, 7, Ui.withAlpha(0x34474E5A, alpha));
        dev.goonclient.client.hud.HudRenderUtil.rim(g, x, y, w, h, 7, .8f * alpha);
    }

    /** SettingsGuiPalette.controlSurface / controlSurfaceHover / glassEdgeSoft: buttons and cards on the glass. */
    public static final int CONTROL = 0x7A13151A, CONTROL_HOVER = 0xA0302731, GLASS_EDGE = 0x34474E5A;

    /** SettingsGuiPalette.workspaceWashLeft/Right: the darker strip behind the icon rail (top / bottom). */
    public static final int RAIL_WASH_TOP = 0x680E0F12, RAIL_WASH_BOTTOM = 0x740C0D10;
    /** SettingsGuiPalette.contentPlaneTop/Bottom and navigationPlaneTop/Bottom: the inner page panels. */
    public static final int CONTENT_TOP = 0x820E0F13, CONTENT_BOTTOM = 0x960B0C0F, NAV_TOP = 0xB20A0B0E, NAV_BOTTOM = 0xC409090C;

    public static void card(GuiGraphicsExtractor g, float x, float y, float w, float h, boolean selected, float hover) {
        int accent = Ui.accent();
        Shapes.panel(g, x, y, x + w, y + h, 3,
            selected ? Ui.lerp(.30f, 0xF0242227, accent) : Ui.lerp(hover, 0xE0222026, 0xF02C2A31),
            selected ? Ui.withAlpha(accent, .85f) : 0x30FFFFFF);
    }

    public static void text(GuiGraphicsExtractor g, String value, float x, float y, float size, int color, boolean bold) {
        GoonFont.draw(g, value, x, y, size, bold ? GoonFont.Weight.BOLD : GoonFont.Weight.REGULAR, color, false);
    }

    public static void line(GuiGraphicsExtractor g, float x, float y, float w) {
        Shapes.rect(g, x, y, x + w, y + .4f, 0x1EFFFFFF);
    }

    public static void hud(GuiGraphicsExtractor g, float w, float h) {
        dev.goonclient.client.hud.HudRenderUtil.panel(g, 0, 0, w, h, 3, true, 1);
    }

    /** "10:45" in a small dark pill, right edge at {@code right}. Returns its left edge. */
    public static float timePill(GuiGraphicsExtractor g, float right, float y, float alpha) {
        String time = LocalTime.now().format(CLOCK);
        float w = GoonFont.width(time, 4.6f, GoonFont.Weight.BOLD) + 9;
        Shapes.roundRect(g, right - w, y, right, y + 9.2f, 4.6f, Ui.withAlpha(0xFF1A171C, .62f * alpha));
        GoonFont.draw(g, time, right - w + 4.5f, y + 2.3f, 4.6f, GoonFont.Weight.BOLD, Ui.withAlpha(0xFFFFFFFF, .92f * alpha), false);
        return right - w;
    }

    /** Geometry of the Modules / Settings switch, shared so clicks line up with drawing. */
    public static final float NAV_W = 69.5f, NAV_H = 12.7f, NAV_Y = 3;

    /**
     * The top-centre Modules / Settings switch with the clock pill beside it. {@code settings} picks the lit side;
     * {@code lit} (0..1) slides the highlight between them.
     */
    public static void navigation(GuiGraphicsExtractor g, float canvasWidth, float lit, float hoverModules, float hoverSettings, float alpha) {
        float x = canvasWidth / 2 - NAV_W / 2, y = NAV_Y;
        timePill(g, x - 2.5f, y + 1.8f, alpha);
        Shapes.roundRect(g, x, y, x + NAV_W, y + NAV_H, NAV_H / 2, Ui.withAlpha(0xFF241E24, .66f * alpha));
        float inset = 1.4f, half = (NAV_W - inset * 2) / 2;
        float hx = x + inset + half * lit;
        Shapes.roundRect(g, hx, y + inset, hx + half, y + NAV_H - inset, (NAV_H - inset * 2) / 2, Ui.withAlpha(Ui.accent(), .9f * alpha));
        String[] labels = {"Modules", "Settings"};
        float[] hover = {hoverModules, hoverSettings};
        for (int i = 0; i < 2; i++) {
            float on = i == 0 ? 1 - lit : lit;
            int color = Ui.lerp(Math.max(on, hover[i] * .6f), 0xFFAFAAB4, 0xFFFFFFFF);
            float tw = GoonFont.width(labels[i], 4.9f, GoonFont.Weight.MEDIUM);
            GoonFont.draw(g, labels[i], x + inset + half * i + (half - tw) / 2, y + 3.9f, 4.9f, GoonFont.Weight.MEDIUM, Ui.withAlpha(color, alpha), false);
        }
    }

    /** True if (mx, my) is on the Modules (0) or Settings (1) half of the switch, else -1. */
    public static int navigationHit(float canvasWidth, double mx, double my) {
        float x = canvasWidth / 2 - NAV_W / 2;
        if (my < NAV_Y || my > NAV_Y + NAV_H || mx < x || mx > x + NAV_W) {
            return -1;
        }
        return mx < x + NAV_W / 2 ? 0 : 1;
    }

    /** Bottom-left key hints in Comfortaa, as in the reference design. Alt+H hides them. */
    public static void hints(GuiGraphicsExtractor g, List<String> lines, float canvasHeight, float alpha) {
        if (!Interface.hints() || alpha <= .01f) {
            return;
        }
        float pitch = 6.8f;
        float y = canvasHeight - 15 - (lines.size() - 1) * pitch;
        for (String line : lines) {
            GoonFont.draw(g, line, 18, y, 5f, GoonFont.Weight.ROUNDED, Ui.withAlpha(0xFFFFFFFF, .86f * alpha), false);
            y += pitch;
        }
    }

    /** The hint lines as one centred row, for menus whose window leaves no room for the stacked list. */
    public static void hintsRow(GuiGraphicsExtractor g, List<String> lines, float centerX, float y, float alpha) {
        if (!Interface.hints() || alpha <= .01f) {
            return;
        }
        String text = String.join("   •   ", lines);
        float w = GoonFont.width(text, 5f, GoonFont.Weight.ROUNDED);
        GoonFont.draw(g, text, centerX - w / 2, y, 5f, GoonFont.Weight.ROUNDED, Ui.withAlpha(0xFFFFFFFF, .86f * alpha), false);
    }

    /** A small search box with the magnifier on the right. */
    public static void searchBox(GuiGraphicsExtractor g, float x, float y, float w, float h, String value, boolean focused, float alpha) {
        Shapes.panel(g, x, y, x + w, y + h, 2.5f, Ui.withAlpha(0xFF2A272E, .9f * alpha),
            Ui.withAlpha(focused ? Ui.accent() : 0xFFFFFFFF, (focused ? .7f : .2f) * alpha));
        boolean empty = value.isEmpty();
        float size = h * .62f;
        String shown = empty ? "Search" : Ui.ellipsize(value, w - h - 6, size, GoonFont.Weight.REGULAR);
        GoonFont.draw(g, shown, x + 3, y + (h - size) / 2 - .2f, size, GoonFont.Weight.REGULAR,
            Ui.withAlpha(empty ? 0xFF8F8A96 : 0xFFFFFFFF, alpha), false);
        if (focused && (System.currentTimeMillis() / 530) % 2 == 0) {
            float cx = x + 3 + (empty ? 0 : GoonFont.width(shown, size, GoonFont.Weight.REGULAR)) + .5f;
            Shapes.rect(g, cx, y + h * .2f, cx + .4f, y + h * .8f, Ui.withAlpha(0xFFFFFFFF, alpha));
        }
        Icons.draw(g, Icons.Icon.SEARCH, x + w - h + 1.5f, y + 1.5f, h - 3, Ui.withAlpha(0xFF8F8A96, alpha));
    }
}
