package dev.goonclient.client.modules.inventory;

import dev.goonclient.client.GoonChat;
import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.Module;
import dev.goonclient.client.module.setting.BooleanSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.item.ItemStack;

/** Original Goon implementation of optional accidental-drop protection. */
public final class ItemGuard extends Module {
    private static ItemGuard instance;
    private final BooleanSetting enchanted = add(new BooleanSetting("enchanted", "Protect enchanted items and books", true));
    private final BooleanSetting named = add(new BooleanSetting("named", "Protect custom-named items", true));
    private final BooleanSetting containers = add(new BooleanSetting("containers", "Protect containers with known contents", true));
    private final BooleanSetting allItems = add(new BooleanSetting("all_items", "Protect every item", false));
    private final BooleanSetting notify = add(new BooleanSetting("notify", "Explain blocked drops in chat", true));
    private long lastNotice;

    public ItemGuard() {
        super("item_guard", "Item Guard", "Stops accidental Q, Ctrl+Q and outside-inventory drops of protected items", Category.INVENTORY, false);
        instance = this;
    }

    public static boolean blockDrop(Player player, ItemStack stack) {
        var self = instance;
        var mc = Minecraft.getInstance();
        if (self == null || !self.isEnabled() || mc.level == null || player == null || player != mc.player
                || player.getAbilities().instabuild || player.isSpectator() || !self.protectedItem(stack)) return false;
        long now = System.nanoTime();
        if (self.notify.isOn() && (self.lastNotice == 0 || now - self.lastNotice >= 2_000_000_000L)) {
            self.lastNotice = now;
            GoonChat.info("Item Guard stopped a drop. Disable Item Guard or change its protection settings to drop this item.");
        }
        return true;
    }

    public static boolean blockContainerDrop(int containerId, int slotId, ContainerInput action, Player player) {
        if (player == null || player != Minecraft.getInstance().player) return false;
        var menu = player.containerMenu;
        if (menu == null || menu.containerId != containerId) return false;
        // Outside clicks drop the carried stack. Normal movement/sorting/swap actions remain untouched.
        if (slotId == -999 && action == ContainerInput.PICKUP) return blockDrop(player, menu.getCarried());
        if (action != ContainerInput.THROW || slotId < 0 || slotId >= menu.slots.size()) return false;
        // Vanilla throws a slot's item only when the cursor is empty.
        if (!menu.getCarried().isEmpty()) return false;
        return blockDrop(player, menu.getSlot(slotId).getItem());
    }

    private boolean protectedItem(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return false;
        if (allItems.isOn()) return true;
        if (named.isOn() && stack.has(DataComponents.CUSTOM_NAME)) return true;
        if (enchanted.isOn()) {
            var stored = stack.get(DataComponents.STORED_ENCHANTMENTS);
            if (stack.isEnchanted() || (stored != null && !stored.isEmpty())) return true;
        }
        var contents = stack.get(DataComponents.CONTAINER);
        return containers.isOn() && contents != null && contents.nonEmptyItems().iterator().hasNext();
    }

    @Override protected void onDisable() { lastNotice = 0; }
}
