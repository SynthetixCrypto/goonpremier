/*
 * This file incorporates code from the Combatant Client distribution.
 * Copyright (c) 2026 pivosos2007.
 * Licensed under the GNU General Public License v3.0.
 * Modified for Goon Client, 2026-10-04: Inventory.java / ScriptedInventoryHudPanel / inventory_panel.js
 * geometry (123 x 62 panel at scale 1.32, 13-unit grid with short divider lines, half-size items) drawn
 * with Goon's renderer; Goon's own read-only inventory data.
 */
package dev.goonclient.client.modules.inventory;

import dev.goonclient.client.gui.Ui;
import dev.goonclient.client.hud.HudModule;
import dev.goonclient.client.hud.HudPosition;
import dev.goonclient.client.hud.HudRenderUtil;
import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.setting.BooleanSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/**
 * Read-only inventory grid in Combatant's style: a titled panel with an item count, then the slots as a grid of short
 * divider lines with half-size items. No sorting packets, automated clicks or knowledge of unopened server containers.
 */
public final class InventoryHud extends HudModule {
	// Inventory.java
	private static final float SCALE = 1.32f, BASE_WIDTH = 123, GRID_START_X = 4, GRID_START_Y = 22, GRID_STEP = 13,
		GRID_LINE_OFFSET_X = 11, GRID_LINE_OFFSET_Y = 10, GRID_LINE_LENGTH = 9, GRID_LINE_THICKNESS = .5f, ITEM_SIZE = 8,
		COUNT_VALUE_OFFSET = 2;
	private static final int BG_ALPHA = 194;

	private final BooleanSetting hotbar = add(new BooleanSetting("hotbar", "Include hotbar", false));
	private final BooleanSetting title = add(new BooleanSetting("title", "Title and item count", true));
	private final BooleanSetting counts = add(new BooleanSetting("counts", "Stack counts and durability", true));

	public InventoryHud() {
		super("inventory_hud", "Inventory HUD", "Your own inventory as a compact grid with an item count and stack counts", Category.INVENTORY, false,
			HudPosition.topRight(87, 159));
	}

	@Override protected void measurePreview(Minecraft mc) { measure(mc, true); }
	@Override protected void renderPreview(GuiGraphicsExtractor g, Minecraft mc) { render(g, mc, true); }

	private int rows() {
		return hotbar.isOn() ? 4 : 3;
	}

	private float top() {
		return title.isOn() ? GRID_START_Y : GRID_START_X;
	}

	private float height() {
		// 62 units for three rows: the last row's cell plus the bottom margin
		return top() + rows() * GRID_STEP + 1;
	}

	/** Reused every frame: x1, y1, x2, y2 per divider line (at most 8 + 3 per row, 4 rows). */
	private final float[] boxes = new float[4 * 64];

	private int line(int index, float x, float y, float w, float h) {
		int i = index * 4;
		boxes[i] = x;
		boxes[i + 1] = y;
		boxes[i + 2] = x + w;
		boxes[i + 3] = y + h;
		return index + 1;
	}

	@Override
	protected void measure(Minecraft mc, boolean editing) {
		float k = HudRenderUtil.panelUnit(SCALE);
		setSize(Math.round(BASE_WIDTH * k), Math.round(height() * k));
	}

	@Override
	protected void render(GuiGraphicsExtractor g, Minecraft mc, boolean editing) {
		measure(mc, editing);
		var inventory = mc.player == null ? null : mc.player.getInventory();
		int items = 0, free = 0;
		if (inventory != null) {
			for (int i = 0; i < 36; i++) {
				items += inventory.getItem(i).getCount();
				if (inventory.getItem(i).isEmpty()) free++;
			}
		}
		float k = HudRenderUtil.panelUnit(SCALE), size = HudRenderUtil.panelFontSize(SCALE);
		var pal = HudRenderUtil.Palette.of(BG_ALPHA);
		g.pose().pushMatrix();
		g.pose().scale(k, k);
		HudRenderUtil.panelChrome(g, BASE_WIDTH, height(), pal, false, 1f, true);
		if (title.isOn()) {
			HudRenderUtil.panelHeader(g, BASE_WIDTH, size, pal.withCounter(inventory != null && free == 0 ? Ui.WARN : pal.counter()),
				"A", HudRenderUtil.Font.ICONS_NUR, 1f, "Inventory", "Items:", Integer.toString(items), COUNT_VALUE_OFFSET);
		}
		int gridColor = HudRenderUtil.scaleAlpha(pal.muted(), .28f);
		float top = top();
		// All the grid's divider lines are one GUI element instead of up to fifty
		int lines = 0;
		for (int row = 0; row < rows(); row++) {
			for (int col = 0; col < 9; col++) {
				float x = GRID_START_X + col * GRID_STEP, y = top + row * GRID_STEP;
				if (col < 8) lines = line(lines, x + GRID_LINE_OFFSET_X, y + 1, GRID_LINE_THICKNESS, GRID_LINE_LENGTH);
				if (row < rows() - 1) lines = line(lines, x + .5f, y + GRID_LINE_OFFSET_Y, GRID_LINE_LENGTH, GRID_LINE_THICKNESS);
			}
		}
		dev.goonclient.client.gui.render.Shapes.rects(g, boxes, lines, gridColor);
		for (int row = 0; row < rows(); row++) {
			for (int col = 0; col < 9; col++) {
				float x = GRID_START_X + col * GRID_STEP, y = top + row * GRID_STEP;
				int slot = row == 3 ? col : 9 + row * 9 + col;
				var stack = inventory == null ? null : inventory.getItem(slot);
				if (stack != null && !stack.isEmpty()) {
					g.pose().pushMatrix();
					g.pose().translate(x, y);
					g.pose().scale(ITEM_SIZE / 16f, ITEM_SIZE / 16f);
					g.item(stack, 0, 0);
					if (counts.isOn()) g.itemDecorations(mc.font, stack, 0, 0);
					g.pose().popMatrix();
				}
			}
		}
		g.pose().popMatrix();
	}
}
