package dev.goonclient.client.modules.hud;

import dev.goonclient.client.hud.HudPosition;
import dev.goonclient.client.gui.Ui;
import dev.goonclient.client.hud.HudModule;
import dev.goonclient.client.mixin.BossHealthOverlayAccessor;
import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.setting.BooleanSetting;
import dev.goonclient.client.module.setting.NumberSetting;
import dev.goonclient.client.waypoint.Waypoint;
import dev.goonclient.client.waypoint.WaypointManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.util.Mth;

/** A horizontal compass strip with waypoint markers. */
public class CompassHud extends HudModule {
	private static final String[] LABELS = {"S", "SW", "W", "NW", "N", "NE", "E", "SE"};

	private final NumberSetting width = add(new NumberSetting("width", "Width", 200, 120, 360, 10, "px"));
	private final BooleanSetting waypoints = add(new BooleanSetting("waypoints", "Waypoint markers", true));
	private final BooleanSetting degrees = add(new BooleanSetting("degrees", "Show heading", true));

	public CompassHud() {
		super("compass", "Compass", "Heading strip with waypoint and death markers", Category.HUD, false, HudPosition.topCenter(0, 2));
	}

	/** Vanilla boss bars sit at the top centre too: slide down below them while any are showing. */
	@Override
	protected int dynamicOffsetY(Minecraft mc) {
		HudPosition position = position();
		if (position.anchorY() != 0 || position.anchorX() != 0.5) {
			return 0;
		}
		int bars = ((BossHealthOverlayAccessor) mc.gui.hud.getBossOverlay()).goonclient$getEvents().size();
		return bars * 19;
	}

	@Override protected void measure(Minecraft mc, boolean editing) {
		setSize(width.intValue(), 14 + (degrees.isOn() ? mc.font.lineHeight + 2 : 0));
	}

	@Override
	protected void render(GuiGraphicsExtractor g, Minecraft mc, boolean editing) {
		Font font = mc.font;
		int w = width.intValue();
		int barHeight = 14;
		float yaw = mc.player != null ? Mth.wrapDegrees(mc.player.getYRot()) : 0f;
		int center = w / 2;

		Ui.roundRect(g, 0, 0, w, barHeight, 4, Ui.HUD_BACKGROUND);
		g.enableScissor(0, 0, w, barHeight);
		// One tick every 15 degrees across the visible +-90 degrees
		int start = (int) Math.floor((yaw - 90) / 15) * 15;
		for (int angle = start; angle <= yaw + 90; angle += 15) {
			int x = center + Math.round((angle - yaw) / 90f * center);
			int normalized = Math.floorMod(angle, 360);
			if (normalized % 45 == 0) {
				String label = LABELS[normalized / 45];
				int color = label.equals("N") ? Ui.BAD : label.length() == 1 ? Ui.TEXT : Ui.MUTED;
				Ui.text(g, font, label, x - Ui.width(font, label) / 2, 3, color, true);
			} else {
				g.fill(x, 5, x + 1, 9, 0x59FFFFFF);
			}
		}

		if (waypoints.isOn() && mc.player != null && mc.level != null) {
			String dimension = mc.level.dimension().identifier().toString();
			for (Waypoint waypoint : WaypointManager.inDimension(dimension)) {
				double dx = waypoint.x() + 0.5 - mc.player.getX();
				double dz = waypoint.z() + 0.5 - mc.player.getZ();
				float bearing = (float) (Mth.atan2(dz, dx) * Mth.RAD_TO_DEG) - 90f;
				float diff = Mth.wrapDegrees(bearing - yaw);
				if (Math.abs(diff) <= 90) {
					int x = center + Math.round(diff / 90f * center);
					diamond(g, x, barHeight - 3, waypoint.color());
				}
			}
		}
		g.disableScissor();

		// Centre marker
		g.fill(center, 1, center + 1, barHeight - 1, Ui.accent());
		int height = barHeight;
		if (degrees.isOn()) {
			// Minecraft yaw 0 faces south; compass headings start at north
			String heading = Math.round(yaw + 180) % 360 + "°";
			Ui.text(g, font, heading, center - Ui.width(font, heading) / 2, barHeight + 2, Ui.MUTED, true);
			height += font.lineHeight + 2;
		}
		setSize(w, height);
	}

	private static void diamond(GuiGraphicsExtractor g, int x, int y, int color) {
		g.fill(x - 1, y - 3, x + 2, y + 3, color);
		g.fill(x - 2, y - 2, x + 3, y + 2, color);
		g.fill(x - 3, y - 1, x + 4, y + 1, color);
	}
}
