package dev.goonclient.client.tracker;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Rarity;

/** Counts what you pick up and works out rates per hour, for farms and grinding. Reset any time. */
public final class LootTracker {
	/** Worth noting even though the game rates them "common". */
	private static final Set<Item> VALUABLE = Set.of(Items.DIAMOND, Items.ANCIENT_DEBRIS, Items.NETHERITE_SCRAP, Items.NETHERITE_INGOT,
		Items.TOTEM_OF_UNDYING, Items.HEART_OF_THE_SEA, Items.TRIDENT, Items.ELYTRA, Items.NAUTILUS_SHELL, Items.WITHER_SKELETON_SKULL,
		Items.DRAGON_EGG, Items.NETHER_STAR, Items.HEAVY_CORE, Items.SNIFFER_EGG, Items.ENCHANTED_GOLDEN_APPLE, Items.SHULKER_SHELL);

	private static final Map<Item, Long> COUNTS = new LinkedHashMap<>();
	private static final Map<Item, ItemStack> ICONS = new LinkedHashMap<>();
	private static long startedAt;
    private static long startedEpochMs;
	private static int xpAtStart;
	private static int killsAtStart;
    private static long revision,cachedRevision=-1,cachedAt;
    private static List<Row> cachedAll=List.of(),cachedValuable=List.of();

	private LootTracker() {
	}

	public static void reset() {
		COUNTS.clear();
		ICONS.clear();
		startedAt = System.nanoTime();startedEpochMs=System.currentTimeMillis();revision++;
		xpAtStart = SessionStats.xpGained();
		killsAtStart = SessionStats.mobsKilled();
	}

	public static void onPickup(ItemStack stack, int amount) {
        if(stack.isEmpty()||amount<=0)return;
        revision++;
		if (startedAt == 0) {
			reset();
		}
		COUNTS.merge(stack.getItem(), (long) amount, Long::sum);
		ICONS.putIfAbsent(stack.getItem(), stack.copyWithCount(1));
	}

	public static boolean isValuable(ItemStack stack) {
		return VALUABLE.contains(stack.getItem()) || stack.getRarity() == Rarity.RARE || stack.getRarity() == Rarity.EPIC;
	}

	/** Items by amount collected, most first. */
	public static List<Row> rows(boolean valuableOnly) {
        long now=System.nanoTime();
        if(cachedRevision!=revision||now-cachedAt>=500_000_000L) {
            List<Row> rows=new ArrayList<>(COUNTS.size());
            for(var entry:COUNTS.entrySet())rows.add(new Row(ICONS.get(entry.getKey()),entry.getValue(),perHour(entry.getValue())));
            rows.sort(Comparator.comparingLong(Row::count).reversed());
            cachedAll=List.copyOf(rows);cachedValuable=rows.stream().filter(row->isValuable(row.icon())).toList();
            cachedRevision=revision;cachedAt=now;
        }
        return valuableOnly?cachedValuable:cachedAll;
	}

	public static long startedEpochMs(){return startedEpochMs;}

    public static long elapsedMs() {
		return startedAt == 0 ? 0 : Math.max(0,(System.nanoTime() - startedAt)/1_000_000L);
	}

	/** Rate per hour; the first minute counts as a full minute so a lucky first pickup doesn't read as thousands per hour. */
	public static long perHour(long count) {
		return count * 3_600_000L / Math.max(60_000L, elapsedMs());
	}

	public static int xpGained() {
		return startedAt == 0 ? 0 : Math.max(0,SessionStats.xpGained() - xpAtStart);
	}

	public static int kills() {
		return startedAt == 0 ? 0 : Math.max(0,SessionStats.mobsKilled() - killsAtStart);
	}

	public record Row(ItemStack icon, long count, long perHour) {
	}
}
