package dev.goonclient.client.modules.hud;

/** Small text formatting helpers shared by the HUD modules. */
public final class Text {
	private Text() {
	}

	/** "dark_forest" -> "Dark Forest" */
	public static String prettify(String id) {
		StringBuilder out = new StringBuilder();
		for (String word : id.split("_")) {
			if (!word.isEmpty()) {
				out.append(out.isEmpty() ? "" : " ").append(Character.toUpperCase(word.charAt(0))).append(word.substring(1));
			}
		}
		return out.toString();
	}

	public static String roman(int number) {
		return switch (number) {
			case 1 -> "I";
			case 2 -> "II";
			case 3 -> "III";
			case 4 -> "IV";
			case 5 -> "V";
			case 6 -> "VI";
			case 7 -> "VII";
			case 8 -> "VIII";
			case 9 -> "IX";
			case 10 -> "X";
			default -> Integer.toString(number);
		};
	}

	/** Ticks as m:ss, or h:mm:ss for long durations. */
	public static String ticks(int ticks) {
		int seconds = ticks / 20;
		int hours = seconds / 3600;
		int minutes = (seconds % 3600) / 60;
		int secs = seconds % 60;
		return hours > 0 ? String.format("%d:%02d:%02d", hours, minutes, secs) : String.format("%d:%02d", minutes, secs);
	}
}
