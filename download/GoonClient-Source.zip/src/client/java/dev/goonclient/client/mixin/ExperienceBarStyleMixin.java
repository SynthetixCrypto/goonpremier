package dev.goonclient.client.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.mojang.renderpearl.api.pipeline.RenderPipeline;
import dev.goonclient.client.gui.Ui;
import dev.goonclient.client.gui.render.Shapes;
import dev.goonclient.client.modules.utility.Interface;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.contextualbar.ExperienceBar;
import net.minecraft.resources.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

/** With the glass hotbar on, the XP bar becomes a rounded dark track with an accent fill. The level number stays vanilla. */
@Mixin(ExperienceBar.class)
public abstract class ExperienceBarStyleMixin {
	@WrapOperation(method = "extractBackground", at = @At(value = "INVOKE",
		target = "Lnet/minecraft/client/gui/GuiGraphicsExtractor;blitSprite(Lcom/mojang/renderpearl/api/pipeline/RenderPipeline;Lnet/minecraft/resources/Identifier;IIII)V"))
	private void goonclient$track(GuiGraphicsExtractor g, RenderPipeline pipeline, Identifier sprite, int x, int y, int width, int height, Operation<Void> original) {
		if (!Interface.glassHotbar()) {
			original.call(g, pipeline, sprite, x, y, width, height);
			return;
		}
		Shapes.panel(g, x, y, x + width, y + height, height / 2f, 0xB01E1A20, 0x30FFFFFF);
	}

	@WrapOperation(method = "extractBackground", at = @At(value = "INVOKE",
		target = "Lnet/minecraft/client/gui/GuiGraphicsExtractor;blitSprite(Lcom/mojang/renderpearl/api/pipeline/RenderPipeline;Lnet/minecraft/resources/Identifier;IIIIIIII)V"))
	private void goonclient$progress(GuiGraphicsExtractor g, RenderPipeline pipeline, Identifier sprite, int textureWidth, int textureHeight, int u, int v,
		int x, int y, int width, int height, Operation<Void> original) {
		if (!Interface.glassHotbar()) {
			original.call(g, pipeline, sprite, textureWidth, textureHeight, u, v, x, y, width, height);
			return;
		}
		if (width > 0) Shapes.roundRect(g, x, y, x + Math.max(height, width), y + height, height / 2f, Ui.accent());
	}
}
