package dev.goonclient.client.gui.render;

import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.renderpearl.api.textures.FilterMode;
import net.minecraft.client.renderer.texture.DynamicTexture;

/** A generated texture sampled with linear filtering (Minecraft's default is nearest, which looks pixelated when scaled). */
final class SmoothTexture extends DynamicTexture {
	SmoothTexture(String name, NativeImage pixels) {
		super(() -> name, pixels);
		this.sampler = RenderSystem.getSamplerCache().getClampToEdge(FilterMode.LINEAR);
		upload();
	}
}
