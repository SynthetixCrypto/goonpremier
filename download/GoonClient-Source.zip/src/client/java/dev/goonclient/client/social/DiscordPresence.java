package dev.goonclient.client.social;

import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.Closeable;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.net.StandardProtocolFamily;
import java.net.UnixDomainSocketAddress;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.SocketChannel;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.LinkedHashSet;
import java.util.Properties;
import java.util.UUID;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/** Native-free Discord IPC. Only generic game activity crosses the local pipe; no account or server data. */
public final class DiscordPresence {
    private record Activity(String state,boolean timer) {}
    private static final ScheduledExecutorService WORKER=Executors.newSingleThreadScheduledExecutor(r->{Thread t=new Thread(r,"Goon Discord presence");t.setDaemon(true);return t;});
    private static final long START=System.currentTimeMillis()/1000;
    private static volatile Activity wanted;
    private static volatile String status="Off", applicationId="";
    private static final java.util.concurrent.atomic.AtomicReference<Connection> CONNECTION = new java.util.concurrent.atomic.AtomicReference<>();
    private static long retryAt;
    private static Activity sent;
    private static long connectedAt;
    private DiscordPresence() {}
    public static void init(){
        try(InputStream in=DiscordPresence.class.getResourceAsStream("/goon-discord.properties")){if(in!=null){Properties p=new Properties();p.load(in);applicationId=p.getProperty("application_id","").trim();}}
        catch(IOException ignored){}
        WORKER.scheduleWithFixedDelay(DiscordPresence::pump,0,3,TimeUnit.SECONDS);
    }
    public static void update(boolean enabled,String state,boolean timer){wanted=enabled?new Activity(state,timer):null;}
    public static String status(){return status;}
    public static String applicationId(){return applicationId;}
    public static void stop(){wanted=null;WORKER.execute(()->{drop(true);status="Off";WORKER.shutdown();});}
    private static void pump(){
        try{
            Activity next=wanted;
            if(next==null){drop(true);status="Off";return;}
            if(!applicationId.matches("[0-9]{17,20}")){status="Application ID not configured";drop(false);return;}
            long now=System.nanoTime();
            if(CONNECTION.get()==null){
                if(now<retryAt)return;
                retryAt=now+TimeUnit.SECONDS.toNanos(15);
                status="Looking for Discord desktop…";
                Connection c=connect();CONNECTION.set(c);connectedAt=now;sent=null;
                JsonObject hello=new JsonObject();hello.addProperty("v",1);hello.addProperty("client_id",applicationId);c.send(0,hello.toString().getBytes(StandardCharsets.UTF_8));
                Thread reader=new Thread(()->read(c),"Goon Discord replies");reader.setDaemon(true);reader.start();
            }
            Connection c=CONNECTION.get();
            if(c!=null&&!c.ready&&now-connectedAt>TimeUnit.SECONDS.toNanos(12)){status="Discord did not accept the connection";drop(false);return;}
            if(c!=null&&c.ready&&!next.equals(sent)){c.send(1,command(next));sent=next;status="Updating presence…";}
        }catch(IOException|RuntimeException e){drop(false);status="Discord desktop unavailable; retrying automatically";}
    }
    private static byte[] command(Activity activity){
        JsonObject args=new JsonObject();args.addProperty("pid",ProcessHandle.current().pid());
        if(activity==null)args.add("activity",JsonNull.INSTANCE);
        else{
            JsonObject a=new JsonObject();a.addProperty("type",0);a.addProperty("details","Goon Client · Minecraft 26.3");a.addProperty("state",activity.state);
            if(activity.timer){JsonObject ts=new JsonObject();ts.addProperty("start",START);a.add("timestamps",ts);}
            args.add("activity",a);
        }
        JsonObject request=new JsonObject();request.addProperty("cmd","SET_ACTIVITY");request.add("args",args);request.addProperty("nonce",UUID.randomUUID().toString());
        return request.toString().getBytes(StandardCharsets.UTF_8);
    }
    private static void read(Connection c){
        try{
            while(CONNECTION.get()==c){
                byte[] head=new byte[8];c.transport.readFully(head);ByteBuffer b=ByteBuffer.wrap(head).order(ByteOrder.LITTLE_ENDIAN);int opcode=b.getInt(),length=b.getInt();
                if(length<0||length>65536)throw new IOException("Invalid Discord frame");
                byte[] payload=new byte[length];c.transport.readFully(payload);
                if(opcode==3){c.send(4,payload);continue;}
                if(opcode==2)throw new EOFException();
                if(opcode!=1)continue;
                JsonObject event=JsonParser.parseString(new String(payload,StandardCharsets.UTF_8)).getAsJsonObject();
                String evt=event.has("evt")&&!event.get("evt").isJsonNull()?event.get("evt").getAsString():"";
                if("READY".equals(evt)){c.ready=true;if(CONNECTION.get()==c)status="Discord connected";}
                else if("ERROR".equals(evt)){if(CONNECTION.get()==c)status="Discord rejected presence. Check the application's settings.";throw new IOException("Discord rejected command");}
                else if(event.has("cmd")&&"SET_ACTIVITY".equals(event.get("cmd").getAsString())&&CONNECTION.get()==c)status="Presence active";
            }
        }catch(IOException|RuntimeException ignored){
            // The scheduler owns reconnects. Closing the transport unblocks the reader without touching the game thread.
            if(CONNECTION.compareAndSet(c,null)){if(wanted!=null&&!status.startsWith("Discord rejected"))status="Discord disconnected; reconnecting…";}
            try{c.transport.close();}catch(IOException ignoredClose){}
        }
    }
    private static void drop(boolean clear){Connection c=CONNECTION.getAndSet(null);sent=null;if(c!=null){try{if(clear&&c.ready)c.send(1,command(null));}catch(IOException ignored){}try{c.transport.close();}catch(IOException ignored){}}}
    private static Connection connect()throws IOException{
        if(System.getProperty("os.name").toLowerCase(java.util.Locale.ROOT).startsWith("windows")){
            for(int n=0;n<10;n++)try{return new Connection(new Pipe(new RandomAccessFile("\\\\?\\pipe\\discord-ipc-"+n,"rw")));}catch(IOException ignored){}
        }else{
            var roots=new LinkedHashSet<String>();for(String key:new String[]{"XDG_RUNTIME_DIR","TMPDIR","TMP","TEMP"}){String value=System.getenv(key);if(value!=null&&!value.isBlank())roots.add(value);}roots.add("/tmp");
            for(String root:roots)for(int n=0;n<10;n++){
                SocketChannel channel=null;
                try{channel=SocketChannel.open(StandardProtocolFamily.UNIX);channel.connect(UnixDomainSocketAddress.of(Path.of(root,"discord-ipc-"+n)));return new Connection(new Unix(channel));}
                catch(IOException e){if(channel!=null)try{channel.close();}catch(IOException ignored){}}
            }
        }
        throw new IOException("Discord desktop not found");
    }
    private interface Transport extends Closeable{void readFully(byte[] bytes)throws IOException;void write(byte[] bytes)throws IOException;}
    /**
     * Windows named pipe. Windows serializes synchronous I/O on one pipe handle, so a read blocked waiting for Discord
     * would stall every write queued behind it (and Discord never answers a command it never received). Read only once
     * bytes are waiting: length() reports the pipe's unread byte count.
     */
    private record Pipe(RandomAccessFile file)implements Transport{
        public void readFully(byte[] bytes)throws IOException{
            int offset=0;
            while(offset<bytes.length){
                long available=file.length();
                if(available<=0){
                    try{Thread.sleep(20);}catch(InterruptedException e){Thread.currentThread().interrupt();throw new java.io.InterruptedIOException();}
                    continue;
                }
                int read=file.read(bytes,offset,(int)Math.min(available,bytes.length-offset));
                if(read<0)throw new EOFException();
                offset+=read;
            }
        }
        public void write(byte[] bytes)throws IOException{file.write(bytes);}
        public void close()throws IOException{file.close();}
    }
    private record Unix(SocketChannel channel)implements Transport{public void readFully(byte[] bytes)throws IOException{ByteBuffer b=ByteBuffer.wrap(bytes);while(b.hasRemaining())if(channel.read(b)<0)throw new EOFException();}public void write(byte[] bytes)throws IOException{ByteBuffer b=ByteBuffer.wrap(bytes);while(b.hasRemaining())channel.write(b);}public void close()throws IOException{channel.close();}}
    private static final class Connection{final Transport transport;volatile boolean ready;Connection(Transport transport){this.transport=transport;}synchronized void send(int opcode,byte[] bytes)throws IOException{ByteBuffer b=ByteBuffer.allocate(8+bytes.length).order(ByteOrder.LITTLE_ENDIAN);b.putInt(opcode).putInt(bytes.length).put(bytes);transport.write(b.array());}}
}
