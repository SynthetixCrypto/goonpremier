package dev.goonclient.client.modules.combat;

import dev.goonclient.client.gui.render.Icons;
import dev.goonclient.client.hud.HudPosition;
import dev.goonclient.client.gui.Ui;
import dev.goonclient.client.hud.TextHudModule;
import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.setting.BooleanSetting;
import dev.goonclient.client.modules.hud.Text;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;

/** Active effects with time remaining. */
public class PotionHud extends TextHudModule {
	private final BooleanSetting effectColors = add(new BooleanSetting("effect_colors", "Colour by effect", false));

	private final BooleanSetting expiryAlerts = add(new BooleanSetting("expiry_alerts", "Warn before beneficial effects expire", false));
	private final dev.goonclient.client.module.setting.NumberSetting warningSeconds = add(new dev.goonclient.client.module.setting.NumberSetting("warning_seconds", "Expiry warning", 10, 3, 30, 1, "s"));
	private final java.util.Set<net.minecraft.core.Holder<MobEffect>> warned = new java.util.HashSet<>();

	@Override public void onTick(Minecraft mc) {
		if (mc.player == null || !expiryAlerts.isOn()) { warned.clear(); return; }
		var effects = mc.player.getActiveEffects();
		warned.removeIf(key -> effects.stream().noneMatch(e -> e.getEffect().equals(key)));
		for (var effect : effects) {
			var key = effect.getEffect(); int duration = effect.getDuration(), threshold = warningSeconds.intValue()*20;
			if (duration > threshold || effect.isInfiniteDuration()) { warned.remove(key); continue; }
			if (duration > 0 && key.value().isBeneficial() && warned.add(key))
				dev.goonclient.client.modules.hud.FeedbackHud.post("effect:"+key.unwrapKey().map(Object::toString).orElse(key.toString()), key.value().getDisplayName().getString(), "Expires in " + Text.ticks(duration), false);
		}
	}
	@Override protected void onDisable() { warned.clear(); }

	public PotionHud() {
		super("potions", "Potion Effects", "Active effects with level and time left", Category.COMBAT, true, HudPosition.topLeft(4, 45));
	}

	@Override
	protected Icons.Icon icon() {
		return Icons.Icon.FLASK;
	}

	@Override
	protected String title() {
		return "Potions";
	}

	@Override
	protected String countLabel() {
		return "Active";
	}

	@Override
	public boolean isVisible(Minecraft mc) {
		return mc.player != null && !mc.player.getActiveEffects().isEmpty();
	}

	@Override
	protected void collect(Minecraft mc, List<Line> lines, boolean editing) {
		List<MobEffectInstance> effects = mc.player != null ? new ArrayList<>(mc.player.getActiveEffects()) : new ArrayList<>();
		if (effects.isEmpty()) {
			if (editing) {
				lines.add(new Line("Speed II", "1:30", Ui.MUTED, Ui.TEXT));
				lines.add(new Line("Fire Resistance", "7:45", Ui.MUTED, Ui.TEXT));
				lines.add(new Line("Poison", "0:12", Ui.WARN, Ui.BAD));
			}
			return;
		}
		effects.sort(Comparator.comparingInt(MobEffectInstance::getDuration));
		for (MobEffectInstance instance : effects) {
			MobEffect effect = instance.getEffect().value();
			String name = effect.getDisplayName().getString();
			if (instance.getAmplifier() > 0) {
				name += " " + Text.roman(instance.getAmplifier() + 1);
			}
			String time = instance.isInfiniteDuration() ? "∞" : Text.ticks(instance.getDuration());
			int nameColor = effectColors.isOn() ? 0xFF000000 | effect.getColor() : effect.isBeneficial() ? Ui.TEXT : Ui.BAD;
			// The time turns amber for the last 10 seconds
			int timeColor = !instance.isInfiniteDuration() && instance.getDuration() <= warningSeconds.intValue()*20 ? Ui.WARN : Ui.MUTED;
			lines.add(new Line(name, time, timeColor, nameColor).withIcon(net.minecraft.client.gui.Hud.getMobEffectSprite(instance.getEffect())));
		}
	}
}
