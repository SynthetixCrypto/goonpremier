package dev.goonclient.client.modules.hud;

import dev.goonclient.client.hud.TextHudModule.Segment;
import dev.goonclient.client.gui.render.Icons;
import dev.goonclient.client.hud.HudPosition;
import dev.goonclient.client.gui.Ui;
import dev.goonclient.client.hud.TextHudModule;
import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.setting.BooleanSetting;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.Level;

public class CoordinatesHud extends TextHudModule {
	private final BooleanSetting compact = add(new BooleanSetting("compact", "One-line pill", true));
	private final BooleanSetting otherDimension = add(new BooleanSetting("other_dimension", "Nether/Overworld coords", true));
	private final BooleanSetting facing = add(new BooleanSetting("facing", "Facing", true));
	private final BooleanSetting biome = add(new BooleanSetting("biome", "Biome", true));

	public CoordinatesHud() {
		super("coordinates", "Coordinates", "Position, matching Nether/Overworld coords, facing and biome", Category.HUD, true, new HudPosition(0, 1, 1, -5, 0, 1));
	}

	@Override
	protected Icons.Icon icon() {
		return Icons.Icon.SATELLITE;
	}

	@Override
	protected void collect(Minecraft mc, List<Line> lines, boolean editing) {
		if (mc.player == null || mc.level == null) {
			lines.add(compact.isOn() ? pill(128, 64, -256, " [16 -32]") : new Line("XYZ", "128 64 -256"));
			return;
		}
		BlockPos pos = mc.player.blockPosition();
		if (compact.isOn()) {
			// "x -101 y 6 z -236 [-12 -29]": the bracket is the matching Nether (or Overworld) position
			String other = "";
			if (otherDimension.isOn() && mc.level.dimension() == Level.OVERWORLD) {
				other = " [" + Math.floorDiv(pos.getX(), 8) + " " + Math.floorDiv(pos.getZ(), 8) + "]";
			} else if (otherDimension.isOn() && mc.level.dimension() == Level.NETHER) {
				other = " [" + pos.getX() * 8 + " " + pos.getZ() * 8 + "]";
			}
			lines.add(pill(pos.getX(), pos.getY(), pos.getZ(), other));
			return;
		}
		lines.add(new Line("XYZ", pos.getX() + " " + pos.getY() + " " + pos.getZ()));
		if (otherDimension.isOn()) {
			if (mc.level.dimension() == Level.OVERWORLD) {
				lines.add(new Line("Nether", Math.floorDiv(pos.getX(), 8) + " " + Math.floorDiv(pos.getZ(), 8), Ui.MUTED));
			} else if (mc.level.dimension() == Level.NETHER) {
				lines.add(new Line("Overworld", pos.getX() * 8 + " " + pos.getZ() * 8, Ui.MUTED));
			}
		}
		if (facing.isOn()) {
			lines.add(new Line("Facing", facingText(mc.player.getDirection())));
		}
		if (biome.isOn()) {
			lines.add(new Line("Biome", mc.level.getBiome(pos).unwrapKey().map(key -> Text.prettify(key.identifier().getPath())).orElse("Unknown")));
		}
	}

	/**
	 * Combatant's Coordinates layout: labels and values drawn 1.6 / 3.2 units apart (compact_stat.js coordinatesRow)
	 * while the box is measured with Coordinates.java's 2 / 8-unit gaps, and 4 units narrower with the nether pair.
	 */
	private static Line pill(int x, int y, int z, String other) {
		List<Segment> parts = new java.util.ArrayList<>(List.of(
			Segment.label("x"), Segment.value(Integer.toString(x)).gap(1.6f, 2),
			Segment.label("y").gap(3.2f, 8), Segment.value(Integer.toString(y)).gap(1.6f, 2),
			Segment.label("z").gap(3.2f, 8), Segment.value(Integer.toString(z)).gap(1.6f, 2)));
		String extra = other.strip();
		if (!extra.isEmpty()) parts.add(Segment.extra(extra).gap(3.2f, 4));
		return Line.rich(parts);
	}

	private static String facingText(Direction direction) {
		String axis = switch (direction) {
			case NORTH -> "-Z";
			case SOUTH -> "+Z";
			case EAST -> "+X";
			case WEST -> "-X";
			default -> "";
		};
		return Text.prettify(direction.getName()) + " (" + axis + ")";
	}
}
