package dev.goonclient.client.config;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.serialization.JsonOps;
import dev.goonclient.Goon;
import dev.goonclient.client.module.ModuleManager;
import dev.goonclient.client.module.setting.Setting;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.CloudStatus;
import net.minecraft.client.GraphicsPreset;
import net.minecraft.client.Minecraft;
import net.minecraft.client.OptionInstance;
import net.minecraft.server.level.ParticleStatus;

/** One-shot changes with a durable undo, rather than a toggle that fights the player's video settings. */
public final class PerformancePreset {
	private static boolean restoring;

	public static boolean restoring() {
		return restoring;
	}
	private PerformancePreset() {
	}

	private static Path backup() {
		return ConfigManager.dir().resolve("performance-backup.json");
	}

	public static boolean canRestore() {
		return Files.isRegularFile(backup());
	}

	private record Change<T>(String id, OptionInstance<T> option, T value) {
		JsonElement current() {
			return option.codec().encodeStart(JsonOps.INSTANCE, option.get()).getOrThrow();
		}

		Runnable restore(JsonElement json) {
			T saved = option.codec().parse(JsonOps.INSTANCE, json).getOrThrow();
			return () -> option.set(saved);
		}

		void apply() {
			option.set(value);
		}
	}

	private static List<Change<?>> changes(Minecraft mc) { return changes(mc,false); }
	private static List<Change<?>> changes(Minecraft mc,boolean maximumFps) {
		var o = mc.options;
		return List.of(new Change<>("render", o.renderDistance(), Math.min(8, o.renderDistance().get())),
			new Change<>("simulation", o.simulationDistance(), Math.min(5, o.simulationDistance().get())),
			new Change<>("entities", o.entityDistanceScaling(), Math.min(0.75, o.entityDistanceScaling().get())),
			new Change<>("fps", o.framerateLimit(), maximumFps?260:Math.min(90, o.framerateLimit().get())),
			new Change<>("vsync",o.enableVsync(),maximumFps?false:o.enableVsync().get()),
			new Change<>("clouds", o.cloudStatus(), CloudStatus.OFF),
			new Change<>("particles", o.particles(), o.particles().get() == ParticleStatus.MINIMAL ? ParticleStatus.MINIMAL : ParticleStatus.DECREASED),
			new Change<>("shadows", o.entityShadows(), false),
			new Change<>("ao", o.ambientOcclusion(), false),
			new Change<>("leaves", o.cutoutLeaves(), true),
			new Change<>("biome", o.biomeBlendRadius(), 0),
			new Change<>("blur", o.menuBackgroundBlurriness(), 0),
			new Change<>("graphics_preset", o.graphicsPreset(), GraphicsPreset.CUSTOM));
	}

	private static List<Setting<?>> interfaceSettings() {
		return ModuleManager.all().stream().filter(m -> m.id().equals("interface")).findFirst().orElseThrow()
			.settings().stream().filter(s -> s.id().equals("menu_blur") || s.id().equals("menu_background")).toList();
	}

	public static String apply(Minecraft mc) {return apply(mc,false);}
	public static String apply(Minecraft mc,boolean maximumFps) {
		try {
			var changes = changes(mc,maximumFps);
			if (!canRestore()) {
				JsonObject root = new JsonObject();
				for (var change : changes) root.add(change.id(), change.current());
				for (var setting : interfaceSettings()) root.add(setting.id(), setting.toJson());
				Files.createDirectories(backup().getParent());
				Path temp = backup().resolveSibling("performance-backup.json.tmp");
				Files.writeString(temp, ConfigManager.GSON.toJson(root));
				Files.move(temp, backup(), StandardCopyOption.ATOMIC_MOVE);
			}
			changes.forEach(Change::apply);
			for (var setting : interfaceSettings()) {
				setting.fromJson(JsonParser.parseString(setting.id().equals("menu_blur") ? "0" : "\"Solid\""));
			}
			mc.options.save();
			ConfigManager.save();
			return "Applied. Your previous settings are saved for Restore.";
		} catch (Exception e) {
			Goon.LOGGER.error("Couldn't apply performance preset", e);
			return "Couldn't apply the preset. See logs/latest.log.";
		}
	}

	public static String restore(Minecraft mc) {
		if (!canRestore()) return "No saved settings to restore yet.";
		try {
			JsonObject root = JsonParser.parseString(Files.readString(backup())).getAsJsonObject();
			List<Runnable> actions = new ArrayList<>();
			// Decode every vanilla value before changing anything, so a broken backup doesn't half-restore.
			for (var change : changes(mc)) {
                if(!root.has(change.id())&&change.id().equals("vsync")) continue; // Backups from earlier releases did not touch VSync.
                actions.add(change.restore(root.get(change.id())));
            }
			for (var setting : interfaceSettings()) {
				JsonElement value = root.get(setting.id());
				if (value == null || !value.isJsonPrimitive()) throw new IllegalStateException("Missing " + setting.id());
				actions.add(() -> setting.fromJson(value));
			}
			restoring = true;
			try {
				actions.forEach(Runnable::run);
			} finally {
				restoring = false;
			}
			mc.options.save();
			ConfigManager.save();
			Files.delete(backup());
			return "Restored your previous video and interface settings.";
		} catch (Exception e) {
			Goon.LOGGER.error("Couldn't restore performance preset", e);
			return "Couldn't restore settings. The backup has been kept.";
		}
	}
}
