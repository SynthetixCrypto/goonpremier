package dev.goonclient.client.hud;

import dev.goonclient.client.config.ConfigManager;
import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.Module;
import dev.goonclient.client.module.setting.NumberSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.ChatComponent;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.ChatVisiblity;

/**
 * A module that draws on the HUD and can be dragged in the HUD editor.
 * Position = an anchor (0 = left/top, 0.5 = centre, 1 = right/bottom) plus a pixel offset from it,
 * so elements keep the same distance from their edge at any resolution or GUI scale.
 */
public abstract class HudModule extends Module {
	private static final List<HudLayout.Rect> PLACED = new ArrayList<>();
	private static final List<HudLayout.Rect> OBSTACLES = new ArrayList<>();

	private final HudPosition defaultPosition;
	private HudPosition position;
	public final NumberSetting scale;

	private int width = 40;
	private int height = 12;
	private int screenX;
	private int screenY;
	private int screenWidth;
	private int screenHeight;

	protected HudModule(String id, String name, String description, Category category, boolean enabledByDefault, HudPosition defaultPosition) {
		super(id, name, description, category, enabledByDefault);
		this.defaultPosition = defaultPosition;
		this.position = defaultPosition;
		this.scale = add(new NumberSetting("scale", "Scale", 1.0, 0.5, 2.0, 0.05, "x"));
	}

	/** Draws the element at the origin. Must call {@link #setSize} with the size it drew. */
	protected abstract void render(GuiGraphicsExtractor g, Minecraft mc, boolean editing);

	/** Native external HUDs measure before placement and draw in screen coordinates. */
	protected void measure(Minecraft mc, boolean editing) { }
	/** Overrides must remain safe before registries/item components are bound. */
	protected void measurePreview(Minecraft mc) { HudPreview.measure(this, mc); }
	protected void renderPreview(GuiGraphicsExtractor g, Minecraft mc) { HudPreview.render(this, g, mc, width, height); }
	protected boolean absoluteCoordinates() { return false; }
	public boolean isLayoutObstacle() { return false; }

	/** Extra vertical shift applied outside the editor, e.g. to make room for boss bars. */
	protected int dynamicOffsetY(Minecraft mc) {
		return 0;
	}

	/** Whether the element has something to show right now (the editor always shows it). */
	public boolean isVisible(Minecraft mc) {
		return true;
	}

	public final void renderAt(GuiGraphicsExtractor g, Minecraft mc, int guiWidth, int guiHeight, boolean editing) {
		boolean preview = editing && (mc.player == null || mc.level == null);
		if (preview) measurePreview(mc);
		else measure(mc, editing);
		float s = scale.floatValue();
		screenWidth = Math.round(width * s);
		screenHeight = Math.round(height * s);
		screenX = Mth.clamp(position.x(guiWidth, screenWidth), 0, Math.max(0, guiWidth - screenWidth));
		int shift = editing ? 0 : dynamicOffsetY(mc);
		int maxY = Math.max(0, guiHeight - screenHeight);
		int baseY = Mth.clamp(position.y(guiHeight, screenHeight) + shift, 0, maxY);
		boolean solid = screenWidth > 2 && screenHeight > 2;
		var preferred = new HudLayout.Rect(screenX, baseY, screenWidth, screenHeight);
		// A panel the player placed stays exactly where they put it (in the editor and in game). Only the default
		// flow makes room around obstacles and around other panels.
		var placed = solid && !isLayoutObstacle() && !isMoved()
			? HudLayout.place(preferred, guiWidth, guiHeight, PLACED, OBSTACLES) : preferred;
		screenX = placed.x();
		screenY = placed.y();
		if (solid) {
			PLACED.add(placed);
			if (isLayoutObstacle()) OBSTACLES.add(placed);
		}
		if (!preview && absoluteCoordinates()) {
			render(g, mc, editing);
			return;
		}
		g.pose().pushMatrix();
		g.pose().translate(screenX, screenY);
		g.pose().scale(s, s);
		try {
			if (preview) renderPreview(g, mc);
			else render(g, mc, editing);
		} finally {
			g.pose().popMatrix();
		}
	}

	/** Starts a new frame of HUD layout. Call before drawing the modules from {@link #layoutOrder}. */
	public static void beginLayout(int guiWidth, int guiHeight) {
		PLACED.clear();
		OBSTACLES.clear();
		// Overflow must also clear the vanilla hotbar, XP and survival bars.
		reserveNative(new HudLayout.Rect(guiWidth / 2 - 92, guiHeight - 50, 184, 50));
		// Never stack an overflowing panel over where the player aims
		reserveNative(new HudLayout.Rect(guiWidth / 2 - 24, guiHeight / 2 - 24, 48, 48));
		reserveVanillaChat(guiWidth, guiHeight);
	}

	/** Reserve the native chat's configured footprint before default Goon panels are auto-stacked. */
	private static void reserveVanillaChat(int guiWidth, int guiHeight) {
		Minecraft mc = Minecraft.getInstance();
		if (mc.player == null || mc.level == null) return;
		var options = mc.options;
		if (options.chatVisibility().get() == ChatVisiblity.HIDDEN) return;
		var visible = ChatFootprint.visible();
        if (visible != null && visible.width() > 0 && visible.height() > 0) reserveNative(visible);
		// The input line along the bottom while chat is open
		if (mc.gui.screen() instanceof net.minecraft.client.gui.screens.ChatScreen) reserveNative(new HudLayout.Rect(0, guiHeight - 16, guiWidth, 16));
	}

	/** Additional native labels are extracted before the remaining panels and reserve their real transformed bounds. */
	public static void reserveNative(HudLayout.Rect rect) {
		PLACED.add(rect);
		OBSTACLES.add(rect);
	}

	/**
	 * Native obstacles reserve space first, then player placements. Panels at their default spot stack around them, the
	 * ones that only show up now and then (Mob Info, pickups) last, so they never shove the permanent ones around.
	 */
	public static List<HudModule> layoutOrder(List<HudModule> modules) {
		List<HudModule> ordered = new ArrayList<>(modules.size());
		for (HudModule module : modules) {
			if (module.isLayoutObstacle()) ordered.add(module);
		}
		for (HudModule module : modules) {
			if (!module.isLayoutObstacle() && module.isMoved()) {
				ordered.add(module);
			}
		}
		for (HudModule module : modules) {
			if (!module.isLayoutObstacle() && !module.isMoved() && !module.isTransient()) {
				ordered.add(module);
			}
		}
		for (HudModule module : modules) {
			if (!module.isLayoutObstacle() && !module.isMoved() && module.isTransient()) {
				ordered.add(module);
			}
		}
		return ordered;
	}

	/** Panels that come and go (popups, warnings, the target you're looking at). They make room for the rest. */
	protected boolean isTransient() {
		return false;
	}

	/** True once the player has dragged the element somewhere other than its default spot. */
	public boolean isMoved() {
		return !position.equals(defaultPosition);
	}

	protected void setSize(int width, int height) {
		this.width = Math.max(1, width);
		this.height = Math.max(1, height);
	}

	/** Moves the element so its top-left corner lands here, re-anchoring it to the closest edge or centre. */
	public void moveTo(int left, int top, int guiWidth, int guiHeight) {
		setPosition(HudPosition.fromScreen(left, top, screenWidth, screenHeight, guiWidth, guiHeight));
	}

	public void setPosition(HudPosition position) {
		this.position = position;
		ConfigManager.markDirty();
	}

	public HudPosition position() {
		return position;
	}

	public HudPosition defaultPosition() {
		return defaultPosition;
	}

	public void resetPosition() {
		setPosition(defaultPosition);
		scale.reset();
	}

	public int screenX() {
		return screenX;
	}

	public int screenY() {
		return screenY;
	}

	public int screenWidth() {
		return screenWidth;
	}

	public int screenHeight() {
		return screenHeight;
	}

	public boolean contains(double mx, double my) {
		return mx >= screenX && mx < screenX + screenWidth && my >= screenY && my < screenY + screenHeight;
	}
}
