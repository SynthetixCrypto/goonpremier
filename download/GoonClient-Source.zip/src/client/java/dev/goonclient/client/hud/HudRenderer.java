package dev.goonclient.client.hud;

import dev.goonclient.Goon;
import dev.goonclient.client.gui.HudEditorScreen;
import dev.goonclient.client.gui.Ui;
import dev.goonclient.client.module.ModuleManager;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/** One Fabric HUD layer that draws every enabled Goon Client HUD module. */
public final class HudRenderer {
	private static boolean hidden;

	private HudRenderer() {
	}

	public static void register() {
		HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT, Goon.id("hud"), HudRenderer::extract);
	}

	public static void toggleHidden() {
		hidden = !hidden;
	}

	private static void extract(GuiGraphicsExtractor g, DeltaTracker deltaTracker) {
		Minecraft mc = Minecraft.getInstance();
		Ui.beginFrame();
		if (hidden || mc.player == null || mc.getDebugOverlay().showDebugScreen() || mc.gui.screen() instanceof HudEditorScreen) {
			return;
		}
		HudModule.beginLayout(g.guiWidth(), g.guiHeight());
		for (HudModule module : HudModule.layoutOrder(ModuleManager.hudModules())) {
			if (module.isEnabled() && module.isVisible(mc)) {
				module.renderAt(g, mc, g.guiWidth(), g.guiHeight(), false);
			}
		}
	}
}
