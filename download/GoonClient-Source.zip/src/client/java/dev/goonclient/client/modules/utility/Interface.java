package dev.goonclient.client.modules.utility;

import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.Module;
import dev.goonclient.client.gui.render.Backdrop;
import dev.goonclient.client.module.setting.BooleanSetting;
import dev.goonclient.client.module.setting.ButtonSetting;
import dev.goonclient.client.module.setting.ModeSetting;
import dev.goonclient.client.module.setting.NumberSetting;

/** How Goon Client itself looks: accent colour, blur behind its screens, panel opacity, menu background and menus. */
public class Interface extends Module {
	public static final int DEFAULT_ACCENT = 0xFF3DDC97;
	private static Interface instance;

	// New setting ids (accent_color, blur_strength, panel_opacity) so the old gradient-theme values don't carry over
	// "theme" replaces the old accent_color setting, so everyone starts on the new default theme
	private final ModeSetting accent = add(new ModeSetting("theme", "Theme", dev.goonclient.client.gui.Themes.DEFAULT, dev.goonclient.client.gui.Themes.names()));
	private final ModeSetting hudArrangement = add(new ModeSetting("hud_arrangement", "HUD arrangement", "Auto", "Auto", "Manual"));
	private final BooleanSetting hints = add(new BooleanSetting("hints", "Key hints in menus", true));
	// "menu_blur" (new id, default 2) keeps the world readable behind the glass panels
	private final NumberSetting blur = add(new NumberSetting("menu_blur", "Background blur", 2, 0, 10, 1));
	private final NumberSetting opacity = add(new NumberSetting("panel_opacity", "Panel opacity", 97, 60, 100, 1, "%"));
	private final ModeSetting material = add(new ModeSetting("menu_material", "ClickGUI material", "Glass", "Glass", "Solid"));
	private final BooleanSetting mainMenu = add(new BooleanSetting("main_menu", "Goon Client main menu", true));
	private final BooleanSetting pauseMenu = add(new BooleanSetting("pause_menu", "Goon Client pause menu", true));
	private final BooleanSetting glassHotbar = add(new BooleanSetting("glass_hotbar", "Glass hotbar", true));
	private final BooleanSetting glassChat = add(new BooleanSetting("glass_chat", "Glass chat backgrounds", true));
	private final ModeSetting menuBackground = add(new ModeSetting("menu_background", "Menu background", "Goon", "Goon", "Custom image", "Panorama", "Solid"));

	public Interface() {
		super("interface", "Interface", "Accent colour, blur, panel opacity, menu background and the Goon Client main and pause menus", Category.UTILITY, true);
		instance = this;
		add(new ButtonSetting("hud_fit", "Arrange enabled HUD panels", "Auto layout", () -> dev.goonclient.client.config.ProfileStore.arrangeCurrent()));
		add(new ButtonSetting("profiles", "Saved module and HUD setups", "Configs", () -> { var mc=net.minecraft.client.Minecraft.getInstance(); mc.gui.setScreen(new dev.goonclient.client.gui.StudioScreen(mc.gui.screen(), dev.goonclient.client.gui.StudioScreen.Page.CONFIGS)); }));
		add(new ButtonSetting("wardrobe", "Goon cosmetics", "Wardrobe", () -> {
			var mc = net.minecraft.client.Minecraft.getInstance();
			mc.gui.setScreen(new dev.goonclient.client.gui.CosmeticsScreen(mc.gui.screen()));
		}));
		add(new ButtonSetting("backgrounds_folder", "Background image (.png or .jpg)", "Open folder", Backdrop::openFolder));
		add(new ButtonSetting("performance_preset", "Performance presets", "Open", () -> {
			var mc = net.minecraft.client.Minecraft.getInstance();
			mc.gui.setScreen(new dev.goonclient.client.gui.PerformanceScreen(mc.gui.screen()));
		}));
		add(new ButtonSetting("screenshots", "Screenshot manager", "Open", () -> {
			var mc = net.minecraft.client.Minecraft.getInstance();
			mc.gui.setScreen(new dev.goonclient.client.gui.ScreenshotScreen(mc.gui.screen()));
		}));
	}

	private static boolean active() {
		return instance != null && instance.isEnabled();
	}

	/** The theme's accent colour: used for state (on, selected, progress). */
	public static int accent() {
		return theme().accent();
	}

	public static dev.goonclient.client.gui.Themes.Theme theme() {
		return dev.goonclient.client.gui.Themes.find(active() ? instance.accent.get() : dev.goonclient.client.gui.Themes.DEFAULT);
	}

	/** Bottom-left key hints in Goon menus (Alt+H toggles). */
	public static boolean autoHud() { return !active() || instance.hudArrangement.is("Auto"); }

	public static void automaticHud() {
		if (instance != null) instance.hudArrangement.set("Auto");
	}

	public static boolean hints() {
		return !active() || instance.hints.isOn();
	}

	public static void toggleHints() {
		if (instance != null) {
			instance.hints.set(!instance.hints.isOn());
			dev.goonclient.client.config.ConfigManager.markDirty();
		}
	}

	/** Blur strength used behind Goon Client screens (vanilla's own setting is used everywhere else). */
	public static int blur() {
		return active() ? instance.blur.intValue() : 2;
	}

	/** 0..1 multiplier for panel backgrounds; lower lets more of the game show through. */
	public static boolean glassMenu() { return !active() || instance.material.is("Glass"); }
	public static boolean glassHotbar() { return active() && instance.glassHotbar.isOn(); }
	public static boolean glassChat() { return active() && instance.glassChat.isOn(); }

	public static float panelOpacity() {
		return active() ? instance.opacity.floatValue() / 100f : 0.97f;
	}

	/** "Goon" (animated), "Custom image" (from config/goonclient/backgrounds) or "Panorama" (vanilla). */
	public static String menuBackground() {
		return active() ? instance.menuBackground.get() : "Panorama";
	}

	public static boolean customMainMenu() {
		return active() && instance.mainMenu.isOn();
	}

	public static boolean customPauseMenu() {
		return active() && instance.pauseMenu.isOn();
	}
}
