package dev.goonclient.client.modules.visual;

import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.Module;
import dev.goonclient.client.module.setting.BooleanSetting;
import dev.goonclient.client.module.setting.NumberSetting;
import java.util.Locale;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.ChatFormatting;
import net.minecraft.world.entity.player.Player;

/** Enriches an existing native tag, preserving its team/invisibility visibility decision. */
public final class PlayerTags extends Module {
    private static PlayerTags instance;
    private final BooleanSetting distance = add(new BooleanSetting("distance", "Distance", true));
    private final BooleanSetting health = add(new BooleanSetting("health", "Reported health (server dependent)", false));
    private final BooleanSetting ping = add(new BooleanSetting("ping", "Reported ping", false));
    private final NumberSetting range = add(new NumberSetting("range", "Detail distance", 24, 4, 48, 1, " m"));
    public PlayerTags() {
        super("player_tags", "Player Tags", "Distance and optional server-reported health/ping on visible player names", Category.VISUAL, false);
        instance = this;
    }
    public static Component decorate(Player player, Component original) {
        Minecraft mc = Minecraft.getInstance();
        if (original == null || instance == null || !instance.isEnabled() || mc.player == null || player == mc.player || player.isInvisible()
            || player.isSpectator() || player.distanceToSqr(mc.player) > instance.range.get() * instance.range.get() || !mc.player.hasLineOfSight(player)) return original;
        var result = original.copy();
        if (instance.distance.isOn()) result.append(Component.literal(String.format(Locale.ROOT, "  %.0f m", player.distanceTo(mc.player))).withStyle(ChatFormatting.GRAY));
        if (instance.health.isOn()) result.append(Component.literal(String.format(Locale.ROOT, "  ~%.0f HP", player.getHealth())).withStyle(ChatFormatting.GREEN));
        if (instance.ping.isOn() && mc.getConnection() != null) {
            var info = mc.getConnection().getPlayerInfo(player.getUUID());
            if (info != null) result.append(Component.literal("  " + info.getLatency() + " ms").withStyle(ChatFormatting.GRAY));
        }
        return result;
    }
}
