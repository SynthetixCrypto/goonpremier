package dev.goonclient.client.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import dev.goonclient.client.modules.visual.TimeChanger;
import net.minecraft.client.ClientClockManager;
import net.minecraft.world.attribute.EnvironmentAttribute;
import net.minecraft.world.attribute.EnvironmentAttributeSystem;
import net.minecraft.world.clock.ClockManager;
import net.minecraft.world.timeline.AttributeTrackSampler;
import net.minecraft.world.timeline.Timeline;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(EnvironmentAttributeSystem.Builder.class)
public class EnvironmentTimelineMixin {
	@WrapOperation(method = "addTimelineLayerForAttribute", at = @At(value = "INVOKE",
		target = "Lnet/minecraft/world/timeline/Timeline;createTrackSampler(Lnet/minecraft/world/attribute/EnvironmentAttribute;Lnet/minecraft/world/clock/ClockManager;)Lnet/minecraft/world/timeline/AttributeTrackSampler;"))
	private <T> AttributeTrackSampler<T, ?> goonclient$visualTime(Timeline timeline, EnvironmentAttribute<T> attribute,
		ClockManager clocks, Operation<AttributeTrackSampler<T, ?>> original) {
		// This class is also used by the integrated server: never wrap its clock manager.
		return original.call(timeline, attribute, clocks instanceof ClientClockManager && TimeChanger.visual(attribute)
			? TimeChanger.visualClock(clocks) : clocks);
	}
}
