package dev.goonclient.client.modules.combat;

import dev.goonclient.client.gui.render.Icons;
import dev.goonclient.client.hud.HudPosition;
import dev.goonclient.client.hud.TextHudModule;
import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.setting.NumberSetting;
import java.util.List;
import java.util.Locale;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;

/** Local attack-ray distance, not server-confirmed damage or a change to attack reach. */
public final class HitDistance extends TextHudModule {
	private static HitDistance instance;
	private final NumberSetting linger=add(new NumberSetting("linger", "Keep visible", 3, 1, 10, 1, " s"));
	private long lastHit;
	private double distance;
	private String mob="";
	public HitDistance() {
		super("hit_distance", "Hit Distance", "Recent attack distance to the visible target; a client estimate", Category.COMBAT, false, HudPosition.rightMiddle(2, 85));
		instance=this;
	}

	@Override
	protected Icons.Icon icon() {
		return Icons.Icon.SWORDS;
	}
	public static void attacked(Entity entity, EntityHitResult result) {
		var mc=Minecraft.getInstance();
		if(instance==null || !instance.isEnabled() || mc.player==null || result==null || result.getEntity()!=entity) return;
		Vec3 eye=mc.player.getEyePosition();
		instance.distance=eye.distanceTo(result.getLocation());
		instance.mob=entity.getDisplayName().getString();
		instance.lastHit=System.nanoTime();
	}
	public static void clear() { if(instance!=null) instance.lastHit=0; }
	@Override public boolean isVisible(Minecraft mc) {
		return mc.player!=null && lastHit!=0 && System.nanoTime()-lastHit < linger.get()*1_000_000_000L;
	}
	@Override protected boolean isTransient() { return true; }
	@Override protected void collect(Minecraft mc, List<Line> lines, boolean editing) {
		if(!editing && !isVisible(mc)) return;
		lines.add(new Line("Hit distance", String.format(Locale.ROOT,"%.2f m", lastHit==0?2.45:distance)));
		lines.add(new Line("", lastHit==0?"Zombie":dev.goonclient.client.gui.Ui.ellipsize(mc.font,mob,120,false)));
	}
}
