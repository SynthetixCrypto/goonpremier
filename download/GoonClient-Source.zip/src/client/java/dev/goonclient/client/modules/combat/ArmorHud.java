package dev.goonclient.client.modules.combat;

import dev.goonclient.client.hud.HudPosition;
import dev.goonclient.client.gui.Ui;
import dev.goonclient.client.hud.HudModule;
import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.setting.BooleanSetting;
import dev.goonclient.client.module.setting.ModeSetting;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/** Armour and held items with their durability. */
public class ArmorHud extends HudModule {
	private static final EquipmentSlot[] ARMOR = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

	private final ModeSetting style = add(new ModeSetting("style", "Style", "Hotbar", "Hotbar", "List"));
	private final ModeSetting mode = add(new ModeSetting("mode", "Durability", "Percent", "Percent", "Remaining", "Both"));
	private final BooleanSetting hands = add(new BooleanSetting("hands", "Show held tools and weapons", true));
	private final BooleanSetting background = add(new BooleanSetting("background", "Background", true));

	public ArmorHud() {
		super("armor", "Armor Status", "Armour and held item durability", Category.COMBAT, true, HudPosition.rightOfHotbar(3, 4));
	}

	@Override protected void measure(Minecraft mc, boolean editing) {
        if (style.is("Hotbar")) {
            boolean any = mc.player != null && java.util.Arrays.stream(ARMOR).anyMatch(slot -> !mc.player.getItemBySlot(slot).isEmpty());
            setSize(any || editing ? 50 : 1, any || editing ? 15 : 1); return;
        }
		List<ItemStack> stacks = new ArrayList<>();
		if (mc.player != null) {
			for (EquipmentSlot slot : ARMOR) {
				ItemStack stack = mc.player.getItemBySlot(slot);
				if (!stack.isEmpty()) {
					stacks.add(stack);
				}
			}
			if (hands.isOn()) {
				// Only items that wear out; a stack of dirt in hand doesn't need a row
				if (mc.player.getMainHandItem().isDamageableItem()) {
					stacks.add(mc.player.getMainHandItem());
				}
				if (mc.player.getOffhandItem().isDamageableItem()) {
					stacks.add(mc.player.getOffhandItem());
				}
			}
		}
		if (stacks.isEmpty() && editing) {
			stacks = samples();
		}
		if (stacks.isEmpty()) {
			setSize(1, 1);
			return;
		}
		Font font = mc.font;
		int textWidth = 0;
		for (ItemStack stack : stacks) {
			textWidth = Math.max(textWidth, Ui.width(font, label(stack)));
		}
		int width = 20 + textWidth + 4;
		int height = stacks.size() * 17 + 2;
		setSize(width, height);
	}

	@Override
	protected void render(GuiGraphicsExtractor g, Minecraft mc, boolean editing) {
		if (style.is("Hotbar")) {
			renderBar(g, mc, editing);
			return;
		}
		List<ItemStack> stacks = new ArrayList<>();
		if (mc.player != null) {
			for (EquipmentSlot slot : ARMOR) {
				ItemStack stack = mc.player.getItemBySlot(slot);
				if (!stack.isEmpty()) {
					stacks.add(stack);
				}
			}
			if (hands.isOn()) {
				// Only items that wear out; a stack of dirt in hand doesn't need a row
				if (mc.player.getMainHandItem().isDamageableItem()) {
					stacks.add(mc.player.getMainHandItem());
				}
				if (mc.player.getOffhandItem().isDamageableItem()) {
					stacks.add(mc.player.getOffhandItem());
				}
			}
		}
		if (stacks.isEmpty() && editing) {
			stacks = samples();
		}
		if (stacks.isEmpty()) {
			setSize(1, 1);
			return;
		}
		Font font = mc.font;
		int textWidth = 0;
		for (ItemStack stack : stacks) {
			textWidth = Math.max(textWidth, Ui.width(font, label(stack)));
		}
		int width = 20 + textWidth + 4;
		int height = stacks.size() * 17 + 2;
		if (background.isOn()) {
			Ui.roundRect(g, 0, 0, width, height, 4, Ui.HUD_BACKGROUND);
		}
		int y = 1;
		for (ItemStack stack : stacks) {
			g.item(stack, 2, y);
			int color = Ui.TEXT;
			if (stack.isDamageableItem()) {
				float left = 1f - stack.getDamageValue() / (float) stack.getMaxDamage();
				color = left < 0.15f ? Ui.BAD : left < 0.4f ? Ui.WARN : Ui.TEXT;
			}
			Ui.text(g, font, label(stack), 20, y + 4, color, true);
			y += 17;
		}
		setSize(width, height);
	}

	/** The reference look: a small glass bar beside the hotbar, four armour icons with a durability line under each. */
	private void renderBar(GuiGraphicsExtractor g, Minecraft mc, boolean editing) {
		List<ItemStack> armor = new ArrayList<>();
		boolean any = false;
		for (EquipmentSlot slot : ARMOR) {
			ItemStack stack = mc.player != null ? mc.player.getItemBySlot(slot) : ItemStack.EMPTY;
			armor.add(stack);
			any |= !stack.isEmpty();
		}
		if (!any) {
			if (!editing) {
				setSize(1, 1);
				return;
			}
			armor = samples().subList(0, 4);
		}
		float slotWidth = 12, width = armor.size() * slotWidth + 2, height = 14.5f;
		dev.goonclient.client.hud.HudRenderUtil.panel(g, 0, 0, width, height, 3, false, 1);
		// Rimmed like the reference's armour bar, with no dividers between the pieces
		dev.goonclient.client.hud.HudRenderUtil.rim(g, 0, 0, width, height, 3, 1);
		for (int i = 0; i < armor.size(); i++) {
			float x = 1 + i * slotWidth;
			ItemStack stack = armor.get(i);
			if (stack.isEmpty()) continue;
			g.pose().pushMatrix();
			g.pose().translate(x + 1.2f, 1.6f);
			g.pose().scale(9.6f / 16f, 9.6f / 16f);
			g.item(stack, 0, 0);
			g.pose().popMatrix();
			if (stack.isDamageableItem() && stack.getMaxDamage() > 0) {
				float left = 1f - stack.getDamageValue() / (float) stack.getMaxDamage();
				float bx = x + 2, bw = slotWidth - 4;
				dev.goonclient.client.gui.render.Shapes.roundRect(g, bx, height - 2.4f, bx + bw, height - 1.6f, .4f, 0x30FFFFFF);
				dev.goonclient.client.gui.render.Shapes.roundRect(g, bx, height - 2.4f, bx + Math.max(.8f, bw * left), height - 1.6f, .4f, Ui.healthColor(left));
			}
		}
		setSize(Math.round(width), Math.round(height));
	}

	private String label(ItemStack stack) {
		if (!stack.isDamageableItem()) {
			return stack.getCount() > 1 ? "x" + stack.getCount() : "";
		}
		int left = stack.getMaxDamage() - stack.getDamageValue();
		int percent = Math.round(left * 100f / stack.getMaxDamage());
		return switch (mode.get()) {
			case "Remaining" -> Integer.toString(left);
			case "Both" -> percent + "% (" + left + ")";
			default -> percent + "%";
		};
	}

	private static List<ItemStack> samples() {
		List<ItemStack> samples = new ArrayList<>();
		samples.add(new ItemStack(Items.DIAMOND_HELMET));
		samples.add(new ItemStack(Items.DIAMOND_CHESTPLATE));
		ItemStack legs = new ItemStack(Items.IRON_LEGGINGS);
		legs.setDamageValue(legs.getMaxDamage() / 2);
		samples.add(legs);
		ItemStack boots = new ItemStack(Items.IRON_BOOTS);
		boots.setDamageValue(boots.getMaxDamage() * 9 / 10);
		samples.add(boots);
		return samples;
	}
}
