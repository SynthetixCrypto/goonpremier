package dev.goonclient.client.mixin;

import dev.goonclient.client.gui.render.Backdrop;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Every menu that would show the vanilla panorama shows the Goon Client background instead (Interface setting). */
@Mixin(Screen.class)
public class ScreenMixin {
	@Inject(method = "extractPanorama", at = @At("HEAD"), cancellable = true)
	private void goonclient$backdrop(GuiGraphicsExtractor g, float partialTick, CallbackInfo ci) {
		if (Backdrop.draw(g)) {
			ci.cancel();
		}
	}
}
