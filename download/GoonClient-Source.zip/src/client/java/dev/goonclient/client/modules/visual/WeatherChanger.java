package dev.goonclient.client.modules.visual;

import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.Module;
import dev.goonclient.client.module.setting.ModeSetting;
import dev.goonclient.client.module.setting.NumberSetting;

/** Changes only the precipitation renderer input; server weather and gameplay remain real. */
public final class WeatherChanger extends Module {
    private static WeatherChanger instance;
    private final ModeSetting mode = add(new ModeSetting("mode", "Visible precipitation", "Clear", "Clear", "Rain", "Server"));
    private final NumberSetting intensity = add(new NumberSetting("intensity", "Rain intensity", 70, 10, 100, 5, "%"));
    public WeatherChanger() {
        super("weather_changer", "Weather Changer", "Clear or add local rain/snow visuals. Biomes stay real; sky, sound and server weather stay unchanged.", Category.VISUAL, false);
        instance = this;
    }
    public static float precipitation(float original) {
        if (instance == null || !instance.isEnabled() || instance.mode.is("Server")) return original;
        return instance.mode.is("Clear") ? 0 : instance.intensity.floatValue() / 100;
    }
}
