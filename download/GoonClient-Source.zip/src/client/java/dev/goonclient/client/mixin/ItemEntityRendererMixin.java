package dev.goonclient.client.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import dev.goonclient.client.modules.visual.ItemPhysics;
import net.minecraft.client.renderer.entity.ItemEntityRenderer;
import net.minecraft.client.renderer.entity.state.ItemEntityRenderState;
import net.minecraft.world.entity.item.ItemEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ItemEntityRenderer.class)
public class ItemEntityRendererMixin {
	@Inject(method = "extractRenderState(Lnet/minecraft/world/entity/item/ItemEntity;Lnet/minecraft/client/renderer/entity/state/ItemEntityRenderState;F)V", at = @At("TAIL"))
	private void goonclient$extractPhysics(ItemEntity entity, ItemEntityRenderState state, float partialTick, CallbackInfo ci) {
		((ItemPhysics.State) state).goonclient$physics(entity.onGround(), entity.isInWater() || entity.isInLava(),
			Math.floorMod(entity.getUUID().hashCode(), 360) * ((float) Math.PI / 180));
	}

	@WrapOperation(method = "submit(Lnet/minecraft/client/renderer/entity/state/ItemEntityRenderState;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;Lnet/minecraft/client/renderer/state/level/CameraRenderState;)V",
		at = @At(value = "INVOKE", target = "Lcom/mojang/blaze3d/vertex/PoseStack;translate(FFF)V"))
	private void goonclient$settle(PoseStack pose, float x, float y, float z, Operation<Void> original, @Local(argsOnly = true) ItemEntityRenderState state) {
		ItemPhysics.State physics = (ItemPhysics.State) state;
		if (ItemPhysics.active() && !physics.goonclient$liquid()) {
			var box = state.item.getModelBoundingBox();
			boolean flat = box.getZsize() <= 0.0625;
			if (physics.goonclient$grounded()) y = (float) (flat ? box.maxZ : -box.minY) + 0.02f;
			else y = (float) -box.minY;
		}
		original.call(pose, x, y, z);
	}

	@WrapOperation(method = "submit(Lnet/minecraft/client/renderer/entity/state/ItemEntityRenderState;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;Lnet/minecraft/client/renderer/state/level/CameraRenderState;)V",
		at = @At(value = "INVOKE", target = "Lcom/mojang/blaze3d/vertex/PoseStack;rotate(Lcom/mojang/math/Axis;F)V"))
	private void goonclient$rotate(PoseStack pose, Axis axis, float angle, Operation<Void> original, @Local(argsOnly = true) ItemEntityRenderState state) {
		ItemPhysics.State physics = (ItemPhysics.State) state;
		if (!ItemPhysics.active() || physics.goonclient$liquid()) {
			original.call(pose, axis, angle);
			return;
		}
		original.call(pose, axis, physics.goonclient$yaw());
		if (physics.goonclient$grounded()) {
			if (state.item.getModelBoundingBox().getZsize() <= 0.0625) pose.rotate(Axis.XP, (float) Math.PI / 2);
		} else if (ItemPhysics.tumble()) {
			pose.rotate(Axis.XP, state.ageInTicks * 0.16f + physics.goonclient$yaw());
		}
	}
}
