package dev.goonclient.client.modules.combat;

import dev.goonclient.client.gui.Ui;
import dev.goonclient.client.hud.HudModule;
import dev.goonclient.client.hud.HudPosition;
import dev.goonclient.client.module.Category;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/** While you hold a shield: whether it's ready, blocking or knocked out by an axe, and its durability. */
public class ShieldStatus extends HudModule {
	private static final int WIDTH = 92;

	public ShieldStatus() {
		super("shield_status", "Shield Status", "Ready, blocking or disabled by an axe, plus durability", Category.COMBAT, true, HudPosition.leftOfHotbar(6, 2));
	}

	private static ItemStack shield(LocalPlayer player) {
		if (player.getOffhandItem().is(Items.SHIELD)) {
			return player.getOffhandItem();
		}
		return player.getMainHandItem().is(Items.SHIELD) ? player.getMainHandItem() : ItemStack.EMPTY;
	}

	@Override
	public boolean isVisible(Minecraft mc) {
		return mc.player != null && !shield(mc.player).isEmpty();
	}

	@Override
	protected void render(GuiGraphicsExtractor g, Minecraft mc, boolean editing) {
		ItemStack stack = mc.player != null ? shield(mc.player) : ItemStack.EMPTY;
		if (stack.isEmpty()) {
			if (!editing) {
				setSize(1, 1);
				return;
			}
			stack = new ItemStack(Items.SHIELD);
		}
		String state;
		int stateColor;
		float cooldown = 0f;
		if (mc.player != null && mc.player.getCooldowns().isOnCooldown(stack)) {
			cooldown = mc.player.getCooldowns().getCooldownPercent(stack, 0f);
			state = "Disabled";
			stateColor = Ui.BAD;
		} else if (mc.player != null && mc.player.isBlocking()) {
			state = "Blocking";
			stateColor = Ui.accent();
		} else {
			state = "Ready";
			stateColor = Ui.TEXT;
		}
		int percent = stack.isDamageableItem() ? Math.round((stack.getMaxDamage() - stack.getDamageValue()) * 100f / stack.getMaxDamage()) : 100;

		Font font = mc.font;
		int height = 22;
		Ui.roundRect(g, 0, 0, WIDTH, height, 4, Ui.HUD_BACKGROUND);
		g.item(stack, 3, 3);
		Ui.bold(g, font, state, 22, 4, stateColor, true);
		String durability = percent + "%";
		Ui.text(g, font, durability, WIDTH - 5 - Ui.width(font, durability), 4, percent < 15 ? Ui.BAD : percent < 40 ? Ui.WARN : Ui.MUTED, true);
		// Second line: how long it's still knocked out, or a full bar when ready
		Ui.roundRect(g, 22, 15, WIDTH - 5, 17, 1, Ui.CONTROL);
		int barEnd = 22 + Math.round((WIDTH - 27) * (cooldown > 0 ? 1f - cooldown : 1f));
		Ui.roundRect(g, 22, 15, Math.max(24, barEnd), 17, 1, cooldown > 0 ? Ui.BAD : Ui.withAlpha(Ui.TEXT, 0.35f));
		setSize(WIDTH, height);
	}
}
