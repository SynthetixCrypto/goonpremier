package dev.goonclient.client.utility;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.HexFormat;
import java.util.Locale;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.resolver.ServerAddress;
import net.minecraft.world.level.storage.LevelResource;

/** Collision-resistant local namespaces. Server addresses are never sent to a Goon service. */
public record WorldScope(String key,String name) {
    public static WorldScope current(Minecraft mc){
        if(mc.getConnection()==null)return null;
        var integrated=mc.getSingleplayerServer();
        if(integrated!=null)return of("sp:"+integrated.getWorldPath(LevelResource.ROOT).toAbsolutePath().normalize(),integrated.getWorldData().getLevelName());
        var server=mc.getCurrentServer();if(server==null)return null;
        var address=ServerAddress.parseString(server.ip);
        return of("mp:"+address.getHost().toLowerCase(Locale.ROOT)+":"+address.getPort(),server.name);
    }
    public static WorldScope of(String identity,String name){
        return new WorldScope(hash(identity),clean(name==null||name.isBlank()?"World":name,96));
    }
    public static String hash(String value){
        try{return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(value.getBytes(StandardCharsets.UTF_8)));}
        catch(java.security.NoSuchAlgorithmException e){throw new IllegalStateException(e);}
    }
    public static String clean(String value,int max){
        String text=value.codePoints().filter(c->!Character.isISOControl(c)).collect(StringBuilder::new,StringBuilder::appendCodePoint,StringBuilder::append).toString();
        return text.length()>max?text.substring(0,text.offsetByCodePoints(0,Math.min(max,text.codePointCount(0,text.length())))):text;
    }
}
