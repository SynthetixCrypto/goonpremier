package dev.goonclient.client.gui;

import dev.goonclient.client.gui.render.BackdropBlur;
import dev.goonclient.client.gui.render.GoonFont;
import dev.goonclient.client.gui.render.Shapes;
import dev.goonclient.client.gui.render.Icons;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/** Pieces shared by the full-screen Goon Client menus (main menu, pause menu): backdrop shading and menu buttons. */
final class Menus {
	enum Style {
		NORMAL,
		PRIMARY,
		DANGER
	}

	static final float BUTTON_HEIGHT = 24;
	static final float LABEL = 8f;

	private Menus() {
	}

	/** Darkens the left side of the screen so the menu column reads over any background. */
	static void sideShade(GuiGraphicsExtractor g, int width, int height, float reach, float alpha) {
		int strips = 48;
		float stripWidth = width * reach / strips;
		for (int i = 0; i < strips; i++) {
			float t = i / (float) strips;
			float a = alpha * (1 - t) * (1 - t);
			// Strips share exact edges (no overlap), so there are no darker seams between them
			Shapes.rect(g, i * stripWidth, 0, (i + 1) * stripWidth, height, Ui.withAlpha(0xFF08090B, a));
		}
	}

	private static final int CONTROL = GlassUi.CONTROL, CONTROL_HOVER = GlassUi.CONTROL_HOVER, EDGE = GlassUi.GLASS_EDGE;

	/**
	 * One menu button in Combatant's glass style: the blurred world behind a translucent control surface with a soft
	 * edge; it slides in (appear 0 to 1), lifts on hover and shows an accent edge. Returns true if the mouse is over it.
	 */
	static boolean button(GuiGraphicsExtractor g, String label, float x1, float y1, float w, int mouseX, int mouseY, float appear, Style style) {
		float x = x1 - (1 - appear) * 14;
		float x2 = x + w;
		float y2 = y1 + BUTTON_HEIGHT;
		boolean hover = appear > 0.9f && Ui.inside(mouseX, mouseY, x1, y1, x1 + w, y2);
		float h = Ui.animate("menu:" + label, hover ? 1f : 0f, 0.55f);
		int fill;
		int border;
		int text;
		switch (style) {
			case PRIMARY -> {
				fill = Ui.withAlpha(Ui.lerp(h * 0.14f, Ui.accent(), 0xFFFFFFFF), .88f);
				border = Ui.withAlpha(0xFFFFFFFF, .18f + .12f * h);
				text = 0xFFFFFFFF;
			}
			case DANGER -> {
				fill = Ui.lerp(h, CONTROL, 0xA02A1A1D);
				border = Ui.lerp(h, EDGE, Ui.withAlpha(Ui.BAD, 0.6f));
				text = Ui.lerp(h, 0xFFF4F4F4, Ui.BAD);
			}
			default -> {
				fill = Ui.lerp(h, GlassUi.themedSurface(CONTROL), GlassUi.themedSurface(CONTROL_HOVER));
				border = Ui.lerp(h, EDGE, 0x55FFFFFF);
				text = 0xFFF4F4F4;
			}
		}
		if (h > 0.01f) {
			Shapes.shadow(g, x, y1, x2, y2, 6, 8, 2, 0.3f * h * appear);
		}
		BackdropBlur.draw(g, x, y1, w, BUTTON_HEIGHT, 4, appear);
		Shapes.panel(g, x, y1, x2, y2, 4, Ui.withAlpha(fill, appear), Ui.withAlpha(border, appear));
		if (style == Style.NORMAL && h > 0.01f) {
			Shapes.roundRect(g, x + 1.5f, y1 + 7, x + 3.6f, y2 - 7, 1, Ui.withAlpha(Ui.accent(), h * appear));
		}
		Icons.draw(g, buttonIcon(label), x + 9, y1 + 7, 10, Ui.withAlpha(text, appear));
		GoonFont.draw(g, label, x + 25 + h * 1.5f, y1 + (BUTTON_HEIGHT - LABEL) / 2f, LABEL, GoonFont.Weight.MEDIUM, Ui.withAlpha(text, appear), false);
		return hover;
	}

	private static Icons.Icon buttonIcon(String label) {
        return switch (label) {
            case "Singleplayer", "World Options" -> Icons.Icon.CUBE;
            case "Multiplayer" -> Icons.Icon.GLOBE;
            case "Options", "Goon Client" -> Icons.Icon.SLIDERS;
            case "Wardrobe" -> Icons.Icon.BACKPACK;
            case "Screenshots" -> Icons.Icon.MONITOR;
            case "Adventure Log", "Mods" -> Icons.Icon.FOLDER;
            case "Statistics", "Advancements" -> Icons.Icon.GAUGE;
            case "Quit Game", "Save and Quit", "Disconnect" -> Icons.Icon.CLOSE;
            default -> Icons.Icon.CHECK;
        };
    }

    /** Stagger helper: how far in a list item's entrance animation is, given when the screen opened. */
	static float stagger(long openedAt, int index, long delay, long duration) {
		return Ui.easeOutCubic((System.currentTimeMillis() - openedAt - delay - index * 40L) / (float) duration);
	}
}
