package dev.goonclient.client.waypoint;

import com.google.gson.JsonObject;

public record Waypoint(String name, int x, int y, int z, String dimension, int color, boolean death, long created) {
	public double distanceTo(double px, double py, double pz) {
		double dx = x + 0.5 - px;
		double dy = y + 0.5 - py;
		double dz = z + 0.5 - pz;
		return Math.sqrt(dx * dx + dy * dy + dz * dz);
	}

	JsonObject toJson() {
		JsonObject json = new JsonObject();
		json.addProperty("name", name);
		json.addProperty("x", x);
		json.addProperty("y", y);
		json.addProperty("z", z);
		json.addProperty("dimension", dimension);
		json.addProperty("color", color);
		json.addProperty("death", death);
		json.addProperty("created", created);
		return json;
	}

	static Waypoint fromJson(JsonObject json) {
		return new Waypoint(
			json.get("name").getAsString(),
			json.get("x").getAsInt(),
			json.get("y").getAsInt(),
			json.get("z").getAsInt(),
			json.get("dimension").getAsString(),
			json.has("color") ? json.get("color").getAsInt() : 0xFF55D4FF,
			json.has("death") && json.get("death").getAsBoolean(),
			json.has("created") ? json.get("created").getAsLong() : 0L
		);
	}
}
