package dev.goonclient.client.compat;

import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;
import dev.goonclient.client.gui.ClickGuiScreen;
import net.minecraft.client.gui.screens.Screen;

/** Mod Menu integration. Only touch this class when Mod Menu is installed. */
public class ModMenuCompat implements ModMenuApi {
	@Override
	public ConfigScreenFactory<?> getModConfigScreenFactory() {
		return ClickGuiScreen::new;
	}

	/** Mod Menu's mod list, for the "Mods" button on the Goon Client main menu. */
	public static Screen modsScreen(Screen parent) {
		return ModMenuApi.createModsScreen(parent);
	}
}
