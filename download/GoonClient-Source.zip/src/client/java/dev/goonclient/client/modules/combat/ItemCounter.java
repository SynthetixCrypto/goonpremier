package dev.goonclient.client.modules.combat;

import dev.goonclient.client.hud.HudPosition;
import dev.goonclient.client.gui.Ui;
import dev.goonclient.client.hud.HudModule;
import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.setting.BooleanSetting;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/** Counts of key supplies in your inventory, shown next to the hotbar. */
public class ItemCounter extends HudModule {
	private final BooleanSetting arrows = add(new BooleanSetting("arrows", "Arrows", true));
	private final BooleanSetting totems = add(new BooleanSetting("totems", "Totems", true));
	private final BooleanSetting pearls = add(new BooleanSetting("pearls", "Ender pearls", true));
	private final BooleanSetting gapples = add(new BooleanSetting("gapples", "Golden apples", true));
	private final BooleanSetting freeSlots = add(new BooleanSetting("free_slots", "Free slots", true));

	public ItemCounter() {
		super("item_counter", "Item Counter", "Arrows, totems, pearls, golden apples and free slots", Category.COMBAT, false, HudPosition.rightOfHotbar(6, 3));
	}

	@Override protected void measure(Minecraft mc, boolean editing) {

		List<Entry> entries = new ArrayList<>();
		if (mc.player != null) {
			Inventory inventory = mc.player.getInventory();
			if (arrows.isOn()) {
				addIfAny(entries, Items.ARROW, count(inventory, Items.ARROW, Items.SPECTRAL_ARROW, Items.TIPPED_ARROW), editing);
			}
			if (totems.isOn()) {
				addIfAny(entries, Items.TOTEM_OF_UNDYING, count(inventory, Items.TOTEM_OF_UNDYING), editing);
			}
			if (pearls.isOn()) {
				addIfAny(entries, Items.ENDER_PEARL, count(inventory, Items.ENDER_PEARL), editing);
			}
			if (gapples.isOn()) {
				addIfAny(entries, Items.GOLDEN_APPLE, count(inventory, Items.GOLDEN_APPLE, Items.ENCHANTED_GOLDEN_APPLE), editing);
			}
			if (freeSlots.isOn()) {
				int free = 0;
				for (ItemStack stack : inventory.getNonEquipmentItems()) {
					if (stack.isEmpty()) {
						free++;
					}
				}
				entries.add(new Entry(new ItemStack(Items.CHEST), free, free == 0 ? Ui.BAD : free <= 3 ? Ui.WARN : Ui.TEXT));
			}
		}
		if (entries.isEmpty()) {
			setSize(1, 1);
			return;
		}
		Font font = mc.font;
        int width = 0;
        for (Entry entry : entries) width += 17 + Ui.width(font, Integer.toString(entry.count())) + 6;
        setSize(width - 6, 16);
	}

	@Override
	protected void render(GuiGraphicsExtractor g, Minecraft mc, boolean editing) {
		List<Entry> entries = new ArrayList<>();
		if (mc.player != null) {
			Inventory inventory = mc.player.getInventory();
			if (arrows.isOn()) {
				addIfAny(entries, Items.ARROW, count(inventory, Items.ARROW, Items.SPECTRAL_ARROW, Items.TIPPED_ARROW), editing);
			}
			if (totems.isOn()) {
				addIfAny(entries, Items.TOTEM_OF_UNDYING, count(inventory, Items.TOTEM_OF_UNDYING), editing);
			}
			if (pearls.isOn()) {
				addIfAny(entries, Items.ENDER_PEARL, count(inventory, Items.ENDER_PEARL), editing);
			}
			if (gapples.isOn()) {
				addIfAny(entries, Items.GOLDEN_APPLE, count(inventory, Items.GOLDEN_APPLE, Items.ENCHANTED_GOLDEN_APPLE), editing);
			}
			if (freeSlots.isOn()) {
				int free = 0;
				for (ItemStack stack : inventory.getNonEquipmentItems()) {
					if (stack.isEmpty()) {
						free++;
					}
				}
				entries.add(new Entry(new ItemStack(Items.CHEST), free, free == 0 ? Ui.BAD : free <= 3 ? Ui.WARN : Ui.TEXT));
			}
		}
		if (entries.isEmpty()) {
			setSize(1, 1);
			return;
		}
		Font font = mc.font;
		int x = 0;
		for (Entry entry : entries) {
			g.item(entry.icon(), x, 0);
			String text = Integer.toString(entry.count());
			Ui.text(g, font, text, x + 17, 5, entry.color(), true);
			x += 17 + Ui.width(font, text) + 6;
		}
		setSize(x - 6, 16);
	}

	private static void addIfAny(List<Entry> entries, Item item, int count, boolean editing) {
		if (count > 0 || editing) {
			entries.add(new Entry(new ItemStack(item), count, count == 0 ? Ui.BAD : Ui.TEXT));
		}
	}

	private static int count(Inventory inventory, Item... items) {
		int total = 0;
		for (int i = 0; i < inventory.getContainerSize(); i++) {
			ItemStack stack = inventory.getItem(i);
			for (Item item : items) {
				if (stack.is(item)) {
					total += stack.getCount();
				}
			}
		}
		return total;
	}

	private record Entry(ItemStack icon, int count, int color) {
	}
}
