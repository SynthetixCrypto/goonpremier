package dev.goonclient.client.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import dev.goonclient.client.modules.visual.Freelook;
import dev.goonclient.client.modules.visual.Zoom;
import net.minecraft.client.Minecraft;
import net.minecraft.client.MouseHandler;
import net.minecraft.client.player.LocalPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MouseHandler.class)
public class MouseHandlerMixin {
    @Inject(method="onButton",at=@At("HEAD"))
    private void goon$buttonActivity(long window,net.minecraft.client.input.MouseButtonInfo button,int action,CallbackInfo ci){dev.goonclient.client.input.InputActivity.record(Minecraft.getInstance(),window);}
    @Inject(method="onMove",at=@At("HEAD"))
    private void goon$moveActivity(long window,double x,double y,double dx,double dy,CallbackInfo ci){if(Math.abs(dx)+Math.abs(dy)>.0001)dev.goonclient.client.input.InputActivity.record(Minecraft.getInstance(),window);}

	/** Records raw button edges after vanilla handling, without consuming gameplay input. */
	@Inject(method = "onButton", at = @At("TAIL"))
	private void goon$clickRate(long handle, net.minecraft.client.input.MouseButtonInfo button, int action, CallbackInfo ci) {
		dev.goonclient.client.tracker.ClickHistory.press(Minecraft.getInstance(), handle, button.button(), action);
	}

	/** Scrolling while zoomed changes the zoom instead of the hotbar slot. */
	@Inject(method = "onScroll", at = @At("HEAD"), cancellable = true)
	private void goonclient$zoomScroll(long window, double xOffset, double yOffset, CallbackInfo ci) {
        if(xOffset!=0||yOffset!=0)dev.goonclient.client.input.InputActivity.record(Minecraft.getInstance(),window);
		if (Minecraft.getInstance().gui.screen() == null && Zoom.onScroll(yOffset)) {
			ci.cancel();
		}
	}

	/**
	 * Mouse movement turns the freelook camera instead of the player, and is slowed while zoomed.
	 * WrapOperation (not Redirect) so other mods hooking the same call still work.
	 */
	@WrapOperation(method = "turnPlayer", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/player/LocalPlayer;turn(DD)V"))
	private void goonclient$turn(LocalPlayer player, double dx, double dy, Operation<Void> original) {
		double scale = Zoom.sensitivityScale();
		if (Freelook.isActive()) {
			Freelook.turn(dx * scale, dy * scale);
		} else {
			original.call(player, dx * scale, dy * scale);
		}
	}
}
