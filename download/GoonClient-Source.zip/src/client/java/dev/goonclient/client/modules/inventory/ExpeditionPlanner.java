package dev.goonclient.client.modules.inventory;

import dev.goonclient.client.GoonClient;
import dev.goonclient.client.config.ConfigManager;
import dev.goonclient.client.expedition.ExpeditionStore;
import dev.goonclient.client.gui.ExpeditionScreen;
import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.Module;
import dev.goonclient.client.module.setting.ButtonSetting;
import net.minecraft.client.Minecraft;

/** Settings launch a manual trip sheet; enabling this module has no background behavior. */
public final class ExpeditionPlanner extends Module {
    private static ExpeditionStore store;

    public ExpeditionPlanner() {
        super("expedition_planner", "Expedition Planner", "Reusable packing lists, manual checks and waypoint destinations", Category.INVENTORY, false);
        add(new ButtonSetting("open", "Edit packing lists and trip destinations", "Open planner", () -> open(false)));
        add(new ButtonSetting("clear", "Remove all saved expedition plans after confirmation", "Clear plans...", () -> open(true)));
    }

    public static ExpeditionStore store() {
        if (store == null) store = new ExpeditionStore(ConfigManager.dir().resolve("expedition-plans.json"));
        return store;
    }

    private static void open(boolean clear) {
        GoonClient.openNextTick(new ExpeditionScreen(Minecraft.getInstance().gui.screen(), store(), clear));
    }
}
