package dev.goonclient.client.modules.hud;

import dev.goonclient.client.hud.TextHudModule.Segment;
import dev.goonclient.client.gui.render.Icons;
import dev.goonclient.client.hud.HudPosition;
import dev.goonclient.client.gui.Ui;
import dev.goonclient.client.hud.TextHudModule;
import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.setting.BooleanSetting;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.world.phys.Vec3;

/** Small one-line HUD panels. */
public final class SimpleHuds {
	private SimpleHuds() {
	}

	public static class Fps extends TextHudModule {
		public Fps() {
			super("fps", "FPS", "Frames per second", Category.HUD, true, HudPosition.topLeft(3, 1));
		}

		@Override
		protected Icons.Icon icon() {
			return Icons.Icon.LAYERS;
		}

		@Override
		protected boolean valueFirst() {
			return true;
		}

		@Override
		protected void collect(Minecraft mc, List<Line> lines, boolean editing) {
			int fps = mc.getFps();
			lines.add(new Line("FPS", Integer.toString(fps), fps < 30 ? Ui.BAD : fps < 60 ? Ui.WARN : Ui.TEXT));
		}
	}

	public static class Ping extends TextHudModule {
		public Ping() {
			super("ping", "Ping", "Your latency to the server (hidden in singleplayer)", Category.HUD, true, HudPosition.topLeft(3, 12));
		}

		@Override
		protected Icons.Icon icon() {
			return Icons.Icon.GLOBE;
		}

		@Override
		protected boolean valueFirst() {
			return true;
		}

		@Override
		public boolean isVisible(Minecraft mc) {
			return !mc.isLocalServer();
		}

		@Override
		protected void collect(Minecraft mc, List<Line> lines, boolean editing) {
			int ping = 0;
			if (mc.getConnection() != null && mc.player != null) {
				PlayerInfo info = mc.getConnection().getPlayerInfo(mc.player.getUUID());
				ping = info != null ? info.getLatency() : 0;
			}
			lines.add(new Line("ms", Integer.toString(ping), ping > 200 ? Ui.BAD : ping > 100 ? Ui.WARN : Ui.TEXT));
		}
	}

	public static class Memory extends TextHudModule {
		public Memory() {
			super("memory", "Memory", "RAM used by the game", Category.HUD, true, HudPosition.topLeft(45, 1));
		}

		@Override
		protected Icons.Icon icon() {
			return Icons.Icon.MEMORY;
		}

		@Override
		protected void collect(Minecraft mc, List<Line> lines, boolean editing) {
			Runtime runtime = Runtime.getRuntime();
			long used = runtime.totalMemory() - runtime.freeMemory();
			long max = runtime.maxMemory();
			int percent = (int) (used * 100 / max);
			Segment value = Segment.value((used >> 20) + "/" + (max >> 20));
			if (percent > 70) value = value.color(percent > 85 ? Ui.BAD : Ui.WARN);
			// Memory.java: value, 2-unit gap, "MB", 5-unit gap, "[n%]"
			lines.add(Line.rich(List.of(value, Segment.unit("MB").gap(2), Segment.extra("[" + percent + "%]").gap(5))));
		}
	}

	public static class Clock extends TextHudModule {
		private static final DateTimeFormatter H24 = DateTimeFormatter.ofPattern("HH:mm");
		private static final DateTimeFormatter H12 = DateTimeFormatter.ofPattern("h:mm a");
		private final BooleanSetting twentyFour = add(new BooleanSetting("24h", "24-hour", true));

		public Clock() {
			super("clock", "Clock", "Real-world time", Category.HUD, true, HudPosition.topCenter(0, 5));
		}

		@Override
		protected Icons.Icon icon() {
			return null;
		}

		@Override
		protected boolean chip() {
			return true;
		}

		@Override
		protected void collect(Minecraft mc, List<Line> lines, boolean editing) {
			lines.add(new Line("", LocalTime.now().format(twentyFour.isOn() ? H24 : H12)));
		}
	}

	public static class WorldTime extends TextHudModule {
		public WorldTime() {
			super("world_time", "World Time", "In-game day count and time", Category.HUD, false, HudPosition.leftColumn(82));
		}

		@Override
		protected Icons.Icon icon() {
			return Icons.Icon.TIMER;
		}

		@Override
		protected void collect(Minecraft mc, List<Line> lines, boolean editing) {
			long time = mc.level != null ? mc.level.getDefaultClockTime() : 6000;
			long day = time / 24000L + 1;
			long timeOfDay = time % 24000L;
			// Tick 0 is 06:00 in-game
			long hours = (timeOfDay / 1000L + 6) % 24;
			long minutes = (timeOfDay % 1000L) * 60 / 1000L;
			boolean night = timeOfDay >= 13000 && timeOfDay < 23000;
			lines.add(new Line("Day " + day, String.format("%02d:%02d %s", hours, minutes, night ? "(night)" : ""), night ? Ui.WARN : Ui.TEXT));
		}
	}

	public static class Speed extends TextHudModule {
		public Speed() {
			super("speed", "Speed", "Horizontal speed in blocks per second", Category.HUD, true, new HudPosition(0, 1, 1, -15, 0, 1));
		}

		@Override
		protected Icons.Icon icon() {
			return Icons.Icon.GAUGE;
		}

		@Override
		protected boolean valueFirst() {
			return true;
		}

		@Override
		protected void collect(Minecraft mc, List<Line> lines, boolean editing) {
			double speed = 0;
			if (mc.player != null) {
				Vec3 delta = mc.player.position().subtract(mc.player.xo, mc.player.yo, mc.player.zo);
				speed = Math.sqrt(delta.x * delta.x + delta.z * delta.z) * 20;
			}
			lines.add(new Line("b/s", String.format("%.1f", speed)));
		}
	}
}
