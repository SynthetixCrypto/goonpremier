package dev.goonclient.client.gui;

/** Marks screens that use the Interface module's blur strength instead of the vanilla setting. */
public interface GoonScreen {
}
