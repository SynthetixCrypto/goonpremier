package dev.goonclient.client.mixin.litematica;

import dev.goonclient.client.modules.utility.Schematics;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Input is released immediately while disabled; do not intercept ordinary Minecraft stick interactions. */
@Mixin(targets="fi.dy.masa.litematica.event.InputHandler",remap=false)
public abstract class LitematicaInputMixin {
    @Inject(method={"onKeyInput","onMouseClick","onMouseScroll"},at=@At("HEAD"),cancellable=true,remap=false)
    private void goonclient$disabled(CallbackInfoReturnable<Boolean> cir){if(!Schematics.active())cir.setReturnValue(false);}
}
