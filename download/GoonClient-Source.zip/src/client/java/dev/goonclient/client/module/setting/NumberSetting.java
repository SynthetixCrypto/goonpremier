package dev.goonclient.client.module.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import java.util.Locale;

/** A clamped number shown as a slider. */
public class NumberSetting extends Setting<Double> {
	private final double min;
	private final double max;
	private final double step;
	private final String suffix;

	public NumberSetting(String id, String name, double defaultValue, double min, double max, double step, String suffix) {
		super(id, name, defaultValue);
		this.min = min;
		this.max = max;
		this.step = step;
		this.suffix = suffix;
	}

	public NumberSetting(String id, String name, double defaultValue, double min, double max, double step) {
		this(id, name, defaultValue, min, max, step, "");
	}

	@Override
	public void set(Double value) {
		double clamped = Math.max(min, Math.min(max, value));
		super.set(Math.round(clamped / step) * step);
	}

	public double min() {
		return min;
	}

	public double max() {
		return max;
	}

	/** Position of the value along the slider, 0..1. */
	public double fraction() {
		return (value - min) / (max - min);
	}

	public void setFraction(double fraction) {
		set(min + fraction * (max - min));
	}

	public int intValue() {
		return (int) Math.round(value);
	}

	public float floatValue() {
		return value.floatValue();
	}

	public String display() {
		String number = step >= 1 ? Integer.toString(intValue()) : String.format(Locale.ROOT, step >= 0.1 ? "%.1f" : "%.2f", value);
		return number + suffix;
	}

	@Override
	public JsonElement toJson() {
		return new JsonPrimitive(value);
	}

	@Override
	public void fromJson(JsonElement json) {
		if (json.isJsonPrimitive() && json.getAsJsonPrimitive().isNumber()) {
			set(json.getAsDouble());
		}
	}
}
