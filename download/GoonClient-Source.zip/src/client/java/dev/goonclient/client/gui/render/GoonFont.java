package dev.goonclient.client.gui.render;

import com.mojang.blaze3d.platform.NativeImage;
import dev.goonclient.Goon;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.font.FontRenderContext;
import java.awt.font.GlyphVector;
import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.resources.Identifier;
import org.joml.Matrix3x2f;

/**
 * Goon Client's own text renderer. Minecraft samples font textures with nearest-neighbour filtering, which makes a
 * smooth TTF font look pixelated once it's scaled. Here every text size gets its own glyph atlas, rasterised with
 * Java2D anti-aliasing at the exact on-screen pixel size, and each glyph is drawn 1:1 onto screen pixels. The result
 * is as crisp as text in a desktop app at any GUI scale.
 *
 * <p>Sizes and positions are in GUI units like the rest of the UI; the current pose's scale is taken into account.
 */
public final class GoonFont {
	public enum Weight {
		REGULAR("inter-regular.ttf"),
		MEDIUM("inter-medium.ttf"),
		BOLD("inter-bold.ttf"),
		/** Comfortaa: hints and other soft, rounded small print. */
		ROUNDED("comfortaa.ttf"),
		/** Onest: Combatant's HUD values (regular) and labels/units (medium). */
		ONEST("onest-regular.ttf"),
		ONEST_MEDIUM("onest-medium.ttf"),
		/** Combatant's glyph icon fonts (panel header icons). */
		ICONS_NUR("iconsnur.ttf"),
		ICONS("icons.ttf");

		private final String file;

		Weight(String file) {
			this.file = file;
		}
	}

	/** Distance from the top of a line to the baseline, as a fraction of the font size. */
	private static final float ASCENT = 0.82f;
	private static final int REFERENCE_SIZE = 64;
	private static final int MAX_ATLASES = 48;
	private static final String BASE_CHARS;
	/** Membership test for {@link #BASE_CHARS}, so drawing a string doesn't scan the whole set for every character. */
	private static final boolean[] BASE_SET = new boolean[Character.MAX_VALUE + 1];

	static {
		StringBuilder chars = new StringBuilder();
		for (char c = 32; c < 127; c++) {
			chars.append(c);
		}
		for (char c = 160; c < 256; c++) {
			chars.append(c);
		}
		chars.append("❤⛨↑↗→↘↓↙←↖•×‹›∞–—…™✓✕★⚠←°");
		BASE_CHARS = chars.toString();
		for (int i = 0; i < BASE_CHARS.length(); i++) {
			BASE_SET[BASE_CHARS.charAt(i)] = true;
		}
	}

	private static final Font[] BASE = new Font[Weight.values().length];
	private static Font fallback;
	private static final FontRenderContext CONTEXT = new FontRenderContext(null, true, true);
	@SuppressWarnings("unchecked")
	private static final Map<Integer, Float>[] REFERENCE_ADVANCE = new Map[Weight.values().length];
	/** Advances of the first 256 characters per weight, without boxing; NaN until measured. */
	private static final float[][] ADVANCE_LOW = new float[Weight.values().length][256];

	static {
		for (int i = 0; i < REFERENCE_ADVANCE.length; i++) {
			REFERENCE_ADVANCE[i] = new HashMap<>();
			java.util.Arrays.fill(ADVANCE_LOW[i], Float.NaN);
		}
	}
	/** Characters met at runtime that weren't in {@link #BASE_CHARS}; atlases rebuild to include them. */
	private static final Set<Character> EXTRA = new LinkedHashSet<>();
	private static int extraVersion;
	private static final Map<Integer, Atlas> ATLASES = new LinkedHashMap<>(16, 0.75f, true);
	private static int nextTextureId;
	private static final List<Atlas> RETIRED = new ArrayList<>();

	private GoonFont() {
	}

	/** Extraction queues texture views for later drawing. Retire replaced atlases only after that frame rendered. */
	public static void beginFrame() {
		RETIRED.forEach(Atlas::close);
		RETIRED.clear();
	}

	// ---- Public API ----------------------------------------------------------------------------------------

	/** Width of the text at this size in GUI units (independent of the current pose). */
	public static float width(String text, float size, Weight weight) {
		float total = 0;
		for (int i = 0; i < text.length(); i++) {
			total += advance(text.charAt(i), weight);
		}
		return total * size / REFERENCE_SIZE;
	}

	/**
	 * Draws text with its top-left corner at (x, y) in the current pose. A {@code size} of 8.5 matches the old
	 * Minecraft-rendered UI font.
	 */
	public static void draw(GuiGraphicsExtractor g, String text, float x, float y, float size, Weight weight, int color, boolean shadow) {
		if (text.isEmpty() || (color >>> 24) == 0) {
			return;
		}
		Matrix3x2f pose = g.pose();
		int guiScale = Px.guiScale();
		float unit = pose.m00 * guiScale;
		int pixelSize = Math.max(4, Math.round(size * unit));
		Atlas atlas = atlas(weight, pixelSize, text);
		float originX = (pose.m00 * x + pose.m20) * guiScale;
		float baseline = (pose.m11 * (y + size * ASCENT) + pose.m21) * guiScale;
		float advanceScale = size * unit / REFERENCE_SIZE;

		g.pose().pushMatrix();
		g.pose().identity();
		g.pose().scale(1f / guiScale, 1f / guiScale);
		if (shadow) {
			int offset = Math.max(1, Math.round(unit / 3f));
			int shadowColor = ((int) ((color >>> 24) * 0.55f) << 24);
			drawRun(g, atlas, text, weight, originX + offset, baseline + offset, advanceScale, shadowColor);
		}
		drawRun(g, atlas, text, weight, originX, baseline, advanceScale, color);
		g.pose().popMatrix();
	}

	/** Like {@link #draw} without a shadow, shaded from {@code top} to {@code bottom} over the glyphs' height. */
	public static void drawGradient(GuiGraphicsExtractor g, String text, float x, float y, float size, Weight weight, int top, int bottom) {
		if (text.isEmpty() || ((top | bottom) >>> 24) == 0) {
			return;
		}
		if (top == bottom) {
			draw(g, text, x, y, size, weight, top, false);
			return;
		}
		Matrix3x2f pose = g.pose();
		int guiScale = Px.guiScale();
		float unit = pose.m00 * guiScale;
		int pixelSize = Math.max(4, Math.round(size * unit));
		Atlas atlas = atlas(weight, pixelSize, text);
		float pen = (pose.m00 * x + pose.m20) * guiScale;
		int baselinePx = Math.round((pose.m11 * (y + size * ASCENT) + pose.m21) * guiScale);
		float advanceScale = size * unit / REFERENCE_SIZE;
		QuadBatch batch = new QuadBatch(text.length());
		for (int i = 0; i < text.length(); i++) {
			char c = text.charAt(i);
			Glyph glyph = atlas.glyphs.get(c);
			if (glyph != null && glyph.w > 0) {
				int dx = Math.round(pen) + glyph.offsetX;
				int dy = baselinePx + glyph.offsetY;
				batch.add(dx, dy, dx + glyph.w, dy + glyph.h, glyph.u / (float) atlas.width, glyph.v / (float) atlas.height,
					(glyph.u + glyph.w) / (float) atlas.width, (glyph.v + glyph.h) / (float) atlas.height);
			}
			pen += advance(c, weight) * advanceScale;
		}
		g.pose().pushMatrix();
		g.pose().identity();
		g.pose().scale(1f / guiScale, 1f / guiScale);
		batch.submitVertical(g, atlas.texture, top, bottom);
		g.pose().popMatrix();
	}

	// ---- Drawing -------------------------------------------------------------------------------------------

	/** The whole string becomes one GUI element (one quad per glyph inside it). */
	private static void drawRun(GuiGraphicsExtractor g, Atlas atlas, String text, Weight weight, float pen, float baseline, float advanceScale, int color) {
		int baselinePx = Math.round(baseline);
		QuadBatch batch = new QuadBatch(text.length());
		float invW = 1f / atlas.width;
		float invH = 1f / atlas.height;
		for (int i = 0; i < text.length(); i++) {
			char c = text.charAt(i);
			Glyph glyph = atlas.glyphs.get(c);
			if (glyph != null && glyph.w > 0) {
				int dx = Math.round(pen) + glyph.offsetX;
				int dy = baselinePx + glyph.offsetY;
				batch.add(dx, dy, dx + glyph.w, dy + glyph.h, glyph.u * invW, glyph.v * invH, (glyph.u + glyph.w) * invW, (glyph.v + glyph.h) * invH);
			}
			pen += advance(c, weight) * advanceScale;
		}
		batch.submit(g, atlas.texture, color);
	}

	// ---- Metrics -------------------------------------------------------------------------------------------

	private static float advance(char c, Weight weight) {
		if (c < 256) {
			float known = ADVANCE_LOW[weight.ordinal()][c];
			if (!Float.isNaN(known)) {
				return known;
			}
			float measured = measure(c, weight);
			ADVANCE_LOW[weight.ordinal()][c] = measured;
			return measured;
		}
		Map<Integer, Float> cache = REFERENCE_ADVANCE[weight.ordinal()];
		Float cached = cache.get((int) c);
		if (cached != null) {
			return cached;
		}
		float value = measure(c, weight);
		cache.put((int) c, value);
		return value;
	}

	private static float measure(char c, Weight weight) {
		Font font = fontFor(c, weight).deriveFont((float) REFERENCE_SIZE);
		return font.createGlyphVector(CONTEXT, String.valueOf(c)).getGlyphMetrics(0).getAdvance();
	}

	private static Font base(Weight weight) {
		Font font = BASE[weight.ordinal()];
		if (font == null) {
			try (InputStream in = GoonFont.class.getResourceAsStream("/assets/goonclient/font/" + weight.file)) {
				font = Font.createFont(Font.TRUETYPE_FONT, in);
			} catch (Exception e) {
				Goon.LOGGER.error("Couldn't load {}, using a system font", weight.file, e);
				font = new Font(Font.SANS_SERIF, weight == Weight.BOLD ? Font.BOLD : Font.PLAIN, 12);
			}
			BASE[weight.ordinal()] = font;
		}
		return font;
	}

	/** Inter (or Comfortaa) for everything it has; a system font for symbols it lacks (hearts, arrows, ...). */
	private static Font fontFor(char c, Weight weight) {
		Font font = base(weight);
		if (font.canDisplay(c)) {
			return font;
		}
		if (fallback == null) {
			fallback = new Font("Segoe UI Symbol", Font.PLAIN, 12);
			if (!fallback.canDisplay('❤')) {
				fallback = new Font(Font.DIALOG, Font.PLAIN, 12);
			}
		}
		return weight == Weight.BOLD ? fallback.deriveFont(Font.BOLD) : fallback;
	}

	// ---- Atlases -------------------------------------------------------------------------------------------

	private static Atlas atlas(Weight weight, int pixelSize, String text) {
		boolean added = false;
		for (int i = 0; i < text.length(); i++) {
			char c = text.charAt(i);
			if (!BASE_SET[c] && c >= 32 && EXTRA.add(c)) {
				added = true;
			}
		}
		if (added) {
			extraVersion++;
		}
		int key = weight.ordinal() * 100_000 + pixelSize;
		Atlas atlas = ATLASES.get(key);
		if (atlas == null || atlas.version != extraVersion) {
			if (atlas != null) {
				RETIRED.add(atlas);
			}
			atlas = build(weight, pixelSize);
			ATLASES.put(key, atlas);
			trim();
		}
		return atlas;
	}

	private static void trim() {
		while (ATLASES.size() > MAX_ATLASES) {
			Map.Entry<Integer, Atlas> eldest = ATLASES.entrySet().iterator().next();
			RETIRED.add(eldest.getValue());
			ATLASES.remove(eldest.getKey());
		}
	}

	private static Atlas build(Weight weight, int pixelSize) {
		StringBuilder all = new StringBuilder(BASE_CHARS);
		for (char c : EXTRA) {
			all.append(c);
		}
		String chars = all.toString();

		// Measure every glyph, then shelf-pack them
		Map<Character, GlyphVector> vectors = new HashMap<>();
		Map<Character, Rectangle> bounds = new HashMap<>();
		int padding = 1;
		int width = pixelSize <= 24 ? 512 : pixelSize <= 56 ? 1024 : 2048;
		int x = 0;
		int y = 0;
		int rowHeight = 0;
		Map<Character, int[]> cells = new HashMap<>();
		for (int i = 0; i < chars.length(); i++) {
			char c = chars.charAt(i);
			if (vectors.containsKey(c)) {
				continue;
			}
			Font font = fontFor(c, weight).deriveFont((float) pixelSize);
			GlyphVector vector = font.createGlyphVector(CONTEXT, String.valueOf(c));
			Rectangle box = vector.getPixelBounds(CONTEXT, 0, 0);
			vectors.put(c, vector);
			bounds.put(c, box);
			if (box.width <= 0 || box.height <= 0) {
				continue;
			}
			int w = box.width + padding * 2;
			int h = box.height + padding * 2;
			if (x + w > width) {
				x = 0;
				y += rowHeight;
				rowHeight = 0;
			}
			cells.put(c, new int[]{x, y, w, h});
			x += w;
			rowHeight = Math.max(rowHeight, h);
		}
		int height = Integer.highestOneBit(Math.max(16, y + rowHeight) - 1) << 1;

		BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
		Graphics2D g = image.createGraphics();
		g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
		g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		g.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_ON);
		g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
		g.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
		g.setColor(java.awt.Color.WHITE);
		Map<Character, Glyph> glyphs = new HashMap<>();
		for (Map.Entry<Character, GlyphVector> entry : vectors.entrySet()) {
			char c = entry.getKey();
			Rectangle box = bounds.get(c);
			int[] cell = cells.get(c);
			if (cell == null) {
				glyphs.put(c, new Glyph(0, 0, 0, 0, 0, 0));
				continue;
			}
			g.drawGlyphVector(entry.getValue(), cell[0] + padding - box.x, cell[1] + padding - box.y);
			glyphs.put(c, new Glyph(cell[0], cell[1], cell[2], cell[3], box.x - padding, box.y - padding));
		}
		g.dispose();

		// White pixels with the coverage as alpha, so tinting gives the text colour and edges stay clean
		NativeImage pixels = new NativeImage(width, height, false);
		for (int py = 0; py < height; py++) {
			for (int px = 0; px < width; px++) {
				int alpha = image.getRGB(px, py) >>> 24;
				pixels.setPixel(px, py, (alpha << 24) | 0xFFFFFF);
			}
		}
		Identifier id = Goon.id("dynamic/font_" + weight.name().toLowerCase() + "_" + pixelSize + "_" + (nextTextureId++));
		SmoothTexture texture = new SmoothTexture(id.toString(), pixels);
		Minecraft.getInstance().getTextureManager().register(id, texture);
		return new Atlas(id, texture, width, height, glyphs, extraVersion);
	}

	private record Glyph(int u, int v, int w, int h, int offsetX, int offsetY) {
	}

	private record Atlas(Identifier id, SmoothTexture texture, int width, int height, Map<Character, Glyph> glyphs, int version) {
		void close() {
			Minecraft.getInstance().getTextureManager().release(id);
		}
	}
}
