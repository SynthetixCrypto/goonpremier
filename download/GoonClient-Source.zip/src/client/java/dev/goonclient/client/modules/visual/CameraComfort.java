package dev.goonclient.client.modules.visual;

import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.Module;
import dev.goonclient.client.module.setting.BooleanSetting;
import dev.goonclient.client.module.setting.NumberSetting;
import net.minecraft.client.renderer.state.OptionsRenderState;

/** Scales this frame's camera effects without rewriting vanilla preferences. */
public final class CameraComfort extends Module {
    private static CameraComfort instance;
    private final NumberSetting hurt = add(new NumberSetting("hurt", "Hurt tilt (relative to vanilla)", 0, 0, 100, 5, "%"));
    private final BooleanSetting bob = add(new BooleanSetting("disable_bob", "Disable view bobbing", true));
    private final NumberSetting effects = add(new NumberSetting("effects", "Screen distortion (relative)", 100, 0, 100, 5, "%"));
    public CameraComfort() {
        super("camera_comfort", "Camera Comfort", "Reduce hurt tilt, walking bob and screen distortion", Category.VISUAL, false);
        instance = this;
    }
    public static void apply(OptionsRenderState state) {
        if (instance == null || !instance.isEnabled()) return;
        state.damageTiltStrength *= instance.hurt.get() / 100;
        if (instance.bob.isOn()) state.bobView = false;
        state.screenEffectScale *= instance.effects.floatValue() / 100;
    }
}
