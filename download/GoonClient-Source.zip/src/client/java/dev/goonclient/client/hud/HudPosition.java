package dev.goonclient.client.hud;

/**
 * Where a HUD element sits: an anchor point on the screen (0, 0.5 or 1 on each axis), the matching point on the
 * element (the pivot) and a pixel offset. Usually the pivot equals the anchor: a right-anchored element grows
 * leftwards, a centred one stays centred.
 */
public record HudPosition(double anchorX, double anchorY, int offsetX, int offsetY, double pivotX, double pivotY) {
	private static final int OLD_MINIMAP_CLEARANCE = 84;
	private static final double BELOW_MINIMAP = 0.30;

	public HudPosition(double anchorX, double anchorY, int offsetX, int offsetY) {
		this(anchorX, anchorY, offsetX, offsetY, anchorX, anchorY);
	}

	public int x(int guiWidth, int elementWidth) {
		return (int) Math.round(anchorX * guiWidth - pivotX * elementWidth) + offsetX;
	}

	public int y(int guiHeight, int elementHeight) {
		return (int) Math.round(anchorY * guiHeight - pivotY * elementHeight) + offsetY;
	}

	public static HudPosition topLeft(int x, int y) {
		return new HudPosition(0, 0, x, y);
	}

	public static HudPosition topRight(int x, int y) {
		return new HudPosition(1, 0, -x, y);
	}

	public static HudPosition topCenter(int x, int y) {
		return new HudPosition(0.5, 0, x, y);
	}

	public static HudPosition center(int x, int y) {
		return new HudPosition(0.5, 0.5, x, y);
	}

	public static HudPosition rightMiddle(int x, int y) {
		return new HudPosition(1, 0.5, -x, y);
	}

	public static HudPosition bottomCenter(int x, int y) {
		return new HudPosition(0.5, 1, x, -y);
	}

	public static HudPosition bottomRight(int x, int y) {
		return new HudPosition(1, 1, -x, -y);
	}

	/** Bottom row, left edge just right of the hotbar (which is 182 px wide), whatever the element's width. */
	public static HudPosition rightOfHotbar(int gap, int y) {
		return new HudPosition(0.5, 1, 91 + gap, -y, 0, 1);
	}

	/** Bottom row, right edge just left of the hotbar. */
	public static HudPosition leftOfHotbar(int gap, int y) {
		return new HudPosition(0.5, 1, -91 - gap, -y, 1, 1);
	}

	/** The minimap is now a real layout obstacle. No estimated clearance based on mod presence. */
	public static HudPosition leftColumn(int y) {
		return topLeft(2, y);
	}

	/** Migrates untouched left-column defaults from the fixed-gap and 30%-height layouts. */
	public static boolean isOldLeftColumnDefault(HudPosition saved, HudPosition current) {
		return current.anchorX() == 0 && current.anchorY() == 0 && current.offsetX() == 2 && saved.anchorX() == 0 && saved.offsetX() == 2
			&& ((saved.anchorY() == BELOW_MINIMAP && saved.offsetY() == current.offsetY())
			|| (saved.anchorY() == 0 && saved.offsetY() == current.offsetY() + OLD_MINIMAP_CLEARANCE));
	}

	/** Picks the anchor nearest to where the element was dropped and keeps the exact pixel position. */
	public static HudPosition fromScreen(int left, int top, int width, int height, int guiWidth, int guiHeight) {
		double anchorX = anchorFor(left + width / 2.0, guiWidth);
		double anchorY = anchorFor(top + height / 2.0, guiHeight);
		int offsetX = left - (int) Math.round(anchorX * guiWidth - anchorX * width);
		int offsetY = top - (int) Math.round(anchorY * guiHeight - anchorY * height);
		return new HudPosition(anchorX, anchorY, offsetX, offsetY);
	}

	private static double anchorFor(double centre, int size) {
		if (centre < size / 3.0) {
			return 0;
		}
		return centre > size * 2 / 3.0 ? 1 : 0.5;
	}
}
