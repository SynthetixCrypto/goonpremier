package dev.goonclient.client.config;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.goonclient.client.hud.HudModule;
import dev.goonclient.client.module.ModuleManager;
import dev.goonclient.client.module.setting.BooleanSetting;
import dev.goonclient.client.module.setting.ButtonSetting;
import dev.goonclient.client.module.setting.ModeSetting;
import dev.goonclient.client.module.setting.NumberSetting;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.AtomicMoveNotSupportedException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/** Local module/HUD snapshots only. Cosmetic identity, Microsoft accounts and performance backups stay separate. */
public final class ProfileStore {
	private static final int LIMIT=32;
	private static final int MAX_BYTES=128*1024;
	private static JsonObject undo;
	private static String lastApplied="";
	private ProfileStore() { }
	public record Profile(String id,String name,String description,boolean builtin,JsonObject settings) {
		public int enabledCount() {
			int count=0; for(var entry:settings.getAsJsonObject("modules").entrySet()) {
				var data=entry.getValue().getAsJsonObject(); if(data.has("enabled")&&data.get("enabled").getAsBoolean())count++;
			} return count;
		}
	}
	public record Result(boolean ok,String message) { }
	private static Path dir(){return ConfigManager.dir().resolve("profiles");}
	private static Path file(String id) {
		if(!id.matches("[a-f0-9]{32}"))throw new IllegalArgumentException("Invalid setup ID");
		return dir().resolve(id+".json");
	}
	public static boolean canUndo(){return undo!=null;}
	public static String lastApplied(){return lastApplied;}

	public static List<Profile> presets() {
		List<Profile> result=new ArrayList<>();
		result.add(preset("survival","Survival","Everyday exploration, food and survival information.",Set.of("nutrition","inventory_hud","death_tracker","adventure_log"),Set.of()));
		result.add(preset("builder","Builder","Building information and materials, with a quieter combat HUD.",Set.of("inventory_hud","mining","chunk_borders","light_level"),Set.of("target","attack_indicator","danger_meter")));
		result.add(preset("boss","Boss run","Preparation, inventory supplies and combat readouts.",Set.of("boss_prep","nutrition","hit_distance","inventory_hud","shield_status","loot_tracker"),Set.of()));
		// The reference HUD: FPS/RAM pills, Potions, Keybinds, Cooldowns, Inventory, target card, speed/coords pills, armour bar
		Set<String> combatant=Set.of("fps","memory","speed","coordinates","clock","potions","active_modules","cooldowns","inventory_hud","target","notifications","armor","minimap");
		Set<String> others=new java.util.HashSet<>();
		for(var module:ModuleManager.hudModules())if(!combatant.contains(module.id()))others.add(module.id());
		result.addFirst(preset("combatant","Combatant","The Combatant-style HUD: pills, Potions, Keybinds, Cooldowns, Inventory and the target card.",combatant,others));
		return result;
	}
	public static List<Profile> list() throws IOException {
		List<Profile> result=new ArrayList<>(presets());
		if(!Files.isDirectory(dir(),LinkOption.NOFOLLOW_LINKS))return result;
		try(var stream=Files.newDirectoryStream(dir(),"*.json")) {
			int seen=0;
			for(Path path:stream) {
				if(++seen>LIMIT)break;
				String id=path.getFileName().toString().replaceFirst("\\.json$","");
				if(!id.matches("[a-f0-9]{32}")||!Files.isRegularFile(path,LinkOption.NOFOLLOW_LINKS))continue;
				try {
					if(Files.size(path)>MAX_BYTES)continue;
					JsonObject data=JsonParser.parseString(Files.readString(path,StandardCharsets.UTF_8)).getAsJsonObject();
					String name=data.get("name").getAsString();
					if(!validName(name))continue;
					JsonObject settings=data.getAsJsonObject("settings");validate(settings);
					result.add(new Profile(id,name,"Saved modules, settings and HUD positions.",false,settings));
				} catch(RuntimeException|IOException error) {
					dev.goonclient.Goon.LOGGER.warn("Skipped invalid Goon setup {}",path.getFileName());
				}
			}
		}
		return result;
	}

	private static Profile preset(String id,String name,String description,Set<String> on,Set<String> off) {
		JsonObject modules=new JsonObject();
		// Presets only switch modules on and off: the player's theme, settings and HUD positions stay as they are
		for(var module:ModuleManager.all()) {
			JsonObject data=new JsonObject();
			data.addProperty("enabled", on.contains(module.id())||module.enabledByDefault()&&!off.contains(module.id()));
			modules.add(module.id(),data);
		}
		JsonObject root=new JsonObject();root.addProperty("version",1);root.add("modules",modules);
		return new Profile(id,name,description,true,root);
	}
	private static JsonObject snapshot() {
		JsonObject root=ConfigManager.capture();
		for(var entry:root.getAsJsonObject("modules").entrySet())entry.getValue().getAsJsonObject().remove("favorite");
		return root;
	}
	private static boolean validName(String name){return name!=null&&!name.isBlank()&&name.length()<=32&&name.codePoints().noneMatch(Character::isISOControl);}
	public static Result create(String name) {
		name=name.strip();
		if(!validName(name))return new Result(false,"Use a name with 1–32 visible characters.");
		try {
			var saved=list().stream().filter(p->!p.builtin()).toList();
			if(saved.size()>=LIMIT)return new Result(false,"You have 32 setups. Remove one before saving another.");
			for(var profile:saved)if(profile.name().equalsIgnoreCase(name))return new Result(false,"That name is already saved. Select it to overwrite, or use another name.");
			write(UUID.randomUUID().toString().replace("-",""),name,snapshot());
			return new Result(true,"Saved “"+name+"” from your current setup.");
		}catch(IOException|RuntimeException e){return new Result(false,"Couldn't save the setup. Check that your config folder is writable.");}
	}
	public static Result overwrite(Profile profile) {
		if(profile.builtin())return new Result(false,"Save a named copy to customize a built-in setup.");
		try{write(profile.id(),profile.name(),snapshot());return new Result(true,"Updated “"+profile.name()+"”.");}
		catch(IOException|RuntimeException e){return new Result(false,"Couldn't update the saved setup.");}
	}
	public static Result delete(Profile profile) {
		if(profile.builtin())return new Result(false,"Built-in setups cannot be removed.");
		try{Files.delete(file(profile.id()));return new Result(true,"Removed “"+profile.name()+"”. Your current settings are unchanged.");}
		catch(IOException|RuntimeException e){return new Result(false,"Couldn't remove the saved setup.");}
	}
	private static void write(String id,String name,JsonObject settings)throws IOException {
		validate(settings);JsonObject root=new JsonObject();root.addProperty("version",1);root.addProperty("name",name);root.add("settings",settings);
		String text=ConfigManager.GSON.toJson(root);if(text.getBytes(StandardCharsets.UTF_8).length>MAX_BYTES)throw new IOException("Setup too large");
		Files.createDirectories(dir());Path target=file(id),temp=dir().resolve(id+".tmp");
		Files.writeString(temp,text,StandardCharsets.UTF_8);
		try{Files.move(temp,target,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);}
		catch(AtomicMoveNotSupportedException e){Files.move(temp,target,StandardCopyOption.REPLACE_EXISTING);}
	}
	public static Result load(Profile profile) {
		JsonObject before=ConfigManager.capture();
		try {
			validate(profile.settings());ConfigManager.apply(profile.settings(),true,false);
			undo=before;lastApplied=profile.name();ConfigManager.markDirty();ConfigManager.save();
			return new Result(true,"Loaded “"+profile.name()+"”. Undo restores your previous setup.");
		}catch(RuntimeException e){ConfigManager.apply(before,true,false);return new Result(false,"Couldn't load this setup. Your previous settings were restored.");}
	}
	public static Result undo() {
		if(undo==null)return new Result(false,"There is no setup change to undo.");
		JsonObject previous=undo;ConfigManager.apply(previous,true,false);undo=null;lastApplied="";ConfigManager.markDirty();ConfigManager.save();
		return new Result(true,"Restored the setup from before your last load.");
	}
	private static void validate(JsonObject root) {
		if(root==null||!root.has("version")||root.get("version").getAsInt()!=1||!root.has("modules")||!root.get("modules").isJsonObject())throw new IllegalArgumentException("Invalid setup");
		for(var module:ModuleManager.all()) {
			JsonElement entry=root.getAsJsonObject("modules").get(module.id());if(entry==null)continue;
			if(!entry.isJsonObject())throw new IllegalArgumentException("Invalid module");var data=entry.getAsJsonObject();
			if(data.has("enabled")&&(!data.get("enabled").isJsonPrimitive()||!data.getAsJsonPrimitive("enabled").isBoolean()))throw new IllegalArgumentException("Invalid switch");
			if(data.has("settings")) {
				if(!data.get("settings").isJsonObject())throw new IllegalArgumentException("Invalid settings");var settings=data.getAsJsonObject("settings");
				for(var setting:module.settings()) {
					var value=settings.get(setting.id());if(value==null||setting instanceof ButtonSetting)continue;
					if(!value.isJsonPrimitive())throw new IllegalArgumentException("Invalid value");var primitive=value.getAsJsonPrimitive();
					if(setting instanceof BooleanSetting&&!primitive.isBoolean())throw new IllegalArgumentException("Invalid boolean");
					if(setting instanceof NumberSetting&&(!primitive.isNumber()||!Double.isFinite(value.getAsDouble())))throw new IllegalArgumentException("Invalid number");
					if(setting instanceof ModeSetting mode&&(!primitive.isString()||!mode.modes().contains(value.getAsString())))throw new IllegalArgumentException("Unknown choice");
				}
			}
			if(module instanceof HudModule&&data.has("anchorX")) {
				for(String key:List.of("anchorX","anchorY","offsetX","offsetY"))if(!data.has(key)||!data.get(key).isJsonPrimitive()||!data.getAsJsonPrimitive(key).isNumber())throw new IllegalArgumentException("Invalid position");
				for(String key:List.of("anchorX","anchorY","pivotX","pivotY"))if(data.has(key)){double n=data.get(key).getAsDouble();if(!Double.isFinite(n)||n<0||n>1)throw new IllegalArgumentException("Invalid anchor");}
				for(String key:List.of("offsetX","offsetY")){double n=data.get(key).getAsDouble();if(!Double.isFinite(n)||Math.abs(n)>10000||n!=Math.rint(n))throw new IllegalArgumentException("Invalid offset");}
			}
		}
	}
}
