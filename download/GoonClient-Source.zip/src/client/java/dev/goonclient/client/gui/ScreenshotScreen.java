package dev.goonclient.client.gui;

import com.mojang.blaze3d.Blaze3D;
import com.mojang.blaze3d.platform.InputConstants;
import dev.goonclient.Goon;
import dev.goonclient.client.gui.render.ScreenshotImage;
import dev.goonclient.client.gui.render.Shapes;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

/** Local screenshot library: six images at a time, full preview, open/copy, and recoverable removal. */
public final class ScreenshotScreen extends Screen implements GoonScreen {
	private static final ExecutorService IO = Executors.newSingleThreadExecutor(Thread.ofPlatform().daemon().name("Goon screenshots").factory());
	private static final DateTimeFormatter DATE = DateTimeFormatter.ofPattern("d MMM yyyy, HH:mm").withZone(ZoneId.systemDefault());
	private final Screen parent;
	private final Path folder;
	private final Map<Path, ScreenshotImage> images = new HashMap<>();
	private final Set<Path> failed = new HashSet<>();
	private final List<Hit> hits = new ArrayList<>();
	private final Deque<Removed> undo = new ArrayDeque<>();
	private List<Shot> shots = List.of();
	private CompletableFuture<List<Shot>> scan;
	private CompletableFuture<BufferedImage> loading;
	private Path loadingPath;
	private Shot selected;
	private String status = "";
	private int page;
	private float scale;
	private int x, y;
	private boolean initialized;

	public ScreenshotScreen(Screen parent) {
		super(Component.literal("Screenshots"));
		this.parent = parent;
		folder = minecraft.gameDirectory.toPath().resolve("screenshots");
	}

	@Override
	protected void init() {
		scale = Ui.menuScale(width, height);
		x = (int) (width / scale - 600) / 2;
		y = (int) (height / scale - 360) / 2;
		if (!initialized) {
			initialized = true;
			refresh();
		}
	}

	public void refresh() {
		if (scan != null) return;
		status = "Reading screenshots...";
		scan = CompletableFuture.supplyAsync(() -> {
			try {
				Files.createDirectories(folder);
				List<Shot> result = new ArrayList<>();
				try (var files = Files.newDirectoryStream(folder)) {
					for (Path file : files) {
						String name = file.getFileName().toString().toLowerCase(Locale.ROOT);
						if (!name.endsWith(".png") && !name.endsWith(".jpg") && !name.endsWith(".jpeg")) continue;
						if (!Files.isRegularFile(file, LinkOption.NOFOLLOW_LINKS)) continue;
						try {
							result.add(new Shot(file, Files.getLastModifiedTime(file).toMillis(), Files.size(file)));
						} catch (IOException ignored) {
							// A screenshot may have been removed outside the game during the scan.
						}
					}
				}
				result.sort(Comparator.comparingLong(Shot::time).reversed().thenComparing(s -> s.file.toString()));
				return result;
			} catch (IOException e) {
				throw new CompletionException(e);
			}
		}, IO);
	}

	@Override
	public void tick() {
		if (scan != null && scan.isDone()) {
			try {
				shots = scan.join();
				page = Math.min(page, pages() - 1);
				if (selected != null && shots.stream().noneMatch(s -> s.file.equals(selected.file))) selected = null;
				status = shots.isEmpty() ? "No screenshots yet. Press F2 in game to take one." : shots.size() + " screenshots · Newest first";
				clearImages();
				failed.clear();
			} catch (CompletionException e) {
				status = "Couldn't read screenshots. Try Refresh.";
				Goon.LOGGER.warn("Couldn't scan screenshots", e);
			}
			scan = null;
		}
	}

	private int pages() {
		return Math.max(1, (shots.size() + 5) / 6);
	}

	private List<Shot> visible() {
		return selected == null ? shots.subList(Math.min(page * 6, shots.size()), Math.min(page * 6 + 6, shots.size())) : List.of(selected);
	}

	/** Upload at most one image per frame; decoding stays off the render thread and memory stays bounded. */
	private void updateImages() {
		List<Path> wanted = visible().stream().map(Shot::file).toList();
		if (loading != null && loading.isDone()) {
			try {
				BufferedImage image = loading.join();
				if (wanted.contains(loadingPath)) images.put(loadingPath, new ScreenshotImage(image));
			} catch (CompletionException e) {
				failed.add(loadingPath);
			}
			loading = null;
		}
		var iterator = images.entrySet().iterator();
		while (iterator.hasNext()) {
			var entry = iterator.next();
			if (!wanted.contains(entry.getKey())) {
				entry.getValue().close();
				iterator.remove();
			}
		}
		if (loading == null) {
			for (Path path : wanted) {
				if (images.containsKey(path) || failed.contains(path)) continue;
				loadingPath = path;
				loading = CompletableFuture.supplyAsync(() -> {
					try {
						return ScreenshotImage.decode(path);
					} catch (IOException | RuntimeException e) {
						throw new CompletionException(e);
					}
				}, IO);
				break;
			}
		}
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor g, int mx, int my, float partialTick) {
		updateImages();
		hits.clear();
		g.pose().pushMatrix();
		g.pose().scale(scale, scale);
		Ui.roundOutline(g, x, y, x + 600, y + 360, 9, Ui.BORDER, Ui.PANEL);
		Ui.scaledBold(g, font, "Screenshots", x + 18, y + 15, 1.4f, Ui.TEXT);
		Ui.text(g, font, Ui.ellipsize(font, status, 550, false), x + 18, y + 37, Ui.MUTED);
		button(g, "Open folder", x + 361, y + 12, 116, mx, my, true, () -> Blaze3D.openPath(folder));
		button(g, "Refresh", x + 485, y + 12, 97, mx, my, scan == null, this::refresh);
		if (selected == null) {
			List<Shot> visible = visible();
			for (int i = 0; i < visible.size(); i++) {
				Shot shot = visible.get(i);
				int cx = x + 18 + (i % 3) * 190, cy = y + 60 + (i / 3) * 124;
				boolean hover = Ui.inside(mx / scale, my / scale, cx, cy, cx + 184, cy + 116);
				Shapes.panel(g, cx, cy, cx + 184, cy + 116, 5, hover ? Ui.RAISED_HOVER : Ui.RAISED, Ui.BORDER);
				image(g, shot, cx + 4, cy + 4, 176, 88);
				Ui.text(g, font, Ui.ellipsize(font, shot.file.getFileName().toString(), 166, false), cx + 8, cy + 100, Ui.TEXT);
				hits.add(new Hit(cx, cy, 184, 116, () -> selected = shot));
			}
			if (shots.isEmpty()) Ui.text(g, font, scan == null ? "Your captures will appear here." : "Loading your library...", x + 192, y + 172, Ui.MUTED);
			button(g, "Previous", x + 18, y + 319, 90, mx, my, page > 0, () -> page--);
			Ui.text(g, font, (page + 1) + " / " + pages(), x + 122, y + 327, Ui.MUTED);
			button(g, "Next", x + 177, y + 319, 75, mx, my, page + 1 < pages(), () -> page++);
			button(g, "Undo remove", x + 300, y + 319, 130, mx, my, !undo.isEmpty(), this::undoRemove);
			button(g, "Done", x + 438, y + 319, 144, mx, my, true, this::onClose);
		} else {
			image(g, selected, x + 18, y + 59, 564, 222);
			Ui.text(g, font, Ui.ellipsize(font, selected.file.getFileName() + "   ·   " + DATE.format(Instant.ofEpochMilli(selected.time))
				+ "   ·   " + String.format(Locale.ROOT, "%.1f MB", selected.size / 1048576.0), 560, false), x + 18, y + 293, Ui.MUTED);
			button(g, "Back", x + 18, y + 319, 82, mx, my, true, () -> selected = null);
			button(g, "Open image", x + 108, y + 319, 110, mx, my, true, () -> Blaze3D.openPath(selected.file));
			button(g, "Copy path", x + 226, y + 319, 102, mx, my, true, () -> {
				minecraft.keyboardHandler.setClipboard(selected.file.toAbsolutePath().toString());
				status = "Image path copied.";
			});
			button(g, "Remove", x + 336, y + 319, 110, mx, my, true, this::removeSelected);
			button(g, "Undo remove", x + 454, y + 319, 128, mx, my, !undo.isEmpty(), this::undoRemove);
		}
		g.pose().popMatrix();
	}

	private void image(GuiGraphicsExtractor g, Shot shot, int x, int y, int w, int h) {
		Shapes.rect(g, x, y, x + w, y + h, Ui.CONTROL);
		ScreenshotImage image = images.get(shot.file);
		if (image != null) image.draw(g, x, y, w, h);
		else Ui.text(g, font, failed.contains(shot.file) ? "Preview unavailable" : "Loading...", x + 8, y + h / 2, Ui.MUTED);
	}

	private void button(GuiGraphicsExtractor g, String label, int bx, int by, int w, int mx, int my, boolean active, Runnable action) {
		Menus.button(g, label, bx, by, w, (int) (mx / scale), (int) (my / scale), active ? 1 : 0.4f, Menus.Style.NORMAL);
		if (active) hits.add(new Hit(bx, by, w, 24, action));
	}

	public void removeSelected() {
		if (selected == null || scan != null) return;
		try {
			Path trash = folder.resolve(".goon-trash");
			Files.createDirectories(trash);
			Path destination = trash.resolve(UUID.randomUUID() + "-" + selected.file.getFileName());
			Files.move(selected.file, destination);
			undo.push(new Removed(selected.file, destination));
			selected = null;
			refresh();
			status = "Moved to screenshots/.goon-trash. Undo remove brings it back.";
		} catch (IOException e) {
			status = "Couldn't remove the image. It may be open in another app.";
		}
	}

	public void undoRemove() {
		if (undo.isEmpty() || scan != null) return;
		Removed removed = undo.peek();
		try {
			// Never replace a newer screenshot with the same name.
			Files.move(removed.trash, removed.original);
			undo.pop();
			refresh();
		} catch (IOException e) {
			status = "Couldn't restore: check for a file with the same name.";
		}
	}

	public boolean previewFile(Path file) {
		if (scan != null) return false;
		selected = shots.stream().filter(s -> s.file.equals(file)).findFirst().orElse(null);
		return selected != null;
	}

	@Override
	public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
		if (event.button() == 1) {
			for (Hit hit : hits) {
				if (Ui.inside(event.x() / scale, event.y() / scale, hit.x, hit.y, hit.x + hit.w, hit.y + hit.h)) {
					hit.action.run();
					return true;
				}
			}
		}
		return super.mouseClicked(event, doubleClick);
	}

	@Override
	public boolean keyPressed(KeyEvent event) {
		if (selected == null && (event.key() == InputConstants.KEY_LEFT || event.key() == InputConstants.KEY_RIGHT)) {
			page = Math.clamp(page + (event.key() == InputConstants.KEY_RIGHT ? 1 : -1), 0, pages() - 1);
			return true;
		}
		return super.keyPressed(event);
	}

	@Override
	public void onClose() {
		if (selected != null) selected = null;
		else minecraft.gui.setScreen(parent);
	}

	private void clearImages() {
		images.values().forEach(ScreenshotImage::close);
		images.clear();
	}

	@Override
	public void removed() {
		clearImages();
		// Workers only own BufferedImages. No GPU resources can be created after this screen closes.
		if (loading != null) loading.cancel(false);
		loading = null;
		if (scan != null) scan.cancel(false);
		scan = null;
		initialized = false;
	}

	private record Shot(Path file, long time, long size) { }
	private record Removed(Path original, Path trash) { }
	private record Hit(int x, int y, int w, int h, Runnable action) { }
}
