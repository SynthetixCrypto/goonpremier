package dev.goonclient.client.module;

import dev.goonclient.Goon;
import dev.goonclient.client.hud.HudModule;
import dev.goonclient.client.modules.combat.ArmorHud;
import dev.goonclient.client.modules.combat.AttackIndicator;
import dev.goonclient.client.modules.combat.BossPrep;
import dev.goonclient.client.modules.combat.ShieldStatus;
import dev.goonclient.client.modules.combat.WorldCombat;
import dev.goonclient.client.modules.combat.DangerMeter;
import dev.goonclient.client.modules.combat.ItemCounter;
import dev.goonclient.client.modules.combat.PotionHud;
import dev.goonclient.client.modules.combat.TargetHud;
import dev.goonclient.client.modules.hud.CompassHud;
import dev.goonclient.client.modules.hud.CoordinatesHud;
import dev.goonclient.client.modules.hud.FrameGraph;
import dev.goonclient.client.modules.hud.HardwareUsage;
import dev.goonclient.client.modules.hud.SimpleHuds;
import dev.goonclient.client.modules.inventory.ContainerPreview;
import dev.goonclient.client.modules.inventory.LootTrackerHud;
import dev.goonclient.client.modules.inventory.PickupNotifier;
import dev.goonclient.client.modules.utility.Interface;
import dev.goonclient.client.modules.utility.UtilityModules;
import dev.goonclient.client.modules.visual.CustomCrosshair;
import dev.goonclient.client.modules.visual.Freelook;
import dev.goonclient.client.modules.visual.Fullbright;
import dev.goonclient.client.modules.visual.Zoom;
import dev.goonclient.client.modules.visual.ItemPhysics;
import dev.goonclient.client.modules.visual.TimeChanger;
import dev.goonclient.client.modules.world.AdventureLogModule;
import dev.goonclient.client.modules.world.DeathTracker;
import dev.goonclient.client.modules.world.Overlays;
import dev.goonclient.client.modules.world.WorldHuds;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.client.Minecraft;

public final class ModuleManager {
	private static final List<Module> MODULES = new ArrayList<>();
	private static final List<HudModule> HUD_MODULES = new ArrayList<>();

	private ModuleManager() {
	}

	public static void init() {
		if (dev.goonclient.client.modules.hud.MinimapHud.available()) register(new dev.goonclient.client.modules.hud.MinimapHud());
		register(
			// HUD
			new CoordinatesHud(),
			new dev.goonclient.client.modules.hud.InputHuds.Keystrokes(),
			new dev.goonclient.client.modules.hud.InputHuds.Cps(),
			new CompassHud(),
			new SimpleHuds.WorldTime(),
			new dev.goonclient.client.modules.hud.FeedbackHud(),
			new dev.goonclient.client.modules.hud.ActiveModulesHud(),
			new SimpleHuds.Fps(),
			new FrameGraph(),
			new HardwareUsage(),
			new SimpleHuds.Ping(),
			new SimpleHuds.Memory(),
			new SimpleHuds.Clock(),
			new SimpleHuds.Speed(),
			// World
			new WorldHuds.LightLevel(),
            new dev.goonclient.client.modules.world.BlockInfo(),
            new dev.goonclient.client.modules.world.BlockFocus(),
            new dev.goonclient.client.modules.world.Breadcrumbs(),
			new WorldHuds.NearbyEntities(),
			new WorldHuds.Mining(),
			new WorldHuds.WaypointList(),
			new DeathTracker(),
			new AdventureLogModule(),
			new Overlays.SpawnOverlay(),
			new Overlays.ChunkBorders(),
			new Overlays.SpawnRange(),
			// Combat
			new ArmorHud(),
			new PotionHud(),
			new TargetHud(),
			new DangerMeter(),
			new ItemCounter(),
			new AttackIndicator(),
            new dev.goonclient.client.modules.combat.ProjectileGuide(),
			new ShieldStatus(),
			new dev.goonclient.client.modules.combat.CooldownsHud(),
			new BossPrep(),
			new dev.goonclient.client.modules.combat.HitDistance(),
			new dev.goonclient.client.modules.combat.NutritionHud(),
			new WorldCombat.HealthBars(),
			new WorldCombat.DamageNumbers(),
			// Inventory
			new PickupNotifier(),
			new ContainerPreview(),
			new LootTrackerHud(),
			new dev.goonclient.client.modules.inventory.InventoryHud(),
			new dev.goonclient.client.modules.inventory.ToolInfoHud(),
            new dev.goonclient.client.modules.inventory.ItemDetails(),
            new dev.goonclient.client.modules.inventory.ItemGuard(),
            new dev.goonclient.client.modules.inventory.ToolSaver(),
			// Visual
			new Zoom(),
			new Freelook(),
			new Fullbright(),
			new CustomCrosshair(),
			new ItemPhysics(),
			new TimeChanger(),
            new dev.goonclient.client.modules.visual.Hitboxes(),
            new dev.goonclient.client.modules.visual.PlayerTags(),
            new dev.goonclient.client.modules.visual.CameraComfort(),
            new dev.goonclient.client.modules.visual.ViewModel(),
            new dev.goonclient.client.modules.visual.WeatherChanger(),
            new dev.goonclient.client.modules.visual.Shaders(),
			// Utility
			new UtilityModules.ToggleSprint(),
			new UtilityModules.ToggleSneak(),
			new UtilityModules.ChatTimestamps(),
			new UtilityModules.BetterChat(),
			new UtilityModules.SessionStatsHud(),
			new dev.goonclient.client.modules.utility.Schematics(),
            new dev.goonclient.client.modules.utility.DiscordRpc(),
            new dev.goonclient.client.modules.utility.TotemAlerts(),
            new dev.goonclient.client.modules.utility.ServerWatch(),
            new Interface()
		);
		Goon.LOGGER.info("Registered {} modules", MODULES.size());
	}

	private static void register(Module... modules) {
		for (Module module : modules) {
			MODULES.add(module);
			if (module instanceof HudModule hud) {
				HUD_MODULES.add(hud);
			}
		}
	}

	public static List<Module> all() {
		return Collections.unmodifiableList(MODULES);
	}

	public static List<HudModule> hudModules() {
		return Collections.unmodifiableList(HUD_MODULES);
	}

	public static List<Module> byCategory(Category category) {
		List<Module> result = new ArrayList<>();
		for (Module module : MODULES) {
			if (module.category() == category) {
				result.add(module);
			}
		}
		return result;
	}

	public static void tick(Minecraft mc) {
		dev.goonclient.client.modules.hud.MinimapHud.syncVisibility();
        dev.goonclient.client.modules.utility.Schematics.sync();
        dev.goonclient.client.modules.visual.Shaders.sync();
        dev.goonclient.client.modules.utility.DiscordRpc.sync(mc);
		for (Module module : MODULES) {
			if (module.isEnabled()) {
				module.onTick(mc);
			}
		}
	}
}
