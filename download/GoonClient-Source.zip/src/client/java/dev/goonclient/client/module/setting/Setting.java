package dev.goonclient.client.module.setting;

import com.google.gson.JsonElement;

/** A single configurable value on a module. The ClickGUI builds its controls from these. */
public abstract class Setting<T> {
	private final String id;
	private final String name;
	private final T defaultValue;
	protected T value;

	protected Setting(String id, String name, T defaultValue) {
		this.id = id;
		this.name = name;
		this.defaultValue = defaultValue;
		this.value = defaultValue;
	}

	public String id() {
		return id;
	}

	public String name() {
		return name;
	}

	public T defaultValue() { return defaultValue; }

	public T get() {
		return value;
	}

	public void set(T value) {
		this.value = value;
	}

	public void reset() {
		set(defaultValue);
	}

	public abstract JsonElement toJson();

	public abstract void fromJson(JsonElement json);
}
