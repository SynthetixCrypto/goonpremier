package dev.goonclient.client;

import dev.goonclient.client.gui.Ui;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

/** Client-side chat messages with the Goon Client prefix. */
public final class GoonChat {
	private GoonChat() {
	}

	public static MutableComponent prefix() {
		return Component.literal("Goon Client » ").withStyle(style -> style.withColor(Ui.accent() & 0xFFFFFF));
	}

	public static void info(String message) {
		send(prefix().append(Component.literal(message).withStyle(style -> style.withColor(0xFFFFFF))));
	}

	public static void error(String message) {
		send(prefix().append(Component.literal(message).withStyle(style -> style.withColor(Ui.BAD & 0xFFFFFF))));
	}

	public static void send(Component component) {
		Minecraft mc = Minecraft.getInstance();
		if (mc.player != null) {
			mc.player.sendSystemMessage(component);
		}
	}
}
