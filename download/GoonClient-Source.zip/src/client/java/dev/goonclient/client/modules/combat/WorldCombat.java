package dev.goonclient.client.modules.combat;

import dev.goonclient.client.gui.Ui;
import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.Module;
import dev.goonclient.client.module.setting.BooleanSetting;
import dev.goonclient.client.module.setting.NumberSetting;
import dev.goonclient.client.render.WorldRender;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.gizmos.GizmoStyle;
import net.minecraft.gizmos.Gizmos;
import net.minecraft.gizmos.TextGizmo;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/** Combat info drawn in the world: health bars over mobs and floating damage numbers. */
public final class WorldCombat {
	private WorldCombat() {
	}

	private static boolean shown(Entity entity, boolean includePlayers) {
		return entity instanceof LivingEntity living && living.isAlive() && !(entity instanceof ArmorStand)
			&& !entity.isInvisible() && (includePlayers || !(entity instanceof Player));
	}

	/** A small bar above each mob's head that always faces you. */
	public static class HealthBars extends Module implements WorldRender.Renderable {
		// Opaque on purpose: see-through gizmos are drawn after opaque ones, so a translucent background would cover the fill
		private static final int BAR_BACKGROUND = 0xFF101113;

		private final NumberSetting range = add(new NumberSetting("range", "Range", 24, 8, 64, 4, " blocks"));
		private final BooleanSetting onlyDamaged = add(new BooleanSetting("only_damaged", "Only hurt mobs", true));
		private final BooleanSetting players = add(new BooleanSetting("players", "Include players", false));
		private final BooleanSetting numbers = add(new BooleanSetting("numbers", "Show numbers", true));

		public HealthBars() {
			super("health_bars", "Health Bars", "A health bar above mobs, so you can see what's nearly dead", Category.COMBAT, false);
		}

		@Override
		public void renderWorld(Minecraft mc, Camera camera, float partialTick) {
			double r = range.get();
			for (Entity entity : mc.level.getEntities(mc.player, mc.player.getBoundingBox().inflate(r), e -> shown(e, players.isOn()))) {
				LivingEntity living = (LivingEntity) entity;
				float max = living.getMaxHealth();
				float health = Math.min(living.getHealth(), max);
				if (max <= 0 || onlyDamaged.isOn() && health >= max) {
					continue;
				}
				// Sit above the name tag when the mob has one
				double lift = entity.getBbHeight() + (entity.shouldShowName() ? 0.75 : 0.45);
				Vec3 centre = entity.getPosition(partialTick).add(0, lift, 0);
				double half = Mth.clamp(entity.getBbWidth() * 0.6, 0.35, 0.8);
				double h = 0.045;
				float fraction = Mth.clamp(health / max, 0f, 1f);

				Vec3[] back = WorldRender.billboard(camera, centre, -half - 0.025, half + 0.025, -h - 0.025, h + 0.025, 0);
				Gizmos.rect(back[0], back[1], back[2], back[3], GizmoStyle.fill(BAR_BACKGROUND));
				Vec3[] fill = WorldRender.billboard(camera, centre, -half, -half + half * 2 * fraction, -h, h, 0.01);
				Gizmos.rect(fill[0], fill[1], fill[2], fill[3], GizmoStyle.fill(Ui.healthColor(fraction)));
				if (numbers.isOn()) {
					String text = format(health) + " / " + format(max);
					Gizmos.billboardText(text, centre.add(0, 0.2, 0), TextGizmo.Style.forColorAndCentered(Ui.TEXT).withScale(0.26f));
				}
			}
		}

		private static String format(float value) {
			return value == Math.floor(value) ? Integer.toString((int) value) : String.format("%.1f", value);
		}
	}

	/** "-4.5" pops up and floats away whenever something near you takes damage. */
	public static class DamageNumbers extends Module implements WorldRender.Renderable {
		private static final long LIFETIME_MS = 1000;

		private final NumberSetting range = add(new NumberSetting("range", "Range", 24, 8, 64, 4, " blocks"));
		private final NumberSetting size = add(new NumberSetting("size", "Size", 1.0, 0.5, 2.0, 0.1, "x"));
		private final BooleanSetting healing = add(new BooleanSetting("healing", "Show healing", false));
		private final BooleanSetting players = add(new BooleanSetting("players", "Include players", true));

		private Map<Integer, Float> lastHealth = new HashMap<>();
		private final List<Popup> popups = new ArrayList<>();

		public DamageNumbers() {
			super("damage_numbers", "Damage Numbers", "Floating numbers showing how much damage each hit did", Category.COMBAT, false);
		}

		@Override
		protected void onDisable() {
			lastHealth.clear();
			popups.clear();
		}

		@Override
		public void onTick(Minecraft mc) {
			if (mc.player == null || mc.level == null) {
				lastHealth.clear();
				return;
			}
			Map<Integer, Float> seen = new HashMap<>();
			long now = System.currentTimeMillis();
			double r = range.get();
			for (Entity entity : mc.level.getEntities(mc.player, mc.player.getBoundingBox().inflate(r),
				e -> e instanceof LivingEntity && !(e instanceof ArmorStand) && (players.isOn() || !(e instanceof Player)))) {
				LivingEntity living = (LivingEntity) entity;
				float health = living.getHealth();
				Float previous = lastHealth.get(entity.getId());
				if (previous != null) {
					float change = health - previous;
					if (change < -0.05f) {
						popups.add(new Popup(spawnPoint(entity), "-" + format(-change), Ui.BAD, now));
					} else if (change > 0.05f && healing.isOn()) {
						popups.add(new Popup(spawnPoint(entity), "+" + format(change), Ui.GOOD, now));
					}
				}
				if (living.isAlive()) {
					seen.put(entity.getId(), health);
				}
			}
			lastHealth = seen;
		}

		private static Vec3 spawnPoint(Entity entity) {
			ThreadLocalRandom random = ThreadLocalRandom.current();
			return entity.position().add(random.nextDouble(-0.35, 0.35), entity.getBbHeight() * 0.8, random.nextDouble(-0.35, 0.35));
		}

		private static String format(float value) {
			return value >= 10 ? Integer.toString(Math.round(value)) : String.format("%.1f", value);
		}

		@Override
		public void renderWorld(Minecraft mc, Camera camera, float partialTick) {
			long now = System.currentTimeMillis();
			Iterator<Popup> it = popups.iterator();
			while (it.hasNext()) {
				Popup popup = it.next();
				float t = (now - popup.time) / (float) LIFETIME_MS;
				if (t >= 1f) {
					it.remove();
					continue;
				}
				float rise = Ui.easeOutCubic(t) * 0.7f;
				float alpha = t < 0.65f ? 1f : 1f - (t - 0.65f) / 0.35f;
				// Pop slightly larger at the start, then settle
				float scale = 0.42f * size.floatValue() * (t < 0.12f ? 1.25f - t * 2f : 1f);
				Gizmos.billboardText(popup.text, popup.pos.add(0, rise, 0),
					TextGizmo.Style.forColorAndCentered(Ui.withAlpha(popup.color, alpha)).withScale(scale));
			}
		}

		private record Popup(Vec3 pos, String text, int color, long time) {
		}
	}
}
