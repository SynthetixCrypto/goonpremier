package dev.goonclient.client.util;

import com.sun.jna.Native;
import com.sun.jna.Pointer;
import com.sun.jna.Structure;
import com.sun.jna.platform.win32.BaseTSD.SIZE_T;
import com.sun.jna.platform.win32.Kernel32;
import com.sun.jna.platform.win32.WinNT.HANDLE;
import com.sun.jna.win32.StdCallLibrary;

/** Resident RAM, private resident RAM and Java heap are distinct. Never forces GC or smooths away real changes. */
public final class MemoryStats {
    public record Sample(long processBytes, long heapUsed, long heapLimit, long privateBytes) {
        public Sample(long processBytes, long heapUsed, long heapLimit) { this(processBytes, heapUsed, heapLimit, -1); }
    }
    private record NativeSample(long resident, long privateResident) {
        private static final NativeSample UNAVAILABLE = new NativeSample(-1, -1);
    }
    private static Sample cached;
    private static long sampledAt;
    private static boolean nativeUnavailable, extendedUnavailable;
    private MemoryStats() {}

    /** Monotonic cache, shared by the HUD and explicit reports; at most two sampling passes per second. */
    public static synchronized Sample sample() {
        long now = System.nanoTime();
        if (cached != null && now - sampledAt < 500_000_000L) return cached;
        NativeSample process = nativeSample();
        Runtime runtime = Runtime.getRuntime();
        cached = new Sample(process.resident(), runtime.totalMemory() - runtime.freeMemory(), runtime.maxMemory(), process.privateResident());
        sampledAt = now;
        return cached;
    }

    private static NativeSample nativeSample() {
        if (nativeUnavailable || !System.getProperty("os.name").startsWith("Windows")) return NativeSample.UNAVAILABLE;
        try {
            if (!extendedUnavailable) {
                ExtendedCounters counters = new ExtendedCounters();
                if (read(counters)) {
                    long resident = counters.workingSet.longValue(), privateResident = counters.privateWorkingSet.longValue();
                    return new NativeSample(resident > 0 ? resident : -1,
                        privateResident > 0 && privateResident <= resident ? privateResident : -1);
                }
                // EX2 requires recent Windows. Older systems still get the original resident metric.
                if (Native.getLastError() == 87 || Native.getLastError() == 122) extendedUnavailable = true;
            }
            Counters counters = new Counters();
            return read(counters) && counters.workingSet.longValue() > 0
                ? new NativeSample(counters.workingSet.longValue(), -1) : NativeSample.UNAVAILABLE;
        } catch (LinkageError ex) {
            nativeUnavailable = true;
            return NativeSample.UNAVAILABLE;
        } catch (RuntimeException ex) {
            // A transient failure must not freeze the counter or permanently disable later samples.
            return NativeSample.UNAVAILABLE;
        }
    }
    private static boolean read(Counters counters) {
        counters.cb = counters.size(); counters.write();
        boolean ok = Api.INSTANCE.K32GetProcessMemoryInfo(Kernel32.INSTANCE.GetCurrentProcess(), counters.getPointer(), counters.cb);
        if (ok) counters.read();
        return ok;
    }
    public interface Api extends StdCallLibrary {
        Api INSTANCE = Native.load("kernel32", Api.class);
        boolean K32GetProcessMemoryInfo(HANDLE process, Pointer counters, int size);
    }
    @Structure.FieldOrder({"cb", "faults", "peakWorkingSet", "workingSet", "peakPaged", "paged", "peakNonPaged", "nonPaged", "pagefile", "peakPagefile"})
    public static class Counters extends Structure {
        public int cb, faults;
        public SIZE_T peakWorkingSet, workingSet, peakPaged, paged, peakNonPaged, nonPaged, pagefile, peakPagefile;
    }
    @Structure.FieldOrder({"privateUsage", "privateWorkingSet", "sharedCommit"})
    public static final class ExtendedCounters extends Counters {
        public SIZE_T privateUsage, privateWorkingSet;
        public long sharedCommit;
    }
}
