package dev.goonclient.client.modules.visual;

import dev.goonclient.client.GoonKeys;
import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.Module;
import dev.goonclient.client.module.setting.BooleanSetting;
import dev.goonclient.client.module.setting.NumberSetting;
import net.minecraft.client.Minecraft;

/** Hold the zoom key to zoom in; scroll while zooming to change how far. */
public class Zoom extends Module {
	private static Zoom instance;

	private final NumberSetting factor = add(new NumberSetting("factor", "Zoom level", 4, 1.5, 15, 0.5, "x"));
	private final BooleanSetting scroll = add(new BooleanSetting("scroll", "Scroll to adjust", true));
	private final BooleanSetting smoothCamera = add(new BooleanSetting("smooth_camera", "Cinematic camera while zoomed", false));
	private final BooleanSetting smoothTransition = add(new BooleanSetting("smooth_transition", "Smooth transition", true));
	private final BooleanSetting reduceSensitivity = add(new BooleanSetting("reduce_sensitivity", "Lower sensitivity while zoomed", true));

	private double scrollFactor = -1;
	private double currentFactor = 1;
	private long lastFrame = System.nanoTime();
	private boolean wasZooming;
	private boolean previousSmoothCamera;

	public Zoom() {
		super("zoom", "Zoom", "Hold C to zoom, scroll to adjust", Category.VISUAL, true);
		instance = this;
	}

	private boolean zooming() {
		Minecraft mc = Minecraft.getInstance();
		return isEnabled() && mc.gui.screen() == null && GoonKeys.ZOOM.isDown();
	}

	@Override
	public void onTick(Minecraft mc) {
		boolean zooming = zooming();
		if (zooming && !wasZooming) {
			scrollFactor = factor.get();
			if (smoothCamera.isOn()) {
				previousSmoothCamera = mc.options.smoothCamera;
				mc.options.smoothCamera = true;
			}
		} else if (!zooming && wasZooming && smoothCamera.isOn()) {
			mc.options.smoothCamera = previousSmoothCamera;
		}
		wasZooming = zooming;
	}

	@Override
	protected void onDisable() {
		if (wasZooming && smoothCamera.isOn()) {
			Minecraft.getInstance().options.smoothCamera = previousSmoothCamera;
		}
		wasZooming = false;
		currentFactor = 1;
	}

	/** Called by the Camera mixin every frame. */
	public static float modifyFov(float fov) {
		if (instance == null) {
			return fov;
		}
		return instance.applyFov(fov);
	}

	private float applyFov(float fov) {
		long now = System.nanoTime();
		float seconds = Math.min(0.1f, (now - lastFrame) / 1_000_000_000f);
		lastFrame = now;
		double target = zooming() ? (scrollFactor > 0 ? scrollFactor : factor.get()) : 1.0;
		if (smoothTransition.isOn()) {
			currentFactor += (target - currentFactor) * (1 - Math.pow(0.0001, seconds));
			if (Math.abs(target - currentFactor) < 0.01) {
				currentFactor = target;
			}
		} else {
			currentFactor = target;
		}
		return (float) (fov / currentFactor);
	}

	/** Called by the MouseHandler mixin; returns true when the scroll was used for zooming. */
	public static boolean onScroll(double amount) {
		if (instance == null || !instance.zooming() || !instance.scroll.isOn() || amount == 0) {
			return false;
		}
		instance.scrollFactor = Math.max(1.5, Math.min(50, instance.scrollFactor * (amount > 0 ? 1.2 : 1 / 1.2)));
		return true;
	}

	/** Mouse sensitivity multiplier, so aiming stays precise while zoomed. */
	public static double sensitivityScale() {
		if (instance == null || !instance.reduceSensitivity.isOn() || instance.currentFactor <= 1.01) {
			return 1.0;
		}
		return 1.0 / instance.currentFactor;
	}
}
