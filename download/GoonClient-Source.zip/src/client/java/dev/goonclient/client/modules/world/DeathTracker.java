package dev.goonclient.client.modules.world;

import dev.goonclient.client.GoonChat;
import dev.goonclient.client.mixin.DeathScreenAccessor;
import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.Module;
import dev.goonclient.client.module.setting.BooleanSetting;
import dev.goonclient.client.tracker.AdventureLog;
import dev.goonclient.client.tracker.SessionStats;
import dev.goonclient.client.waypoint.Waypoint;
import dev.goonclient.client.waypoint.WaypointManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import net.minecraft.client.gui.screens.DeathScreen;
import net.minecraft.core.BlockPos;

/** Marks every death with a waypoint, a chat message and (optionally) a screenshot, and logs what killed you. */
public class DeathTracker extends Module {
	/** How long to wait for the death screen (which carries the death message) before logging without it. */
	private static final int CAUSE_WAIT_TICKS = 40;

	private final BooleanSetting waypoint = add(new BooleanSetting("waypoint", "Create death waypoint", true));
	private final BooleanSetting screenshot = add(new BooleanSetting("screenshot", "Screenshot on death", false));
	private boolean wasDead;
	private BlockPos pendingPos;
	private String pendingDimension;
	private int pendingTicks;

	public DeathTracker() {
		super("death_tracker", "Death Tracker", "Saves where you died as a waypoint and tells you in chat", Category.WORLD, true);
	}

	@Override
	public void onTick(Minecraft mc) {
		if (mc.player == null || mc.level == null) {
			wasDead = false;
			pendingPos = null;
			return;
		}
		boolean dead = mc.player.isDeadOrDying();
		if (dead && !wasDead) {
			onDeath(mc);
		}
		wasDead = dead;

		if (pendingPos != null) {
			if (mc.gui.screen() instanceof DeathScreen deathScreen) {
				String cause = ((DeathScreenAccessor) deathScreen).goonclient$getCauseOfDeath().getString();
				AdventureLog.onDeath(pendingPos, pendingDimension, cause);
				pendingPos = null;
			} else if (++pendingTicks > CAUSE_WAIT_TICKS) {
				AdventureLog.onDeath(pendingPos, pendingDimension, "");
				pendingPos = null;
			}
		}
	}

	private void onDeath(Minecraft mc) {
		SessionStats.onDeath();
		BlockPos pos = mc.player.blockPosition();
		String dimension = mc.level.dimension().identifier().toString();
		String name = "Death " + (WaypointManager.deathCount() + 1);
		if (waypoint.isOn()) {
			WaypointManager.add(new Waypoint(name, pos.getX(), pos.getY(), pos.getZ(), dimension, WaypointManager.DEATH_COLOR, true, System.currentTimeMillis()));
		}
		GoonChat.info("You died at " + pos.getX() + " " + pos.getY() + " " + pos.getZ() + " in " + WorldHuds.dimensionName(dimension)
			+ (waypoint.isOn() ? " - saved as waypoint '" + name + "'" : ""));
		if (screenshot.isOn()) {
			Screenshot.grab(mc, false);
		}
		pendingPos = pos;
		pendingDimension = dimension;
		pendingTicks = 0;
	}
}
