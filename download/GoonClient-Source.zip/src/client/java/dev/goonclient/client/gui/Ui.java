package dev.goonclient.client.gui;

import dev.goonclient.Goon;
import dev.goonclient.client.gui.render.GoonFont;
import dev.goonclient.client.gui.render.Shapes;
import dev.goonclient.client.modules.utility.Interface;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FontDescription;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.util.ARGB;

/**
 * The Goon Client look ("Graphite"): neutral charcoal surfaces, hairline borders, white text, grey labels and a single
 * accent colour used only for state. All text and shapes go through {@link GoonFont} and {@link Shapes}, which draw on
 * real screen pixels with anti-aliasing, so nothing looks pixelated at any GUI scale.
 *
 * <p>The {@code Font} parameters are kept so call sites read like vanilla code; they're not used.
 */
public final class Ui {
	// Surfaces, darkest to lightest
	public static final int BG = 0xFF0F1012;
	public static final int FIELD = 0xFF141517;
	public static final int PANEL = 0xFF18191C;
	public static final int RAISED = 0xFF1E1F23;
	public static final int RAISED_HOVER = 0xFF25262B;
	public static final int CONTROL = 0xFF2C2E33;
	public static final int BORDER = 0xFF26272B;
	public static final int BORDER_STRONG = 0xFF383A40;

	// Text
	public static final int TEXT = 0xFFF4F5F7;
	public static final int MUTED = 0xFF8B9099;
	public static final int FAINT = 0xFF5D6169;
	/** Text drawn on top of the accent colour. */
	public static final int ON_ACCENT = 0xFF08130E;

	// Meaning
	public static final int GOOD = 0xFF4ADE80;
	public static final int WARN = 0xFFF5B83D;
	public static final int BAD = 0xFFF0616D;

	// In-game HUD panels: neutral, see-through, no tint
	public static final int HUD_BACKGROUND = 0xB4111214;

	/** Body text size in GUI units (matches the line height the HUD layouts were designed around). */
	public static final float TEXT_SIZE = 8.5f;

	private static final FontDescription UI_FONT = new FontDescription.Resource(Goon.id("ui"));
	private static final FontDescription UI_BOLD = new FontDescription.Resource(Goon.id("ui_bold"));

	/** Each animated value remembers when it was last updated, so it moves at the same speed however often it's drawn. */
	private static final Map<String, float[]> ANIMATIONS = new HashMap<>();
	private static final long START = System.nanoTime();

	private Ui() {
	}

	// ---- Theme ---------------------------------------------------------------------------------------------

	/** The accent colour chosen in the Interface module. */
	public static int accent() {
		return Interface.accent();
	}

	/** Applies the panel opacity setting to a surface colour. */
	public static int glass(int color) {
		return withAlpha(color, Interface.panelOpacity());
	}

	// ---- Text ----------------------------------------------------------------------------------------------

	/** A chat/vanilla component in the UI font, for places that must use Minecraft's own text rendering. */
	public static MutableComponent styled(String text, boolean bold) {
		return Component.literal(text).withStyle(style -> style.withFont(bold ? UI_BOLD : UI_FONT));
	}

	public static void text(GuiGraphicsExtractor g, Font font, String text, int x, int y, int color) {
		GoonFont.draw(g, text, x, y, TEXT_SIZE, GoonFont.Weight.REGULAR, color, false);
	}

	public static void text(GuiGraphicsExtractor g, Font font, String text, int x, int y, int color, boolean shadow) {
		GoonFont.draw(g, text, x, y, TEXT_SIZE, GoonFont.Weight.REGULAR, color, shadow);
	}

	public static void bold(GuiGraphicsExtractor g, Font font, String text, int x, int y, int color) {
		GoonFont.draw(g, text, x, y, TEXT_SIZE, GoonFont.Weight.BOLD, color, false);
	}

	public static void bold(GuiGraphicsExtractor g, Font font, String text, int x, int y, int color, boolean shadow) {
		GoonFont.draw(g, text, x, y, TEXT_SIZE, GoonFont.Weight.BOLD, color, shadow);
	}

	/** Bold text at a multiple of the body size, e.g. headings. */
	public static void scaledBold(GuiGraphicsExtractor g, Font font, String text, float x, float y, float scale, int color) {
		GoonFont.draw(g, text, x, y, TEXT_SIZE * scale, GoonFont.Weight.BOLD, color, false);
	}

	public static int width(Font font, String text) {
		return (int) Math.ceil(GoonFont.width(text, TEXT_SIZE, GoonFont.Weight.REGULAR));
	}

	public static int boldWidth(Font font, String text) {
		return (int) Math.ceil(GoonFont.width(text, TEXT_SIZE, GoonFont.Weight.BOLD));
	}

	/** Shortens text to fit, adding "..." when it had to cut. */
	public static String ellipsize(Font font, String text, int maxWidth, boolean bold) {
		return ellipsize(text, maxWidth, TEXT_SIZE, bold ? GoonFont.Weight.BOLD : GoonFont.Weight.REGULAR);
	}

	public static String ellipsize(String text, float maxWidth, float size, GoonFont.Weight weight) {
		if (GoonFont.width(text, size, weight) <= maxWidth) {
			return text;
		}
		String cut = text;
		while (!cut.isEmpty() && GoonFont.width(cut + "...", size, weight) > maxWidth) {
			cut = cut.substring(0, cut.length() - 1);
		}
		return cut.stripTrailing() + "...";
	}

	// ---- Icons ---------------------------------------------------------------------------------------------

	/** A "settings" icon: three slider lines with knobs, 9x9. */
	public static void tuneIcon(GuiGraphicsExtractor g, float x, float y, int color) {
		for (int i = 0; i < 3; i++) {
			float ly = y + 1.5f + i * 3f;
			Shapes.roundRect(g, x, ly - 0.35f, x + 9, ly + 0.35f, 0.35f, withAlpha(color, 0.55f));
			float knob = x + (i == 1 ? 5.5f : i == 0 ? 2.5f : 6.5f);
			Shapes.circle(g, knob, ly, 1.35f, color);
		}
	}

	/** A left-pointing chevron, about 4x7. */
	public static void chevronLeft(GuiGraphicsExtractor g, int x, int y, int color) {
		GoonFont.draw(g, "‹", x - 0.5f, y - 2.5f, 12f, GoonFont.Weight.BOLD, color, false);
	}

	/** The Goon Client mark: a dark glass tile with the rounded-square "G" in the accent colour. */
	public static void logoMark(GuiGraphicsExtractor g, Font font, float x, float y, float size, float alpha) {
		dev.goonclient.client.gui.render.Logo.draw(g, x, y, size, accent(), alpha);
	}

	// ---- Animation -----------------------------------------------------------------------------------------

	/** Kept for older call sites; animations now track their own time, so this does nothing. */
	public static void beginFrame() {
	}

	/**
	 * Animates a named value to a target. Every change plays as a short ease-out tween that always lands exactly on
	 * the target (exponential smoothing never quite arrived, which made toggles look stuck halfway). {@code speed}
	 * picks the length: 0.42 is about 0.2 s, 0.6 about 0.14 s, 0.9 about 0.1 s. Time is real time, so it doesn't
	 * matter how often or from where this is called.
	 */
	public static float animate(String key, float target, float speed) {
		float now = (System.nanoTime() - START) / 1_000_000_000f;
		float[] state = ANIMATIONS.get(key);
		if (state == null) {
			// value, from, to, start time
			ANIMATIONS.put(key, new float[]{target, target, target, now});
			return target;
		}
		if (target != state[2]) {
			state[1] = state[0];
			state[2] = target;
			state[3] = now;
		}
		float duration = Math.max(0.08f, Math.min(0.26f, 0.085f / Math.max(0.05f, speed)));
		float t = (now - state[3]) / duration;
		state[0] = t >= 1f ? target : state[1] + (target - state[1]) * easeOutCubic(t);
		return state[0];
	}

	/** Jumps a named value straight to a target (no animation). */
	public static void snap(String key, float value) {
		ANIMATIONS.put(key, new float[]{value, value, value, (System.nanoTime() - START) / 1_000_000_000f});
	}

	/**
	 * Scale for full-screen Goon Client menus, so they lay out in a comfortable virtual space (at least 640x380)
	 * even at large GUI scales, where Minecraft leaves only about 480x270 units.
	 */
	public static float menuScale(int width, int height) {
		return Math.max(0.6f, Math.min(1f, Math.min(width / 640f, height / 380f)));
	}

	public static float easeOutCubic(float t) {
		float inv = 1f - Math.max(0f, Math.min(1f, t));
		return 1f - inv * inv * inv;
	}

	// ---- Colour --------------------------------------------------------------------------------------------

	public static int withAlpha(int color, float alpha) {
		int a = Math.round(ARGB.alpha(color) * Math.max(0f, Math.min(1f, alpha)));
		return (a << 24) | (color & 0x00FFFFFF);
	}

	public static int lerp(float t, int from, int to) {
		return ARGB.linearLerp(Math.max(0f, Math.min(1f, t)), from, to);
	}

	/** Red at 0, amber at 0.5, green at 1. */
	public static int healthColor(float fraction) {
		return fraction < 0.5f ? lerp(fraction * 2f, BAD, WARN) : lerp((fraction - 0.5f) * 2f, WARN, GOOD);
	}

	// ---- Shapes --------------------------------------------------------------------------------------------

	public static void roundRect(GuiGraphicsExtractor g, float x1, float y1, float x2, float y2, float radius, int color) {
		Shapes.roundRect(g, x1, y1, x2, y2, radius, color);
	}

	/** A soft, neutral drop shadow under a panel (elevation, not a glow). */
	public static void shadow(GuiGraphicsExtractor g, float x1, float y1, float x2, float y2, float radius, float size, float alpha) {
		Shapes.shadow(g, x1, y1, x2, y2, radius, size, size * 0.3f, alpha * 0.55f);
	}

	/** Rounded panel with a hairline border. */
	public static void roundOutline(GuiGraphicsExtractor g, float x1, float y1, float x2, float y2, float radius, int border, int fill) {
		Shapes.panel(g, x1, y1, x2, y2, radius, fill, border);
	}

	/** Pill-shaped on/off switch, 20x10. */
	public static void toggleSwitch(GuiGraphicsExtractor g, float x, float y, float on, float alpha) {
		Shapes.roundRect(g, x, y, x + 20, y + 10, 5, withAlpha(lerp(on, CONTROL, accent()), alpha));
		float knob = x + 5 + on * 10;
		// A white knob vanishes on a very light accent (the White preset), so it turns dark there
		int knobOn = luminance(accent()) > 0.75f ? 0xFF1A1B1E : 0xFFFFFFFF;
		Shapes.circle(g, knob, y + 5, 3.8f, withAlpha(lerp(on, 0xFFB4B8C0, knobOn), alpha));
	}

	/** Perceived brightness from 0 (black) to 1 (white). */
	public static float luminance(int color) {
		return (0.2126f * ARGB.red(color) + 0.7152f * ARGB.green(color) + 0.0722f * ARGB.blue(color)) / 255f;
	}

	public static boolean inside(double mx, double my, float x1, float y1, float x2, float y2) {
		return mx >= x1 && mx < x2 && my >= y1 && my < y2;
	}
}
