package dev.goonclient.client.tracker;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/** Everything counted since joining the current world or server. */
public final class SessionStats {
	private static final long KILL_CREDIT_MS = 5000;
	private static final long RATE_WINDOW_MS = 60_000;

	private static long startedAt = System.currentTimeMillis();
	private static int blocksMined;
	private static int mobsKilled;
	private static int deaths;
	private static int itemsPickedUp;
	private static int xpGained;
	private static double distance;
	private static final Map<String, Integer> ORES = new LinkedHashMap<>();
	private static final Deque<Long> RECENT_BLOCKS = new ArrayDeque<>();
	private static final Map<Integer, Long> RECENTLY_ATTACKED = new HashMap<>();

	private static Vec3 lastPosition;
	private static ResourceKey<Level> lastDimension;
	private static int lastTotalXp = -1;

	private SessionStats() {
	}

	public static void reset() {
		startedAt = System.currentTimeMillis();
		blocksMined = 0;
		mobsKilled = 0;
		deaths = 0;
		itemsPickedUp = 0;
		xpGained = 0;
		distance = 0;
		ORES.clear();
		RECENT_BLOCKS.clear();
		RECENTLY_ATTACKED.clear();
		lastPosition = null;
		lastDimension = null;
		lastTotalXp = -1;
	}

	public static void tick(Minecraft mc) {
		if (mc.player == null || mc.level == null) {
			return;
		}
		Vec3 position = mc.player.position();
		if (lastPosition != null && mc.level.dimension() == lastDimension) {
			double dx = position.x - lastPosition.x;
			double dz = position.z - lastPosition.z;
			double moved = Math.sqrt(dx * dx + dz * dz);
			// Ignore teleports
			if (moved < 10) {
				distance += moved;
			}
		}
		lastPosition = position;
		lastDimension = mc.level.dimension();

		int totalXp = mc.player.totalExperience;
		if (lastTotalXp >= 0 && totalXp > lastTotalXp) {
			xpGained += totalXp - lastTotalXp;
		}
		lastTotalXp = totalXp;

		long now = System.currentTimeMillis();
		Iterator<Map.Entry<Integer, Long>> attacked = RECENTLY_ATTACKED.entrySet().iterator();
		while (attacked.hasNext()) {
			Map.Entry<Integer, Long> entry = attacked.next();
			Entity entity = mc.level.getEntity(entry.getKey());
			if (now - entry.getValue() > KILL_CREDIT_MS || entity == null) {
				attacked.remove();
			} else if (entity instanceof LivingEntity living && living.isDeadOrDying()) {
				mobsKilled++;
				attacked.remove();
			}
		}
		while (!RECENT_BLOCKS.isEmpty() && now - RECENT_BLOCKS.peekFirst() > RATE_WINDOW_MS) {
			RECENT_BLOCKS.pollFirst();
		}
	}

	public static void onAttack(Entity target) {
		if (target instanceof LivingEntity) {
			RECENTLY_ATTACKED.put(target.getId(), System.currentTimeMillis());
		}
	}

	public static void onBlockBroken(BlockState state) {
		blocksMined++;
		RECENT_BLOCKS.addLast(System.currentTimeMillis());
		String path = BuiltInRegistries.BLOCK.getKey(state.getBlock()).getPath();
		if (path.endsWith("_ore") || path.equals("ancient_debris")) {
			ORES.merge(state.getBlock().getName().getString(), 1, Integer::sum);
		}
	}

	public static void onDeath() {
		deaths++;
	}

	public static void onPickup(int amount) {
		itemsPickedUp += amount;
	}

	public static long durationMs() {
		return System.currentTimeMillis() - startedAt;
	}

	public static int blocksMined() {
		return blocksMined;
	}

	public static int blocksPerMinute() {
		return RECENT_BLOCKS.size();
	}

	public static Map<String, Integer> ores() {
		return ORES;
	}

	public static int mobsKilled() {
		return mobsKilled;
	}

	public static int deaths() {
		return deaths;
	}

	public static int itemsPickedUp() {
		return itemsPickedUp;
	}

	public static int xpGained() {
		return xpGained;
	}

	public static double distance() {
		return distance;
	}

	public static String formatDuration(long ms) {
		long seconds = ms / 1000;
		long hours = seconds / 3600;
		long minutes = (seconds % 3600) / 60;
		long secs = seconds % 60;
		return hours > 0 ? String.format("%d:%02d:%02d", hours, minutes, secs) : String.format("%d:%02d", minutes, secs);
	}

	public static String formatDistance(double blocks) {
		return blocks >= 1000 ? String.format("%.2f km", blocks / 1000) : String.format("%d m", (int) blocks);
	}
}
