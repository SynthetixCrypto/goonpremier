package dev.goonclient.client.mixin;

import java.util.List;
import java.util.Set;
import net.fabricmc.loader.api.FabricLoader;
import org.objectweb.asm.tree.ClassNode;
import org.spongepowered.asm.mixin.extensibility.IMixinConfigPlugin;
import org.spongepowered.asm.mixin.extensibility.IMixinInfo;

/** Optional-mod hooks must not resolve their target classes when that mod isn't installed. */
public final class GoonMixinPlugin implements IMixinConfigPlugin {
	@Override public void onLoad(String mixinPackage) { }
	@Override public String getRefMapperConfig() { return null; }
	@Override public boolean shouldApplyMixin(String target, String mixin) {
		if (mixin.endsWith(".XaeroWorldMapFileMixin")) return FabricLoader.getInstance().isModLoaded("xaeroworldmap");
		if (mixin.contains(".litematica.")) return FabricLoader.getInstance().isModLoaded("litematica");
        return !mixin.contains(".xaero.") || FabricLoader.getInstance().isModLoaded("xaerominimap");
	}
	@Override public void acceptTargets(Set<String> mine, Set<String> others) { }
	@Override public List<String> getMixins() { return null; }
	@Override public void preApply(String target, ClassNode node, String mixin, IMixinInfo info) { }
	@Override public void postApply(String target, ClassNode node, String mixin, IMixinInfo info) { }
}
