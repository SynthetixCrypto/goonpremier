package dev.goonclient.client.gui;

import dev.goonclient.client.gui.render.Shapes;
import dev.goonclient.client.hud.HudRenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.entity.HumanoidArm;

/** Paint only the native slot backgrounds; item rendering, controls and HUD geometry stay with Minecraft. */
public final class HotbarStyle {
    /** Vanilla's offhand slot sits 29 units outside the hotbar; its item starts 26 units out. */
    private static final int OFFHAND_W = 29;

    private HotbarStyle() { }

    /**
     * One glass bar behind all nine slots, as in the Combatant reference: when the offhand holds something the bar
     * grows to take it in, with a thin divider between the offhand and the hotbar.
     */
    public static void background(GuiGraphicsExtractor g, float x, float y, float w, float h) {
        int side = offhandSide();
        float x1 = side < 0 ? x - OFFHAND_W : x, x2 = side > 0 ? x + w + OFFHAND_W : x + w;
        HudRenderUtil.panel(g, x1, y, x2 - x1, h, 6, true, 1);
        HudRenderUtil.rim(g, x1, y, x2 - x1, h, 6, 1);
        if (side != 0) {
            float dx = side < 0 ? x - 3.5f : x + w + 3.5f;
            HudRenderUtil.bar(g, dx - .25f, y + 4.5f, .5f, h - 9, HudRenderUtil.setAlpha(HudRenderUtil.TEXT_MUTED, 0x52));
        }
    }

    /** The selected slot: a rounded square tinted and outlined in the accent colour. */
    public static void selected(GuiGraphicsExtractor g, float x, float y, float w, float h) {
        Shapes.panel(g, x + 2, y + 2, x + w - 2, y + h - 1, 4.5f, Ui.withAlpha(Ui.accent(), .22f), Ui.withAlpha(Ui.accent(), .9f));
    }

    /** The offhand slot's own sprite: nothing, {@link #background} already drew it into the bar. */
    public static void offhand(GuiGraphicsExtractor g, float x, float y, float w, float h) {
    }

    /** -1 when the offhand slot shows left of the hotbar, 1 right, 0 when it's empty. */
    private static int offhandSide() {
        var player = Minecraft.getInstance().player;
        if (player == null || player.getOffhandItem().isEmpty()) return 0;
        return player.getMainArm().getOpposite() == HumanoidArm.LEFT ? -1 : 1;
    }
}
