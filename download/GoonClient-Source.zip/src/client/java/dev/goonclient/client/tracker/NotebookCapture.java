package dev.goonclient.client.tracker;

import java.util.Arrays;

/** Client-thread frame cadence collector; the hot path uses only primitives and a fixed array. */
public final class NotebookCapture {
    public static final long WINDOW_NANOS = 60_000_000_000L;
    public static final int CAPACITY = 240_000;
    public enum Stop { COMPLETE, CANCELLED, DISCONNECTED, SAMPLE_LIMIT }
    private final long[] frames = new long[CAPACITY];
    private boolean running, anchored;
    private long started, lastFrame, elapsed, measured;
    private int count, over33, over50;
    private Stop stop;

    public void start(long now) {
        started = now; elapsed = measured = 0; count = over33 = over50 = 0;
        anchored = false; stop = null; running = true;
    }
    public boolean running() { return running; }
    public boolean hasCapture() { return running || stop != null; }
    public int count() { return count; }
    public long measuredNanos() { return measured; }
    public long elapsedNanos() { return elapsed; }
    public Stop stopReason() { return stop; }

    /** Start-to-start intervals count only when both endpoints and the intervening frame are eligible. */
    public void frame(long now, boolean eligible, boolean connected) {
        if (!running) return;
        elapsed = Math.max(0, Math.min(WINDOW_NANOS, now - started));
        if (now - started > WINDOW_NANOS) { stop(now, Stop.COMPLETE); return; }
        if (!connected) { stop(now, Stop.DISCONNECTED); return; }
        if (eligible && anchored) {
            long delta = now - lastFrame;
            if (delta > 0) {
                frames[count++] = delta; measured += delta;
                if (delta > 33_000_000L) over33++;
                if (delta > 50_000_000L) over50++;
                if (count == CAPACITY) { stop(now, Stop.SAMPLE_LIMIT); return; }
            }
        }
        anchored = eligible; lastFrame = now;
        if (now - started == WINDOW_NANOS) stop(now, Stop.COMPLETE);
    }
    /** A menu/focus/world transition inside a frame invalidates its next interval. */
    public void boundary(boolean eligible) { if (!eligible) anchored = false; }
    public void stop(long now, Stop reason) {
        if (!running) return;
        elapsed = Math.max(0, Math.min(WINDOW_NANOS, now - started));
        stop = now - started >= WINDOW_NANOS ? Stop.COMPLETE : reason;
        running = false; anchored = false;
    }
    /** Called on demand after capture, never by the per-frame hook. */
    public Result result() {
        if (running || stop == null) return null;
        return new Result(Arrays.copyOf(frames, count), measured, elapsed, over33, over50, stop);
    }
    public static final class Result {
        private final long[] frames;
        private final long measured, elapsed;
        private final int over33, over50;
        private final Stop stop;
        private final double p95, p99, max;
        private Result(long[] frames, long measured, long elapsed, int over33, int over50, Stop stop) {
            this.frames = frames; this.measured = measured; this.elapsed = elapsed;
            this.over33 = over33; this.over50 = over50; this.stop = stop;
            long[] sorted = frames.clone(); Arrays.sort(sorted);
            p95 = percentile(sorted, .95); p99 = percentile(sorted, .99);
            max = sorted.length == 0 ? 0 : sorted[sorted.length - 1] / 1_000_000d;
        }
        private static double percentile(long[] sorted, double p) {
            return sorted.length == 0 ? 0 : sorted[(int)Math.ceil(p * sorted.length) - 1] / 1_000_000d;
        }
        public int samples() { return frames.length; }
        public long frameNanos(int index) { return frames[index]; }
        public double activeSeconds() { return measured / 1_000_000_000d; }
        public double elapsedSeconds() { return elapsed / 1_000_000_000d; }
        public double meanFps() { return measured == 0 ? 0 : frames.length * 1_000_000_000d / measured; }
        public double p95Ms() { return p95; }
        public double p99Ms() { return p99; }
        public double maxMs() { return max; }
        public int over33() { return over33; }
        public int over50() { return over50; }
        public Stop stop() { return stop; }
        public boolean early() { return stop != Stop.COMPLETE; }
        /** A small partial capture still has useful data, but unstable estimates. */
        public boolean provisional() { return measured < 5_000_000_000L || frames.length < 120; }
    }
}
