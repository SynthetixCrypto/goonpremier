package dev.goonclient.client.gui;

import java.util.List;
import net.minecraft.util.ARGB;

/**
 * Colour themes. Each is a dark base plus one or two accents; the twelve-colour swatch row on the Themes page is
 * derived from them, so every theme previews the same way. Accents of the themes Combatant also has are the values
 * from its Themes.java (Copyright (c) 2026 pivosos2007, GPL-3.0).
 */
public final class Themes {
	public record Theme(String name, int accent, int accent2, int base) {
		/** Twelve preview swatches: base tones, the accent ramp and the light text tones. */
		public int[] swatches() {
			int dim = ARGB.linearLerp(0.62f, accent, base);
			int deep = ARGB.linearLerp(0.82f, accent, base);
			int light = ARGB.linearLerp(0.45f, accent, 0xFFFFFFFF);
			int grey = ARGB.linearLerp(0.5f, base, 0xFFB8B4C0);
			return new int[]{base, accent, dim, deep, ARGB.linearLerp(0.5f, base, deep), accent2, light,
				grey, 0xFFE4E2EA, 0xFFF4F3F7, ARGB.linearLerp(0.35f, grey, 0xFFFFFFFF), accent};
		}
	}

	public static final List<Theme> ALL = List.of(
		new Theme("Noir", 0xFFE16B78, 0xFFE07A88, 0xFF16141A),
		new Theme("Classic", 0xFF5CC8E7, 0xFF6FD3E2, 0xFF11181C),
		new Theme("Legacy", 0xFF767C94, 0xFFB7BCCB, 0xFF141518),
		new Theme("Amber", 0xFFE69A43, 0xFFF2C27A, 0xFF1A1510),
		new Theme("Purple", 0xFF9B6BFF, 0xFFB397FF, 0xFF15121E),
		new Theme("Blue", 0xFF2E64CC, 0xFF7AA8FF, 0xFF10141E),
		new Theme("Azure", 0xFF5DA7FF, 0xFF8CC6FF, 0xFF0F161D),
		new Theme("Nitro", 0xFF7A5CFF, 0xFF3D8BF0, 0xFF12121E),
		new Theme("Sunset", 0xFFFF7A45, 0xFFE05C8A, 0xFF1C1314),
		new Theme("Aurora", 0xFF2DD9C3, 0xFF7A6CF0, 0xFF0F1718),
		new Theme("Mint", 0xFF43E0B2, 0xFF7FEBBE, 0xFF0F1513),
		new Theme("Sky", 0xFF4DA3FF, 0xFF8EC6FF, 0xFF0F1520),
		new Theme("Violet", 0xFF9D8CFF, 0xFFC4B9FF, 0xFF14121D),
		new Theme("Rose", 0xFFFF6B9A, 0xFFFF9DBC, 0xFF1C1218),
		new Theme("Red", 0xFFFF4655, 0xFFFF7D88, 0xFF1C1012),
		new Theme("White", 0xFFE6E7EA, 0xFFFFFFFF, 0xFF151518));

	public static final String DEFAULT = "Noir";

	private Themes() {
	}

	public static String[] names() {
		return ALL.stream().map(Theme::name).toArray(String[]::new);
	}

	public static Theme find(String name) {
		for (Theme theme : ALL) {
			if (theme.name().equals(name)) {
				return theme;
			}
		}
		return ALL.getFirst();
	}
}
