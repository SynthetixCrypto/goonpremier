package dev.goonclient.client.expedition;

import com.google.gson.*;
import dev.goonclient.client.utility.LocalFiles;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/** One local store shared across worlds. Publish memory only after a complete replacement is saved. */
public final class ExpeditionStore {
    public static final int MAX_PLANS = 32;
    public static final long MAX_BYTES = 512 * 1024;
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private final Path file;
    private List<ExpeditionPlan> plans = List.of();
    private String error = "";
    private boolean readable = true;

    public ExpeditionStore(Path file) { this.file = file; reload(); }
    public List<ExpeditionPlan> plans() { return plans; }
    public String error() { return error; }
    public boolean writable() { return readable; }

    public void reload() {
        try {
            if (Files.notExists(file, LinkOption.NOFOLLOW_LINKS)) plans = List.of();
            else plans = decode(LocalFiles.read(file, MAX_BYTES));
            error = "";
            readable = true;
        } catch (IOException | RuntimeException e) {
            readable = false;
            error = "Plans file could not be read. Original retained; repair or move expedition-plans.json, then Re-read.";
        }
    }

    public boolean save(ExpeditionPlan plan) {
        List<ExpeditionPlan> next = new ArrayList<>(plans);
        next.removeIf(p -> p.id().equals(plan.id()));
        next.add(plan);
        return replace(next);
    }

    public boolean remove(String id) { return replace(plans.stream().filter(p -> !p.id().equals(id)).toList()); }
    public boolean clear() { return replace(List.of()); }

    private boolean replace(List<ExpeditionPlan> next) {
        if (!readable) return false;
        try {
            String json = encode(next);
            LocalFiles.write(file, json);
            plans = List.copyOf(next);
            error = "";
            return true;
        } catch (IOException | RuntimeException e) {
            error = e instanceof IllegalArgumentException ? e.getMessage() : "Couldn't save plans. Check the config folder is writable and retry.";
            return false;
        }
    }

    public static String encode(List<ExpeditionPlan> plans) {
        validate(plans);
        JsonObject root = new JsonObject();
        root.addProperty("version", 1);
        root.add("plans", GSON.toJsonTree(plans));
        String json = GSON.toJson(root);
        if (json.getBytes(StandardCharsets.UTF_8).length > MAX_BYTES) throw new IllegalArgumentException("Plans file exceeds 512 KiB.");
        return json;
    }

    public static List<ExpeditionPlan> decode(String json) {
        if (json.getBytes(StandardCharsets.UTF_8).length > MAX_BYTES) throw new IllegalArgumentException("Plans file exceeds 512 KiB.");
        JsonObject root = JsonParser.parseString(json).getAsJsonObject();
        if (integer(root, "version") != 1) throw new IllegalArgumentException("Unsupported plans version.");
        JsonArray array = root.getAsJsonArray("plans");
        if (array.size() > MAX_PLANS) throw new IllegalArgumentException("At most 32 named plans.");
        List<ExpeditionPlan> result = new ArrayList<>();
        for (JsonElement element : array) {
            JsonObject p = element.getAsJsonObject();
            JsonArray supplies = p.getAsJsonArray("supplies"), tasks = p.getAsJsonArray("tasks");
            if (supplies.size() + tasks.size() > ExpeditionPlan.MAX_ROWS) throw new IllegalArgumentException("Too many checklist rows.");
            List<ExpeditionPlan.Supply> s = new ArrayList<>();
            for (JsonElement row : supplies) {
                JsonObject r = row.getAsJsonObject();
                s.add(new ExpeditionPlan.Supply(string(r, "item"), integer(r, "target")));
            }
            List<ExpeditionPlan.Task> t = new ArrayList<>();
            for (JsonElement row : tasks) {
                JsonObject r = row.getAsJsonObject();
                JsonPrimitive done = r.getAsJsonPrimitive("done");
                if (!done.isBoolean()) throw new IllegalArgumentException("Invalid checklist state.");
                t.add(new ExpeditionPlan.Task(string(r, "label"), done.getAsBoolean()));
            }
            ExpeditionPlan.Destination destination = null;
            if (p.has("destination") && !p.get("destination").isJsonNull()) {
                JsonObject d = p.getAsJsonObject("destination");
                destination = new ExpeditionPlan.Destination(string(d,"world"), string(d,"name"), string(d,"dimension"),
                        integer(d,"x"), integer(d,"y"), integer(d,"z"));
            }
            result.add(new ExpeditionPlan(string(p,"id"), string(p,"name"), s, t, destination));
        }
        validate(result);
        return List.copyOf(result);
    }

    private static String string(JsonObject object, String key) {
        JsonPrimitive p = object.getAsJsonPrimitive(key);
        if (!p.isString()) throw new IllegalArgumentException("Invalid text field.");
        return p.getAsString();
    }

    private static int integer(JsonObject object, String key) {
        JsonPrimitive p = object.getAsJsonPrimitive(key);
        if (!p.isNumber()) throw new IllegalArgumentException("Invalid number field.");
        return p.getAsBigDecimal().intValueExact();
    }

    private static void validate(List<ExpeditionPlan> plans) {
        if (plans.size() > MAX_PLANS) throw new IllegalArgumentException("At most 32 named plans.");
        if (plans.stream().map(ExpeditionPlan::id).distinct().count() != plans.size()) throw new IllegalArgumentException("Duplicate plan ID.");
        if (plans.stream().map(p -> p.name().toLowerCase(Locale.ROOT)).distinct().count() != plans.size())
            throw new IllegalArgumentException("A plan with this name already exists. Choose another name.");
    }
}
