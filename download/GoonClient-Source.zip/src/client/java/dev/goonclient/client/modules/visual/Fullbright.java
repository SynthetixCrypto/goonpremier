package dev.goonclient.client.modules.visual;

import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.Module;
import dev.goonclient.client.module.setting.NumberSetting;
import net.minecraft.client.renderer.state.LightmapRenderState;
import org.joml.Vector3f;

/** Lights everything up like Night Vision, without touching your gamma setting. */
public class Fullbright extends Module {
	private static Fullbright instance;
	private static final Vector3f WHITE = new Vector3f(1f, 1f, 1f);

	private final NumberSetting strength = add(new NumberSetting("strength", "Strength", 100, 10, 100, 5, "%"));

	public Fullbright() {
		super("fullbright", "Fullbright", "See in the dark without torches or potions", Category.VISUAL, false);
		instance = this;
	}

	/** Called at the end of LightmapRenderStateExtractor#extract. */
	public static void apply(LightmapRenderState state) {
		if (instance == null || !instance.isEnabled()) {
			return;
		}
		state.nightVisionEffectIntensity = Math.max(state.nightVisionEffectIntensity, instance.strength.floatValue() / 100f);
		if (state.nightVisionColor == null) {
			state.nightVisionColor = WHITE;
		}
	}
}
