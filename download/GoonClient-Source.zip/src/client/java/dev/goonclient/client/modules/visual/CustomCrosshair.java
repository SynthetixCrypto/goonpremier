package dev.goonclient.client.modules.visual;

import dev.goonclient.client.gui.Ui;
import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.Module;
import dev.goonclient.client.module.setting.BooleanSetting;
import dev.goonclient.client.module.setting.ModeSetting;
import dev.goonclient.client.module.setting.NumberSetting;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElement;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.entity.monster.Enemy;

/** Replaces the vanilla crosshair with a crisp, configurable one (drawn at screen-pixel resolution). */
public class CustomCrosshair extends Module {
	private static CustomCrosshair instance;

	private final ModeSetting style = add(new ModeSetting("style", "Style", "Cross", "Cross", "Cross + Dot", "Dot", "Circle", "T"));
	private final NumberSetting size = add(new NumberSetting("size", "Length", 5, 1, 14, 1));
	private final NumberSetting gap = add(new NumberSetting("gap", "Gap", 2, 0, 10, 1));
	private final NumberSetting thickness = add(new NumberSetting("thickness", "Thickness", 2, 1, 5, 1));
	private final ModeSetting color = add(new ModeSetting("color", "Colour", "White", "White", "Accent", "Green", "Yellow", "Cyan", "Pink"));
	private final BooleanSetting outline = add(new BooleanSetting("outline", "Dark outline", true));
	private final BooleanSetting hostile = add(new BooleanSetting("hostile", "Red when aiming at a hostile mob", true));

	public CustomCrosshair() {
		super("crosshair", "Custom Crosshair", "Your own crosshair: style, size, gap, thickness and colour", Category.VISUAL, false);
		instance = this;
	}

	public static void register() {
		HudElementRegistry.replaceElement(VanillaHudElements.CROSSHAIR, vanilla -> (HudElement) (g, deltaTracker) -> {
			Minecraft mc = Minecraft.getInstance();
			// The debug screen draws its own axis crosshair; leave that (and spectators) to vanilla
			if (instance == null || !instance.isEnabled() || mc.getDebugOverlay().showDebugScreen() || mc.player == null || mc.player.isSpectator()) {
				vanilla.extractRenderState(g, deltaTracker);
				return;
			}
			if (mc.options.getCameraType().isFirstPerson()) {
				instance.draw(g, mc);
			}
		});
	}

	private int colour(Minecraft mc) {
		if (hostile.isOn() && mc.crosshairPickEntity instanceof Enemy) {
			return Ui.BAD;
		}
		return switch (color.get()) {
			case "Accent" -> Ui.accent();
			case "Green" -> 0xFF4ADE80;
			case "Yellow" -> 0xFFFFD84D;
			case "Cyan" -> 0xFF4DE1FF;
			case "Pink" -> 0xFFFF6BCB;
			default -> 0xFFFFFFFF;
		};
	}

	private void draw(GuiGraphicsExtractor g, Minecraft mc) {
		int scale = Math.max(1, mc.getWindow().getGuiScale());
		// Settings are in "pixels at 1080p"; bigger screens scale them up so the crosshair keeps its size
		int unit = Math.max(1, scale / 3);
		int cx = g.guiWidth() * scale / 2;
		int cy = g.guiHeight() * scale / 2;
		int length = size.intValue() * unit;
		int space = gap.intValue() * unit;
		int t = thickness.intValue() * unit;
		int lo = t / 2;
		int hi = t - lo;
		int fill = colour(mc);

		java.util.List<int[]> rects = new java.util.ArrayList<>();
		String s = style.get();
		boolean arms = !s.equals("Dot") && !s.equals("Circle");
		if (arms) {
			rects.add(new int[]{cx - space - length, cy - lo, cx - space, cy + hi});
			rects.add(new int[]{cx + space + (t % 2), cy - lo, cx + space + length + (t % 2), cy + hi});
			rects.add(new int[]{cx - lo, cy + space + (t % 2), cx + hi, cy + space + length + (t % 2)});
			if (!s.equals("T")) {
				rects.add(new int[]{cx - lo, cy - space - length, cx + hi, cy - space});
			}
		}
		if (s.equals("Dot") || s.equals("Cross + Dot")) {
			int d = Math.max(2 * unit, t);
			rects.add(new int[]{cx - d / 2, cy - d / 2, cx - d / 2 + d, cy - d / 2 + d});
		}
		if (s.equals("Circle")) {
			int radius = space + length;
			int steps = Math.max(24, radius * 4);
			for (int i = 0; i < steps; i++) {
				double angle = Math.PI * 2 * i / steps;
				int px = cx + (int) Math.round(Math.cos(angle) * radius);
				int py = cy + (int) Math.round(Math.sin(angle) * radius);
				rects.add(new int[]{px - lo, py - lo, px + hi, py + hi});
			}
		}

		g.pose().pushMatrix();
		g.pose().scale(1f / scale, 1f / scale);
		if (outline.isOn()) {
			for (int[] r : rects) {
				g.fill(r[0] - unit, r[1] - unit, r[2] + unit, r[3] + unit, 0x99000000);
			}
		}
		for (int[] r : rects) {
			g.fill(r[0], r[1], r[2], r[3], fill);
		}
		g.pose().popMatrix();
	}
}
