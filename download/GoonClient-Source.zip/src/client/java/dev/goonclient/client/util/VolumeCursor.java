package dev.goonclient.client.util;

/** A bounded scan over a block volume, with whole-column skipping for unloaded chunks. */
public final class VolumeCursor {
    private final int minX,minY,minZ,sizeY,sizeZ,total;
    private int index;
    public VolumeCursor(int minX,int minY,int minZ,int sizeX,int sizeY,int sizeZ) {
        if(sizeX<=0||sizeY<=0||sizeZ<=0)throw new IllegalArgumentException("Empty scan volume");
        this.minX=minX;this.minY=minY;this.minZ=minZ;this.sizeY=sizeY;this.sizeZ=sizeZ;
        total=Math.multiplyExact(Math.multiplyExact(sizeX,sizeY),sizeZ);
    }
    public boolean done(){return index>=total;}
    public int column(){return index/sizeY;}
    public int x(){return minX+column()/sizeZ;}
    public int y(){return minY+index%sizeY;}
    public int z(){return minZ+column()%sizeZ;}
    public void advance(){if(!done())index++;}
    public void skipColumn(){index=Math.min(total,(column()+1)*sizeY);}
    public int total(){return total;}
}
