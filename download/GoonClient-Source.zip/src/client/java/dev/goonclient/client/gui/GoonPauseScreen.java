package dev.goonclient.client.gui;

import dev.goonclient.client.compat.ModMenuCompat;
import dev.goonclient.client.gui.render.GoonFont;
import dev.goonclient.client.gui.render.Shapes;
import dev.goonclient.client.tracker.SessionStats;
import dev.goonclient.client.waypoint.WaypointManager;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.WorldOptionsScreen;
import net.minecraft.client.gui.screens.achievement.StatsScreen;
import net.minecraft.client.gui.screens.advancements.AdvancementsScreen;
import net.minecraft.client.gui.screens.options.OptionsScreen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;

/**
 * The Goon Client pause menu: the blurred game behind a shaded left column of buttons, plus a card with what you've
 * done this session. Replaces the vanilla pause menu (the "F3 + Esc" pause without a menu is left alone).
 */
public class GoonPauseScreen extends Screen implements GoonScreen {
	private static final float COLUMN = 210;
	private static final float GAP = 6;

	private final List<Row> rows = new ArrayList<>();
	private final List<Entry> entries = new ArrayList<>();
	private long openedAt;
    private float frameX, frameY, frameW, frameH;
	private float s = 1;
	private float vw;
	private float vh;

	public GoonPauseScreen() {
		super(Component.translatable("menu.game"));
	}

	@Override
	protected void init() {
		if (openedAt == 0) {
			openedAt = System.currentTimeMillis();
		}
		s = Ui.menuScale(width, height);
		vw = width / s;
		vh = height / s;
		rows.clear();
		rows.add(new Row(new Entry("Back to Game", Menus.Style.PRIMARY, () -> minecraft.gui.setScreen(null))));
		rows.add(new Row(new Entry("Goon Client", Menus.Style.NORMAL, () -> minecraft.gui.setScreen(new ClickGuiScreen(this))),
			new Entry("Adventure Log", Menus.Style.NORMAL, () -> minecraft.gui.setScreen(new AdventureLogScreen(this)))));
		if (minecraft.player != null) {
			rows.add(new Row(new Entry("Advancements", Menus.Style.NORMAL,
				() -> minecraft.gui.setScreen(new AdvancementsScreen(minecraft.player.connection.getAdvancements(), this))),
				new Entry("Statistics", Menus.Style.NORMAL, () -> minecraft.gui.setScreen(new StatsScreen(this, minecraft.player.getStats())))));
		}
		Entry options = new Entry("Options", Menus.Style.NORMAL, () -> minecraft.gui.setScreen(new OptionsScreen(this, minecraft.options)));
		if (FabricLoader.getInstance().isModLoaded("modmenu")) {
			rows.add(new Row(options, new Entry("Mods", Menus.Style.NORMAL, () -> minecraft.gui.setScreen(ModMenuCompat.modsScreen(this)))));
		} else {
			rows.add(new Row(options));
		}
		if (minecraft.hasSingleplayerServer() && minecraft.level != null) {
			rows.add(new Row(new Entry("World Options", Menus.Style.NORMAL, () -> minecraft.gui.setScreen(new WorldOptionsScreen(this, minecraft.level))),
				new Entry("Screenshots", Menus.Style.NORMAL, () -> minecraft.gui.setScreen(new ScreenshotScreen(this)))));
		} else {
			rows.add(new Row(new Entry("Screenshots", Menus.Style.NORMAL, () -> minecraft.gui.setScreen(new ScreenshotScreen(this)))));
		}
		String leave = minecraft.isLocalServer() ? "Save and Quit to Title" : "Disconnect";
		rows.add(new Row(new Entry(leave, Menus.Style.DANGER, () -> minecraft.disconnectFromWorld(ClientLevel.DEFAULT_QUIT_MESSAGE))));
		entries.clear();
		rows.forEach(row -> entries.addAll(row.entries));
	}

	@Override
	public void extractBackground(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
		super.extractBackground(g, mouseX, mouseY, partialTick);
		float open = Ui.easeOutCubic((System.currentTimeMillis() - openedAt) / 300f);
		g.fill(0, 0, width, height, Ui.withAlpha(0x40000000, open));
		Menus.sideShade(g, width, height, 0.55f, 0.75f * open);
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor g, int realMouseX, int realMouseY, float partialTick) {
		int mouseX = (int) (realMouseX / s);
		int mouseY = (int) (realMouseY / s);
		g.pose().pushMatrix();
		g.pose().scale(s, s);

		boolean narrow = vw < 510;
		float block = rows.size() * (Menus.BUTTON_HEIGHT + GAP) - GAP + 6;
		frameW = narrow ? COLUMN + 36 : 440;
        frameH = block + 72; frameX = (vw - frameW) / 2f; frameY = Math.max(12, (vh - frameH) / 2f);
        GlassUi.window(g, frameX, frameY, frameW, frameH, Menus.stagger(openedAt, 0, 0, 350));
        float left = frameX + 18, top = frameY + 16;
        if (!narrow) Shapes.rect(g, frameX + COLUMN + 31, frameY + 16, frameX + COLUMN + 31.4f, frameY + frameH - 16, 0x22FFFFFF);

		// Header
		float head = Menus.stagger(openedAt, 0, 0, 380);
		float hx = left - (1 - head) * 12;
		Ui.logoMark(g, font, hx, top, 20, head);
		GoonFont.draw(g, "Game paused", hx + 28, top + 0.5f, 11.5f, GoonFont.Weight.BOLD, Ui.withAlpha(Ui.TEXT, head), false);
		String where = WaypointManager.worldName();
		String subtitle = (where.isEmpty() ? "" : where + "   ") + SessionStats.formatDuration(SessionStats.durationMs()) + " this session";
		GoonFont.draw(g, Ui.ellipsize(subtitle, COLUMN, 7.6f, GoonFont.Weight.REGULAR), hx + 28, top + 13, 7.6f, GoonFont.Weight.REGULAR,
			Ui.withAlpha(Ui.MUTED, head), false);

		float y = top + 40;
		int index = 0;
		for (int r = 0; r < rows.size(); r++) {
			Row row = rows.get(r);
			if (r == rows.size() - 1) {
				// A little space before the button that leaves the world
				y += 6;
			}
			float w = row.entries.size() == 1 ? COLUMN : (COLUMN - GAP) / 2f;
			float x = left;
			for (Entry entry : row.entries) {
				entry.x = x;
				entry.y = y;
				entry.w = w;
				Menus.button(g, entry.label, x, y, w, mouseX, mouseY, Menus.stagger(openedAt, ++index, 60, 360), entry.style);
				x += w + GAP;
			}
			y += Menus.BUTTON_HEIGHT + GAP;
		}

		if (!narrow) {
			drawSessionCard(g);
		}
		g.pose().popMatrix();
		super.extractRenderState(g, realMouseX, realMouseY, partialTick);
	}

	/** What you've done since joining, bottom right. */
	private void drawSessionCard(GuiGraphicsExtractor g) {
		float appear = Menus.stagger(openedAt, 3, 120, 420);
		String[][] stats = {
			{"Played", SessionStats.formatDuration(SessionStats.durationMs())},
			{"Mobs killed", Integer.toString(SessionStats.mobsKilled())},
			{"Deaths", Integer.toString(SessionStats.deaths())},
			{"Blocks mined", Integer.toString(SessionStats.blocksMined())},
			{"Travelled", SessionStats.formatDistance(SessionStats.distance())},
			{"Items picked up", Integer.toString(SessionStats.itemsPickedUp())}
		};
		float w = 170;
		float h = 30 + stats.length * 14 + 8;
		float x1 = frameX + frameW - w - 14 + (1 - appear) * 8;
		float y1 = frameY + 56;
		// The settings-window glass, with Combatant's list-panel rows: muted names, values in the accent mix
		GlassUi.window(g, x1, y1, w, h, appear);
		GoonFont.draw(g, "This session", x1 + 12, y1 + 11, 8.6f, GoonFont.Weight.BOLD, Ui.withAlpha(0xFFF4F4F4, appear), false);
		Shapes.rect(g, x1 + 10, y1 + 24, x1 + w - 10, y1 + 24.4f, Ui.withAlpha(0x22FFFFFF, appear));
		float y = y1 + 30;
		int value = dev.goonclient.client.hud.HudRenderUtil.mixColor(Ui.accent() | 0xFF000000, 0xFFF4F4F4, .38f);
		for (String[] stat : stats) {
			GoonFont.draw(g, stat[0], x1 + 12, y, 7.4f, GoonFont.Weight.ONEST_MEDIUM, Ui.withAlpha(0xFFC7CBD3, .85f * appear), false);
			float valueWidth = GoonFont.width(stat[1], 7.4f, GoonFont.Weight.ONEST_MEDIUM);
			GoonFont.draw(g, stat[1], x1 + w - 12 - valueWidth, y, 7.4f, GoonFont.Weight.ONEST_MEDIUM, Ui.withAlpha(value, appear), false);
			y += 14;
		}
	}

	@Override
	public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
		double mx = event.x() / s;
		double my = event.y() / s;
		for (Entry entry : entries) {
			if (Ui.inside(mx, my, entry.x, entry.y, entry.x + entry.w, entry.y + Menus.BUTTON_HEIGHT)) {
				minecraft.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, 1.0f));
				entry.action.run();
				return true;
			}
		}
		return super.mouseClicked(event, doubleClick);
	}

	@Override
	public boolean isPauseScreen() {
		return true;
	}

	private record Row(List<Entry> entries) {
		Row(Entry... entries) {
			this(List.of(entries));
		}
	}

	private static final class Entry {
		private final String label;
		private final Menus.Style style;
		private final Runnable action;
		private float x;
		private float y;
		private float w;

		private Entry(String label, Menus.Style style, Runnable action) {
			this.label = label;
			this.style = style;
			this.action = action;
		}
	}
}
