package dev.goonclient.client;

import static net.fabricmc.fabric.api.client.command.v2.ClientCommands.argument;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommands.literal;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import dev.goonclient.client.gui.AdventureLogScreen;
import dev.goonclient.client.gui.ClickGuiScreen;
import dev.goonclient.client.tracker.LootTracker;
import dev.goonclient.client.modules.world.WorldHuds;
import dev.goonclient.client.waypoint.Waypoint;
import dev.goonclient.client.waypoint.WaypointManager;
import java.util.Comparator;
import java.util.List;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.core.BlockPos;

/** Client-side commands: /goonclient (menu, log, loot reset) and /wp. */
public final class GoonCommands {
	private GoonCommands() {
	}

	public static void register() {
		ClientCommandRegistrationCallback.EVENT.register((dispatcher, buildContext) -> registerAll(dispatcher));
	}

	private static void registerAll(CommandDispatcher<FabricClientCommandSource> dispatcher) {
		dispatcher.register(literal("goonclient").executes(context -> {
			GoonClient.openNextTick(new ClickGuiScreen(null));
			return 1;
		})
			.then(literal("log").executes(context -> {
				GoonClient.openNextTick(new AdventureLogScreen(null));
				return 1;
			}))
            .then(literal("coords")
                .executes(context -> dev.goonclient.client.utility.LocationTools.coordinates(context.getSource().getPlayer(), false))
                .then(literal("copy").executes(context -> dev.goonclient.client.utility.LocationTools.coordinates(context.getSource().getPlayer(), true))))
            .then(literal("portal")
                .executes(context -> dev.goonclient.client.utility.LocationTools.portal(context.getSource().getPlayer(), false))
                .then(literal("copy").executes(context -> dev.goonclient.client.utility.LocationTools.portal(context.getSource().getPlayer(), true))))
			.then(literal("loot").then(literal("reset").executes(context -> {
				LootTracker.reset();
				GoonChat.info("Loot tracker reset");
				return 1;
			}))));

		dispatcher.register(literal("wp")
			.then(literal("add")
				.then(argument("name", StringArgumentType.word())
					.executes(context -> {
						BlockPos pos = context.getSource().getPlayer().blockPosition();
						return add(context, pos.getX(), pos.getY(), pos.getZ());
					})
					.then(argument("x", IntegerArgumentType.integer())
						.then(argument("y", IntegerArgumentType.integer())
							.then(argument("z", IntegerArgumentType.integer())
								.executes(context -> add(context,
									IntegerArgumentType.getInteger(context, "x"),
									IntegerArgumentType.getInteger(context, "y"),
									IntegerArgumentType.getInteger(context, "z"))))))))
			.then(literal("remove")
				.then(argument("name", StringArgumentType.word())
					.suggests((context, builder) -> {
						WaypointManager.all().forEach(w -> builder.suggest(w.name()));
						return builder.buildFuture();
					})
					.executes(context -> {
						String name = StringArgumentType.getString(context, "name");
						if (WaypointManager.remove(name)) {
							GoonChat.info("Removed waypoint '" + name + "'");
							return 1;
						}
						GoonChat.error("No waypoint called '" + name + "'");
						return 0;
					})))
            .then(literal("copy").then(argument("name", StringArgumentType.greedyString())
                .suggests((context, builder) -> {
                    WaypointManager.all().forEach(w -> builder.suggest(w.name()));
                    return builder.buildFuture();
                })
                .executes(context -> dev.goonclient.client.utility.LocationTools.waypoint(StringArgumentType.getString(context, "name")))))
			.then(literal("list").executes(context -> list(context.getSource())))
			.then(literal("clear-deaths").executes(context -> {
				GoonChat.info("Removed " + WaypointManager.clearDeaths() + " death waypoints");
				return 1;
			})));
	}

	private static int add(CommandContext<FabricClientCommandSource> context, int x, int y, int z) {
		String name = StringArgumentType.getString(context, "name");
		String dimension = context.getSource().getPlayer().level().dimension().identifier().toString();
		WaypointManager.add(new Waypoint(name, x, y, z, dimension, WaypointManager.nextColor(), false, System.currentTimeMillis()));
		GoonChat.info("Added waypoint '" + name + "' at " + x + " " + y + " " + z);
		return 1;
	}

	private static int list(FabricClientCommandSource source) {
		List<Waypoint> waypoints = WaypointManager.all();
		if (waypoints.isEmpty()) {
			GoonChat.info("No waypoints yet. Add one with /wp add <name>");
			return 0;
		}
		var player = source.getPlayer();
		GoonChat.info(waypoints.size() + " waypoints:");
		waypoints.stream()
			.sorted(Comparator.comparingDouble(w -> w.distanceTo(player.getX(), player.getY(), player.getZ())))
			.forEach(w -> GoonChat.info(" " + w.name() + ": " + w.x() + " " + w.y() + " " + w.z()
				+ " (" + WorldHuds.dimensionName(w.dimension()) + ", " + (int) w.distanceTo(player.getX(), player.getY(), player.getZ()) + "m)"));
		return waypoints.size();
	}
}
