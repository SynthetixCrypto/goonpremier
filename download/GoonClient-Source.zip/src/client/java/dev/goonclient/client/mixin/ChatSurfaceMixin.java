package dev.goonclient.client.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import dev.goonclient.client.gui.render.Shapes;
import dev.goonclient.client.modules.utility.Interface;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

/** Both visible chat paths keep vanilla text, signatures, hover/click behavior and opacity. */
@Mixin(targets={"net.minecraft.client.gui.components.ChatComponent$DrawingBackgroundGraphicsAccess","net.minecraft.client.gui.components.ChatComponent$DrawingFocusedGraphicsAccess"})
public abstract class ChatSurfaceMixin {
    @WrapOperation(method="fill",at=@At(value="INVOKE",target="Lnet/minecraft/client/gui/GuiGraphicsExtractor;fill(IIIII)V"))
    private void goon$chatSurface(GuiGraphicsExtractor g,int x0,int y0,int x1,int y1,int color,Operation<Void> original) {
        dev.goonclient.client.hud.ChatFootprint.record(g,x0,y0,x1,y1,color);
        if(Interface.glassChat() && x1-x0>12 && y1>y0 && (color&0xFFFFFF)==0) {
            // Preserve the player's chat opacity and vanilla fade. Tag indicators and scrollbars are untouched.
            Shapes.roundRect(g,x0,y0,x1,y1,Math.min(3,(y1-y0)/2f),(color&0xFF000000)|0x302A3A);
        } else original.call(g,x0,y0,x1,y1,color);
    }
}
