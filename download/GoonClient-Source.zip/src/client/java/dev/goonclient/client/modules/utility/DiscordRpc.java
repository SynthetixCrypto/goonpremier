package dev.goonclient.client.modules.utility;

import dev.goonclient.client.gui.DiscordStatusScreen;
import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.Module;
import dev.goonclient.client.module.setting.BooleanSetting;
import dev.goonclient.client.module.setting.ButtonSetting;
import dev.goonclient.client.social.DiscordPresence;
import net.minecraft.client.Minecraft;

public final class DiscordRpc extends Module {
    private static DiscordRpc instance;
    private final BooleanSetting activity=add(new BooleanSetting("activity","Show menu / singleplayer / multiplayer",true));
    private final BooleanSetting timer=add(new BooleanSetting("timer","Show elapsed time",true));
    public DiscordRpc(){super("discord_rpc","Discord Presence","Show Goon Client on your Discord profile. Server addresses stay private.",Category.UTILITY,false);instance=this;add(new ButtonSetting("status","Desktop Discord connection","View status",()->{var mc=Minecraft.getInstance();mc.gui.setScreen(new DiscordStatusScreen(mc.gui.screen()));}));}
    public static void sync(Minecraft mc){if(instance==null)return;String state=!instance.activity.isOn()?"Playing Minecraft":mc.level==null?"In the main menu":mc.hasSingleplayerServer()?"Singleplayer adventure":"Playing with friends";DiscordPresence.update(instance.isEnabled(),state,instance.timer.isOn());}
    @Override protected void onDisable(){DiscordPresence.update(false,"",false);}
}
