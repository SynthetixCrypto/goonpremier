package dev.goonclient.client.modules.combat;

import dev.goonclient.client.gui.Ui;
import dev.goonclient.client.gui.render.Shapes;
import dev.goonclient.client.hud.HudModule;
import dev.goonclient.client.hud.HudPosition;
import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.setting.BooleanSetting;
import dev.goonclient.client.module.setting.NumberSetting;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.core.component.DataComponents;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/**
 * A pre-fight checklist: armour, weapon, food, healing, totems, arrows, blocks and inventory space, each marked
 * ready, low or missing. Handy before the Wither, the Warden, raids or a Dragon run.
 */
public class BossPrep extends HudModule {
	private static final int PAD = 5;
	private static final int ROW = 11;
	private static final EquipmentSlot[] ARMOR = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

	private final BooleanSetting missingOnly = add(new BooleanSetting("missing_only", "Only list what isn't ready", false));
	private final NumberSetting foodTarget = add(new NumberSetting("food_target", "Food to bring", 16, 4, 64, 4));
	private final NumberSetting blockTarget = add(new NumberSetting("block_target", "Blocks to bring", 32, 0, 256, 16));
	private final NumberSetting arrowTarget = add(new NumberSetting("arrow_target", "Arrows to bring", 64, 16, 256, 16));

	public BossPrep() {
		super("boss_prep", "Boss Prep", "Checklist before a fight: armour, weapon, food, healing, totems, arrows, blocks and space",
			Category.COMBAT, false, HudPosition.rightMiddle(2, -20));
	}

	@Override
	protected void render(GuiGraphicsExtractor g, Minecraft mc, boolean editing) {
		List<Check> checks = mc.player != null ? checks(mc.player) : sample();
		int ready = 0;
		for (Check check : checks) {
			if (check.status == Status.READY) {
				ready++;
			}
		}
		List<Check> shown = new ArrayList<>();
		for (Check check : checks) {
			if (!missingOnly.isOn() || check.status != Status.READY) {
				shown.add(check);
			}
		}

		Font font = mc.font;
		String title = "Boss Prep";
		boolean allReady = ready == checks.size();
		String summary = allReady ? "Ready" : ready + "/" + checks.size();
		int labelW = 0;
		int valueW = 0;
		for (Check check : shown) {
			labelW = Math.max(labelW, Ui.width(font, check.label));
			valueW = Math.max(valueW, Ui.width(font, check.value));
		}
		int width = Math.max(PAD * 2 + 8 + labelW + 10 + valueW, PAD * 2 + Ui.boldWidth(font, title) + 12 + Ui.width(font, summary));
		width = Math.max(width, 104);
		int rows = shown.isEmpty() ? 1 : shown.size();
		int height = PAD + 12 + rows * ROW + PAD - 2;

		Ui.roundRect(g, 0, 0, width, height, 4, Ui.HUD_BACKGROUND);
		Ui.bold(g, font, title, PAD, PAD, Ui.TEXT, true);
		Ui.text(g, font, summary, width - PAD - Ui.width(font, summary), PAD, allReady ? Ui.GOOD : Ui.WARN, true);
		int y = PAD + 12;
		if (shown.isEmpty()) {
			Ui.text(g, font, "Everything's packed", PAD, y, Ui.MUTED, true);
		}
		for (Check check : shown) {
			Shapes.circle(g, PAD + 2.5f, y + 3.5f, 2.5f, check.status.color);
			Ui.text(g, font, check.label, PAD + 8, y, Ui.MUTED, true);
			int valueColor = check.status == Status.READY ? Ui.TEXT : check.status.color;
			Ui.text(g, font, check.value, width - PAD - Ui.width(font, check.value), y, valueColor, true);
			y += ROW;
		}
		setSize(width, height);
	}

	private List<Check> checks(Player player) {
		Inventory inventory = player.getInventory();
		List<Check> checks = new ArrayList<>();

		// Armour: pieces worn and the most worn-out piece
		int pieces = 0;
		int lowest = 100;
		for (EquipmentSlot slot : ARMOR) {
			ItemStack stack = player.getItemBySlot(slot);
			if (!stack.isEmpty()) {
				pieces++;
				if (stack.isDamageableItem()) {
					lowest = Math.min(lowest, durability(stack));
				}
			}
		}
		Status armor = pieces == 0 || lowest < 10 ? Status.MISSING : pieces < 4 || lowest < 30 ? Status.LOW : Status.READY;
		checks.add(new Check("Armour", pieces == 0 ? "None" : pieces + "/4  " + lowest + "%", armor));

		// Weapon: the melee weapon with the most uses left
		ItemStack weapon = ItemStack.EMPTY;
		boolean ranged = false;
		int food = 0;
		int healing = 0;
		int totems = 0;
		int arrows = 0;
		int blocks = 0;
		int free = 0;
		for (int i = 0; i < inventory.getContainerSize(); i++) {
			ItemStack stack = inventory.getItem(i);
			if (stack.isEmpty()) {
				continue;
			}
			if (isMeleeWeapon(stack) && (weapon.isEmpty() || usesLeft(stack) > usesLeft(weapon))) {
				weapon = stack;
			}
			if (stack.is(Items.BOW) || stack.is(Items.CROSSBOW)) {
				ranged = true;
			}
			if (stack.is(Items.GOLDEN_APPLE) || stack.is(Items.ENCHANTED_GOLDEN_APPLE) || stack.is(Items.POTION)
				|| stack.is(Items.SPLASH_POTION) || stack.is(Items.LINGERING_POTION)) {
				healing += stack.getCount();
			} else if (stack.has(DataComponents.FOOD) && !isBadFood(stack)) {
				food += stack.getCount();
			}
			if (stack.is(Items.TOTEM_OF_UNDYING)) {
				totems += stack.getCount();
			}
			if (stack.is(Items.ARROW) || stack.is(Items.SPECTRAL_ARROW) || stack.is(Items.TIPPED_ARROW)) {
				arrows += stack.getCount();
			}
			if (stack.getItem() instanceof BlockItem) {
				blocks += stack.getCount();
			}
		}
		for (ItemStack stack : inventory.getNonEquipmentItems()) {
			if (stack.isEmpty()) {
				free++;
			}
		}

		if (weapon.isEmpty()) {
			checks.add(new Check("Weapon", "None", Status.MISSING));
		} else {
			int left = weapon.isDamageableItem() ? durability(weapon) : 100;
			checks.add(new Check("Weapon", left + "%", left < 25 ? Status.LOW : Status.READY));
		}
		checks.add(new Check("Food", Integer.toString(food), food >= foodTarget.intValue() ? Status.READY : food > 0 ? Status.LOW : Status.MISSING));
		checks.add(new Check("Healing", Integer.toString(healing), healing >= 4 ? Status.READY : healing > 0 ? Status.LOW : Status.MISSING));
		checks.add(new Check("Totems", Integer.toString(totems), totems > 0 ? Status.READY : Status.LOW));
		if (ranged) {
			checks.add(new Check("Arrows", Integer.toString(arrows), arrows >= arrowTarget.intValue() ? Status.READY : arrows > 0 ? Status.LOW : Status.MISSING));
		}
		if (blockTarget.intValue() > 0) {
			checks.add(new Check("Blocks", Integer.toString(blocks), blocks >= blockTarget.intValue() ? Status.READY : Status.LOW));
		}
		checks.add(new Check("Free slots", Integer.toString(free), free >= 4 ? Status.READY : free > 0 ? Status.LOW : Status.MISSING));
		return checks;
	}

	private static List<Check> sample() {
		return List.of(new Check("Armour", "4/4  62%", Status.READY), new Check("Weapon", "84%", Status.READY),
			new Check("Food", "9", Status.LOW), new Check("Healing", "12", Status.READY), new Check("Totems", "0", Status.LOW),
			new Check("Arrows", "64", Status.READY), new Check("Blocks", "0", Status.LOW), new Check("Free slots", "11", Status.READY));
	}

	private static boolean isMeleeWeapon(ItemStack stack) {
		return stack.is(ItemTags.SWORDS) || stack.is(ItemTags.AXES) || stack.is(ItemTags.SPEARS) || stack.is(Items.MACE) || stack.is(Items.TRIDENT);
	}

	/** Food that hurts more than it helps. */
	private static boolean isBadFood(ItemStack stack) {
		return stack.is(Items.ROTTEN_FLESH) || stack.is(Items.SPIDER_EYE) || stack.is(Items.POISONOUS_POTATO) || stack.is(Items.PUFFERFISH);
	}

	private static int usesLeft(ItemStack stack) {
		return stack.isDamageableItem() ? stack.getMaxDamage() - stack.getDamageValue() : Integer.MAX_VALUE;
	}

	private static int durability(ItemStack stack) {
		return Math.round((stack.getMaxDamage() - stack.getDamageValue()) * 100f / stack.getMaxDamage());
	}

	private enum Status {
		READY(Ui.GOOD), LOW(Ui.WARN), MISSING(Ui.BAD);

		final int color;

		Status(int color) {
			this.color = color;
		}
	}

	private record Check(String label, String value, Status status) {
	}
}
