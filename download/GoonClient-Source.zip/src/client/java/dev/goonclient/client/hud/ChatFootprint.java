package dev.goonclient.client.hud;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.ChatScreen;

/** Last rendered unfocused chat surface; frozen while chat is focused to avoid editor jumps. */
public final class ChatFootprint {
    private static HudLayout.Rect visible, collecting;
    private ChatFootprint() { }
    public static void beginFrame() {
        var mc=Minecraft.getInstance();
        if(mc.level==null){visible=null;collecting=null;return;}
        if(!(mc.gui.screen() instanceof ChatScreen)){visible=collecting;collecting=null;}
    }
    public static HudLayout.Rect visible(){return visible;}
    public static void record(GuiGraphicsExtractor g,int x0,int y0,int x1,int y1,int color) {
        if(Minecraft.getInstance().gui.screen() instanceof ChatScreen || x1-x0<=12 || y1<=y0 || (color&0xFFFFFF)!=0 || (color>>>24)<2)return;
        var p=g.pose();
        int left=(int)Math.floor(p.m00*x0+p.m20),top=(int)Math.floor(p.m11*y0+p.m21);
        int right=(int)Math.ceil(p.m00*x1+p.m20),bottom=(int)Math.ceil(p.m11*y1+p.m21);
        if(collecting!=null){left=Math.min(left,collecting.x());top=Math.min(top,collecting.y());right=Math.max(right,collecting.x()+collecting.width());bottom=Math.max(bottom,collecting.y()+collecting.height());}
        collecting=new HudLayout.Rect(left,top,Math.max(0,right-left),Math.max(0,bottom-top));
    }
}
