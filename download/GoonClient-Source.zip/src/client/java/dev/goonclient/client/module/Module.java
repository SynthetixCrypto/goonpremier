package dev.goonclient.client.module;

import dev.goonclient.client.config.ConfigManager;
import dev.goonclient.client.module.setting.Setting;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.client.Minecraft;

/** A toggleable feature with settings. Subclasses declare settings as fields via {@link #add}. */
public abstract class Module {
	private final String id;
	private final String name;
	private final String description;
	private final Category category;
	private final List<Setting<?>> settings = new ArrayList<>();
	private boolean enabled;
	private final boolean enabledByDefault;
	private boolean favorite;

	protected Module(String id, String name, String description, Category category, boolean enabledByDefault) {
		this.id = id;
		this.name = name;
		this.description = description;
		this.category = category;
		this.enabled = enabledByDefault;
		this.enabledByDefault = enabledByDefault;
	}

	protected <S extends Setting<?>> S add(S setting) {
		settings.add(setting);
		return setting;
	}

	public void setEnabled(boolean enabled) {
		if (this.enabled == enabled) {
			return;
		}
		this.enabled = enabled;
		if (enabled) {
			onEnable();
		} else {
			onDisable();
		}
		ConfigManager.markDirty();
	}

	public void toggle() {
		setEnabled(!enabled);
	}

	/** Called every client tick while enabled. */
	public void onTick(Minecraft mc) {
	}

	protected void onEnable() {
	}

	protected void onDisable() {
	}

	public boolean enabledByDefault() { return enabledByDefault; }
	public boolean isFavorite() { return favorite; }
	public void loadFavorite(boolean value) { favorite = value; }
	public void toggleFavorite() { favorite = !favorite; ConfigManager.markDirty(); }
	public void resetSettings() { for (var setting : settings) if (!(setting instanceof dev.goonclient.client.module.setting.ButtonSetting)) setting.reset(); ConfigManager.markDirty(); }

	public boolean isEnabled() {
		return enabled;
	}

	/** Sets the state while loading config, without firing enable/disable hooks. */
	public void loadEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	public String id() {
		return id;
	}

	public String name() {
		return name;
	}

	public String description() {
		return description;
	}

	public Category category() {
		return category;
	}

	public List<Setting<?>> settings() {
		return Collections.unmodifiableList(settings);
	}
}
