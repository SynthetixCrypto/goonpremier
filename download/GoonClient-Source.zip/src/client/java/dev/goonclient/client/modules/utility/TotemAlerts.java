package dev.goonclient.client.modules.utility;

import dev.goonclient.client.GoonChat;
import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.Module;
import dev.goonclient.client.module.setting.BooleanSetting;
import dev.goonclient.client.modules.hud.FeedbackHud;
import java.util.LinkedHashMap;
import java.util.UUID;
import net.minecraft.client.Minecraft;
import net.minecraft.network.protocol.game.ClientboundEntityEventPacket;
import net.minecraft.world.entity.EntityEvent;
import net.minecraft.world.entity.player.Player;

/** Local alerts for death-protection events already delivered by the server. */
public final class TotemAlerts extends Module {
    private static TotemAlerts instance;
    private final BooleanSetting self = add(new BooleanSetting("self", "Your totem uses", true));
    private final BooleanSetting others = add(new BooleanSetting("others", "Other loaded players", true));
    private final BooleanSetting counts = add(new BooleanSetting("counts", "Show observed session count", true));
    private final BooleanSetting chat = add(new BooleanSetting("chat", "Local chat alerts", true));
    private final BooleanSetting notifications = add(new BooleanSetting("notifications", "Use existing Notifications HUD", false));
    private final LinkedHashMap<UUID, Integer> uses = new LinkedHashMap<>(16, .75f, true);
    private final LinkedHashMap<UUID, Long> lastNotice = new LinkedHashMap<>(16, .75f, true);

    public TotemAlerts() {
        super("totem_alerts", "Totem Alerts", "Local notices when you or another loaded player uses death protection", Category.UTILITY, false);
        instance = this;
    }

    public static void onEvent(ClientboundEntityEventPacket packet) {
        var module = instance;
        var mc = Minecraft.getInstance();
        if (module == null || !module.isEnabled() || mc.level == null || mc.player == null
                || packet.getEventId() != EntityEvent.PROTECTED_FROM_DEATH) return;
        if (!(packet.getEntity(mc.level) instanceof Player player)) return;
        boolean own = player == mc.player;
        if (!(own ? module.self.isOn() : module.others.isOn())) return;
        UUID id = player.getUUID();
        int count = Math.min(9999, module.uses.getOrDefault(id, 0) + 1);
        module.uses.put(id, count);
        trim(module.uses);
        long now = System.nanoTime();
        long previous = module.lastNotice.getOrDefault(id, 0L);
        if (previous != 0 && now - previous < 500_000_000L) return;
        module.lastNotice.put(id, now);
        trim(module.lastNotice);
        String name = own ? "You" : player.getName().getString();
        String message = name + " used death protection" + (module.counts.isOn() ? " (" + count + " observed this session)" : "") + ".";
        if (module.chat.isOn()) GoonChat.info(message);
        if (module.notifications.isOn()) FeedbackHud.post("totem-" + id, "Totem Alerts", message, true);
    }

    private static void trim(LinkedHashMap<?, ?> map) {
        while (map.size() > 128) map.pollFirstEntry();
    }

    public static void reset() {
        if (instance != null) { instance.uses.clear(); instance.lastNotice.clear(); }
    }

    @Override protected void onEnable() { reset(); }
    @Override protected void onDisable() { reset(); }
    @Override public void onTick(Minecraft mc) { if (mc.level == null) reset(); }
}
