package dev.goonclient.client.modules.visual;

import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.Module;
import dev.goonclient.client.module.setting.BooleanSetting;

/** Cosmetic dropped-item motion. Entity movement, pickup range and collisions remain server-controlled. */
public final class ItemPhysics extends Module {
	private static ItemPhysics instance;
	private final BooleanSetting tumble = add(new BooleanSetting("tumble", "Tumble while falling", true));

	public ItemPhysics() {
		super("item_physics", "Item Physics", "Dropped items settle on the ground instead of hovering and spinning. Cosmetic only.", Category.VISUAL, false);
		instance = this;
	}

	public static boolean active() {
		return instance != null && instance.isEnabled();
	}

	public static boolean tumble() {
		return active() && instance.tumble.isOn();
	}

	public interface State {
		void goonclient$physics(boolean grounded, boolean liquid, float yaw);
		boolean goonclient$grounded();
		boolean goonclient$liquid();
		float goonclient$yaw();
	}
}
