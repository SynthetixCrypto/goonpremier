package dev.goonclient.client.mixin;

import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.mojang.blaze3d.vertex.PoseStack;
import dev.goonclient.client.modules.visual.ViewModel;
import net.minecraft.client.renderer.FirstPersonHandsAndItemsRenderer;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.state.level.FirstPersonHandsAndItemsRenderState;
import net.minecraft.client.renderer.state.level.PlayerRenderState;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(FirstPersonHandsAndItemsRenderer.class)
public abstract class ViewModelMixin {
    @WrapMethod(method = "submitArmWithItem")
    private void goon$viewModel(PlayerRenderState player, FirstPersonHandsAndItemsRenderState state, float partialTick, float xRot,
        InteractionHand hand, float attack, ItemStack stack, float inverseArmHeight, PoseStack pose, SubmitNodeCollector collector, int light, Operation<Void> original) {
        // Wrapping restores the pose even if another renderer aborts; maps keep their two-hand transforms.
        pose.pushPose();
        try {
            if (player.avatarRenderState != null && !stack.has(DataComponents.MAP_ID)) {
                var arm = hand == InteractionHand.MAIN_HAND ? player.avatarRenderState.mainArm : player.avatarRenderState.mainArm.getOpposite();
                ViewModel.apply(pose, hand, arm);
            }
            original.call(player, state, partialTick, xRot, hand, attack, stack, inverseArmHeight, pose, collector, light);
        } finally { pose.popPose(); }
    }
}
