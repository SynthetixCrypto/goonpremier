package dev.goonclient.client.gui;

import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.blaze3d.Blaze3D;
import dev.goonclient.client.gui.render.GoonFont;
import dev.goonclient.client.gui.render.Shapes;
import dev.goonclient.client.tracker.FarmReports;
import dev.goonclient.client.tracker.SessionStats;
import java.util.*;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

/** A frozen report is previewed before copying/exporting, so the UI and both output files show identical counts. */
public final class FarmReportScreen extends Screen implements GoonScreen {
    private record Hit(float x1,float y1,float x2,float y2,Runnable run){}
    private final Screen parent;
    private final List<Hit> hits=new ArrayList<>();
    private int focus=-1;
    private FarmReports.Snapshot report;
    private String status="Export saves a CSV and a readable summary on this device.";
    private boolean error;
    private float s,x,y,w,h,top,bottom,scroll;
    public FarmReportScreen(Screen parent){super(Component.literal("Farm report"));this.parent=parent;report=FarmReports.snapshot();}
    @Override protected void init(){GlassUi.hideHud(minecraft);s=Math.max(.01f,Math.min(Ui.menuScale(width,height),Math.min(width/600f,height/410f)));float vw=width/s,vh=height/s;w=Math.min(580,vw-28);h=Math.min(370,vh-28);x=(vw-w)/2;y=(vh-h)/2;top=y+135;bottom=y+h-100;}
    private static void text(GuiGraphicsExtractor g,String label,float x,float y,float size,boolean bold,int color){GoonFont.draw(g,label,x,y,size,bold?GoonFont.Weight.BOLD:GoonFont.Weight.REGULAR,color==Ui.MUTED?GlassUi.LABEL:color,false);}
    private static String shortText(String text,float width,float size,boolean bold){return Ui.ellipsize(text,width,size,bold?GoonFont.Weight.BOLD:GoonFont.Weight.REGULAR);}
    @Override public void extractRenderState(GuiGraphicsExtractor g,int realX,int realY,float dt){
        hits.clear();int mx=(int)(realX/s),my=(int)(realY/s);g.pose().pushMatrix();g.pose().scale(s,s);GlassUi.panel(g,x,y,w,h,1);
        text(g,"Farm session report",x+18,y+17,15,true,Ui.TEXT);button(g,"Done",x+w-70,y+15,52,mx,my,true,this::onClose);
        if(report==null)text(g,"Join a world to start counting. Reset the Loot Tracker when your farm session starts.",x+18,y+51,8.2f,false,Ui.MUTED);
        else{
            text(g,shortText(report.world()+" · "+SessionStats.formatDuration(report.elapsedMs())+(report.finished()?" · ended":" · snapshot"),w-36,9,true),x+18,y+50,9,true,Ui.TEXT);
            text(g,report.total()+" items picked up  ·  "+report.xp()+" XP  ·  "+report.kills()+" credited kills",x+18,y+72,8.2f,false,Ui.MUTED);
            text(g,FarmReports.rate(report.xp(),report.rateBasisMs())+" XP/hour  ·  Rates use at least 60 seconds",x+18,y+90,8.2f,false,Ui.MUTED);
            text(g,"Item",x+18,y+117,8.2f,true,Ui.TEXT);text(g,"Collected",x+w-163,y+117,8.2f,true,Ui.TEXT);text(g,"Per hour",x+w-82,y+117,8.2f,true,Ui.TEXT);
            Shapes.rect(g,x+18,top-3,x+w-18,top-2.5f,Ui.BORDER);
            scroll=Math.max(0,Math.min(scroll,Math.max(0,report.items().size()*21-(bottom-top))));
            g.enableScissor((int)(x+17),(int)top,(int)(x+w-17),(int)bottom);
            for(int i=0;i<report.items().size();i++){
                var item=report.items().get(i);float yy=top+i*21-scroll;if(yy+21<=top||yy>=bottom)continue;
                text(g,shortText(item.name(),w-210,8.2f,false),x+18,yy+5,8.2f,false,Ui.TEXT);
                text(g,Long.toString(item.count()),x+w-163,yy+5,8.2f,true,Ui.TEXT);text(g,Long.toString(item.perHour()),x+w-82,yy+5,8.2f,false,Ui.MUTED);
            }
            if(report.items().isEmpty())text(g,"No item pickups counted in this session.",x+18,top+6,8.2f,false,Ui.MUTED);
            g.disableScissor();float max=Math.max(0,report.items().size()*21-(bottom-top));if(max>0){float view=bottom-top,thumb=Math.max(16,view*view/(view+max));float yy=top+(view-thumb)*scroll/max;Shapes.roundRect(g,x+w-17,yy,x+w-15,yy+thumb,1,Ui.BORDER_STRONG);}
        }
        text(g,"Counts include local pickups and observed XP. Time includes menus/pauses.",x+18,y+h-88,7.4f,false,Ui.MUTED);
        float bw=(w-51)/4,by=y+h-65;
        button(g,"Refresh",x+18,by,bw,mx,my,true,()->{report=FarmReports.snapshot();scroll=0;status="Report refreshed.";error=false;});
        button(g,"Export CSV + summary",x+23+bw,by,bw,mx,my,report!=null,()->{try{var result=FarmReports.export(report);status="Saved "+result.csv().getFileName()+" and summary.";error=false;}catch(Exception e){status="Couldn't save reports. Check the game folder is writable.";error=true;}});
        button(g,"Copy summary",x+28+2*bw,by,bw,mx,my,report!=null,()->{minecraft.keyboardHandler.setClipboard(FarmReports.share(report));status="Session summary copied.";error=false;});
        button(g,"Open folder",x+33+3*bw,by,bw,mx,my,true,()->{try{java.nio.file.Files.createDirectories(FarmReports.folder());Blaze3D.openPath(FarmReports.folder());}catch(Exception e){status="Couldn't open the reports folder.";error=true;}});
        text(g,shortText(status,w-36,7.6f,false),x+18,y+h-29,7.6f,false,error?Ui.WARN:Ui.MUTED);
        if(focus>=0&&focus<hits.size()){var f=hits.get(focus);Shapes.outline(g,f.x1()-1,f.y1()-1,f.x2()+1,f.y2()+1,5,Ui.accent());}
        g.pose().popMatrix();super.extractRenderState(g,realX,realY,dt);
    }
    private void button(GuiGraphicsExtractor g,String label,float bx,float by,float bw,int mx,int my,boolean enabled,Runnable run){boolean hover=enabled&&Ui.inside(mx,my,bx,by,bx+bw,by+24);Shapes.panel(g,bx,by,bx+bw,by+24,5,hover?Ui.RAISED_HOVER:Ui.RAISED,Ui.BORDER);String shown=shortText(label,bw-10,7.3f,true);text(g,shown,bx+(bw-GoonFont.width(shown,7.3f,GoonFont.Weight.BOLD))/2,by+8,7.3f,true,enabled?Ui.TEXT:Ui.FAINT);if(enabled)hits.add(new Hit(bx,by,bx+bw,by+24,run));}
    @Override public boolean mouseClicked(MouseButtonEvent e,boolean twice){if(e.button()!=InputConstants.MOUSE_BUTTON_LEFT)return true;for(int i=0;i<hits.size();i++){var hit=hits.get(i);if(Ui.inside(e.x()/s,e.y()/s,hit.x1(),hit.y1(),hit.x2(),hit.y2())){focus=i;hit.run().run();return true;}}return true;}
    @Override public boolean mouseScrolled(double mx,double my,double dx,double dy){if(report!=null&&Ui.inside(mx/s,my/s,x+18,top,x+w-18,bottom)){scroll=Math.max(0,Math.min(Math.max(0,report.items().size()*21-(bottom-top)),scroll-(float)dy*30));return true;}return false;}
    @Override public boolean keyPressed(KeyEvent e){if(e.key()==InputConstants.KEY_ESCAPE){onClose();return true;}if(e.key()==InputConstants.KEY_TAB&&!hits.isEmpty()){focus=Math.floorMod(focus+(e.hasShiftDown()?-1:1),hits.size());return true;}if(e.key()==InputConstants.KEY_RETURN&&focus>=0&&focus<hits.size()){hits.get(focus).run().run();return true;}return super.keyPressed(e);}
    @Override public void removed(){GlassUi.restoreHud(minecraft);}
    @Override public void onClose(){minecraft.gui.setScreen(parent);}
    @Override public boolean isPauseScreen(){return false;}
}
