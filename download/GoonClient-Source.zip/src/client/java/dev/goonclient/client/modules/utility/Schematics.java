package dev.goonclient.client.modules.utility;

import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.Module;
import dev.goonclient.client.module.setting.BooleanSetting;
import dev.goonclient.client.module.setting.ButtonSetting;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;

/** Owns Litematica's master rendering/tool switches. Loading schematics alone never claims a stick. */
public final class Schematics extends Module {
    private static Schematics instance;
    private final BooleanSetting pick=add(new BooleanSetting("pick","Schematic pick-block",true));
    private final BooleanSetting easy=add(new BooleanSetting("easy_place","Easy place (only where permitted)",false));
    private final BooleanSetting tool=add(new BooleanSetting("tool","Use schematic tool (stick)",false));
    public Schematics(){super("schematics","Schematics","Blueprints on demand. Stick tool is a separate, opt-in setting.",Category.UTILITY,false);instance=this;add(new ButtonSetting("manage","Blueprints and materials","Open Litematica",()->{var mc=Minecraft.getInstance();if(available())mc.gui.setScreen(new fi.dy.masa.litematica.gui.GuiMainMenu().setParent(mc.gui.screen()));}));}
    public static boolean available(){return FabricLoader.getInstance().isModLoaded("litematica");}
    public static boolean active(){return instance!=null&&instance.isEnabled();}
    public static void sync(){
        if(instance==null||!available())return;
        boolean on=active();
        var generic=fi.dy.masa.litematica.config.Configs.Generic.TOOL_ITEM_ENABLED;
        if(generic.getBooleanValue()!=(on&&instance.tool.isOn()))generic.setBooleanValue(on&&instance.tool.isOn());
        var visual=fi.dy.masa.litematica.config.Configs.Visuals.ENABLE_RENDERING;
        if(visual.getBooleanValue()!=on)visual.setBooleanValue(on);
        var easy=fi.dy.masa.litematica.config.Configs.Generic.EASY_PLACE_MODE;
        if(easy.getBooleanValue()!=(on&&instance.easy.isOn()))easy.setBooleanValue(on&&instance.easy.isOn());
        var pickup=fi.dy.masa.litematica.config.Configs.Generic.PICK_BLOCK_ENABLED;
        if(pickup.getBooleanValue()!=(on&&instance.pick.isOn()))pickup.setBooleanValue(on&&instance.pick.isOn());
        if(!on){
            var restriction=fi.dy.masa.litematica.config.Configs.Generic.PLACEMENT_RESTRICTION;
            if(restriction.getBooleanValue())restriction.setBooleanValue(false);
        }
    }
    @Override protected void onEnable(){if(!available()){loadEnabled(false);dev.goonclient.client.modules.hud.FeedbackHud.post("schematics","Schematics","Litematica is not installed",false);}else sync();}
    @Override protected void onDisable(){sync();}
}
