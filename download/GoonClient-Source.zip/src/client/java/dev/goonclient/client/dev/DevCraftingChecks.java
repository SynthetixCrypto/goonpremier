package dev.goonclient.client.dev;

import dev.goonclient.Goon;
import java.lang.reflect.Field;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.gui.screens.inventory.CraftingScreen;
import net.minecraft.client.gui.screens.inventory.StonecutterScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.inventory.CraftingMenu;
import net.minecraft.world.inventory.StonecutterMenu;

/** Explicit opt-in dev tour only. Forces upstream settings ON to verify Goon's exclusion, not a new user feature. */
public final class DevCraftingChecks {
    private DevCraftingChecks() {}
    private static Object initWidgets;
    private static void require(boolean ok,String message){if(!ok)throw new IllegalStateException(message);}
    private static Object field(Object object,String name)throws Exception{
        Field f=object.getClass().getDeclaredField(name);f.setAccessible(true);return f.get(object);
    }
    private static Object config(String getter)throws Exception{
        Class<?> c=Class.forName("org.anti_ad.mc.ipnext.config.GuiSettings");
        return c.getMethod(getter).invoke(c.getField("INSTANCE").get(null));
    }
    private static void forceSettingsOn()throws Exception{
        config("getCONTINUOUS_CRAFTING_SAVED_VALUE").getClass().getMethod("setValue",boolean.class)
            .invoke(config("getCONTINUOUS_CRAFTING_SAVED_VALUE"),true);
        Object checkbox=config("getSHOW_CONTINUOUS_CRAFTING_CHECKBOX");
        checkbox.getClass().getMethod("setValue",boolean.class).invoke(checkbox,true);
    }
    private static void handlersOff()throws Exception{
        Class<?> grid=Class.forName("org.anti_ad.mc.ipnext.event.ContinuousCraftingHandler");
        var enabled=grid.getDeclaredMethod("getEnabled");enabled.setAccessible(true);
        require(!(boolean)enabled.invoke(grid.getField("INSTANCE").get(null)),"Grid auto-crafting remained enabled");
        Class<?> base=Class.forName("org.anti_ad.mc.ipnext.event.CutterCraftingHandlerBase");
        var cutterEnabled=base.getDeclaredMethod("getEnabled");cutterEnabled.setAccessible(true);
        Class<?> stone=Class.forName("org.anti_ad.mc.ipnext.event.StoneCutterCraftingHandler");
        require(!(boolean)cutterEnabled.invoke(stone.getField("INSTANCE").get(null)),"Stonecutter auto-crafting remained enabled");
    }
    private static void checkScreen(Minecraft mc,AbstractContainerScreen<?> screen)throws Exception{
        mc.gui.setScreen(screen);
        Class<?> hints=Class.forName("org.anti_ad.mc.ipnext.integration.HintClassData");
        Class<?> collection=Class.forName("org.anti_ad.mc.ipnext.gui.inject.SortingButtonCollectionWidget");
        Object owner=collection.getConstructor(AbstractContainerScreen.class,hints)
            .newInstance(screen,hints.getConstructor().newInstance());
        Class<?> init=Class.forName("org.anti_ad.mc.ipnext.gui.inject.SortingButtonCollectionWidget$InitWidgets");
        initWidgets=init.getConstructor(collection).newInstance(owner);
        Object box=field(initWidgets,"continuousCraftingCheckbox");
        require(!(boolean)box.getClass().getMethod("getVisible").invoke(box),"Auto-craft checkbox visible");
        require(field(initWidgets,"sortButtonPlayer")!=null,"Sorting widget removed");
        handlersOff();
        Goon.LOGGER.info("0.17.9 CRAFT CHECK: {} hides crafting checkbox; sorting widget retained",screen.getClass().getSimpleName());
    }
    public static void tick(Minecraft mc,int step,Runnable done){
        try{
            require(FabricLoader.getInstance().isDevelopmentEnvironment(),"Development environment required");
            require(FabricLoader.getInstance().isModLoaded("inventoryprofilesnext"),"IPN required for crafting regression tour");
            if(step==0){
                mc.gui.setScreen(null);
                var server=mc.getSingleplayerServer();require(server!=null,"Integrated dev world required");
                server.execute(()->server.getCommands().performPrefixedCommand(server.createCommandSourceStack().withSuppressedOutput(),"execute as @p run gamemode survival"));
                forceSettingsOn();handlersOff();
            }
            if(step==20){forceSettingsOn();checkScreen(mc,new InventoryScreen(mc.player));}
            if(step==30)shot(mc,"inventory");
            if(step==40){forceSettingsOn();checkScreen(mc,new CraftingScreen(new CraftingMenu(77,mc.player.getInventory()),mc.player.getInventory(),Component.literal("Crafting")));}
            if(step==50)shot(mc,"crafting-table");
            if(step==60){forceSettingsOn();checkScreen(mc,new StonecutterScreen(new StonecutterMenu(78,mc.player.getInventory()),mc.player.getInventory(),Component.literal("Stonecutter")));}
            if(step==70)shot(mc,"stonecutter");
            if(step==80){forceSettingsOn();handlersOff();Goon.LOGGER.info("0.17.9 CRAFT CHECKS PASSED: both handlers stay off with true settings; inventory/table/stonecutter checkbox hidden; sorting widgets retained");done.run();}
        }catch(Exception e){throw new IllegalStateException("Crafting regression failed",e);}
    }
    private static void shot(Minecraft mc,String name){Screenshot.grab(mc.gameDirectory,"goon-0179-"+name+".png",mc.gameRenderer.mainRenderTarget(),1,message->{});}
}
