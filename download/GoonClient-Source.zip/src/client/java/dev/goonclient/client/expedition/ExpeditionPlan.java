package dev.goonclient.client.expedition;

import java.util.List;
import java.util.UUID;

/** Immutable, bounded trip sheet. Item requirements are exact registry IDs, not contents inside bags. */
public record ExpeditionPlan(String id, String name, List<Supply> supplies, List<Task> tasks, Destination destination) {
    public static final int MAX_ROWS = 48;

    public ExpeditionPlan {
        UUID.fromString(id);
        name = text(name, 48);
        supplies = List.copyOf(supplies);
        tasks = List.copyOf(tasks);
        if (supplies.size() + tasks.size() > MAX_ROWS) throw new IllegalArgumentException("At most 48 checklist rows per plan.");
        if (supplies.stream().map(Supply::item).distinct().count() != supplies.size())
            throw new IllegalArgumentException("Each item can appear only once.");
    }

    public record Supply(String item, int target) {
        public Supply {
            item = text(item, 128);
            if (!item.matches("[a-z0-9_.-]+:[a-z0-9_./-]+") || item.equals("minecraft:air"))
                throw new IllegalArgumentException("Use an item ID such as minecraft:torch.");
            if (target < 1 || target > 4096) throw new IllegalArgumentException("Item targets must be 1 to 4096.");
        }
    }

    public record Task(String label, boolean done) {
        public Task { label = text(label, 96); }
    }

    /** A manual snapshot of a waypoint, namespaced to its source world; never a navigation instruction. */
    public record Destination(String world, String name, String dimension, int x, int y, int z) {
        public Destination {
            world = text(world, 192);
            name = text(name, 96);
            dimension = text(dimension, 128);
            if (!dimension.matches("[a-z0-9_.-]+:[a-z0-9_./-]+") || Math.abs((long)x) > 30_000_000
                    || Math.abs((long)z) > 30_000_000 || y < -4096 || y > 4096)
                throw new IllegalArgumentException("Invalid destination coordinates or dimension.");
        }
    }

    public static String text(String value, int max) {
        if (value == null || value.isBlank() || value.length() > max
                || value.codePoints().anyMatch(c -> Character.isISOControl(c) || Character.getType(c) == Character.SURROGATE))
            throw new IllegalArgumentException("Text is empty, too long, or contains control characters.");
        return value.strip();
    }

    public enum Template {
        EXPLORATION("Exploration"), NETHER("Nether"), BOSS("Boss trip");
        public final String label;
        Template(String label) { this.label = label; }
    }

    public static ExpeditionPlan starter(Template template) {
        List<Supply> supplies = switch (template) {
            case EXPLORATION -> List.of(new Supply("minecraft:cooked_beef", 32), new Supply("minecraft:torch", 64),
                    new Supply("minecraft:cobblestone", 64), new Supply("minecraft:oak_boat", 1), new Supply("minecraft:white_bed", 1));
            case NETHER -> List.of(new Supply("minecraft:cooked_beef", 32), new Supply("minecraft:cobblestone", 128),
                    new Supply("minecraft:flint_and_steel", 1), new Supply("minecraft:obsidian", 10), new Supply("minecraft:golden_boots", 1));
            case BOSS -> List.of(new Supply("minecraft:cooked_beef", 32), new Supply("minecraft:arrow", 64),
                    new Supply("minecraft:bow", 1), new Supply("minecraft:golden_apple", 4), new Supply("minecraft:cobblestone", 64));
        };
        List<Task> tasks = switch (template) {
            case EXPLORATION -> List.of(new Task("Mark home before leaving", false), new Task("Check tool durability and spare space", false));
            case NETHER -> List.of(new Task("Record the return portal coordinates", false),
                    new Task("Check fire resistance supplies manually", false), new Task("Avoid placing beds in the Nether", false));
            case BOSS -> List.of(new Task("Choose supplies for this specific boss", false),
                    new Task("Check armor, weapon durability and enchantments", false), new Task("Set a safe return point", false));
        };
        return new ExpeditionPlan(UUID.randomUUID().toString(), template.label, supplies, tasks, null);
    }
}
