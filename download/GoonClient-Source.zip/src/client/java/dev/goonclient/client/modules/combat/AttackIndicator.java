package dev.goonclient.client.modules.combat;

import dev.goonclient.client.gui.Ui;
import dev.goonclient.client.hud.HudModule;
import dev.goonclient.client.hud.HudPosition;
import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.setting.BooleanSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.effect.MobEffects;

/** A thin bar under the crosshair while your attack recharges, and a marker when a jump hit would crit. */
public class AttackIndicator extends HudModule {
	private static final int WIDTH = 28;

	private final BooleanSetting always = add(new BooleanSetting("always", "Always show the bar", false));
	private final BooleanSetting crits = add(new BooleanSetting("crits", "Show when a hit will crit", true));

	public AttackIndicator() {
		super("attack_indicator", "Attack Indicator", "Attack cooldown under the crosshair and a crit-ready marker", Category.COMBAT, true, HudPosition.center(0, 12));
	}

	@Override
	public boolean isVisible(Minecraft mc) {
		return mc.player != null && mc.options.getCameraType().isFirstPerson();
	}

	@Override
	protected boolean isTransient() {
		return true;
	}

	@Override protected void measure(Minecraft mc, boolean editing) {
        float strength = mc.player == null ? .6f : mc.player.getAttackStrengthScale(0f);
        boolean crit = mc.player != null && crits.isOn() && strength > .9f && critReady(mc.player);
        setSize(editing || strength < 1 || crit || always.isOn() ? WIDTH : 1, editing || strength < 1 || crit || always.isOn() ? 11 : 1);
	}

	@Override
	protected void render(GuiGraphicsExtractor g, Minecraft mc, boolean editing) {
		LocalPlayer player = mc.player;
		float strength = player != null ? player.getAttackStrengthScale(0f) : 0.6f;
		boolean crit = player != null && crits.isOn() && strength > 0.9f && critReady(player);
		boolean charging = strength < 1f;
		if (!editing && !charging && !crit && !always.isOn()) {
			setSize(WIDTH, 8);
			return;
		}
		if (charging || always.isOn() || editing) {
			Ui.roundRect(g, 0, 0, WIDTH, 3, 1, 0xB0000000);
			int filled = Math.round(WIDTH * strength);
			Ui.roundRect(g, 0, 0, Math.max(2, filled), 3, 1, charging ? 0xE6FFFFFF : Ui.accent());
		}
		if (crit || editing) {
			String label = "CRIT";
			g.pose().pushMatrix();
			g.pose().translate(WIDTH / 2f - Ui.boldWidth(mc.font, label) * 0.35f, 5);
			g.pose().scale(0.7f, 0.7f);
			Ui.bold(g, mc.font, label, 0, 0, Ui.accent(), true);
			g.pose().popMatrix();
		}
		setSize(WIDTH, 11);
	}

	/** The game's own critical hit rules: falling, not on a ladder or in water, not blind, riding or sprinting. */
	private static boolean critReady(LocalPlayer player) {
		return player.fallDistance > 0 && !player.onGround() && !player.onClimbable() && !player.isInWater()
			&& !player.hasEffect(MobEffects.BLINDNESS) && !player.isPassenger() && !player.isSprinting()
			&& !player.getAbilities().flying;
	}
}
