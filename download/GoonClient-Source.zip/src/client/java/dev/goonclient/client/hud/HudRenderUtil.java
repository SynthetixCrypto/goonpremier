/*
 * This file is part of the Combatant Client distribution.
 * Copyright (c) 2026 pivosos2007.
 *
 * Licensed under the GNU General Public License v3.0.
 *
 * Modified for Goon Client, 2026-10-04: ported the compact-stat (Fps/Memory/SpeedBps/Coordinates,
 * compact_stat.js) and list-panel (ScriptedListHudPanel, panel_base.js, list_panel.js) geometry, Noir
 * theme palette formulas, HUD scale math (HudScale, HudPanelLayoutModes, TextSizing) and MSDF font
 * metrics to Minecraft 26.3, drawn with GoonFont/Shapes and Goon's shared framebuffer blur instead of
 * Combatant's UI script runtime and render engine.
 */
package dev.goonclient.client.hud;

import dev.goonclient.client.gui.Ui;
import dev.goonclient.client.gui.render.BackdropBlur;
import dev.goonclient.client.gui.render.GoonFont;
import dev.goonclient.client.gui.render.Px;
import dev.goonclient.client.gui.render.Shapes;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/**
 * Combatant's HUD material and layout. Elements draw in Combatant's own units after scaling the pose by
 * {@link #compactUnit()} or {@link #panelUnit(float)}, so every number below is copied as-is from its source.
 */
public final class HudRenderUtil {
    // ---- HudScale / TextSizing ----
    private static final float BASE_WIDTH = 1920f, BASE_HEIGHT = 1080f;
    private static final float REFERENCE_SIZE = 18f, HUD_FONT_SIZE = 20f;

    // ---- Compact stat (Fps.java and friends, compact_stat.js) ----
    public static final float SCALE_MULT = .68f, COMPACT_SCALE = 2.37f;
    public static final float BOX_HEIGHT = 20, BOX_RADIUS = 5, ICON_X = 5, DIVIDER_X = 21, DIVIDER_Y = 4,
        DIVIDER_WIDTH = .6f, TEXT_LEFT_X = 26, VALUE_UNIT_GAP = 2, EXTRA_GAP = 5, RIGHT_PAD = 5;
    /** Line height of compact-stat text: TextSizing.REFERENCE_SIZE at drawScale. */
    public static final float COMPACT_TEXT = REFERENCE_SIZE;
    public static final int COMPACT_BG_ALPHA = 133, COMPACT_SHADOW_ALPHA = 48;

    // ---- List panel (ScriptedListHudPanel, panel_base.js, list_panel.js) ----
    public static final float HEADER_HEIGHT = 15.5f, BODY_Y_OFFSET = 18.5f, CONTENT_START_Y = 25f, BODY_INSET_Y = 6.5f,
        ROW_STEP = 11f, PANEL_RADIUS = 4f, ROW_TEXT_START_X = 18f, ROW_TEXT_RIGHT_GAP = 4f, HEADER_DIVIDER_H = 6f,
        LEFT_INSET = 4f, ICON_SLOT = 8f, ICON_DIVIDER_GAP = 3f, DIVIDER_TITLE_GAP = 2.75f, DIVIDER_W = .5f;
    /** Row rail (list_panel.js): icon slot centre, divider centre and text start. */
    public static final float DIVIDER_CENTER_X = LEFT_INSET + ICON_SLOT + ICON_DIVIDER_GAP;
    public static final float TITLE_X = DIVIDER_CENTER_X + DIVIDER_W * .5f + DIVIDER_TITLE_GAP;
    public static final float ICON_CENTER_X = LEFT_INSET + ICON_SLOT * .5f;
    /**
     * Header rail as in the reference screenshot (Inventory/Potions.java: TITLE_ICON_X, HEADER_DIVIDER_X,
     * TITLE_TEXT_X), which predates the script's shared rail; measured 8.7 / 18.2 / 22.1 units on hud.png.
     */
    public static final float HEADER_ICON_X = 4.5f, HEADER_DIVIDER_X = 18f, HEADER_TITLE_X = 22f;
    public static final int PANEL_SHADOW_ALPHA = 38;

    // ---- Combatant's Noir theme (Themes.NOIR) ----
    private static final int WINDOW_BG = 0xF00C0D10, WINDOW_HEADER = 0xF0121317, SURFACE = 0xFF14161B;
    public static final int TEXT_PRIMARY = 0xFFF4F4F4, TEXT_MUTED = 0x88C7CBD3;
    /** HudRenderUtil.GLASS_BG: the plain see-through glass (notifications, time chip). */
    public static final int GLASS_BG = 0x660C0C0C;
    /** TargetHud bar track: surface darkened 18%, alpha 200. */
    public static final int BAR_BACKGROUND = 0xC8101216;

    private HudRenderUtil() { }

    /** Combatant's MSDF fonts: TextRenderer sizes are line heights, so em = size / lineHeight. */
    public enum Font {
        ONEST(GoonFont.Weight.ONEST, 1.275f, .97f),
        ONEST_MEDIUM(GoonFont.Weight.ONEST_MEDIUM, 1.275f, .97f),
        INTER_BOLD(GoonFont.Weight.BOLD, 1.2102273f, .96875f),
        ICONS_NUR(GoonFont.Weight.ICONS_NUR, 1.0898438f, 1f),
        ICONS(GoonFont.Weight.ICONS, .925f, .749f);

        final GoonFont.Weight weight;
        public final float lineHeight, ascender;

        Font(GoonFont.Weight weight, float lineHeight, float ascender) {
            this.weight = weight;
            this.lineHeight = lineHeight;
            this.ascender = ascender;
        }
    }

    /** Text laid out like Combatant's TextRenderer: top of the line box at {@code top}, {@code size} = line height. */
    public static void text(GuiGraphicsExtractor g, String text, float x, float top, float size, Font font, int color) {
        float em = size / font.lineHeight;
        GoonFont.draw(g, text, x, top + (font.ascender - .82f) * em, em, font.weight, color, false);
    }

    public static void textGradient(GuiGraphicsExtractor g, String text, float x, float top, float size, Font font, int from, int to) {
        float em = size / font.lineHeight;
        GoonFont.drawGradient(g, text, x, top + (font.ascender - .82f) * em, em, font.weight, from, to);
    }

    public static float width(String text, float size, Font font) {
        return GoonFont.width(text, size / font.lineHeight, font.weight);
    }

    // ---- Scale ----------------------------------------------------------------------------------------------

    /** HudScale.scale for the framebuffer, divided by the GUI scale: GUI units per 1080p pixel. */
    public static float resolutionScale() {
        var window = Minecraft.getInstance().getWindow();
        float scale = Math.min(window.getWidth() / BASE_WIDTH, window.getHeight() / BASE_HEIGHT);
        return (scale > 0 ? scale : 1f) / Px.guiScale();
    }

    /** GUI units per compact-stat unit: HudScale * TextSizing.scaleForSize(20) * 0.68 * 2.37. */
    public static float compactUnit() {
        return resolutionScale() * (HUD_FONT_SIZE / REFERENCE_SIZE) * SCALE_MULT * COMPACT_SCALE;
    }

    /** GUI units per list-panel unit: HudScale * 1.1 * HudPanelLayoutModes.effectiveScale(scale). */
    public static float panelUnit(float scale) {
        return resolutionScale() * 1.1f * scale * 2f;
    }

    /** Panel text line height in panel units: TextSizing.sizeForScale(0.98 * scaleForSize(20) / renderScale). */
    public static float panelFontSize(float scale) {
        return REFERENCE_SIZE * .98f * (HUD_FONT_SIZE / REFERENCE_SIZE) / (1.1f * scale * 2f);
    }

    // ---- Colour -----------------------------------------------------------------------------------------------

    public static int setAlpha(int color, int alpha) {
        return (Math.max(0, Math.min(255, alpha)) << 24) | (color & 0xFFFFFF);
    }

    public static int scaleAlpha(int color, float factor) {
        return ((int) (((color >>> 24) & 0xFF) * Math.max(0, Math.min(1, factor))) << 24) | (color & 0xFFFFFF);
    }

    public static int mixColor(int from, int to, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int a = (int) (((from >>> 24) & 0xFF) * (1 - t) + ((to >>> 24) & 0xFF) * t);
        int r = (int) (((from >>> 16) & 0xFF) * (1 - t) + ((to >>> 16) & 0xFF) * t);
        int g = (int) (((from >>> 8) & 0xFF) * (1 - t) + ((to >>> 8) & 0xFF) * t);
        int b = (int) ((from & 0xFF) * (1 - t) + (to & 0xFF) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    /** Goon's theme accent in Combatant's theme slot. */
    public static int accent() {
        return Ui.accent() | 0xFF000000;
    }

    /** Fps.updatePalette in theme mode. */
    public record CompactPalette(int bgPrimary, int bgSecondary, int icon, int value, int meta, int divider) {
        public static CompactPalette current() {
            return new CompactPalette(
                setAlpha(WINDOW_BG, COMPACT_BG_ALPHA),
                setAlpha(mixColor(SURFACE, WINDOW_HEADER, .35f), COMPACT_BG_ALPHA),
                TEXT_PRIMARY, TEXT_PRIMARY, TEXT_MUTED, setAlpha(TEXT_MUTED, 0x52));
        }
    }

    /** Potions/Keybinds/Cooldowns/Inventory.updatePalette in theme mode for a panel's background alpha. */
    public record Palette(int headerLeft, int headerRight, int bodyLeft, int bodyRight, int text, int titleText,
                          int muted, int counter, int ampText, int divider) {
        public static Palette of(int bgAlpha) {
            int window = setAlpha(WINDOW_BG, bgAlpha);
            int header = setAlpha(mixColor(WINDOW_HEADER, SURFACE, .18f), Math.min(255, bgAlpha + 14));
            int surface = setAlpha(mixColor(SURFACE, WINDOW_BG, .22f), Math.min(255, bgAlpha + 6));
            int deep = setAlpha(mixColor(SURFACE, WINDOW_HEADER, .42f), Math.min(255, bgAlpha + 18));
            int muted = mixColor(TEXT_MUTED, TEXT_PRIMARY, .16f);
            int accent = accent();
            return new Palette(
                mixColor(header, window, .22f), mixColor(surface, header, .52f),
                mixColor(window, surface, .24f), mixColor(deep, surface, .18f),
                TEXT_PRIMARY, mixColor(TEXT_PRIMARY, accent, .14f), muted,
                mixColor(accent, TEXT_PRIMARY, .38f), mixColor(TEXT_PRIMARY, accent, .22f),
                scaleAlpha(muted, .68f));
        }

        public Palette withCounter(int counter) {
            return new Palette(headerLeft, headerRight, bodyLeft, bodyRight, text, titleText, muted, counter, ampText, divider);
        }
    }

    /** Themes.hudForegroundGradient for a theme without a card gradient: accent to accent-soft. */
    public static int headerIconFrom() {
        return accent();
    }

    public static int headerIconTo() {
        return setAlpha(accent(), 0x80);
    }

    // ---- Material -----------------------------------------------------------------------------------------------

    /** HudRenderUtil.drawHudShadow (black): a 6-unit soft shadow, faint under the panel itself. */
    public static void shadow(GuiGraphicsExtractor g, float x, float y, float w, float h, float radius, int alpha) {
        Shapes.glow(g, x, y, x + w, y + h, radius, 6f, alpha / 255f, .055f);
    }

    /**
     * A blurred-backdrop surface with Combatant's blur alpha: the blurred frame shows through at {@code blurAlpha}
     * and the fill's own alpha is weighted by it (matches the reference HUD's measured translucency).
     */
    public static void glassFill(GuiGraphicsExtractor g, float x, float y, float w, float h, float radiusTop, float radiusBottom,
                                 int top, int bottom, boolean blur, float blurAlpha) {
        float fillAlpha = blur ? blurAlpha : 1f;
        if (blur) BackdropBlur.draw(g, x, y, w, h, radiusTop, radiusBottom, blurAlpha);
        Shapes.gradientRect(g, x, y, x + w, y + h, radiusTop, radiusBottom, scaleAlpha(top, fillAlpha), scaleAlpha(bottom, fillAlpha));
    }

    /**
     * The bright edge of Combatant's liquid-glass material (drawLiquidGlass's fresnel term), as a faint light
     * hairline: what rims the target card and notifications in the reference.
     */
    public static void rim(GuiGraphicsExtractor g, float x, float y, float w, float h, float radius, float alpha) {
        Shapes.outline(g, x, y, x + w, y + h, radius, scaleAlpha(0x3AFFFFFF, alpha));
    }

    /** The faint white sheen along the top of every Combatant surface ("top-glint"). */
    public static void glint(GuiGraphicsExtractor g, float x, float y, float w, float h, float radiusTop, float paintAlpha) {
        int top = setAlpha(0xFFFFFF, Math.round(255 * .065f * paintAlpha));
        Shapes.gradientRect(g, x, y, x + w, y + h, radiusTop, 0, top, 0x00FFFFFF);
    }

    public static float alpha01(int color) {
        return ((color >>> 24) & 0xFF) / 255f;
    }

    /** A thin rounded bar (dividers). */
    public static void bar(GuiGraphicsExtractor g, float x, float y, float w, float h, int color) {
        Shapes.roundRect(g, x, y, x + w, y + h, Math.min(w, h) * .5f, color);
    }

    /**
     * The compact-stat material for other surfaces (hotbar, armour bar, target card, notifications), in the caller's
     * units. {@code large} uses the list panels' lighter shadow.
     */
    public static void panel(GuiGraphicsExtractor g, float x, float y, float w, float h, float radius, boolean large, float alpha) {
        if (alpha <= .001f || w <= 0 || h <= 0) return;
        CompactPalette p = CompactPalette.current();
        float shadowBlur = 6f * compactUnit() / Math.max(1e-3f, g.pose().m00);
        Shapes.glow(g, x, y, x + w, y + h, radius, shadowBlur, (large ? PANEL_SHADOW_ALPHA : COMPACT_SHADOW_ALPHA) / 255f * alpha, .055f);
        glassFill(g, x, y, w, h, radius, radius, scaleAlpha(p.bgPrimary(), alpha), scaleAlpha(p.bgSecondary(), alpha), BackdropBlur.available(), alpha);
        glint(g, x + .5f, y + .5f, w - 1, h * .42f, Math.max(0, radius - .5f), Math.max(alpha01(p.bgPrimary()), alpha01(p.bgSecondary())) * alpha);
    }

    /** compact_stat.js shell: shadow, blur, top-to-bottom fill, top glint. Coordinates in compact units. */
    public static void compactShell(GuiGraphicsExtractor g, float w, CompactPalette palette, boolean background) {
        if (!background) return;
        shadow(g, 0, 0, w, BOX_HEIGHT, BOX_RADIUS, COMPACT_SHADOW_ALPHA);
        glassFill(g, 0, 0, w, BOX_HEIGHT, BOX_RADIUS, BOX_RADIUS, palette.bgPrimary(), palette.bgSecondary(), BackdropBlur.available(), 1f);
        float paint = Math.max(alpha01(palette.bgPrimary()), alpha01(palette.bgSecondary()));
        glint(g, 1, 1, w - 2, BOX_HEIGHT * .42f, BOX_RADIUS - 1, paint);
    }

    /**
     * panel_base.js chrome. Unified Divider: one plate, a separator under the header. Split Header: header and body
     * as separate plates with a gap. Coordinates in panel units.
     */
    public static void panelChrome(GuiGraphicsExtractor g, float w, float h, Palette pal, boolean split, float blurAlpha, boolean background) {
        if (!background) return;
        boolean blur = BackdropBlur.available();
        float r = PANEL_RADIUS;
        shadow(g, 0, 0, w, h, r, PANEL_SHADOW_ALPHA);
        if (split) {
            float bodyH = Math.max(0, h - BODY_Y_OFFSET);
            glassFill(g, 0, 0, w, HEADER_HEIGHT, r, 0, pal.headerLeft(), pal.headerRight(), blur, blurAlpha);
            glint(g, 1, 1, w - 2, HEADER_HEIGHT * .42f, r - 1, Math.max(alpha01(pal.headerLeft()), alpha01(pal.headerRight())));
            if (bodyH > 0) {
                glassFill(g, 0, BODY_Y_OFFSET, w, bodyH, 0, r, pal.bodyLeft(), pal.bodyRight(), blur, blurAlpha);
                glint(g, 1, BODY_Y_OFFSET + 1, w - 2, Math.max(1, bodyH * .18f), 0, Math.max(alpha01(pal.bodyLeft()), alpha01(pal.bodyRight())));
            }
            headerDivider(g, pal.divider());
            return;
        }
        float paint = Math.max(alpha01(pal.bodyLeft()), alpha01(pal.bodyRight()));
        glassFill(g, 0, 0, w, h, r, r, pal.bodyLeft(), pal.bodyRight(), blur, blurAlpha);
        glint(g, 1, 1, w - 2, Math.max(1, Math.min(h * .34f, HEADER_HEIGHT * .52f)), r - 1, paint);
        float dividerAlpha = Math.min(.42f, Math.max(.12f, paint * .38f));
        bar(g, 6, HEADER_HEIGHT + 1.4f, Math.max(1, w - 12), .55f, scaleAlpha(pal.divider(), dividerAlpha));
        headerDivider(g, scaleAlpha(pal.divider(), dividerAlpha * .85f));
    }

    private static void headerDivider(GuiGraphicsExtractor g, int color) {
        bar(g, HEADER_DIVIDER_X, (HEADER_HEIGHT - HEADER_DIVIDER_H) * .5f, DIVIDER_W, HEADER_DIVIDER_H, color);
    }

    /**
     * panel_base.js header(): glyph icon, bold title, then "Active:" and the count right-aligned.
     * {@code size} is the panel's text line height ({@link #panelFontSize}).
     */
    public static void panelHeader(GuiGraphicsExtractor g, float w, float size, Palette pal, String glyph, Font glyphFont, float glyphScale,
                                   String title, String counterLabel, String count, float countValueOffset) {
        textGradient(g, glyph, HEADER_ICON_X, (HEADER_HEIGHT - size) * .5f, size * glyphScale, glyphFont, headerIconFrom(), headerIconTo());
        text(g, title, HEADER_TITLE_X, (HEADER_HEIGHT - size) * .5f, size, Font.INTER_BOLD, pal.titleText());
        if (counterLabel == null) return;
        float countSize = size * .92f, fs = size / REFERENCE_SIZE;
        float countValueW = Math.max(8, width(count, countSize, Font.ONEST_MEDIUM) + 1.5f);
        float countLabelW = Math.max(26 * fs, width(counterLabel, countSize, Font.ONEST_MEDIUM) + 1.5f);
        float countValueX = w - countValueW - countValueOffset;
        float countLabelX = countValueX - countLabelW - Math.max(3.2f, 3f * fs);
        float countY = (HEADER_HEIGHT - size) * .5f + .8f;
        text(g, counterLabel, countLabelX, countY, countSize, Font.ONEST_MEDIUM, pal.text());
        text(g, count, countValueX, countY, countSize, Font.ONEST_MEDIUM, pal.counter());
    }

    /** Width a list panel needs for its header (Potions/Keybinds/Cooldowns.renderEngine headerWidth). */
    public static float headerWidth(float size, String title, String counterLabel, String count, float countLabelOffset) {
        float w = 22f + width(title, size, Font.INTER_BOLD) + countLabelOffset + 12f;
        if (counterLabel != null) w += width(counterLabel, size * .92f, Font.ONEST_MEDIUM) + width(count, size * .92f, Font.ONEST_MEDIUM);
        return w;
    }
}
