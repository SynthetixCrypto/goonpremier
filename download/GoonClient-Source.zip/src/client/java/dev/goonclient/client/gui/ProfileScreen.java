package dev.goonclient.client.gui;

import com.mojang.blaze3d.platform.InputConstants;
import dev.goonclient.client.config.ProfileStore;
import dev.goonclient.client.gui.render.GoonFont;
import dev.goonclient.client.gui.render.Shapes;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

/** One place to save/load local module and HUD setups, with recovery before destructive changes. */
public final class ProfileScreen extends Screen implements GoonScreen {
	private static final float BODY=8.2f, SMALL=7.4f;
	private final Screen parent;
	private final List<Hit> hits=new ArrayList<>();
	private List<ProfileStore.Profile> profiles=List.of();
	private ProfileStore.Profile selected;
	private float s,x,y,w,h,listTop,listBottom,listLeft,listRight,scroll;
	private String name="",status="Load a setup, or save your current settings under a new name.",armed="";
	private boolean nameFocus,selectAll,error;
	private long armedAt;
	public ProfileScreen(Screen parent){super(Component.literal("Goon setups"));this.parent=parent;refresh("");}
	private void refresh(String preferred){
		try{profiles=ProfileStore.list();}
		catch(IOException e){profiles=ProfileStore.presets();status="Couldn't read your saved setups. Built-in setups are available.";error=true;}
		selected=profiles.stream().filter(p->p.id().equals(preferred)).findFirst().orElse(profiles.isEmpty()?null:profiles.getFirst());
		scroll=Math.max(0,Math.min(scroll,Math.max(0,profiles.size()*43-(listBottom-listTop))));
	}
	@Override protected void init(){
		s=Math.max(.01f,Math.min(Ui.menuScale(width,height),Math.min(width/640f,height/420f)));float vw=width/s,vh=height/s;
		w=Math.min(640,vw-28);h=Math.min(390,vh-30);x=(vw-w)/2;y=(vh-h)/2;
		listLeft=x+18;listRight=x+208;listTop=y+70;listBottom=y+h-47;
		scroll=Math.max(0,Math.min(scroll,Math.max(0,profiles.size()*43-(listBottom-listTop))));
	}
	@Override public void extractRenderState(GuiGraphicsExtractor g,int realX,int realY,float partialTick){
		int mx=(int)(realX/s),my=(int)(realY/s);hits.clear();
		g.pose().pushMatrix();g.pose().scale(s,s);
		GlassUi.panel(g,x,y,w,h,1);
		text(g,"Your setups",x+20,y+18,15,GoonFont.Weight.BOLD,Ui.TEXT);
		text(g,"Modules, settings and HUD layouts for the way you play.",x+20,y+42,BODY,GoonFont.Weight.REGULAR,Ui.MUTED);
		button(g,"Done",x+w-73,y+16,54,mx,my,true,false,this::onClose);
		Shapes.rect(g,x+220,y+70,x+220.5f,y+h-48,Ui.BORDER);
		g.enableScissor((int)listLeft-1,(int)listTop-1,(int)listRight+1,(int)listBottom);
		for(int i=0;i<profiles.size();i++){
			var profile=profiles.get(i);float ry=listTop+i*43-scroll;
			if(ry+40<=listTop||ry>=listBottom)continue;
			boolean active=selected!=null&&selected.id().equals(profile.id());
			boolean hover=Ui.inside(mx,my,listLeft,Math.max(ry,listTop),listRight,Math.min(ry+40,listBottom));
			float a=Ui.animate("profiles:hover:"+profile.id(),hover?1:0,.6f);
			Shapes.panel(g,listLeft,ry,listRight,ry+40,7,active?Ui.withAlpha(Ui.accent(),.18f):Ui.lerp(a,0x48272331,0x66534D60),active?Ui.withAlpha(Ui.accent(),.65f):Ui.withAlpha(Ui.BORDER,a));
			text(g,Ui.ellipsize(profile.name(),160,9.2f,GoonFont.Weight.BOLD),listLeft+10,ry+7,9.2f,GoonFont.Weight.BOLD,active?Ui.TEXT:Ui.MUTED);
			text(g,(profile.builtin()?"Built in":"Saved")+" · "+profile.enabledCount()+" enabled",listLeft+10,ry+23,SMALL,GoonFont.Weight.REGULAR,Ui.MUTED);
			hits.add(new Hit(listLeft,Math.max(ry,listTop),listRight,Math.min(ry+40,listBottom),()->{selected=profile;armed="";nameFocus=false;}));
		}
		g.disableScissor();
		float max=Math.max(0,profiles.size()*43-(listBottom-listTop));
		if(max>0){float thumb=Math.max(18,(listBottom-listTop)*(listBottom-listTop)/(profiles.size()*43));float ty=listTop+(listBottom-listTop-thumb)*scroll/max;Shapes.roundRect(g,listRight+3,ty,listRight+5,ty+thumb,1,Ui.BORDER_STRONG);}
		float left=x+238,right=x+w-20,available=right-left;
		if(selected!=null){
			text(g,Ui.ellipsize(selected.name(),available,12,GoonFont.Weight.BOLD),left,y+74,12,GoonFont.Weight.BOLD,Ui.TEXT);
			float yy=y+95;
			for(String line:wrap(selected.description(),available,BODY,3)){text(g,line,left,yy,BODY,GoonFont.Weight.REGULAR,Ui.MUTED);yy+=11;}
			text(g,"Enabled modules",left,y+134,BODY,GoonFont.Weight.BOLD,Ui.TEXT);
			var modules=selected.settings().getAsJsonObject("modules");
			List<String> names=new ArrayList<>();
			for(var module:dev.goonclient.client.module.ModuleManager.all()){var data=modules.getAsJsonObject(module.id());if(data!=null&&data.has("enabled")&&data.get("enabled").getAsBoolean())names.add(module.name());}
			yy=y+149;
			int rows=Math.max(1,Math.min(4,(int)((h-145-yy+y)/10)));
			for(String line:wrap(String.join(" · ",names),available,SMALL,rows)){text(g,line,left,yy,SMALL,GoonFont.Weight.REGULAR,Ui.MUTED);yy+=10;}
		}
		if(!armed.isEmpty()&&System.currentTimeMillis()-armedAt>5000){armed="";status="Confirmation expired. Select the action again.";error=false;}
		text(g,Ui.ellipsize(dev.goonclient.client.config.ServerProfiles.linkLabel(),available,SMALL,GoonFont.Weight.REGULAR),left,y+h-188,SMALL,GoonFont.Weight.REGULAR,Ui.MUTED);
        float linkWidth=(available-5)/2;
        button(g,"Link selected setup",left,y+h-176,linkWidth,mx,my,selected!=null&&dev.goonclient.client.config.ServerProfiles.canLink(),false,()->result(dev.goonclient.client.config.ServerProfiles.bind(selected),false));
        button(g,"Unlink this world",left+linkWidth+5,y+h-176,linkWidth,mx,my,dev.goonclient.client.config.ServerProfiles.canLink()&&dev.goonclient.client.config.ServerProfiles.linked(),false,()->result(dev.goonclient.client.config.ServerProfiles.unbind(),false));
        float actions=y+h-133, gap=5,loadW=(available-gap*3)/4,updateW=loadW,deleteW=loadW,undoW=loadW;
		button(g,"Load setup",left,actions,loadW,mx,my,selected!=null,true,()->result(ProfileStore.load(selected),false));
		button(g,armed.equals("save")?"Confirm save":"Overwrite",left+loadW+gap,actions,updateW,mx,my,selected!=null&&!selected.builtin(),false,()->confirm("save",()->result(ProfileStore.overwrite(selected),true)));
		button(g,armed.equals("delete")?"Confirm":"Delete",left+loadW+updateW+gap*2,actions,deleteW,mx,my,selected!=null&&!selected.builtin(),false,()->confirm("delete",()->result(ProfileStore.delete(selected),true)));
		button(g,"Undo",left+loadW+updateW+deleteW+gap*3,actions,undoW,mx,my,ProfileStore.canUndo(),false,()->result(ProfileStore.undo(),false));
		text(g,"Save the current setup",left,y+h-91,BODY,GoonFont.Weight.BOLD,Ui.TEXT);
		float fieldY=y+h-73,fieldW=available-81;
		Shapes.panel(g,left,fieldY,left+fieldW,fieldY+24,6,Ui.FIELD,nameFocus?Ui.accent():Ui.BORDER_STRONG);
		String shown=Ui.ellipsize(name.isEmpty()?"Name this setup":name,fieldW-15,BODY,GoonFont.Weight.REGULAR);
		if(nameFocus&&selectAll&&!name.isEmpty())Shapes.roundRect(g,left+5,fieldY+5,left+7+GoonFont.width(shown,BODY,GoonFont.Weight.REGULAR),fieldY+19,2,Ui.withAlpha(Ui.accent(),.2f));
		text(g,shown,left+7,fieldY+8,BODY,GoonFont.Weight.REGULAR,name.isEmpty()?Ui.MUTED:Ui.TEXT);
		if(nameFocus&&!selectAll&&(System.currentTimeMillis()/530)%2==0){float cx=left+7+(name.isEmpty()?0:GoonFont.width(shown,BODY,GoonFont.Weight.REGULAR));Shapes.rect(g,cx,fieldY+6,cx+.65f,fieldY+18,Ui.accent());}
		hits.add(new Hit(left,fieldY,left+fieldW,fieldY+24,()->{nameFocus=true;armed="";}));
		button(g,"Save new",right-75,fieldY,75,mx,my,!name.isBlank(),false,this::create);
		float yy=y+h-34;for(String line:wrap(status,available,SMALL,2)){text(g,line,left,yy,SMALL,GoonFont.Weight.REGULAR,error?Ui.WARN:Ui.MUTED);yy+=10;}
		text(g,profiles.stream().filter(p->!p.builtin()).count()+" / 32 saved locally",listLeft,y+h-29,SMALL,GoonFont.Weight.REGULAR,Ui.MUTED);
		g.pose().popMatrix();super.extractRenderState(g,realX,realY,partialTick);
	}
	private void confirm(String action,Runnable run){
		if(armed.equals(action)&&System.currentTimeMillis()-armedAt<=5000){armed="";run.run();}
		else{armed=action;armedAt=System.currentTimeMillis();error=false;status=action.equals("save")?"Click Confirm save to replace this saved setup with your current settings.":"Click Confirm to remove this saved setup. Current settings are kept.";}
	}
	private void result(ProfileStore.Result result,boolean reload){status=result.message();error=!result.ok();armed="";if(reload&&result.ok())refresh(selected==null?"":selected.id());}
	private void create(){String label=name.strip();var result=ProfileStore.create(label);result(result,true);if(result.ok()){selected=profiles.stream().filter(p->!p.builtin()&&p.name().equals(label)).findFirst().orElse(selected);name="";selectAll=false;nameFocus=false;}}
	private void button(GuiGraphicsExtractor g,String label,float bx,float by,float bw,int mx,int my,boolean enabled,boolean primary,Runnable action){
		boolean hover=enabled&&Ui.inside(mx,my,bx,by,bx+bw,by+24);float a=Ui.animate("profile:button:"+bx+":"+by,hover?1:0,.7f);
		Shapes.panel(g,bx,by,bx+bw,by+24,6,primary&&enabled?Ui.accent():Ui.lerp(a,Ui.RAISED,Ui.RAISED_HOVER),primary&&enabled?Ui.accent():Ui.BORDER);
		String shown=Ui.ellipsize(label,bw-12,SMALL,GoonFont.Weight.BOLD);
		text(g,shown,bx+(bw-GoonFont.width(shown,SMALL,GoonFont.Weight.BOLD))/2,by+8,SMALL,GoonFont.Weight.BOLD,!enabled?Ui.FAINT:primary?Ui.ON_ACCENT:Ui.TEXT);
		if(enabled)hits.add(new Hit(bx,by,bx+bw,by+24,()->{nameFocus=false;action.run();}));
	}
	private static void text(GuiGraphicsExtractor g,String text,float x,float y,float size,GoonFont.Weight weight,int color){GoonFont.draw(g,text,x,y,size,weight,color,false);}
	private static List<String> wrap(String text,float width,float size,int limit){
		List<String> lines=new ArrayList<>();String row="";
		for(String word:text.split(" ")){String next=row.isEmpty()?word:row+" "+word;if(!row.isEmpty()&&GoonFont.width(next,size,GoonFont.Weight.REGULAR)>width){lines.add(row);row=word;if(lines.size()==limit){lines.set(limit-1,Ui.ellipsize(lines.getLast()+"…",width,size,GoonFont.Weight.REGULAR));return lines;}}else row=next;}
		if(!row.isEmpty())lines.add(Ui.ellipsize(row,width,size,GoonFont.Weight.REGULAR));return lines;
	}
	@Override public boolean mouseClicked(MouseButtonEvent event,boolean doubleClick){if(event.button()!=InputConstants.MOUSE_BUTTON_LEFT)return true;double mx=event.x()/s,my=event.y()/s;for(int i=hits.size()-1;i>=0;i--){var hit=hits.get(i);if(Ui.inside(mx,my,hit.x1,hit.y1,hit.x2,hit.y2)){hit.action.run();return true;}}nameFocus=false;return true;}
	@Override public boolean mouseScrolled(double mx,double my,double dx,double dy){if(Ui.inside(mx/s,my/s,listLeft,listTop,listRight,listBottom)){scroll=Math.max(0,Math.min(Math.max(0,profiles.size()*43-(listBottom-listTop)),scroll-(float)dy*30));return true;}return false;}
	@Override public boolean charTyped(CharacterEvent event){if(nameFocus&&event.isAllowedChatCharacter()){String typed=event.codepointAsString();if(selectAll){name="";selectAll=false;}if(name.length()+typed.length()<=32)name+=typed;return true;}return super.charTyped(event);}
	@Override public boolean keyPressed(KeyEvent event){
		if(event.key()==InputConstants.KEY_ESCAPE){onClose();return true;}
		if(event.key()==InputConstants.KEY_TAB){nameFocus=!nameFocus;return true;}
		if(nameFocus){
			if(event.hasControlDown()&&event.key()==InputConstants.KEY_A){selectAll=true;return true;}
			if(event.key()==InputConstants.KEY_BACKSPACE){name=selectAll||event.hasControlDown()?"":name.isEmpty()?"":name.substring(0,name.offsetByCodePoints(name.length(),-1));selectAll=false;return true;}
			if(event.key()==InputConstants.KEY_RETURN){create();return true;}
		}else if(selected!=null){
			if(event.key()==InputConstants.KEY_RETURN){result(ProfileStore.load(selected),false);return true;}
			if(event.key()==InputConstants.KEY_UP||event.key()==InputConstants.KEY_DOWN){int i=profiles.indexOf(selected);i=Math.max(0,Math.min(profiles.size()-1,i+(event.key()==InputConstants.KEY_UP?-1:1)));selected=profiles.get(i);float ry=i*43;if(ry<scroll)scroll=ry;else if(ry+40>scroll+listBottom-listTop)scroll=ry+40-(listBottom-listTop);armed="";return true;}
		}
		return super.keyPressed(event);
	}
	@Override public void onClose(){minecraft.gui.setScreen(parent);}
	@Override public boolean isPauseScreen(){return false;}
	private record Hit(float x1,float y1,float x2,float y2,Runnable action){}
}
