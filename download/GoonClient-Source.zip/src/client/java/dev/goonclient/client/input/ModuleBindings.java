package dev.goonclient.client.input;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.blaze3d.platform.InputConstants;
import dev.goonclient.Goon;
import dev.goonclient.client.config.ConfigManager;
import dev.goonclient.client.module.Module;
import dev.goonclient.client.module.ModuleManager;
import dev.goonclient.client.modules.hud.FeedbackHud;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.Map;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.Minecraft;
import net.minecraft.client.input.KeyEvent;

/** Per-device shortcuts. Stored separately from profiles so changing a setup preserves muscle memory. */
public final class ModuleBindings {
    private static final Map<String, Integer> KEYS = new HashMap<>();
    private ModuleBindings() { }
    public record Result(boolean ok, String message) { }
    public static int key(Module module) { return KEYS.getOrDefault(module.id(), -1); }
    public static String label(Module module) {
        int key = key(module);
        return key < 0 ? "Not bound" : InputConstants.Type.KEYBOARD.getOrCreate(key).getDisplayName().getString();
    }
    private static boolean supported(int key) { return key >= 4 && key <= 286; }
    public static String conflict(Minecraft mc, Module owner, int key) {
        if (!supported(key)) return "Choose a regular keyboard key.";
        if (key == InputConstants.KEY_ESCAPE || key == InputConstants.KEY_F3 || key == InputConstants.KEY_LCONTROL
                || key == InputConstants.KEY_RCONTROL || key == InputConstants.KEY_LSHIFT || key == InputConstants.KEY_RSHIFT
                || key == InputConstants.KEY_LALT || key == InputConstants.KEY_RALT) return "This key is reserved for navigation or modifiers.";
        for (var mapping : mc.options.keyMappings) {
            var bound = KeyMappingHelper.getBoundKeyOf(mapping);
            if (bound.getType() == InputConstants.Type.KEYBOARD && bound.getValue() == key)
                return "Already used by " + net.minecraft.network.chat.Component.translatable(mapping.getName()).getString() + ".";
        }
        for (var module : ModuleManager.all()) if (module != owner && key(module) == key)
            return "Already used by " + module.name() + ".";
        return "";
    }
    public static Result assign(Minecraft mc, Module module, int key) {
        String conflict = conflict(mc, module, key);
        if (!conflict.isEmpty()) return new Result(false, conflict);
        KEYS.put(module.id(), key); save();
        return new Result(true, "Bound to " + label(module) + ". Shortcuts work while playing.");
    }
    public static void clear(Module module) { KEYS.remove(module.id()); save(); }
    public static JsonObject capture() {
        var data = new JsonObject(); KEYS.forEach(data::addProperty); return data;
    }
    public static void restore(JsonObject data) {
        KEYS.clear();
        for (var module : ModuleManager.all()) {
            var value = data.get(module.id());
            if (value != null && value.isJsonPrimitive() && value.getAsJsonPrimitive().isNumber()) {
                double n = value.getAsDouble();
                if (Double.isFinite(n) && n == Math.rint(n) && supported((int)n)) KEYS.put(module.id(), (int)n);
            }
        }
    }
    public static void load() {
        var path = ConfigManager.dir().resolve("keybinds.json");
        try {
            if (Files.exists(path) && Files.size(path) <= 32768) restore(JsonParser.parseString(Files.readString(path)).getAsJsonObject());
        } catch (Exception e) { Goon.LOGGER.warn("Couldn't load module shortcuts", e); }
    }
    private static void save() { ConfigManager.writeAtomically(ConfigManager.dir().resolve("keybinds.json"), ConfigManager.GSON.toJson(capture())); }
    public static void press(Minecraft mc, long window, int action, KeyEvent event) {
        if (window != mc.getWindow().handle() || action != InputConstants.PRESS || mc.player == null || mc.level == null
                || mc.gui.screen() != null || mc.gui.overlay() != null || mc.player.isDeadOrDying() || mc.options.keyDebugModifier.isDown()
                || (event.modifiers() & (InputConstants.MOD_CONTROL | InputConstants.MOD_ALT | InputConstants.MOD_SHIFT | InputConstants.MOD_SUPER)) != 0) return;
        for (var module : ModuleManager.all()) if (key(module) == event.key() && conflict(mc, module, event.key()).isEmpty()) {
            toggle(module); break;
        }
    }
    public static void toggle(Module module) {
        module.toggle();
        FeedbackHud.post("toggle:" + module.id(), module.name(), module.isEnabled() ? "Enabled" : "Disabled", module.isEnabled());
    }
}


