package dev.goonclient.client.mixin;

import dev.goonclient.client.modules.inventory.ContainerPreview;
import java.util.Optional;
import net.minecraft.world.inventory.tooltip.TooltipComponent;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ItemStack.class)
public class ItemStackMixin {
	/** Gives filled containers (shulker boxes) a slot-grid tooltip image. */
	@Inject(method = "getTooltipImage", at = @At("RETURN"), cancellable = true)
	private void goonclient$containerPreview(CallbackInfoReturnable<Optional<TooltipComponent>> cir) {
		if (cir.getReturnValue().isEmpty()) {
			ContainerPreview.tooltipFor((ItemStack) (Object) this).ifPresent(tooltip -> cir.setReturnValue(Optional.of(tooltip)));
		}
	}
}
