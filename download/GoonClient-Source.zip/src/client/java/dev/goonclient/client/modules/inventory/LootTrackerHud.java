package dev.goonclient.client.modules.inventory;

import dev.goonclient.client.GoonChat;
import dev.goonclient.client.gui.Ui;
import dev.goonclient.client.hud.HudModule;
import dev.goonclient.client.hud.HudPosition;
import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.setting.BooleanSetting;
import dev.goonclient.client.module.setting.ButtonSetting;
import dev.goonclient.client.module.setting.NumberSetting;
import dev.goonclient.client.tracker.LootTracker;
import dev.goonclient.client.tracker.SessionStats;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/** Loot & farm tracker: what you've collected since the last reset, with rates per hour. */
public class LootTrackerHud extends HudModule {
	private static final int ROW = 17;
	private static final int PAD = 5;

	private final NumberSetting rows = add(new NumberSetting("rows", "Items shown", 6, 1, 12, 1));
	private final BooleanSetting valuableOnly = add(new BooleanSetting("valuable_only", "Valuable items only", false));
	private final BooleanSetting heldOnly=add(new BooleanSetting("held_item_only","Focus held item only",false));
    private List<LootTracker.Row> prepared=List.of();
    private String elapsed="",footer="",emptyLabel="Nothing picked up yet";
    private int preparedWidth=110,preparedHeight=30;
	private final BooleanSetting xpRate = add(new BooleanSetting("xp_rate", "XP per hour", true));
	private final BooleanSetting killRate = add(new BooleanSetting("kill_rate", "Kills per hour", true));

	public LootTrackerHud() {
		super("loot_tracker", "Loot Tracker", "Items collected since you reset it, with drops, XP and kills per hour", Category.INVENTORY, false, HudPosition.leftColumn(98));
		add(new ButtonSetting("report","Farm session report","Open",()->dev.goonclient.client.GoonClient.openNextTick(new dev.goonclient.client.gui.FarmReportScreen(Minecraft.getInstance().gui.screen()))));
        add(new ButtonSetting("reset", "Start counting again", "Reset", () -> {
			LootTracker.reset();
			GoonChat.info("Loot tracker reset");
		}));
	}

	@Override protected void measure(Minecraft mc, boolean editing) {

		Font font = mc.font;
		List<LootTracker.Row> list=new ArrayList<>(LootTracker.rows(valuableOnly.isOn()));
        if(heldOnly.isOn()&&mc.player!=null) {
            ItemStack held=mc.player.getMainHandItem();
            if(held.isEmpty()){list.clear();emptyLabel="Hold an item to focus";}
            else{list.removeIf(row->row.icon().getItem()!=held.getItem());emptyLabel="No "+Ui.ellipsize(mc.font,held.getHoverName().getString(),80,false)+" picked up";}
        } else emptyLabel="Nothing picked up yet";
		boolean sample = list.isEmpty() && editing;
		if (sample) {
			list.add(new LootTracker.Row(new ItemStack(Items.ROTTEN_FLESH), 64, 512));
			list.add(new LootTracker.Row(new ItemStack(Items.BONE), 37, 296));
			list.add(new LootTracker.Row(new ItemStack(Items.ARROW), 22, 176));
		}
		if (list.size() > rows.intValue()) {
			list = list.subList(0, rows.intValue());
		}

		String title = "Loot";
		String time = SessionStats.formatDuration(sample ? 450_000 : LootTracker.elapsedMs());
		List<String> footer = new ArrayList<>();
		if (xpRate.isOn()) {
			footer.add(compact(sample ? 3400 : LootTracker.perHour(LootTracker.xpGained())) + " XP/h");
		}
		if (killRate.isOn()) {
			footer.add(compact(sample ? 120 : LootTracker.perHour(LootTracker.kills())) + " kills/h");
		}
		String footerText = String.join("   ", footer);

		// Columns: icon | name | count | rate
		int nameWidth = 0;
		int countWidth = 0;
		int rateWidth = 0;
		for (LootTracker.Row row : list) {
			nameWidth = Math.max(nameWidth, Math.min(96, Ui.width(font, row.icon().getHoverName().getString())));
			countWidth = Math.max(countWidth, Ui.boldWidth(font, compact(row.count())));
			rateWidth = Math.max(rateWidth, Ui.width(font, compact(row.perHour()) + "/h"));
		}
		int width = Math.max(PAD * 2 + 18 + nameWidth + 8 + countWidth + 6 + rateWidth,
			Math.max(Ui.boldWidth(font, title) + Ui.width(font, time) + PAD * 2 + 12, Ui.width(font, footerText) + PAD * 2));
		width = Math.max(width, 110);
		boolean empty = list.isEmpty();
        if(empty)width=Math.max(width,Ui.width(font,emptyLabel)+PAD*2);
		int height = PAD + 11 + (empty ? 12 : list.size() * ROW) + (footer.isEmpty() ? 0 : 12) + PAD - 1;

		prepared=List.copyOf(list);elapsed=time;this.footer=footerText;preparedWidth=width;preparedHeight=height;
        setSize(width, height);
	}

	@Override
	protected void render(GuiGraphicsExtractor g, Minecraft mc, boolean editing) {
        Font font=mc.font;List<LootTracker.Row> list=prepared;String title="Loot",time=elapsed,footerText=footer;
        int width=preparedWidth,height=preparedHeight;boolean empty=list.isEmpty();

		Ui.roundRect(g, 0, 0, width, height, 4, Ui.HUD_BACKGROUND);
		Ui.bold(g, font, title, PAD, PAD, Ui.TEXT, true);
		Ui.text(g, font, time, width - PAD - Ui.width(font, time), PAD, Ui.FAINT, true);
		int y = PAD + 11;
		if (empty) {
			Ui.text(g, font, emptyLabel, PAD, y + 1, Ui.MUTED, true);
			y += 12;
		}
		for (LootTracker.Row row : list) {
			g.item(row.icon(), PAD - 1, y);
			Ui.text(g, font, Ui.ellipsize(font, row.icon().getHoverName().getString(), 96, false), PAD + 18, y + 4, Ui.TEXT, true);
			String rate = compact(row.perHour()) + "/h";
			int rateX = width - PAD - Ui.width(font, rate);
			Ui.text(g, font, rate, rateX, y + 4, Ui.MUTED, true);
			String count = compact(row.count());
			Ui.bold(g, font, count, rateX - 6 - Ui.boldWidth(font, count), y + 4, Ui.TEXT, true);
			y += ROW;
		}
		if (!footerText.isEmpty()) {
			Ui.text(g, font, footerText, PAD, y + 1, Ui.MUTED, true);
		}
		setSize(width, height);
	}

	/** 1234 -> "1.2k", 1234567 -> "1.2M". */
	static String compact(long value) {
		if (value >= 1_000_000) {
			return String.format("%.1fM", value / 1_000_000.0);
		}
		if (value >= 10_000) {
			return String.format("%.0fk", value / 1000.0);
		}
		if (value >= 1000) {
			return String.format("%.1fk", value / 1000.0);
		}
		return Long.toString(value);
	}
}
