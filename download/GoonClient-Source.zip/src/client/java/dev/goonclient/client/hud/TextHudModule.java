/*
 * This file incorporates code from the Combatant Client distribution.
 * Copyright (c) 2026 pivosos2007.
 * Licensed under the GNU General Public License v3.0.
 * Modified for Goon Client, 2026-10-04: compact-stat layout from Fps/Memory/SpeedBps/Coordinates and
 * compact_stat.js; list-panel layout from ScriptedListHudPanel variants, panel_base.js and list_panel.js.
 * Drawn on Minecraft 26.3 with Goon's renderer and fed by Goon's own data providers.
 */
package dev.goonclient.client.hud;

import dev.goonclient.client.gui.Ui;
import dev.goonclient.client.gui.render.GoonFont;
import dev.goonclient.client.gui.render.Icons;
import dev.goonclient.client.hud.HudRenderUtil.Font;
import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.setting.BooleanSetting;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.ItemStack;

/**
 * Text HUD elements in Combatant's two shapes. A single line is a compact stat: picture icon | value + unit
 * ("76 FPS"). Several lines (or any element with a counter) are a list panel: glyph | bold title ... "Active: N",
 * then rows of icon | name ... value. Both draw in Combatant's units with the pose scaled to them.
 */
public abstract class TextHudModule extends HudModule {
	/** ScriptedListHudPanel.Variant plus the owning element's scale/alpha defaults. */
	public record Variant(String glyph, Font glyphFont, float glyphScale, float minWidth, float countLabelOffset, float countValueOffset,
						  float rowIconSize, float rowDividerH, float rowRightPad, float rowCenterOffset,
						  float scale, int bgAlpha, float blurAlpha, boolean split, boolean mutedRowDivider) {
		private static float themeBlur(int alpha) {
			return Math.min(1f, alpha / 255f * 1.15f);
		}

		public static final Variant POTIONS = new Variant(String.valueOf((char) 0x42), Font.ICONS_NUR, 1f, 95, 22, 3, 8, 7, 8, 2.1f,
			1.05f, 200, themeBlur(159), false, true);
		public static final Variant COOLDOWNS = new Variant("C", Font.ICONS_NUR, 1f, 110, 22, 2.5f, 8, 6, 8, 1.9f,
			1.0f, 185, themeBlur(255), true, true);
		public static final Variant KEYBINDS = new Variant("M", Font.ICONS, 1.18f, 102, 22, 3, 8, 6, 8, 1.95f,
			1.0f, 225, themeBlur(140), false, false);
	}

	protected final BooleanSetting background = add(new BooleanSetting("background", "Background", true));
	protected final BooleanSetting shadow = add(new BooleanSetting("shadow", "Text shadow", true));
	private final List<Line> lines = new ArrayList<>();

	protected TextHudModule(String id, String name, String description, Category category, boolean enabledByDefault, HudPosition defaultPosition) {
		super(id, name, description, category, enabledByDefault, defaultPosition);
	}

	/** Adds this frame's lines. When editing, add sample lines if there is nothing real to show. */
	protected abstract void collect(Minecraft mc, List<Line> lines, boolean editing);

	/** The vector icon for rows without their own; null for a compact stat without an icon. */
	protected Icons.Icon icon() {
		return Icons.Icon.DOTS;
	}

	/** The compact stat's picture icon (Combatant's textures/hud/elements/NAME.png), or null to use {@link #icon()}. */
	protected String picture() {
		return switch (id()) {
			case "fps" -> "fps";
			case "memory" -> "memory";
			case "speed" -> "speedometer";
			case "coordinates" -> "coords";
			case "ping" -> "ping";
			default -> null;
		};
	}

	/** Compact-stat icon size in Combatant units: 12.5 for FPS, 11 for the others. */
	protected float pictureSize() {
		return "fps".equals(id()) ? 12.5f : 11f;
	}

	/** Draw the single line as the small round time chip from the reference (the clock), not a compact stat. */
	protected boolean chip() {
		return false;
	}

	/** Single-line stats: value before label, like "76 FPS" or "4.3 b/s". */
	protected boolean valueFirst() {
		return false;
	}

	/** Right side of a panel header: "Active" shows as "Active: 3". Null hides it. */
	protected String countLabel() {
		return null;
	}

	/** The number shown after {@link #countLabel()}; the row count unless overridden. */
	protected int count(List<Line> lines) {
		return lines.size();
	}

	/** The panel title; the module name unless overridden. */
	protected String title() {
		return name();
	}

	/** The panel's Combatant variant (glyph, widths, scale, alpha). */
	protected Variant variant() {
		return Variant.POTIONS;
	}

	@Override
	protected final void render(GuiGraphicsExtractor g, Minecraft mc, boolean editing) {
		lines.clear();
		collect(mc, lines, editing);
		if (lines.isEmpty()) {
			setSize(1, 1);
			return;
		}
		if (lines.size() == 1 && countLabel() == null && chip()) {
			chip(g, lines.getFirst());
		} else if (lines.size() == 1 && countLabel() == null) {
			compact(g, lines.getFirst());
		} else if (background.isOn()) {
			panel(g);
		} else {
			plain(g);
		}
	}

	// ---- Time chip ---------------------------------------------------------------------------------------

	// Measured on the reference screenshot in compact-stat units: 10.6 tall, ~8.9 side padding, 5.36-unit Inter Bold
	private static final float CHIP_H = 10.6f, CHIP_PAD = 8.9f, CHIP_EM = 5.36f;

	private void chip(GuiGraphicsExtractor g, Line line) {
		String text = line.label().isEmpty() ? line.value() : line.label() + " " + line.value();
		float size = CHIP_EM * Font.INTER_BOLD.lineHeight;
		float width = CHIP_PAD * 2 + HudRenderUtil.width(text, size, Font.INTER_BOLD);
		float k = HudRenderUtil.compactUnit();
		setSize(Math.max(1, Math.round(width * k)), Math.max(1, Math.round(CHIP_H * k)));
		g.pose().pushMatrix();
		g.pose().scale(k, k);
		if (background.isOn()) {
			HudRenderUtil.glassFill(g, 0, 0, width, CHIP_H, CHIP_H / 2, CHIP_H / 2, HudRenderUtil.GLASS_BG, HudRenderUtil.GLASS_BG,
				dev.goonclient.client.gui.render.BackdropBlur.available(), 1f);
		}
		// Cap height centred half a unit above the middle
		float top = CHIP_H / 2 - .5f + (.367f - Font.INTER_BOLD.ascender) * CHIP_EM;
		int color = line.color() == Ui.TEXT ? HudRenderUtil.TEXT_PRIMARY : line.color();
		HudRenderUtil.text(g, text, CHIP_PAD, top, size, Font.INTER_BOLD, color);
		g.pose().popMatrix();
	}

	// ---- Compact stat ------------------------------------------------------------------------------------

	private void compact(GuiGraphicsExtractor g, Line line) {
		List<Segment> parts = line.segments() != null ? line.segments() : segments(line);
		boolean hasIcon = picture() != null || icon() != null;
		float start = hasIcon ? HudRenderUtil.TEXT_LEFT_X : HudRenderUtil.RIGHT_PAD;
		float width = start;
		for (Segment part : parts) width += part.layoutGap() + HudRenderUtil.width(part.text(), HudRenderUtil.COMPACT_TEXT, font(part));
		width += HudRenderUtil.RIGHT_PAD;
		float k = HudRenderUtil.compactUnit();
		setSize(Math.max(1, Math.round(width * k)), Math.max(1, Math.round(HudRenderUtil.BOX_HEIGHT * k)));

		var palette = HudRenderUtil.CompactPalette.current();
		g.pose().pushMatrix();
		g.pose().scale(k, k);
		HudRenderUtil.compactShell(g, width, palette, background.isOn());
		if (hasIcon) {
			float size = pictureSize();
			float iy = (HudRenderUtil.BOX_HEIGHT - size) * .5f;
			if (picture() == null || !Icons.drawPicture(g, picture(), HudRenderUtil.ICON_X, iy, size, palette.icon()))
				Icons.draw(g, icon(), HudRenderUtil.ICON_X, iy, size, palette.icon());
			float dividerH = Math.max(.5f, HudRenderUtil.BOX_HEIGHT - 2 * HudRenderUtil.DIVIDER_Y);
			HudRenderUtil.bar(g, HudRenderUtil.DIVIDER_X, HudRenderUtil.DIVIDER_Y, HudRenderUtil.DIVIDER_WIDTH, dividerH, palette.divider());
		}
		float x = start, top = (HudRenderUtil.BOX_HEIGHT - HudRenderUtil.COMPACT_TEXT) * .5f;
		boolean textShadow = !background.isOn() && shadow.isOn();
		for (Segment part : parts) {
			x += part.gap();
			if (textShadow) HudRenderUtil.text(g, part.text(), x + .6f, top + .6f, HudRenderUtil.COMPACT_TEXT, font(part), 0x8C000000);
			HudRenderUtil.text(g, part.text(), x, top, HudRenderUtil.COMPACT_TEXT, font(part), part.color());
			x += HudRenderUtil.width(part.text(), HudRenderUtil.COMPACT_TEXT, font(part));
		}
		g.pose().popMatrix();
	}

	private static Font font(Segment part) {
		return part.weight() == GoonFont.Weight.MEDIUM || part.weight() == GoonFont.Weight.ONEST_MEDIUM ? Font.ONEST_MEDIUM : Font.ONEST;
	}

	/** A plain line as Combatant's value / unit pair ("76" + 2 + "FPS"). */
	private List<Segment> segments(Line line) {
		int value = line.color() == Ui.TEXT ? HudRenderUtil.TEXT_PRIMARY : line.color();
		List<Segment> parts = new ArrayList<>();
		if (line.label().isEmpty()) {
			parts.add(new Segment(line.value(), value, GoonFont.Weight.ONEST, 0, 0));
		} else if (valueFirst()) {
			parts.add(new Segment(line.value(), value, GoonFont.Weight.ONEST, 0, 0));
			parts.add(Segment.unit(line.label()).gap(HudRenderUtil.VALUE_UNIT_GAP));
		} else {
			parts.add(Segment.unit(line.label()));
			parts.add(new Segment(line.value(), value, GoonFont.Weight.ONEST, HudRenderUtil.VALUE_UNIT_GAP, HudRenderUtil.VALUE_UNIT_GAP));
		}
		return parts;
	}

	// ---- List panel ----------------------------------------------------------------------------------------

	private void panel(GuiGraphicsExtractor g) {
		Variant v = variant();
		float size = HudRenderUtil.panelFontSize(v.scale());
		String info = countLabel() == null ? null : countLabel() + ":";
		String countText = Integer.toString(count(lines));
		String title = title();
		float width = Math.max(v.minWidth(), HudRenderUtil.headerWidth(size, title, info, countText, v.countLabelOffset()));
		for (Line line : lines) {
			float label = HudRenderUtil.width(line.label(), size, Font.ONEST_MEDIUM);
			float right = HudRenderUtil.width(line.value(), size, Font.ONEST_MEDIUM);
			// ScriptedListHudPanel.rowRequiredWidth
			width = Math.max(width, HudRenderUtil.ROW_TEXT_START_X + label + HudRenderUtil.ROW_TEXT_RIGHT_GAP + right + v.rowRightPad());
		}
		float height = HudRenderUtil.CONTENT_START_Y + lines.size() * HudRenderUtil.ROW_STEP;
		float k = HudRenderUtil.panelUnit(v.scale());
		setSize(Math.max(1, Math.round(width * k)), Math.max(1, Math.round(height * k)));

		var pal = HudRenderUtil.Palette.of(v.bgAlpha());
		g.pose().pushMatrix();
		g.pose().scale(k, k);
		HudRenderUtil.panelChrome(g, width, height, pal, v.split(), v.blurAlpha(), true);
		HudRenderUtil.panelHeader(g, width, size, pal, v.glyph(), v.glyphFont(), v.glyphScale(), title, info, countText, v.countValueOffset());
		int dividerColor = v.mutedRowDivider() ? HudRenderUtil.setAlpha(pal.muted(), 130) : pal.divider();
		float centerY = HudRenderUtil.BODY_Y_OFFSET + HudRenderUtil.BODY_INSET_Y + v.rowCenterOffset();
		for (Line line : lines) {
			float iconSize = v.rowIconSize();
			rowIcon(g, line, HudRenderUtil.ICON_CENTER_X - iconSize * .5f, centerY - iconSize * .5f, iconSize, pal.counter());
			HudRenderUtil.bar(g, HudRenderUtil.DIVIDER_CENTER_X - HudRenderUtil.DIVIDER_W * .5f, centerY - v.rowDividerH() * .5f,
				HudRenderUtil.DIVIDER_W, v.rowDividerH(), dividerColor);
			int nameColor = line.labelColor() == Ui.MUTED || line.labelColor() == Ui.TEXT ? pal.text() : line.labelColor();
			String name = line.label().isEmpty() ? line.value() : line.label();
			HudRenderUtil.text(g, name, HudRenderUtil.TITLE_X, centerY - size * .5f, size, Font.ONEST_MEDIUM, nameColor);
			if (!line.label().isEmpty()) {
				int valueColor = line.color() == Ui.TEXT || line.color() == Ui.MUTED ? pal.counter() : line.color();
				float rw = HudRenderUtil.width(line.value(), size, Font.ONEST_MEDIUM);
				HudRenderUtil.text(g, line.value(), width - v.rowRightPad() - rw, centerY - size * .5f, size, Font.ONEST_MEDIUM, valueColor);
			}
			centerY += HudRenderUtil.ROW_STEP;
		}
		g.pose().popMatrix();
	}

	/** A row's icon: an item, a GUI sprite (effects) or a vector icon; the module icon when the line has none. */
	private void rowIcon(GuiGraphicsExtractor g, Line line, float x, float y, float size, int tint) {
		Object icon = line.icon();
		if (icon instanceof ItemStack stack && !stack.isEmpty()) {
			g.pose().pushMatrix();
			g.pose().translate(x, y);
			g.pose().scale(size / 16f, size / 16f);
			g.item(stack, 0, 0);
			g.pose().popMatrix();
		} else if (icon instanceof Identifier sprite) {
			g.pose().pushMatrix();
			g.pose().translate(x, y);
			g.pose().scale(size / 18f, size / 18f);
			g.blitSprite(RenderPipelines.GUI_TEXTURED, sprite, 0, 0, 18, 18);
			g.pose().popMatrix();
		} else {
			Icons.Icon vector = icon instanceof Icons.Icon v ? v : icon();
			if (vector != null) Icons.draw(g, vector, x, y, size, tint);
		}
	}

	/** No background: a plain label / value table with text shadows. */
	private void plain(GuiGraphicsExtractor g) {
		final float em = 4.7f, step = 6.5f;
		float labelColumn = 0;
		for (Line line : lines) {
			if (!line.label().isEmpty()) labelColumn = Math.max(labelColumn, GoonFont.width(line.label(), em, GoonFont.Weight.ONEST_MEDIUM));
		}
		float valueX = labelColumn > 0 ? labelColumn + 4 : 0, width = 0, y = 1;
		for (Line line : lines) {
			if (line.label().isEmpty()) {
				GoonFont.draw(g, line.value(), 1, y, em, GoonFont.Weight.ONEST, line.color(), shadow.isOn());
				width = Math.max(width, GoonFont.width(line.value(), em, GoonFont.Weight.ONEST));
			} else {
				GoonFont.draw(g, line.label(), 1, y, em, GoonFont.Weight.ONEST_MEDIUM, line.labelColor(), shadow.isOn());
				GoonFont.draw(g, line.value(), 1 + valueX, y, em, GoonFont.Weight.ONEST, line.color(), shadow.isOn());
				width = Math.max(width, valueX + GoonFont.width(line.value(), em, GoonFont.Weight.ONEST));
			}
			y += step;
		}
		setSize(Math.round(width + 2), Math.round(y));
	}

	/**
	 * A run of text in a compact stat. {@code gap} is the space drawn before it and {@code layoutGap} the space its
	 * width reserves (Combatant's Coordinates measures with wider gaps than it draws), both in Combatant units.
	 */
	public record Segment(String text, int color, GoonFont.Weight weight, float gap, float layoutGap) {
		/** Theme muted text: Combatant's units and labels. */
		public static final int GREY = HudRenderUtil.TEXT_MUTED;
		/** Memory/Coordinates "extra" text: muted mixed 18% towards primary. */
		public static final int EXTRA = HudRenderUtil.mixColor(HudRenderUtil.TEXT_MUTED, HudRenderUtil.TEXT_PRIMARY, .18f);

		public Segment(String text, int color, GoonFont.Weight weight) {
			this(text, color, weight, 0, 0);
		}

		/** A unit or axis label (Onest Medium, muted). */
		public static Segment unit(String text) {
			return new Segment(text, GREY, GoonFont.Weight.ONEST_MEDIUM);
		}

		public static Segment label(String text) {
			return unit(text);
		}

		/** A value (Onest, primary text). */
		public static Segment value(String text) {
			return new Segment(text, HudRenderUtil.TEXT_PRIMARY, GoonFont.Weight.ONEST);
		}

		/** Bracketed extra info such as "[16%]" (Onest Medium). */
		public static Segment extra(String text) {
			return new Segment(text, EXTRA, GoonFont.Weight.ONEST_MEDIUM);
		}

		public Segment gap(float units) {
			return new Segment(text, color, weight, units, units);
		}

		public Segment gap(float drawn, float reserved) {
			return new Segment(text, color, weight, drawn, reserved);
		}

		public Segment color(int color) {
			return new Segment(text, color, weight, gap, layoutGap);
		}
	}

	/**
	 * One row. {@code color} is the value's colour; labels use the theme text colour unless {@code labelColor} says
	 * otherwise. {@code icon} (optional) is an {@link ItemStack}, a sprite {@link Identifier} or an {@link Icons.Icon}.
	 */
	public record Line(String label, String value, int color, int labelColor, List<Segment> segments, Object icon) {
		public Line(String label, String value, int color, int labelColor) {
			this(label, value, color, labelColor, null, null);
		}

		public Line(String label, String value, int color) {
			this(label, value, color, Ui.MUTED);
		}

		public Line(String label, String value) {
			this(label, value, Ui.TEXT, Ui.MUTED);
		}

		public Line withIcon(Object icon) {
			return new Line(label, value, color, labelColor, segments, icon);
		}

		/** A single compact-stat line built from segments. */
		public static Line rich(List<Segment> segments) {
			StringBuilder text = new StringBuilder();
			segments.forEach(s -> text.append(s.text()));
			return new Line("", text.toString(), Ui.TEXT, Ui.MUTED, List.copyOf(segments), null);
		}
	}
}
