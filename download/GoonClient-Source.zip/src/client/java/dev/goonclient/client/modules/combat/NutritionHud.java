package dev.goonclient.client.modules.combat;

import dev.goonclient.client.gui.Ui;
import dev.goonclient.client.hud.HudModule;
import dev.goonclient.client.hud.HudPosition;
import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.setting.BooleanSetting;
import java.util.Locale;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/** The local player's food values. Multiplayer servers may not synchronize saturation precisely. */
public final class NutritionHud extends HudModule {
	private final BooleanSetting bars=add(new BooleanSetting("bars", "Food and saturation bars", true));
	public NutritionHud() {
		super("nutrition", "Food & Saturation", "Food and estimated saturation from your local player data", Category.COMBAT, false, HudPosition.rightOfHotbar(10, 55));
	}
	@Override protected void measurePreview(Minecraft mc) { measure(mc, true); }
	@Override protected void renderPreview(GuiGraphicsExtractor g, Minecraft mc) { render(g, mc, true); }
	@Override protected void measure(Minecraft mc, boolean editing) { setSize(120,bars.isOn()?46:32); }
	@Override protected void render(GuiGraphicsExtractor g, Minecraft mc, boolean editing) {
		measure(mc,editing);
		int food=mc.player==null?18:mc.player.getFoodData().getFoodLevel();
		float saturation=mc.player==null?8.5f:mc.player.getFoodData().getSaturationLevel();
		Ui.roundRect(g,0,0,120,bars.isOn()?46:32,4,Ui.HUD_BACKGROUND);
		row(g,mc,"Food", food+" / 20",4,food/20f,food<=6?Ui.BAD:Ui.TEXT);
		row(g,mc,"Saturation ~",String.format(Locale.ROOT,"%.1f",saturation),bars.isOn()?24:18,saturation/20f,Ui.accent());
	}
	private void row(GuiGraphicsExtractor g,Minecraft mc,String label,String value,int y,float fraction,int color) {
		Ui.text(g,mc.font,label,5,y,Ui.MUTED,true);
		Ui.text(g,mc.font,value,115-Ui.width(mc.font,value),y,color,true);
		if(bars.isOn()) {
			Ui.roundRect(g,5,y+12,115,y+15,1.5f,Ui.CONTROL);
			float fill=110*Math.max(0,Math.min(1,fraction));
			if(fill>0) Ui.roundRect(g,5,y+12,5+fill,y+15,Math.min(1.5f,fill/2),color);
		}
	}
}
