package dev.goonclient.client.dev;

import dev.goonclient.client.config.ConfigManager;
import dev.goonclient.client.gui.ClickGuiScreen;
import dev.goonclient.client.gui.HudEditorScreen;
import dev.goonclient.client.gui.ProfileScreen;
import dev.goonclient.client.module.ModuleManager;
import java.lang.reflect.Field;
import java.util.Set;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;

/** Optional visual capture only: no worlds, assertions, synthetic gameplay or external accounts. */
public final class DevUiPreview {
	private static com.google.gson.JsonObject original;
	private static int ticks,scale;
    private static String originalCape;
    private static final java.util.Map<String,Boolean> originalFavorites = new java.util.HashMap<>();
    private static final Set<String> FEATURES = Set.of("block_info", "block_focus", "breadcrumbs", "projectile_guide", "hitboxes", "player_tags", "camera_comfort", "view_model", "weather_changer");
	private static volatile boolean pending;
	private static net.minecraft.client.gui.screens.Screen title;
	private static final Set<String> NEW_HUDS=Set.of("notifications","active_modules","tool_info","inventory_hud");
	private DevUiPreview(){}
	public static void init(){
		if(!Boolean.getBoolean("goonclient.devUiPreview"))return;
		ClientTickEvents.END_CLIENT_TICK.register(DevUiPreview::tick);
		ClientLifecycleEvents.CLIENT_STOPPING.register(mc->restore(mc));
	}
	private static void restore(Minecraft mc){
        for(var module:ModuleManager.all())if(originalFavorites.containsKey(module.id()))module.loadFavorite(originalFavorites.get(module.id()));
        originalFavorites.clear();if(originalCape!=null){dev.goonclient.client.cosmetics.Cosmetics.equip(originalCape);originalCape=null;}if(original!=null){ConfigManager.apply(original,true,false);ConfigManager.save();original=null;mc.options.guiScale().set(scale);mc.resizeGui();}}
	private static void tick(Minecraft mc){
		if(!mc.isGameLoadFinished()||pending)return;
		mc.getFramerateLimitTracker().onInputReceived();ticks++;
		if(Boolean.getBoolean("goonclient.wardrobePreview")){wardrobe(mc);return;}
        if(Boolean.getBoolean("goonclient.featurePreview")){features(mc);return;}
        if(Boolean.getBoolean("goonclient.studioPreview")){studio(mc);return;}
        if(Boolean.getBoolean("goonclient.glassPreview")){glass(mc);return;}
        switch(ticks){
			case 30 -> {
				original=ConfigManager.capture();scale=mc.options.guiScale().get();title=mc.gui.screen();
				for(var module:ModuleManager.all())if(NEW_HUDS.contains(module.id()))module.loadFavorite(true);
				mc.options.guiScale().set(2);mc.resizeGui();mc.gui.setScreen(new ProfileScreen(title));
			}
			case 60 -> shot(mc,"profiles");
			case 65 -> mc.gui.setScreen(modules("FAVORITES"));
			case 95 -> shot(mc,"favorites");
			case 100 -> mc.gui.setScreen(modules("ENABLED"));
			case 130 -> shot(mc,"enabled");
			case 135 -> {var menu=modules("ALL");menu.openSettingsFor(ModuleManager.all().stream().filter(m->m.id().equals("inventory_hud")).findFirst().orElseThrow());mc.gui.setScreen(menu);}
			case 165 -> shot(mc,"inventory-settings");
			case 170 -> {
				for(var module:ModuleManager.hudModules())module.loadEnabled(NEW_HUDS.contains(module.id())||module.id().equals("minimap")||module.id().equals("coordinates"));
				mc.gui.setScreen(new HudEditorScreen(title));
			}
			case 200 -> shot(mc,"new-huds");
			case 205 -> {mc.options.guiScale().set(3);mc.resizeGui();mc.gui.setScreen(new ProfileScreen(title));}
			case 235 -> shot(mc,"profiles-scale3");
			case 240 -> mc.gui.setScreen(modules("FAVORITES"));
			case 270 -> shot(mc,"favorites-scale3");
			case 275 -> {restore(mc);mc.stop();}
		}
	}
	private static void wardrobe(Minecraft mc) {
        switch(ticks) {
            case 30 -> {original=ConfigManager.capture();scale=mc.options.guiScale().get();title=mc.gui.screen();originalCape=dev.goonclient.client.cosmetics.Cosmetics.selected();mc.options.guiScale().set(2);mc.resizeGui();dev.goonclient.client.cosmetics.Cosmetics.equip("nation_noir");mc.gui.setScreen(new dev.goonclient.client.gui.CosmeticsScreen(title));}
            case 60 -> shot(mc,"wardrobe-mint");
            case 65 -> {dev.goonclient.client.cosmetics.Cosmetics.equip("ember");mc.gui.setScreen(new dev.goonclient.client.gui.CosmeticsScreen(title));}
            case 95 -> shot(mc,"wardrobe-ember");
            case 100 -> {mc.options.guiScale().set(3);mc.resizeGui();dev.goonclient.client.cosmetics.Cosmetics.equip("ghost");mc.gui.setScreen(new dev.goonclient.client.gui.CosmeticsScreen(title));}
            case 130 -> shot(mc,"wardrobe-scale3");
            case 135 -> {var menu=modules("ALL");menu.openSettingsFor(ModuleManager.all().stream().filter(m->m.id().equals("schematics")).findFirst().orElseThrow());mc.gui.setScreen(menu);}
            case 165 -> shot(mc,"schematics");
            case 170 -> mc.gui.setScreen(new dev.goonclient.client.gui.DiscordStatusScreen(title));
            case 200 -> shot(mc,"discord");
            case 205 -> {restore(mc);mc.stop();}
        }
    }
    private static void studio(Minecraft mc) {
        switch(ticks) {
            case 30 -> {original=ConfigManager.capture();scale=mc.options.guiScale().get();title=mc.gui.screen();mc.options.guiScale().set(2);mc.resizeGui();mc.gui.setScreen(modules("ALL"));}
            case 65 -> shot(mc,"columns");
            case 70 -> mc.gui.setScreen(new dev.goonclient.client.gui.StudioScreen(title,dev.goonclient.client.gui.StudioScreen.Page.HUD));
            case 100 -> shot(mc,"hud-browser");
            case 105 -> mc.gui.setScreen(new dev.goonclient.client.gui.AppearanceScreen(title));
            case 135 -> shot(mc,"themes");
            case 140 -> mc.gui.setScreen(new dev.goonclient.client.gui.StudioScreen(title,dev.goonclient.client.gui.StudioScreen.Page.INTERFACE));
            case 170 -> shot(mc,"interface");
            case 175 -> mc.gui.setScreen(new ProfileScreen(title));
            case 205 -> shot(mc,"profiles");
            case 210 -> {
                for(var module:ModuleManager.hudModules())module.loadEnabled(Set.of("coordinates","potions","fps","inventory_hud","active_modules","minimap").contains(module.id()));
                var editor=new HudEditorScreen(title);editor.inspect(ModuleManager.hudModules().stream().filter(m->m.id().equals("coordinates")).findFirst().orElseThrow());mc.gui.setScreen(editor);
            }
            case 240 -> shot(mc,"hud-inspector");
            case 245 -> {mc.options.guiScale().set(3);mc.resizeGui();mc.gui.setScreen(new dev.goonclient.client.gui.StudioScreen(title,dev.goonclient.client.gui.StudioScreen.Page.HUD));}
            case 275 -> shot(mc,"hud-browser-scale3");
            case 280 -> mc.gui.setScreen(new dev.goonclient.client.gui.AppearanceScreen(title));
            case 310 -> shot(mc,"themes-scale3");
            case 315 -> {
                var editor=new HudEditorScreen(title);editor.inspect(ModuleManager.hudModules().stream().filter(m->m.id().equals("coordinates")).findFirst().orElseThrow());mc.gui.setScreen(editor);
            }
            case 345 -> shot(mc,"hud-inspector-scale3");
            case 350 -> {restore(mc);mc.stop();}
        }
    }
    private static void glass(Minecraft mc) {
        switch(ticks) {
            case 30 -> {original=ConfigManager.capture();scale=mc.options.guiScale().get();title=mc.gui.screen();mc.options.guiScale().set(2);mc.resizeGui();mc.gui.setScreen(modules("ALL"));}
            case 65 -> shot(mc,"columns");
            case 70 -> settings(mc,"projectile_guide");
            case 105 -> shot(mc,"settings");
            case 110 -> mc.gui.setScreen(new dev.goonclient.client.gui.AppearanceScreen(title));
            case 145 -> shot(mc,"appearance");
            case 150 -> {mc.options.guiScale().set(3);mc.resizeGui();mc.gui.setScreen(modules("ALL"));}
            case 185 -> shot(mc,"columns-scale3");
            case 190 -> settings(mc,"interface");
            case 225 -> shot(mc,"settings-scale3");
            case 230 -> mc.gui.setScreen(new dev.goonclient.client.gui.AppearanceScreen(title));
            case 265 -> shot(mc,"appearance-scale3");
            case 270 -> {restore(mc);mc.stop();}
        }
    }
    private static void features(Minecraft mc) {
        switch(ticks) {
            case 30 -> {
                original=ConfigManager.capture();scale=mc.options.guiScale().get();title=mc.gui.screen();
                for(var module:ModuleManager.all()){originalFavorites.put(module.id(),module.isFavorite());module.loadFavorite(FEATURES.contains(module.id()));}
                mc.options.guiScale().set(2);mc.resizeGui();mc.gui.setScreen(modules("FAVORITES"));
            }
            case 65 -> shot(mc,"features");
            case 70 -> settings(mc,"projectile_guide");
            case 105 -> shot(mc,"projectile-settings");
            case 110 -> settings(mc,"view_model");
            case 145 -> shot(mc,"view-model");
            case 150 -> {
                for(var module:ModuleManager.hudModules())module.loadEnabled(Set.of("block_info","coordinates","minimap").contains(module.id()));
                mc.gui.setScreen(new HudEditorScreen(title));
            }
            case 185 -> shot(mc,"block-hud");
            case 190 -> {mc.options.guiScale().set(3);mc.resizeGui();mc.gui.setScreen(modules("FAVORITES"));}
            case 225 -> shot(mc,"features-scale3");
            case 230 -> settings(mc,"camera_comfort");
            case 265 -> shot(mc,"camera-scale3");
            case 270 -> {restore(mc);mc.stop();}
        }
    }
    private static void settings(Minecraft mc,String id){var screen=modules("ALL");screen.openSettingsFor(ModuleManager.all().stream().filter(m->m.id().equals(id)).findFirst().orElseThrow());mc.gui.setScreen(screen);}
    @SuppressWarnings({"unchecked","rawtypes"})
	private static ClickGuiScreen modules(String filter){
		var screen=new ClickGuiScreen(title);
		try{Field category=ClickGuiScreen.class.getDeclaredField("selected");category.setAccessible(true);category.set(null,null);
			Field f=ClickGuiScreen.class.getDeclaredField("filter");f.setAccessible(true);f.set(null,Enum.valueOf((Class)f.getType(),filter));}
		catch(ReflectiveOperationException e){throw new IllegalStateException(e);}return screen;
	}
	private static void shot(Minecraft mc,String name){
		pending=true;String filename=(Boolean.getBoolean("goonclient.studioPreview")?"goon-0120-":Boolean.getBoolean("goonclient.glassPreview")?"goon-0110-":Boolean.getBoolean("goonclient.featurePreview")?"goon-0100-":Boolean.getBoolean("goonclient.wardrobePreview")?"goon-090-":"goon-080-")+name+".png";
		Screenshot.grab(mc.gameDirectory,filename,mc.gameRenderer.mainRenderTarget(),1,message->{pending=false;});
	}
}
