package dev.goonclient.client.waypoint;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import dev.goonclient.Goon;
import dev.goonclient.client.config.ConfigManager;
import java.io.IOException;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.server.IntegratedServer;

/** Waypoints, stored per world (singleplayer) or per server address (multiplayer). */
public final class WaypointManager {
	private static final int[] PALETTE = {0xFF3DDC97, 0xFF4DA3FF, 0xFF9D8CFF, 0xFFF5B83D, 0xFFFF6B9A, 0xFFFF8A3D, 0xFFE6E7EA};
	public static final int DEATH_COLOR = 0xFFF0616D;

	private static final List<Waypoint> WAYPOINTS = new ArrayList<>();
	private static String worldKey;
	private static String worldName = "";

	private WaypointManager() {
	}

	public static void onJoin(Minecraft mc) {
		worldKey = computeWorldKey(mc);
		worldName = computeWorldName(mc);
		WAYPOINTS.clear();
		Path file = file();
		if (file == null || !Files.exists(file)) {
			return;
		}
		try (Reader reader = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
			for (JsonElement element : JsonParser.parseReader(reader).getAsJsonArray()) {
				WAYPOINTS.add(Waypoint.fromJson(element.getAsJsonObject()));
			}
		} catch (IOException | RuntimeException e) {
			Goon.LOGGER.error("Couldn't read waypoints from {}", file, e);
		}
	}

	public static void onLeave() {
		worldKey = null;
		WAYPOINTS.clear();
	}

	/** File-safe id of the current world or server, or null when not in one. */
	public static String worldKey() {
		return worldKey;
	}

	/** The world's or server's display name. */
	public static String worldName() {
		return worldName;
	}

	public static List<Waypoint> all() {
		return Collections.unmodifiableList(WAYPOINTS);
	}

	public static List<Waypoint> inDimension(String dimension) {
		List<Waypoint> result = new ArrayList<>();
		for (Waypoint waypoint : WAYPOINTS) {
			if (waypoint.dimension().equals(dimension)) {
				result.add(waypoint);
			}
		}
		return result;
	}

	public static Optional<Waypoint> byName(String name) {
		return WAYPOINTS.stream().filter(w -> w.name().equalsIgnoreCase(name)).findFirst();
	}

	public static void add(Waypoint waypoint) {
		WAYPOINTS.removeIf(w -> w.name().equalsIgnoreCase(waypoint.name()));
		WAYPOINTS.add(waypoint);
		save();
	}

	public static boolean remove(String name) {
		boolean removed = WAYPOINTS.removeIf(w -> w.name().equalsIgnoreCase(name));
		if (removed) {
			save();
		}
		return removed;
	}

	public static int clearDeaths() {
		int before = WAYPOINTS.size();
		WAYPOINTS.removeIf(Waypoint::death);
		save();
		return before - WAYPOINTS.size();
	}

	public static int nextColor() {
		return PALETTE[WAYPOINTS.size() % PALETTE.length];
	}

	public static int deathCount() {
		return (int) WAYPOINTS.stream().filter(Waypoint::death).count();
	}

	private static void save() {
		Path file = file();
		if (file == null) {
			return;
		}
		JsonArray array = new JsonArray();
		for (Waypoint waypoint : WAYPOINTS) {
			array.add(waypoint.toJson());
		}
		ConfigManager.writeAtomically(file, ConfigManager.GSON.toJson(array));
	}

	private static Path file() {
		return worldKey == null ? null : ConfigManager.dir().resolve("waypoints").resolve(worldKey + ".json");
	}

	private static String computeWorldName(Minecraft mc) {
		IntegratedServer server = mc.getSingleplayerServer();
		if (server != null) {
			return server.getWorldData().getLevelName();
		}
		ServerData data = mc.getCurrentServer();
		return data == null ? "Unknown server" : data.name == null || data.name.isBlank() ? data.ip : data.name;
	}

	private static String computeWorldKey(Minecraft mc) {
		IntegratedServer server = mc.getSingleplayerServer();
		String key;
		if (server != null) {
			key = "sp_" + server.getWorldData().getLevelName();
		} else {
			ServerData data = mc.getCurrentServer();
			key = "mp_" + (data != null ? data.ip : "unknown");
		}
		return key.replaceAll("[^A-Za-z0-9._-]", "_");
	}
}
