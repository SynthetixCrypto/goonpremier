package dev.goonclient.client.gui.render;

import com.mojang.blaze3d.platform.NativeImage;
import dev.goonclient.Goon;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.nio.file.Path;
import javax.imageio.ImageIO;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.resources.Identifier;

/** Bounded image decoding off-thread, then a smooth GPU texture owned by the gallery screen. */
public final class ScreenshotImage implements AutoCloseable {
	private static int serial;
	private final Identifier id;
	private final SmoothTexture texture;
	private final int width, height;

	public ScreenshotImage(BufferedImage image) {
		width = image.getWidth();
		height = image.getHeight();
		NativeImage pixels = new NativeImage(width, height, false);
		for (int y = 0; y < height; y++) {
			for (int x = 0; x < width; x++) pixels.setPixel(x, y, image.getRGB(x, y) | 0xFF000000);
		}
		id = Goon.id("dynamic/screenshot_" + serial++);
		texture = new SmoothTexture(id.toString(), pixels);
		Minecraft.getInstance().getTextureManager().register(id, texture);
	}

	/** Subsample while reading, so even a very large screenshot doesn't allocate its full resolution. */
	public static BufferedImage decode(Path file) throws IOException {
		try (var input = ImageIO.createImageInputStream(file.toFile())) {
			if (input == null) throw new IOException("Cannot read image");
			var readers = ImageIO.getImageReaders(input);
			if (!readers.hasNext()) throw new IOException("Unsupported image");
			var reader = readers.next();
			try {
				reader.setInput(input);
				int w = reader.getWidth(0), h = reader.getHeight(0);
				if (w < 1 || h < 1 || w > 32768 || h > 32768) throw new IOException("Image dimensions too large");
				var params = reader.getDefaultReadParam();
				int sample = Math.max(1, (Math.max(w, h) + 1279) / 1280);
				params.setSourceSubsampling(sample, sample, 0, 0);
				return reader.read(0, params);
			} finally {
				reader.dispose();
			}
		}
	}

	public void draw(GuiGraphicsExtractor g, float x, float y, float w, float h) {
		float scale = Math.min(w / width, h / height);
		float dw = width * scale, dh = height * scale;
		int[] rect = Px.rect(g, x + (w - dw) / 2, y + (h - dh) / 2, x + (w + dw) / 2, y + (h + dh) / 2);
		QuadBatch batch = new QuadBatch(1);
		batch.add(rect[0], rect[1], rect[2], rect[3], 0, 0, 1, 1);
		Px.begin(g);
		batch.submit(g, texture, 0xFFFFFFFF);
		Px.end(g);
	}

	@Override
	public void close() {
		Minecraft.getInstance().getTextureManager().release(id);
	}
}
