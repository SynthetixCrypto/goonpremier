package dev.goonclient.client.dev;

import com.mojang.blaze3d.platform.InputConstants;
import dev.goonclient.Goon;
import dev.goonclient.client.expedition.*;
import dev.goonclient.client.gui.ExpeditionScreen;
import dev.goonclient.client.waypoint.*;
import java.lang.reflect.*;
import java.nio.file.*;
import java.util.*;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.*;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.*;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.item.*;
import net.minecraft.world.item.component.ItemContainerContents;

/** Explicit development-only tour. Run only in a copied game directory after coordinating with other agents. */
public final class DevExpeditionChecks {
    private static int step;
    private static ExpeditionStore store;
    private static Screen parent;
    private static int originalScale;
    private static ExpeditionPlan savedPlan;
    private static boolean hudHidden;
    private static long nextStep;
    private static boolean failed;
    private DevExpeditionChecks() {}
    public static void init() {
        if (Boolean.getBoolean("goonclient.expeditionChecks") && FabricLoader.getInstance().isDevelopmentEnvironment())
            ClientTickEvents.END_CLIENT_TICK.register(DevExpeditionChecks::tick);
    }
    private static void require(boolean value,String message) { if(!value)throw new IllegalStateException(message); }
    private static Object value(Object object,String field) throws Exception {
        Field f=object.getClass().getDeclaredField(field);f.setAccessible(true);return f.get(object);
    }
    private static Object component(Object record,String key) throws Exception {
        Method method=record.getClass().getDeclaredMethod(key);method.setAccessible(true);return method.invoke(record);
    }
    private static void set(Object object,String field,Object value) throws Exception {
        Field f=object.getClass().getDeclaredField(field);f.setAccessible(true);f.set(object,value);
    }
    private static Object invoke(Object object,String name,Class<?>[] types,Object... args) throws Exception {
        Method method=object.getClass().getDeclaredMethod(name,types);method.setAccessible(true);return method.invoke(object,args);
    }
    private static Object invoke(Object object,String name) throws Exception { return invoke(object,name,new Class<?>[0]); }
    /** Exercises the production transition methods directly, independent of frame timing and hit geometry. */
    private static void reviewRegressions(Path folder) throws Exception {
        var fixture=new ExpeditionStore(folder.resolve("review-regressions.json"));
        var a=ExpeditionPlan.starter(ExpeditionPlan.Template.EXPLORATION);
        var b=ExpeditionPlan.starter(ExpeditionPlan.Template.NETHER);
        require(fixture.save(a)&&fixture.save(b),"Review fixtures did not save");
        var screen=new ExpeditionScreen(null,fixture,false);
        set(screen,"name","Edited A");invoke(screen,"adjust",new Class<?>[]{int.class,int.class},0,1);
        ExpeditionPlan changed=(ExpeditionPlan)value(screen,"draft");
        invoke(screen,"selectPlan",new Class<?>[]{String.class},a.id());
        require(value(screen,"pending")==null&&value(screen,"draft").equals(changed),"Reselecting dirty A queued an obsolete snapshot");
        invoke(screen,"save");
        ExpeditionPlan updated=fixture.plans().stream().filter(p->p.id().equals(a.id())).findFirst().orElseThrow();
        require(updated.name().equals("Edited A")&&updated.supplies().getFirst().target()==a.supplies().getFirst().target()+1
                &&value(screen,"draft").equals(updated)&&!(boolean)invoke(screen,"dirty"),"Save after reselecting A restored obsolete data");
        require(new ExpeditionStore(folder.resolve("review-regressions.json")).plans().contains(updated),"Edited A missing on disk");
        // Resolve a queued selection against the store at execution time, even if that plan was replaced.
        set(screen,"name","Edited A again");invoke(screen,"selectPlan",new Class<?>[]{String.class},b.id());
        require(value(screen,"pending")!=null,"Dirty switch did not defer navigation");
        invoke(screen,"selectPlan",new Class<?>[]{String.class},a.id());
        require(value(screen,"pending")==null&&value(screen,"name").equals("Edited A again"),"Returning to dirty A retained a pending switch");
        invoke(screen,"selectPlan",new Class<?>[]{String.class},b.id());
        var newerB=new ExpeditionPlan(b.id(),"Updated B",b.supplies(),b.tasks(),null);
        require(fixture.save(newerB),"Replace queued B failed");invoke(screen,"save");
        require(value(screen,"draft").equals(newerB),"Deferred selection used stale B");
        invoke(screen,"selectPlan",new Class<?>[]{String.class},a.id());invoke(screen,"deleteSelected");
        require(value(screen,"armed").equals("delete:"+a.id()),"Delete confirmation is not bound to A");
        invoke(screen,"selectPlan",new Class<?>[]{String.class},b.id());
        require(value(screen,"armed").equals(""),"Switching plans retained A's confirmation");
        invoke(screen,"deleteSelected");
        require(fixture.plans().size()==2&&value(screen,"armed").equals("delete:"+b.id()),"First Delete B reused A's confirmation");
        invoke(screen,"deleteSelected");
        require(fixture.plans().size()==1&&fixture.plans().getFirst().id().equals(a.id()),"Confirmed Delete B affected wrong plan");
        invoke(screen,"deleteSelected");invoke(screen,"newPlan",new Class<?>[]{ExpeditionPlan.Template.class},ExpeditionPlan.Template.BOSS);
        require(value(screen,"armed").equals(""),"New plan retained delete confirmation");
        // Clearing saved plans must preserve every part of an unsaved trip and its input field.
        set(screen,"name","Unsaved boss trip");set(screen,"entry","Unsubmitted manual note");
        invoke(screen,"adjust",new Class<?>[]{int.class,int.class},0,7);invoke(screen,"toggleTask",new Class<?>[]{int.class},0);
        var draft=(ExpeditionPlan)value(screen,"draft");
        invoke(screen,"clearSavedPlans");require(fixture.plans().size()==1,"Clear skipped confirmation");
        invoke(screen,"clearSavedPlans");
        require(fixture.plans().isEmpty()&&value(screen,"draft").equals(draft)&&value(screen,"name").equals("Unsaved boss trip")
                &&value(screen,"entry").equals("Unsubmitted manual note")&&value(screen,"saved")==null
                &&(boolean)invoke(screen,"dirty"),"Clear all discarded unsaved work or retained a stale saved baseline");
        invoke(screen,"save");
        require(fixture.plans().getFirst().name().equals("Unsaved boss trip")&&fixture.plans().getFirst().supplies().equals(draft.supplies())
                &&fixture.plans().getFirst().tasks().equals(draft.tasks()),"Preserved draft could not be saved after Clear");
        // Also preserve edits to the currently saved plan, not only a newly created draft.
        set(screen,"name","Saved draft edited");invoke(screen,"adjust",new Class<?>[]{int.class,int.class},0,1);
        draft=(ExpeditionPlan)value(screen,"draft");invoke(screen,"clearSavedPlans");invoke(screen,"clearSavedPlans");
        require(value(screen,"draft").equals(draft)&&value(screen,"name").equals("Saved draft edited")
                &&value(screen,"saved")==null&&(boolean)invoke(screen,"dirty"),"Clear discarded edits to an existing saved plan");
        Goon.LOGGER.info("EXPEDITION REVIEW CHECKS PASSED: dirty same-plan selection; deferred ID resolution; plan-bound delete confirmation; load/new reset; saved-only clear preserves new/existing drafts");
    }
    private static void click(Minecraft mc,String key) throws Exception {
        ExpeditionScreen screen=(ExpeditionScreen)mc.gui.screen();
        List<?> hits=(List<?>)value(screen,"hits");
        Object hit=hits.stream().filter(h -> {try{return component(h,"key").equals(key);}catch(Exception e){throw new RuntimeException(e);}}).findFirst().orElseThrow(() -> new IllegalStateException("Missing action "+key));
        float scale=(float)value(screen,"scale");
        double x=((float)component(hit,"x1")+(float)component(hit,"x2"))/2*scale;
        double y=((float)component(hit,"y1")+(float)component(hit,"y2"))/2*scale;
        screen.mouseClicked(new MouseButtonEvent(x,y,new MouseButtonInfo(InputConstants.MOUSE_BUTTON_LEFT,0)),false);
    }
    private static void type(Minecraft mc,String text) { text.codePoints().forEach(c -> mc.gui.screen().charTyped(new CharacterEvent(c))); }
    private static void shot(Minecraft mc,String name) {
        Screenshot.grab(mc.gameDirectory,"goon-expedition-"+name+".png",mc.gameRenderer.mainRenderTarget(),1,message -> {});
    }
    private static void inventory(Minecraft mc) {
        var player=mc.player;var inv=player.getInventory();var oldMenu=player.containerMenu;
        var equipment=new EnumMap<EquipmentSlot,ItemStack>(EquipmentSlot.class);
        EquipmentSlot[] slots={EquipmentSlot.OFFHAND,EquipmentSlot.HEAD,EquipmentSlot.CHEST,EquipmentSlot.LEGS,EquipmentSlot.FEET};
        var main=inv.getNonEquipmentItems().stream().map(ItemStack::copy).toList();
        for(var slot:slots)equipment.put(slot,player.getItemBySlot(slot).copy());
        int selected=inv.getSelectedSlot();
        try {
            for(int i=0;i<main.size();i++)inv.setItem(i,ItemStack.EMPTY);
            for(var slot:slots)player.setItemSlot(slot,ItemStack.EMPTY);
            inv.setSelectedSlot(0);inv.setItem(0,new ItemStack(Items.TORCH,12));inv.setItem(9,new ItemStack(Items.TORCH,20));
            player.setItemSlot(EquipmentSlot.OFFHAND,new ItemStack(Items.TORCH,3));
            player.setItemSlot(EquipmentSlot.FEET,new ItemStack(Items.GOLDEN_BOOTS));
            ItemStack bag=new ItemStack(Items.SHULKER_BOX);
            bag.set(DataComponents.CONTAINER,ItemContainerContents.fromItems(List.of(new ItemStack(Items.TORCH,64))));inv.setItem(10,bag);
            var chest=new SimpleContainer(27);chest.setItem(0,new ItemStack(Items.TORCH,64));
            player.containerMenu=ChestMenu.threeRows(717,inv,chest);player.containerMenu.setCarried(new ItemStack(Items.TORCH,64));
            var snapshot=ExpeditionInventory.capture(mc);
            require(snapshot.available()&&snapshot.count("minecraft:torch")==35,"Inventory counted selected hand twice, chest, cursor or nested contents");
            require(snapshot.count("minecraft:golden_boots")==1&&snapshot.count("minecraft:shulker_box")==1,"Equipment/bag item absent");
            inv.setItem(9,ItemStack.EMPTY);require(ExpeditionInventory.capture(mc).count("minecraft:torch")==15,"Inventory did not refresh");
            Goon.LOGGER.info("EXPEDITION CHECK: actual hotbar/main/offhand/armor; selected-hand, chest, cursor and nested exclusion passed");
        } finally {
            player.containerMenu=oldMenu;
            for(int i=0;i<main.size();i++)inv.setItem(i,main.get(i));
            for(var slot:slots)player.setItemSlot(slot,equipment.get(slot));inv.setSelectedSlot(selected);
        }
    }
    private static void tick(Minecraft mc) {
        if(failed||!mc.isGameLoadFinished())return;
        if(step==0&&(mc.player==null||mc.level==null))return;
        // Loading can execute many catch-up ticks before the first screen extraction. Wait for actual controls.
        if(System.nanoTime()<nextStep)return;
        if(mc.gui.screen() instanceof ExpeditionScreen screen) {
            try { if(((List<?>)value(screen,"hits")).isEmpty())return; }
            catch(Exception e){throw new IllegalStateException(e);}
        }
        nextStep=System.nanoTime()+100_000_000L;
        step++;mc.getFramerateLimitTracker().onInputReceived();
        try {
            if(step==1) {
                require(mc.getSingleplayerServer()!=null,"Use a disposable integrated world");
                originalScale=mc.options.guiScale().get();parent=mc.gui.screen();hudHidden=mc.gui.hud.isHidden();inventory(mc);
                Path folder=Files.createTempDirectory(mc.gameDirectory.toPath(),"expedition-check-");
                reviewRegressions(folder);
                store=new ExpeditionStore(folder.resolve("expedition-plans.json"));
                mc.options.guiScale().set(2);mc.resizeGui();mc.gui.setScreen(new ExpeditionScreen(parent,store,false));
            }
            if(step==10) { require(mc.gui.hud.isHidden(),"Planner did not hide HUD");require(!mc.gui.screen().mouseScrolled(0,0,0,-1),"Outside scroll accepted");click(mc,"name");mc.gui.screen().keyPressed(new KeyEvent(InputConstants.KEY_BACKSPACE,0,128));type(mc,"Regression trip"); }
            if(step==14)click(mc,"save");
            if(step==18) { require(store.plans().size()==1&&store.plans().getFirst().name().equals("Regression trip"),"Mouse/name/save failed");click(mc,"entry");type(mc,"torch 80");mc.gui.screen().keyPressed(new KeyEvent(InputConstants.KEY_RETURN,0,0)); }
            if(step==22) {click(mc,"mode");}
            if(step==26) {click(mc,"entry");type(mc,"Check return route");mc.gui.screen().keyPressed(new KeyEvent(InputConstants.KEY_RETURN,0,0));}
            if(step==30) {require(((ExpeditionPlan)value(mc.gui.screen(),"draft")).tasks().getLast().label().equals("Check return route"),"Manual task add failed");click(mc,"task-2");}
            if(step==34) {click(mc,"save");require(store.plans().getFirst().tasks().getLast().done(),"Manual tick did not save");
                WaypointManager.add(new Waypoint("Expedition_check",11,64,22,"minecraft:overworld",WaypointManager.nextColor(),false,System.currentTimeMillis()));click(mc,"destination");}
            if(step==35)set(mc.gui.screen(),"scroll",Float.MAX_VALUE);
            if(step==38) {int index=0;for(var p:WaypointManager.all()){if(p.name().equals("Expedition_check"))break;index++;}click(mc,"waypoint-"+index);}
            if(step==42) {click(mc,"save");savedPlan=store.plans().getFirst();require(savedPlan.destination()!=null&&savedPlan.destination().x()==11,"Waypoint selection did not persist");
                require(new ExpeditionStore(storePath(mc)).plans().equals(store.plans()),"Disk reload mismatch");}
            if(step==46)shot(mc,"world-scale2");
            if(step==50) {mc.options.guiScale().set(4);mc.resizeGui();}
            if(step==58)shot(mc,"world-scale4");
            if(step==62) {mc.gui.screen().keyPressed(new KeyEvent(InputConstants.KEY_ESCAPE,0,0));require(mc.gui.screen()==parent&&mc.gui.hud.isHidden()==hudHidden,"Esc/parent/HUD restore failed");
                WaypointManager.remove("Expedition_check");mc.disconnectFromWorld(net.minecraft.client.multiplayer.ClientLevel.DEFAULT_QUIT_MESSAGE);}
            if(step==80) {require(mc.player==null&&mc.level==null,"No-world phase missing");require(!ExpeditionInventory.capture(mc).available()&&ExpeditionInventory.capture(mc).counts().isEmpty(),"No-world stale inventory");parent=mc.gui.screen();mc.options.guiScale().set(2);mc.resizeGui();mc.gui.setScreen(new ExpeditionScreen(parent,store,false));}
            if(step==90) {shot(mc,"no-world-scale2");click(mc,"destination");}
            if(step==94) {require((boolean)value(mc.gui.screen(),"picking"),"No-world waypoint preview failed");mc.gui.screen().keyPressed(new KeyEvent(InputConstants.KEY_ESCAPE,0,0));require(!(boolean)value(mc.gui.screen(),"picking"),"Picker Esc failed");click(mc,"name");type(mc," edited");}
            if(step==98) {mc.gui.screen().keyPressed(new KeyEvent(InputConstants.KEY_ESCAPE,0,0));mc.gui.screen().keyPressed(new KeyEvent(InputConstants.KEY_ESCAPE,0,0));require(mc.gui.screen() instanceof ExpeditionScreen,"Dirty Esc lost draft");click(mc,"discard");require(mc.gui.screen()==parent,"Discard did not complete pending close");mc.gui.setScreen(new ExpeditionScreen(parent,store,true));}
            if(step==102) {mc.options.guiScale().set(4);mc.resizeGui();}
            if(step==110)shot(mc,"no-world-scale4-clear");
            if(step==114) {click(mc,"clear");require(store.plans().isEmpty(),"Confirmed clear failed");require(new ExpeditionStore(storePath(mc)).plans().isEmpty(),"Clear not on disk");}
            if(step==118) {click(mc,"discard");}
            if(step==122) {click(mc,"save");}
            if(step==124)mc.gui.setScreen(new ExpeditionScreen(parent,store,false));
            if(step==126) {mc.gui.screen().keyPressed(new KeyEvent(InputConstants.KEY_TAB,0,0));mc.gui.screen().keyPressed(new KeyEvent(InputConstants.KEY_RETURN,0,0));require(mc.gui.screen()==parent,"Tab/Enter Done failed");
                mc.options.guiScale().set(originalScale);mc.resizeGui();Goon.LOGGER.info("EXPEDITION CHECKS PASSED: persistence; live inventory isolation; mouse/keyboard editing; waypoint selection; dirty-draft guard; clear; no-world; scale2/4; parent and HUD restore");mc.stop();}
        } catch(Exception e) { failed=true;Goon.LOGGER.error("EXPEDITION CHECKS FAILED at step "+step,e);mc.stop(); }
    }
    private static Path storePath(Minecraft mc) throws Exception { Field field=ExpeditionStore.class.getDeclaredField("file");field.setAccessible(true);return (Path)field.get(store); }
}
