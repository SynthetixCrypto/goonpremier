package dev.goonclient.client.gui;

import com.mojang.blaze3d.platform.InputConstants;
import dev.goonclient.client.config.ConfigManager;
import dev.goonclient.client.gui.render.GoonFont;
import dev.goonclient.client.gui.render.Icons;
import dev.goonclient.client.gui.render.Shapes;
import dev.goonclient.client.hud.HudModule;
import dev.goonclient.client.module.Module;
import dev.goonclient.client.module.ModuleManager;
import dev.goonclient.client.module.setting.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

/**
 * The Settings side of the menu: a dark window with an icon rail, a titled header with search, and a page of cards
 * (HUD elements, interface options, themes, client tools). Laid out on the shared {@link GlassUi} canvas.
 */
public class StudioScreen extends Screen implements GoonScreen {
    public enum Page { HUD, INTERFACE, THEMES, MAIN, CONFIGS }

    // Window geometry in canvas units (the reference window is ~46% of the screen, slightly below centre)
    private static final float WIN_W = 309, WIN_H = 175.5f, RAIL = 30, HEADER = 20;
    private static final float CARD_GAP = 4.2f;

    private final Screen parent;
    private final Module appearance;
    private final List<Hit> hits = new ArrayList<>();
    private Page page;
    private String search = "";
    private boolean searchFocus;
    private float s, vw, vh, x, y, left, right, top, bottom, scroll, extent;
    private NumberSetting dragging;
    private float dragLeft, dragWidth;
    private int group;

    public StudioScreen(Screen parent, Page page) {
        super(Component.literal("Goon settings"));
        this.parent = parent;
        this.page = page;
        appearance = ModuleManager.all().stream().filter(m -> m.id().equals("interface")).findFirst().orElseThrow();
    }

    @Override
    protected void init() {
        hits.clear();
        dragging = null;
        s = GlassUi.canvasScale(width, height);
        GlassUi.hideHud(minecraft);
        vw = width / s;
        vh = height / s;
        x = (vw - WIN_W) / 2;
        y = Math.max(22, (vh - WIN_H) / 2 + 6);
        left = x + RAIL + 6;
        right = x + WIN_W - 12;
        top = y + HEADER + 3.5f;
        bottom = y + WIN_H - 6;
        scroll = 0;
    }

    @Override
    public void extractBackground(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
        if (minecraft.level == null) {
            super.extractBackground(g, mouseX, mouseY, partialTick);
            return;
        }
        extractBlurredBackground(g);
        g.fill(0, 0, width, height, 0x1E000000);
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int realX, int realY, float partialTick) {
        int mx = (int) (realX / s), my = (int) (realY / s);
        hits.clear();
        g.pose().pushMatrix();
        g.pose().scale(s, s);

        // Top switch: Modules on the left, Settings (this screen) lit
        int navHover = GlassUi.navigationHit(vw, mx, my);
        GlassUi.navigation(g, vw, 1, Ui.animate("studio:nav0", navHover == 0 ? 1 : 0, .6f), Ui.animate("studio:nav1", navHover == 1 ? 1 : 0, .6f), 1);
        float nx = vw / 2 - GlassUi.NAV_W / 2;
        hit(nx, GlassUi.NAV_Y, nx + GlassUi.NAV_W / 2, GlassUi.NAV_Y + GlassUi.NAV_H,
            () -> minecraft.gui.setScreen(parent instanceof ClickGuiScreen ? parent : new ClickGuiScreen(parent)));

        GlassUi.window(g, x, y, WIN_W, WIN_H, 1);
        // Rail: the darker wash down the left (rounded on the window's side only)
        Shapes.gradientRect(g, x + .5f, y + .5f, x + RAIL, y + WIN_H - .5f, 6.5f, 0, 0, 6.5f, GlassUi.RAIL_WASH_TOP, GlassUi.RAIL_WASH_BOTTOM);
        rail(g, mx, my);

        // Header band with the page icon, title and search
        Shapes.rect(g, x + RAIL, y + .5f, x + WIN_W - 7, y + HEADER, 0x0FFFFFFF);
        Icons.draw(g, pageIcon(page), left, y + 6.5f, 6.6f, 0xFFEDEAF2);
        GlassUi.text(g, title(), left + 10, y + 6.6f, 7, 0xFFF2F0F5, false);
        float sw = 56, sx = x + WIN_W - 6.5f - sw, sy = y + 5.3f;
        GlassUi.searchBox(g, sx, sy, sw, 10.2f, search, searchFocus, 1);
        hit(sx, sy, sx + sw, sy + 10.2f, () -> searchFocus = true);
        if (page == Page.HUD) {
            // Where the panels sit on screen: the HUD layout editor
            float ew = 62, ex = sx - ew - 5;
            boolean over = Ui.inside(mx, my, ex, sy, ex + ew, sy + 10.2f);
            float lit = Ui.animate("studio:editlayout", over ? 1 : 0, .6f);
            int accent = Ui.accent() | 0xFF000000;
            Shapes.panel(g, ex, sy, ex + ew, sy + 10.2f, 3, Ui.lerp(lit * .35f, (0xA8 << 24) | (accent & 0xFFFFFF), (0xE0 << 24) | (Ui.lerp(.3f, accent, 0xFFFFFFFF) & 0xFFFFFF)),
                Ui.withAlpha(Ui.lerp(.4f, accent, 0xFFFFFFFF), .75f));
            Icons.draw(g, Icons.Icon.LAYOUT, ex + 4, sy + 1.9f, 6.4f, 0xFFFFFFFF);
            GoonFont.draw(g, "Edit layout", ex + 12.5f, sy + 2.4f, 5.4f, GoonFont.Weight.BOLD, 0xFFFFFFFF, false);
            hit(ex, sy, ex + ew, sy + 10.2f, () -> minecraft.gui.setScreen(new HudEditorScreen(this)));
        }
        Shapes.rect(g, x + RAIL, y + HEADER, x + WIN_W - .5f, y + HEADER + .35f, 0x24FFFFFF);

        extent = contentHeight();
        scroll = Math.max(0, Math.min(scroll, Math.max(0, extent - (bottom - top))));
        g.enableScissor((int) Math.ceil(left - 1), (int) Math.ceil(top), (int) Math.floor(right + 1), (int) Math.floor(bottom));
        switch (page) {
            case HUD -> hud(g, mx, my);
            case THEMES -> themes(g, mx, my);
            case INTERFACE, MAIN -> settings(g, mx, my);
            case CONFIGS -> configs(g, mx, my);
        }
        g.disableScissor();
        float max = Math.max(0, extent - (bottom - top));
        if (max > 0) {
            float thumb = Math.max(18, (bottom - top) * (bottom - top) / extent);
            float ty = top + (bottom - top - thumb) * scroll / max;
            float bx = x + WIN_W - 5.5f;
            Shapes.roundRect(g, bx, top, bx + 1.3f, bottom, .65f, 0x30000000);
            Shapes.roundRect(g, bx, ty, bx + 1.3f, ty + thumb, .65f, 0x55FFFFFF);
        }
        GlassUi.hints(g, hintLines(), vh, 1);
        g.pose().popMatrix();
        super.extractRenderState(g, realX, realY, partialTick);
    }

    private String title() {
        return switch (page) {
            case HUD -> "HUD";
            case INTERFACE -> "Interface";
            case THEMES -> "Themes";
            case MAIN -> "Main Settings";
            case CONFIGS -> "Configs";
        };
    }

    private static Icons.Icon pageIcon(Page page) {
        return switch (page) {
            case HUD -> Icons.Icon.MONITOR;
            case INTERFACE -> Icons.Icon.SLIDERS;
            case THEMES -> Icons.Icon.PALETTE;
            case MAIN -> Icons.Icon.LAYOUT;
            case CONFIGS -> Icons.Icon.FOLDER;
        };
    }

    private List<String> hintLines() {
        return switch (page) {
            case HUD -> List.of("LMB - toggle HUD element", "RMB - open element settings", "Edit layout - move widgets", "Esc - close", "Alt+H - hide hints");
            case THEMES -> List.of("LMB - select theme", "Wheel - scroll themes", "Esc - close", "Alt+H - hide hints");
            case CONFIGS -> List.of("LMB - load or save a setup", "Bin twice - remove a setup", "Undo load - restore previous", "Esc - close", "Alt+H - hide hints");
            default -> List.of("LMB - change setting", "Left list - switch setting group", "Wheel - scroll settings", "Esc - close", "Alt+H - hide hints");
        };
    }

    // ---- Rail --------------------------------------------------------------------------------------------

    private record RailItem(String label, Icons.Icon icon, Runnable action, boolean active) {
    }

    private void rail(GuiGraphicsExtractor g, int mx, int my) {
        List<RailItem> items = List.of(
            new RailItem("HUD", null, () -> show(Page.HUD), page == Page.HUD),
            new RailItem("UI", null, () -> show(Page.INTERFACE), page == Page.INTERFACE),
            new RailItem("", Icons.Icon.PALETTE, () -> show(Page.THEMES), page == Page.THEMES),
            new RailItem("", Icons.Icon.LAYOUT, () -> show(Page.MAIN), page == Page.MAIN),
            new RailItem("", Icons.Icon.USER, () -> minecraft.gui.setScreen(new CosmeticsScreen(this)), false),
            new RailItem("", Icons.Icon.FOLDER, () -> show(Page.CONFIGS), page == Page.CONFIGS));
        float cx = x + RAIL / 2;
        float[] rows = {35, 55.4f, 75.8f, 103.3f, 124, 151.5f};
        for (int i = 0; i < items.size(); i++) {
            RailItem item = items.get(i);
            float cy = y + rows[i];
            boolean hover = Ui.inside(mx, my, cx - 7, cy - 7, cx + 7, cy + 7);
            float h = Ui.animate("studio:rail:" + i, item.active ? 1 : hover ? .5f : 0, .6f);
            if (h > .01f) Shapes.roundRect(g, cx - 7, cy - 7, cx + 7, cy + 7, 3, Ui.withAlpha(0xFFFFFFFF, .09f * h));
            int color = item.active ? 0xFFFFFFFF : Ui.lerp(hover ? 1 : 0, 0xFFC9C5CF, 0xFFFFFFFF);
            if (item.icon == null) {
                float tw = GoonFont.width(item.label, 4.6f, GoonFont.Weight.MEDIUM);
                GoonFont.draw(g, item.label, cx - tw / 2, cy - 2.3f, 4.6f, GoonFont.Weight.MEDIUM, color, false);
            } else {
                Icons.draw(g, item.icon, cx - 3.6f, cy - 3.6f, 7.2f, color);
            }
            hit(cx - 7, cy - 7, cx + 7, cy + 7, item.action);
        }
        // Separators between the page groups, as in the reference rail
        Shapes.rect(g, cx - 7, y + 89.6f, cx + 7, y + 89.9f, 0x22FFFFFF);
        Shapes.rect(g, cx - 7, y + 137.8f, cx + 7, y + 138.1f, 0x22FFFFFF);
    }

    private void show(Page next) {
        page = next;
        profiles = null;
        configStatus = "";
        search = "";
        scroll = 0;
        group = 0;
        searchFocus = false;
        dragging = null;
        hits.clear();
    }

    // ---- Pages -------------------------------------------------------------------------------------------

    private List<HudModule> huds() {
        String q = search.toLowerCase(Locale.ROOT);
        return ModuleManager.hudModules().stream().filter(m -> (m.name() + " " + m.description()).toLowerCase(Locale.ROOT).contains(q)).toList();
    }

    private List<Themes.Theme> themeList() {
        return Themes.ALL.stream().filter(t -> matches(t.name())).toList();
    }

    private boolean matches(String value) {
        return value.toLowerCase(Locale.ROOT).contains(search.toLowerCase(Locale.ROOT));
    }

    private float cardWidth() {
        return (right - left - CARD_GAP) / 2;
    }

    private float contentHeight() {
        return switch (page) {
            case HUD -> (float) Math.ceil(huds().size() / 2d) * 42.6f;
            case THEMES -> (float) Math.ceil(themeList().size() / 2d) * 36.6f;
            case INTERFACE, MAIN -> Math.max(4 * 17f, settingList().size() * 21f + 22);
            case CONFIGS -> 17 + (float) Math.ceil(profileList().size() / 2d) * 44;
        };
    }

    /** HUD element cards: name, description, a divider and the on/off switch. */
    private void hud(GuiGraphicsExtractor g, int mx, int my) {
        List<HudModule> list = huds();
        float cw = cardWidth(), ch = 36;
        if (list.isEmpty()) GlassUi.text(g, "No HUD elements match your search.", left + 4, top + 8, 6, GlassUi.MUTED, false);
        for (int i = 0; i < list.size(); i++) {
            HudModule module = list.get(i);
            float cx = left + (i % 2) * (cw + CARD_GAP), cy = top + (i / 2) * 42.6f - scroll;
            if (cy + ch <= top || cy >= bottom) continue;
            boolean hover = Ui.inside(mx, my, cx, Math.max(top, cy), cx + cw, Math.min(bottom, cy + ch));
            darkCard(g, cx, cy, cw, ch, 22, false, Ui.animate("studio:hud:" + module.id(), hover ? 1 : 0, .65f));
            float on = Ui.animate("studio:toggle:" + module.id(), module.isEnabled() ? 1 : 0, .5f);
            GlassUi.text(g, Ui.ellipsize(module.name(), cw - 16, 7, GoonFont.Weight.REGULAR), cx + 10.5f, cy + 4.2f, 7, Ui.lerp(on, 0xFFB9B5C0, 0xFFFFFFFF), false);
            Icons.draw(g, Icons.Icon.INFO, cx + 4.5f, cy + 13.4f, 4.4f, 0xFFBDB9C4);
            GlassUi.text(g, Ui.ellipsize(module.description(), cw - 16, 5.4f, GoonFont.Weight.REGULAR), cx + 10.5f, cy + 13.2f, 5.4f, 0xFFBDB9C4, false);
            smallSwitch(g, cx + cw - 17, cy + 26.4f, on);
            clippedHit(cx, cy, cx + cw, cy + ch, () -> openSettings(module));
            clippedHit(cx + cw - 22, cy + 22, cx + cw, cy + ch, () -> { module.toggle(); ConfigManager.markDirty(); });
        }
    }

    /** Theme cards: name, divider and the twelve-colour swatch row. */
    private void themes(GuiGraphicsExtractor g, int mx, int my) {
        ModeSetting theme = (ModeSetting) find("theme");
        List<Themes.Theme> list = themeList();
        float cw = cardWidth(), ch = 32;
        for (int i = 0; i < list.size(); i++) {
            Themes.Theme entry = list.get(i);
            float cx = left + (i % 2) * (cw + CARD_GAP), cy = top + (i / 2) * 36.6f - scroll;
            if (cy + ch <= top || cy >= bottom) continue;
            boolean selected = theme.is(entry.name());
            boolean hover = Ui.inside(mx, my, cx, Math.max(top, cy), cx + cw, Math.min(bottom, cy + ch));
            darkCard(g, cx, cy, cw, ch, 11.3f, selected, Ui.animate("studio:theme:" + entry.name(), hover ? 1 : 0, .6f), entry.accent());
            GlassUi.text(g, entry.name(), cx + 4.2f, cy + 3, 6, 0xFFF4F2F7, false);
            int[] swatches = entry.swatches();
            float step = (cw - 8.4f - 6.3f) / 11f;
            for (int n = 0; n < swatches.length; n++) {
                float sx = cx + 4.2f + n * step;
                Shapes.roundRect(g, sx, cy + 18.3f, sx + 6.3f, cy + 24.6f, 1.1f, swatches[n]);
            }
            clippedHit(cx, cy, cx + cw, cy + ch, () -> { theme.set(entry.name()); changed(); });
        }
        if (list.isEmpty()) GlassUi.text(g, "No matching themes.", left + 4, top + 8, 6, GlassUi.MUTED, false);
    }

    private Setting<?> find(String id) {
        return appearance.settings().stream().filter(v -> v.id().equals(id)).findFirst().orElseThrow();
    }

    private String[] groups() {
        return page == Page.MAIN ? new String[]{"Tools", "Social", "Data"} : new String[]{"Visual", "Menus", "HUD"};
    }

    private static Icons.Icon groupIcon(String name) {
        return switch (name) {
            case "Visual" -> Icons.Icon.PEN;
            case "Menus" -> Icons.Icon.LAYOUT;
            case "HUD" -> Icons.Icon.MONITOR;
            case "Tools" -> Icons.Icon.COG;
            case "Social" -> Icons.Icon.USER;
            default -> Icons.Icon.CUBE;
        };
    }

    private List<Setting<?>> settingList() {
        List<String> ids = page == Page.MAIN
            ? switch (group) { case 0 -> List.of("performance_preset", "screenshots", "backgrounds_folder"); case 1 -> List.of("wardrobe"); default -> List.of("profiles"); }
            : switch (group) { case 0 -> List.of("menu_material", "menu_blur", "panel_opacity", "menu_background"); case 1 -> List.of("main_menu", "pause_menu", "hints"); default -> List.of("hud_arrangement", "hud_fit", "glass_hotbar", "glass_chat"); };
        return appearance.settings().stream().filter(v -> ids.contains(v.id()) && matches(v.name())).toList();
    }

    /** Group list on the left, the group's settings in a panel on the right (as in the reference Main Settings). */
    private void settings(GuiGraphicsExtractor g, int mx, int my) {
        String[] names = groups();
        float listW = 78.5f, ly = top + .5f;
        plane(g, left, ly, listW, bottom - ly + scroll, GlassUi.NAV_TOP, GlassUi.NAV_BOTTOM);
        for (int i = 0; i < names.length; i++) {
            int index = i;
            float ry = ly + 4 + i * 17;
            boolean active = group == i, hover = Ui.inside(mx, my, left + 4, ry, left + listW - 4, ry + 14);
            float h = Ui.animate("studio:group:" + page + i, active ? 1 : hover ? .5f : 0, .6f);
            if (h > .01f) Shapes.roundRect(g, left + 4, ry, left + listW - 4, ry + 14, 3, Ui.withAlpha(0xFFFFFFFF, .07f * h));
            if (i > 0) Shapes.rect(g, left + 8, ry - 1.5f, left + listW - 8, ry - 1.2f, 0x18FFFFFF);
            int color = active ? 0xFFFFFFFF : 0xFFA9A5B1;
            Icons.draw(g, groupIcon(names[i]), left + 8.5f, ry + 4, 5.8f, color);
            GlassUi.text(g, names[i], left + 19, ry + 4.5f, 4.6f, color, false);
            hit(left + 4, ry, left + listW - 4, ry + 14, () -> { group = index; scroll = 0; dragging = null; hits.clear(); });
        }
        float px = left + listW + 6, pw = right - px;
        plane(g, px, ly, pw, bottom - ly + scroll, GlassUi.CONTENT_TOP, GlassUi.CONTENT_BOTTOM);
        GlassUi.text(g, names[group], px + 5.5f, ly + 6, 5, 0xFFE6E3EB, false);
        Shapes.rect(g, px + 5, ly + 14.2f, px + pw - 5, ly + 14.5f, 0x1EFFFFFF);
        List<Setting<?>> list = settingList();
        if (list.isEmpty()) GlassUi.text(g, "No matching settings.", px + 6, ly + 21, 5.5f, GlassUi.MUTED, false);
        float cy = ly + 19 - scroll;
        for (Setting<?> setting : list) {
            float rx = px + 6, rw = pw - 12;
            if (setting instanceof BooleanSetting bool) {
                float on = Ui.animate("studio:setting:" + setting.id(), bool.isOn() ? 1 : 0, .5f);
                Shapes.panel(g, rx, cy, rx + rw, cy + 17, 2.5f, 0x40100E13, Ui.withAlpha(Ui.accent(), .35f + .25f * on));
                accentSwitch(g, rx + 4, cy + 4.6f, on);
                GlassUi.text(g, setting.name(), rx + 25, cy + 5.4f, 6.4f, 0xFFF2F0F5, false);
                clippedHit(rx, cy, rx + rw, cy + 17, () -> { bool.set(!bool.isOn()); changed(); });
                cy += 21;
            } else if (setting instanceof NumberSetting number) {
                GlassUi.text(g, setting.name(), rx + 1, cy + 1, 5.6f, 0xFFF2F0F5, false);
                String value = number.display();
                GlassUi.text(g, value, rx + rw - GoonFont.width(value, 5.6f, GoonFont.Weight.REGULAR), cy + 1, 5.6f, 0xFFF2F0F5, false);
                float sx = rx + 1, sw = rw - 2, sy = cy + 11;
                float f = (float) number.fraction();
                Shapes.roundRect(g, sx, sy, sx + sw, sy + .9f, .45f, 0x40FFFFFF);
                Shapes.roundRect(g, sx, sy, sx + sw * f, sy + .9f, .45f, Ui.accent());
                Shapes.roundRect(g, sx + sw * f - .5f, sy - 1.7f, sx + sw * f + .5f, sy + 2.6f, .4f, Ui.accent());
                final float dl = sx, dw = sw;
                clippedHit(sx - 2, cy + 6, sx + sw + 2, cy + 16, () -> { dragging = number; dragLeft = dl; dragWidth = dw; });
                cy += 21;
            } else if (setting instanceof ModeSetting mode) {
                GlassUi.text(g, setting.name(), rx + 1, cy + 1, 6.2f, 0xFFF2F0F5, false);
                float ox = rx + 1.5f;
                for (String option : mode.modes()) {
                    float ow = GoonFont.width(option, 6, GoonFont.Weight.REGULAR);
                    boolean selected = mode.is(option);
                    GlassUi.text(g, option, ox, cy + 10.3f, 6, selected ? Ui.accent() : 0xFFCFCBD5, false);
                    final String choice = option;
                    clippedHit(ox - 1, cy + 9, ox + ow + 1, cy + 18, () -> { mode.set(choice); changed(); });
                    ox += ow + 3.2f;
                }
                cy += 21;
            } else if (setting instanceof ButtonSetting action) {
                boolean hover = Ui.inside(mx, my, rx, Math.max(top, cy), rx + rw, Math.min(bottom, cy + 17));
                Shapes.panel(g, rx, cy, rx + rw, cy + 17, 2.5f, hover ? 0x5A2A2730 : 0x40100E13, 0x26FFFFFF);
                GlassUi.text(g, setting.name(), rx + 5, cy + 5.4f, 5.8f, 0xFFF2F0F5, false);
                String label = action.buttonLabel();
                float lw = GoonFont.width(label, 5.4f, GoonFont.Weight.MEDIUM);
                GoonFont.draw(g, label, rx + rw - lw - 6, cy + 5.8f, 5.4f, GoonFont.Weight.MEDIUM, Ui.accent(), false);
                clippedHit(rx, cy, rx + rw, cy + 17, action::press);
                cy += 21;
            }
        }
    }

    // ---- Configs ----------------------------------------------------------------------------------------

    private static final String[] CONFIG_TABS = {"All", "Saved", "Built in"};
    private static final java.time.format.DateTimeFormatter DATE = java.time.format.DateTimeFormatter.ofPattern("dd.MM.yyyy");
    private int configTab;
    private List<dev.goonclient.client.config.ProfileStore.Profile> profiles;
    private String configStatus = "";
    private String armedDelete = "";
    private long armedAt;

    private List<dev.goonclient.client.config.ProfileStore.Profile> profileList() {
        if (profiles == null) {
            try {
                profiles = dev.goonclient.client.config.ProfileStore.list();
            } catch (java.io.IOException e) {
                profiles = dev.goonclient.client.config.ProfileStore.presets();
                configStatus = "Couldn't read saved setups; built-in ones still work.";
            }
        }
        return profiles.stream()
            .filter(p -> configTab == 0 || (configTab == 1) != p.builtin())
            .filter(p -> matches(p.name()))
            .toList();
    }

    private String updated(dev.goonclient.client.config.ProfileStore.Profile profile) {
        if (profile.builtin()) return "Built in";
        try {
            var file = ConfigManager.dir().resolve("profiles").resolve(profile.id() + ".json");
            return java.time.LocalDate.ofInstant(java.nio.file.Files.getLastModifiedTime(file).toInstant(), java.time.ZoneId.systemDefault()).format(DATE);
        } catch (java.io.IOException | RuntimeException e) {
            return "-";
        }
    }

    private void configResult(dev.goonclient.client.config.ProfileStore.Result result, boolean reload) {
        configStatus = result.message();
        armedDelete = "";
        if (reload) profiles = null;
    }

    /** Tabs, a Save button and config cards (name, kind, enabled count, date, load / overwrite / delete). */
    private void configs(GuiGraphicsExtractor g, int mx, int my) {
        float ty = top + 1.5f + 0 * scroll, tw = 87, th = 10.5f;
        // The toolbar scrolls away with the cards
        ty -= scroll;
        Shapes.panel(g, left, ty, left + tw, ty + th, 2.5f, 0xE01D1A20, 0x22FFFFFF);
        float seg = (tw - 2) / CONFIG_TABS.length;
        for (int i = 0; i < CONFIG_TABS.length; i++) {
            int index = i;
            float sx = left + 1 + seg * i;
            boolean active = configTab == i;
            if (active) Shapes.roundRect(g, sx, ty + 1, sx + seg, ty + th - 1, 2, Ui.lerp(.45f, 0xFF2A2026, Ui.accent()));
            if (i > 0 && !active && configTab != i - 1) Shapes.rect(g, sx, ty + 2.5f, sx + .35f, ty + th - 2.5f, 0x22FFFFFF);
            float lw = GoonFont.width(CONFIG_TABS[i], 4.8f, GoonFont.Weight.REGULAR);
            GoonFont.draw(g, CONFIG_TABS[i], sx + (seg - lw) / 2, ty + 2.9f, 4.8f, GoonFont.Weight.REGULAR, active ? 0xFFFFFFFF : 0xFFA9A5B1, false);
            clippedHit(sx, ty, sx + seg, ty + th, () -> { configTab = index; scroll = 0; hits.clear(); });
        }
        float bx = left + tw + 5, bw = 46;
        boolean saveHover = Ui.inside(mx, my, bx, ty, bx + bw, ty + th);
        Shapes.panel(g, bx, ty, bx + bw, ty + th, 2.5f, saveHover ? 0xF02E2A33 : 0xE01D1A20, 0x22FFFFFF);
        Icons.draw(g, Icons.Icon.SAVE, bx + 4, ty + 2.6f, 5.3f, 0xFFE8E4EE);
        GoonFont.draw(g, "Save", bx + 12, ty + 2.9f, 4.8f, GoonFont.Weight.REGULAR, 0xFFF2F0F5, false);
        clippedHit(bx, ty, bx + bw, ty + th, () -> {
            // Saves the current modules and HUD as "Setup N"
            int n = 1;
            var saved = profileList().stream().map(dev.goonclient.client.config.ProfileStore.Profile::name).toList();
            while (saved.contains("Setup " + n)) n++;
            configResult(dev.goonclient.client.config.ProfileStore.create("Setup " + n), true);
        });
        if (dev.goonclient.client.config.ProfileStore.canUndo()) {
            float ux = bx + bw + 5, uw = 40;
            boolean undoHover = Ui.inside(mx, my, ux, ty, ux + uw, ty + th);
            Shapes.panel(g, ux, ty, ux + uw, ty + th, 2.5f, undoHover ? 0xF02E2A33 : 0xE01D1A20, Ui.withAlpha(Ui.accent(), .5f));
            GoonFont.draw(g, "Undo load", ux + 4, ty + 2.9f, 4.8f, GoonFont.Weight.REGULAR, Ui.accent(), false);
            clippedHit(ux, ty, ux + uw, ty + th, () -> configResult(dev.goonclient.client.config.ProfileStore.undo(), false));
        }

        if (!armedDelete.isEmpty() && System.currentTimeMillis() - armedAt > 5000) armedDelete = "";
        List<dev.goonclient.client.config.ProfileStore.Profile> list = profileList();
        float cw = cardWidth(), ch = 40, cardsTop = top + 17 - scroll;
        if (list.isEmpty()) GlassUi.text(g, "No setups here yet. Save your current setup to start.", left + 1, cardsTop + 4, 5.4f, GlassUi.MUTED, false);
        for (int i = 0; i < list.size(); i++) {
            var profile = list.get(i);
            float cx = left + (i % 2) * (cw + CARD_GAP), cy = cardsTop + (i / 2) * 44;
            if (cy + ch <= top || cy >= bottom) continue;
            darkCard(g, cx, cy, cw, ch, 16, false, 0);
            Icons.draw(g, Icons.Icon.FOLDER, cx + 4.5f, cy + 4.6f, 6.6f, 0xFFE8E4EE);
            GoonFont.draw(g, Ui.ellipsize(profile.name(), cw - 20, 5.4f, GoonFont.Weight.REGULAR), cx + 14, cy + 2.8f, 5.4f, GoonFont.Weight.REGULAR, 0xFFF4F2F7, false);
            GoonFont.draw(g, profile.builtin() ? "Goon Client" : "Saved locally", cx + 14, cy + 9.4f, 4.2f, GoonFont.Weight.REGULAR, 0xFF9C98A4, false);
            GoonFont.draw(g, "Enabled:", cx + 4.5f, cy + 21, 4.6f, GoonFont.Weight.REGULAR, 0xFFB9B5C0, false);
            GoonFont.draw(g, profile.enabledCount() + " modules", cx + 29, cy + 21, 4.6f, GoonFont.Weight.REGULAR, 0xFFB9B5C0, false);
            GoonFont.draw(g, "Updated:", cx + 4.5f, cy + 28.5f, 4.6f, GoonFont.Weight.REGULAR, 0xFFB9B5C0, false);
            GoonFont.draw(g, updated(profile), cx + 29, cy + 28.5f, 4.6f, GoonFont.Weight.REGULAR, 0xFFB9B5C0, false);
            // Action icons, right-aligned: load, then overwrite and delete for saved setups
            float ax = cx + cw - 4.5f;
            if (!profile.builtin()) {
                boolean armed = armedDelete.equals(profile.id());
                ax -= 9;
                iconButton(g, Icons.Icon.TRASH, ax, cy + 24.5f, mx, my, armed ? Ui.BAD : 0xFFE8E4EE,
                    () -> {
                        if (armedDelete.equals(profile.id())) configResult(dev.goonclient.client.config.ProfileStore.delete(profile), true);
                        else { armedDelete = profile.id(); armedAt = System.currentTimeMillis(); configStatus = "Click the bin again to remove \"" + profile.name() + "\"."; }
                    });
                ax -= 11;
                iconButton(g, Icons.Icon.DOWNLOAD, ax, cy + 24.5f, mx, my, 0xFFE8E4EE,
                    () -> configResult(dev.goonclient.client.config.ProfileStore.overwrite(profile), true));
            }
            ax -= profile.builtin() ? 9 : 11;
            iconButton(g, Icons.Icon.UPLOAD, ax, cy + 24.5f, mx, my, 0xFFE8E4EE,
                () -> configResult(dev.goonclient.client.config.ProfileStore.load(profile), false));
        }
        if (!configStatus.isEmpty()) {
            float sy = bottom - 8;
            Shapes.rect(g, left, sy - 2, right, bottom, 0xD8211E24);
            GlassUi.text(g, Ui.ellipsize(configStatus, right - left - 2, 4.8f, GoonFont.Weight.REGULAR), left + 1, sy, 4.8f, 0xFFD2CED8, false);
        }
    }

    private void iconButton(GuiGraphicsExtractor g, Icons.Icon icon, float bx, float by, int mx, int my, int color, Runnable action) {
        boolean hover = Ui.inside(mx, my, bx, by, bx + 9, by + 9);
        Shapes.roundRect(g, bx, by, bx + 9, by + 9, 2, hover ? 0xFF3A363F : 0xFF2A272E);
        Icons.draw(g, icon, bx + 1.8f, by + 1.8f, 5.4f, color);
        clippedHit(bx, by, bx + 9, by + 9, action);
    }

    // ---- Pieces ------------------------------------------------------------------------------------------

    /** SettingsGlassMaterial.navigation / content: a see-through dark plane with a soft edge. */
    private static void plane(GuiGraphicsExtractor g, float x, float y, float w, float h, int top, int bottom) {
        Shapes.gradientRect(g, x, y, x + w, y + h, 3.5f, 3.5f, top, bottom);
        Shapes.outline(g, x, y, x + w, y + h, 3.5f, 0x34474E5A);
    }

    private void darkCard(GuiGraphicsExtractor g, float cx, float cy, float cw, float ch, float header, boolean selected, float hover) {
        darkCard(g, cx, cy, cw, ch, header, selected, hover, Ui.accent());
    }

    /** Dark card with a lighter header band; selected cards take the accent tint and outline. */
    private void darkCard(GuiGraphicsExtractor g, float cx, float cy, float cw, float ch, float header, boolean selected, float hover, int accent) {
        int fill = selected ? Ui.lerp(.32f, 0xFF242227, accent) : Ui.lerp(hover * .5f, 0xFF201F23, 0xFF2B2A2F);
        Shapes.panel(g, cx, cy, cx + cw, cy + ch, 2.5f, Ui.withAlpha(fill, .94f), selected ? Ui.withAlpha(accent, .9f) : 0x22FFFFFF);
        if (header > 0) {
            int band = selected ? Ui.lerp(.35f, 0xFF3C3A40, accent) : 0xFF3A383E;
            Shapes.roundRect(g, cx + .5f, cy + .5f, cx + cw - .5f, cy + header, 2.2f, Ui.withAlpha(band, .55f));
            Shapes.rect(g, cx + 3.5f, cy + header, cx + cw - 3.5f, cy + header + .35f, selected ? Ui.withAlpha(accent, .5f) : 0x30FFFFFF);
        }
    }

    /** The grey HUD-card switch: a ring knob that slides right and brightens when on. */
    private static void smallSwitch(GuiGraphicsExtractor g, float sx, float sy, float on) {
        Shapes.roundRect(g, sx, sy, sx + 10, sy + 5, 2.5f, Ui.lerp(on, 0xFF3A383F, 0xFF8E8A96));
        float kx = sx + 2.5f + on * 5;
        Shapes.circle(g, kx, sy + 2.5f, 2.2f, 0xFF2A282E);
        Shapes.circle(g, kx, sy + 2.5f, 1.7f, 0xFFF4F2F7);
    }

    /** The accent switch used in settings rows. */
    private static void accentSwitch(GuiGraphicsExtractor g, float sx, float sy, float on) {
        Shapes.roundRect(g, sx, sy, sx + 16, sy + 8, 4, Ui.lerp(on, 0xFF3A383F, Ui.accent()));
        Shapes.circle(g, sx + 4 + on * 8, sy + 4, 3, 0xFFFFFFFF);
    }

    private void hit(float x1, float y1, float x2, float y2, Runnable action) {
        hits.add(new Hit(x1, y1, x2, y2, action));
    }

    private void clippedHit(float x1, float y1, float x2, float y2, Runnable action) {
        if (y2 > top && y1 < bottom) hit(x1, Math.max(top, y1), x2, Math.min(bottom, y2), action);
    }

    private void openSettings(Module module) {
        ClickGuiScreen screen = new ClickGuiScreen(this);
        screen.openSettingsFor(module);
        minecraft.gui.setScreen(screen);
    }

    private void changed() {
        appearance.setEnabled(true);
        ConfigManager.markDirty();
    }

    private void drag(double realX) {
        if (dragging != null) {
            dragging.setFraction(Math.max(0, Math.min(1, (realX / s - dragLeft) / dragWidth)));
            changed();
        }
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        boolean right = event.button() == InputConstants.MOUSE_BUTTON_RIGHT;
        if (event.button() != InputConstants.MOUSE_BUTTON_LEFT && !right) return true;
        searchFocus = false;
        double mx = event.x() / s, my = event.y() / s;
        if (right && page == Page.HUD) {
            // RMB on a HUD card opens that element's settings
            List<HudModule> list = huds();
            float cw = cardWidth();
            for (int i = 0; i < list.size(); i++) {
                float cx = left + (i % 2) * (cw + CARD_GAP), cy = top + (i / 2) * 42.6f - scroll;
                if (Ui.inside(mx, my, cx, Math.max(top, cy), cx + cw, Math.min(bottom, cy + 36))) {
                    openSettings(list.get(i));
                    return true;
                }
            }
            return true;
        }
        if (right) return true;
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit hit = hits.get(i);
            if (Ui.inside(mx, my, hit.x1, hit.y1, hit.x2, hit.y2)) {
                hit.action.run();
                drag(event.x());
                return true;
            }
        }
        return true;
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dx, double dy) {
        drag(event.x());
        return true;
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        dragging = null;
        return true;
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double dx, double dy) {
        if (Ui.inside(mx / s, my / s, left, top, right + 6, bottom)) {
            scroll = Math.max(0, Math.min(Math.max(0, extent - (bottom - top)), scroll - (float) dy * 18));
            hits.clear();
            dragging = null;
        }
        return true;
    }

    @Override
    public boolean charTyped(CharacterEvent event) {
        if (!searchFocus) return false;
        if (search.length() < 64) {
            search += event.codepointAsString();
            scroll = 0;
            hits.clear();
        }
        return true;
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        if (event.hasAltDown() && event.key() == InputConstants.KEY_H) {
            dev.goonclient.client.modules.utility.Interface.toggleHints();
            return true;
        }
        if (event.hasControlDown() && event.key() == InputConstants.KEY_F) {
            searchFocus = true;
            return true;
        }
        if (event.key() == InputConstants.KEY_ESCAPE) {
            if (!search.isEmpty() || searchFocus) {
                search = "";
                searchFocus = false;
                scroll = 0;
                hits.clear();
            } else onClose();
            return true;
        }
        if (event.key() == InputConstants.KEY_BACKSPACE && searchFocus) {
            if (!search.isEmpty()) search = search.substring(0, search.offsetByCodePoints(search.length(), -1));
            scroll = 0;
            hits.clear();
            return true;
        }
        return super.keyPressed(event);
    }

    @Override
    public void removed() {
        GlassUi.restoreHud(minecraft);
        dragging = null;
        hits.clear();
        ConfigManager.save();
    }

    @Override
    public void onClose() {
        ConfigManager.save();
        minecraft.gui.setScreen(parent);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    public static List<String> wrap(String value, float width, float size, int max) {
        List<String> lines = new ArrayList<>();
        String line = "";
        for (String word : value.split("\\s+")) {
            String next = line.isEmpty() ? word : line + " " + word;
            if (!line.isEmpty() && GoonFont.width(next, size, GoonFont.Weight.REGULAR) > width) {
                lines.add(line);
                line = word;
            } else line = next;
        }
        if (!line.isEmpty()) lines.add(line);
        if (lines.size() > max) {
            String tail = String.join(" ", lines.subList(max - 1, lines.size()));
            lines = new ArrayList<>(lines.subList(0, max - 1));
            lines.add(Ui.ellipsize(tail, width, size, GoonFont.Weight.REGULAR));
        }
        return lines;
    }

    private record Hit(float x1, float y1, float x2, float y2, Runnable action) {
    }
}
