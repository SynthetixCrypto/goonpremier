package dev.goonclient.client.gui.render;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import org.joml.Matrix3x2f;

/**
 * Screen-pixel helpers. The UI is laid out in GUI units, but shapes and text are drawn on real screen pixels so edges
 * are crisp (one GUI unit is 2-4 screen pixels) and animations can move by fractions of a GUI unit.
 */
public final class Px {
	private Px() {
	}

	public static int guiScale() {
		return Math.max(1, Minecraft.getInstance().getWindow().getGuiScale());
	}

	/** A rectangle given in the current pose's coordinates, converted to whole screen pixels. */
	public static int[] rect(GuiGraphicsExtractor g, float x1, float y1, float x2, float y2) {
		Matrix3x2f pose = g.pose();
		int scale = guiScale();
		return new int[]{
			Math.round((pose.m00 * x1 + pose.m20) * scale),
			Math.round((pose.m11 * y1 + pose.m21) * scale),
			Math.round((pose.m00 * x2 + pose.m20) * scale),
			Math.round((pose.m11 * y2 + pose.m21) * scale)
		};
	}

	/** A length in the current pose's units, in screen pixels. */
	public static float length(GuiGraphicsExtractor g, float value) {
		return value * g.pose().m00 * guiScale();
	}

	/** Switches the pose to screen pixels; pair with {@link #end}. */
	public static void begin(GuiGraphicsExtractor g) {
		g.pose().pushMatrix();
		g.pose().identity();
		float inverse = 1f / guiScale();
		g.pose().scale(inverse, inverse);
	}

	public static void end(GuiGraphicsExtractor g) {
		g.pose().popMatrix();
	}
}
