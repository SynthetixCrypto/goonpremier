package dev.goonclient.client.tracker;

import com.mojang.blaze3d.platform.InputConstants;
import dev.goonclient.client.modules.hud.InputHuds;
import net.minecraft.client.Minecraft;

/** Bounded, monotonic one-second windows. Raw presses count once; GUI clicks never count. */
public final class ClickHistory {
	private static final long[][] PRESSES = new long[2][256];
	private static final int[] NEXT = new int[2];
	private ClickHistory() { }

	public static void press(Minecraft mc, long window, int button, int action) {
		if (action != 1 || window == 0 || window != mc.getWindow().handle() || mc.player == null || mc.level == null
			|| mc.gui.screen() != null || mc.gui.overlay() != null || !InputHuds.trackingClicks()) return;
		int index = button == InputConstants.MOUSE_BUTTON_LEFT ? 0 : button == InputConstants.MOUSE_BUTTON_RIGHT ? 1 : -1;
		if (index < 0) return;
		PRESSES[index][NEXT[index]] = System.nanoTime();
		NEXT[index] = (NEXT[index] + 1) % PRESSES[index].length;
	}

	public static int count(boolean right) {
		long now = System.nanoTime(); int count = 0;
		for (long press : PRESSES[right ? 1 : 0]) if (press != 0 && now - press < 1_000_000_000L) count++;
		return count;
	}

	public static void clear() { for (long[] window : PRESSES) java.util.Arrays.fill(window, 0); }
}
