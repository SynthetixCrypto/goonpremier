package dev.goonclient.client.tracker;

import dev.goonclient.client.util.MemoryStats;
import dev.goonclient.client.utility.LocalFiles;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.util.Locale;
import java.util.UUID;
import net.minecraft.client.Minecraft;

/** Explicit local captures. Frame hooks never allocate, sort, sample memory, write files or request GPU timing. */
public final class PerformanceNotebook {
    public record Settings(int renderDistance, int simulationDistance, int fpsCap, boolean vsync,
                           int guiScale, int width, int height, String graphicsPreset) {}
    public record Snapshot(NotebookCapture.Result result, Settings settings, MemoryStats.Sample startMemory,
                           MemoryStats.Sample reviewMemory) {}
    public record Export(Path csv, Path summary) {}
    private static final NotebookCapture capture = new NotebookCapture();
    private static Object connection;
    private static Settings settings;
    private static MemoryStats.Sample startMemory;
    private static Snapshot finished;
    private PerformanceNotebook() {}

    public static boolean canStart(Minecraft mc) {
        return mc != null && mc.level != null && mc.player != null && mc.getConnection() != null && !capture.running();
    }
    public static boolean start(Minecraft mc) {
        if (!canStart(mc)) return false;
        var options = mc.options; var window = mc.getWindow();
        settings = new Settings(options.renderDistance().get(), options.simulationDistance().get(),
            options.framerateLimit().get(), options.enableVsync().get(), options.guiScale().get(),
            window.getWidth(), window.getHeight(), options.graphicsPreset().get().name());
        startMemory = MemoryStats.sample(); finished = null; connection = mc.getConnection();
        capture.start(System.nanoTime()); return true;
    }
    public static boolean running() { return capture.running(); }
    public static int samples() { return capture.count(); }
    public static double activeSeconds() { return capture.measuredNanos() / 1_000_000_000d; }
    public static double elapsedSeconds() { return capture.elapsedNanos() / 1_000_000_000d; }
    private static boolean eligible(Minecraft mc) {
        return mc.level != null && mc.player != null && mc.gui.screen() == null && mc.gui.overlay() == null
            && mc.isWindowActive() && !mc.isPaused();
    }
    public static void beginFrame(Minecraft mc) {
        if (!capture.running()) return;
        capture.frame(System.nanoTime(), eligible(mc), mc.getConnection() != null && mc.getConnection() == connection);
        if (!capture.running()) connection = null;
    }
    public static void endFrame(Minecraft mc) {
        if (!capture.running()) return;
        if (mc.getConnection() == null || mc.getConnection() != connection) {
            capture.stop(System.nanoTime(), NotebookCapture.Stop.DISCONNECTED); connection = null;
        } else capture.boundary(eligible(mc));
    }
    /** Transition callbacks call this even if an excluded state ends before the next frame poll. */
    public static void invalidateBoundary() { if (capture.running()) capture.boundary(false); }
    public static void cancel() {
        capture.stop(System.nanoTime(), NotebookCapture.Stop.CANCELLED); connection = null;
    }
    /** Freezes once when the result is reviewed; no per-frame summary or memory allocation. */
    public static Snapshot snapshot() {
        if (capture.running() || !capture.hasCapture()) return null;
        if (finished == null) finished = new Snapshot(capture.result(), settings, startMemory, MemoryStats.sample());
        return finished;
    }
    public static Path folder() { return Minecraft.getInstance().gameDirectory.toPath().resolve("goonclient/reports"); }
    public static String stopLabel(NotebookCapture.Result r) {
        return switch (r.stop()) {
            case COMPLETE -> "60-second window finished";
            case CANCELLED -> "Stopped early: cancelled";
            case DISCONNECTED -> "Stopped early: disconnected";
            case SAMPLE_LIMIT -> "Stopped early: sample capacity reached";
        };
    }
    public static String number(double n) { return String.format(Locale.ROOT, "%.3f", n); }
    public static String memory(long bytes) { return bytes < 0 ? "unavailable" : number(bytes / 1048576d) + " MiB"; }
    public static final String INSUFFICIENT = "Provisional metrics: insufficient sample (need at least 5 s active and 120 samples).";
    public static String summary(Snapshot s) {
        var r = s.result(); var o = s.settings();
        return "# Goon Client Performance Notebook\n\n" + stopLabel(r)
            + (r.provisional() ? "\n\n" + INSUFFICIENT : "")
            + "\n\nWindow elapsed: " + number(r.elapsedSeconds()) + " s (target 60 s wall time)"
            + "\nActive measured duration: " + number(r.activeSeconds()) + " s"
            + "\nSamples: " + r.samples() + "\nMean FPS: " + (r.samples() == 0 ? "unavailable" : number(r.meanFps()))
            + "\nP95 / P99 / max frame ms: " + (r.samples() == 0 ? "unavailable" : number(r.p95Ms()) + " / " + number(r.p99Ms()) + " / " + number(r.maxMs()))
            + "\nFrames strictly >33 ms / >50 ms: " + r.over33() + " / " + r.over50()
            + "\n\nSettings at start only (may change during capture): render distance " + o.renderDistance()
            + ", simulation distance " + o.simulationDistance() + ", FPS cap " + o.fpsCap() + ", VSync " + o.vsync()
            + ", GUI scale option " + o.guiScale() + ", window pixels " + o.width() + " x " + o.height() + ", graphics preset " + o.graphicsPreset()
            + "\n\nMemory at start: heap " + memory(s.startMemory().heapUsed()) + " / " + memory(s.startMemory().heapLimit())
            + "; process resident RAM " + memory(s.startMemory().processBytes())
            + "\nMemory when result first reviewed: heap " + memory(s.reviewMemory().heapUsed()) + " / " + memory(s.reviewMemory().heapLimit())
            + "; process resident RAM " + memory(s.reviewMemory().processBytes())
            + "\n\n" + CAVEATS + "\n";
    }
    public static final String CAVEATS = "Frame times are consecutive renderFrame start intervals, including pacing, CPU work and possible GPU waits; this is not GPU instrumentation or pure CPU render time. Menus, overlays/loading, unfocused, paused and no-world frames are excluded; intervals touching exclusions are dropped rather than bridged. The first eligible frame establishes an anchor. The 60-second window includes excluded time; an interval ending after its deadline is omitted. Active duration is the sum of retained intervals. Mean FPS = sample count / active seconds. P95/P99 use nearest-rank frame-time percentiles; they are not 1% low FPS. Counts use strict >33 ms and >50 ms thresholds. At most 240,000 samples are retained, then capture stops early without overwriting samples. Zero samples have no FPS or percentile estimate. Settings are a start snapshot, not a controlled benchmark. Memory uses MemoryStats and may be cached up to 0.5 s; review memory can be later than capture completion, and process resident RAM is separate from Java heap and may be unavailable. No accounts, server identities, paths, coordinates or logs are included. Nothing is uploaded.";
    public static String csv(Snapshot s) {
        var r = s.result(); var out = new StringBuilder("sample,active_elapsed_seconds,frame_ms\r\n"); long active = 0;
        for (int i = 0; i < r.samples(); i++) {
            long n = r.frameNanos(i); active += n;
            out.append(i + 1).append(',').append(number(active / 1_000_000_000d)).append(',').append(number(n / 1_000_000d)).append("\r\n");
        }
        return out.toString();
    }
    /** Caller runs this off the client thread after explicit export. Snapshot contains no live game objects. */
    public static Export export(Snapshot s, Path folder) throws IOException {
        if (s == null) throw new IOException("No finished capture");
        String base = "performance-" + Instant.now().toEpochMilli() + "-" + UUID.randomUUID();
        Path csv = folder.resolve(base + ".csv"), summary = folder.resolve(base + ".md");
        try { LocalFiles.write(csv, csv(s)); LocalFiles.write(summary, summary(s)); return new Export(csv, summary); }
        catch (IOException e) { try { Files.deleteIfExists(csv); Files.deleteIfExists(summary); } catch (IOException cleanup) { e.addSuppressed(cleanup); } throw e; }
    }
}
