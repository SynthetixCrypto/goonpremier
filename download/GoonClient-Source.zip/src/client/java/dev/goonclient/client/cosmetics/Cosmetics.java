package dev.goonclient.client.cosmetics;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.goonclient.Goon;
import java.io.InputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.User;
import net.minecraft.world.entity.player.PlayerSkin;

/** Local wardrobe plus opt-in UUID lookup. All network I/O runs on one daemon, never in player rendering. */
public final class Cosmetics {
	private static final Gson JSON = new GsonBuilder().setPrettyPrinting().create();
	private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("goonclient/cosmetics.json");
	private static final ExecutorService WORKER = Executors.newSingleThreadExecutor(r -> { Thread t = new Thread(r, "Goon cosmetics"); t.setDaemon(true); return t; });
	private static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).followRedirects(HttpClient.Redirect.NEVER).build();
	private static final AtomicBoolean BUSY = new AtomicBoolean();
	private static final Map<UUID, String> REMOTE = new HashMap<>(); // Client-thread only.
	private static String cape = "none";
	private static boolean visible = true;
	private static boolean sharing;
	private static String serviceUrl = "";
	private static URI service;
	private static long nextLookup;
	private static volatile int generation;
	private static UUID account;
	private static UUID publishedAccount;
	private static String publishedCape;
	private static long remoteExpiry;
	private static volatile String status = "Choose a cape. Your local preview works immediately.";
	private Cosmetics() {}

	public static void init() {
		try (InputStream input = Cosmetics.class.getResourceAsStream("/goon-cosmetics.properties")) {
			if (input != null) { Properties p = new Properties(); p.load(input); serviceUrl = p.getProperty("service_url", "").trim(); }
		} catch (Exception e) { Goon.LOGGER.warn("Couldn't read cosmetic service settings"); }
		try {
			if (Files.isRegularFile(FILE) && Files.size(FILE) <= 8192) {
				JsonObject config = JsonParser.parseString(Files.readString(FILE)).getAsJsonObject();
				if (config.has("cape") && CapeCatalog.valid(config.get("cape").getAsString())) cape = config.get("cape").getAsString();
				if (config.has("visible")) visible = config.get("visible").getAsBoolean();
				if (config.has("sharing")) sharing = config.get("sharing").getAsBoolean();
				if (config.has("service_url")) serviceUrl = config.get("service_url").getAsString().trim();
			}
			service = endpoint(serviceUrl);
		} catch (Exception e) { sharing = false; service = null; status = "Cosmetic settings need attention; local previews still work."; }
	}

	private static URI endpoint(String url) {
		if (url.isBlank()) return null;
		URI uri = URI.create(url);
		boolean local = Set.of("localhost", "127.0.0.1", "[::1]").contains(uri.getHost() == null ? "" : uri.getHost());
		if (uri.getHost() == null || uri.getUserInfo() != null || uri.getQuery() != null || uri.getFragment() != null
			|| !("https".equals(uri.getScheme()) || local && "http".equals(uri.getScheme()))
			|| !(uri.getPath().isEmpty() || uri.getPath().equals("/"))) throw new IllegalArgumentException("Use the HTTPS root of your cosmetic service.");
		return uri.resolve("/");
	}

	public static String selected() { return cape; }
	public static boolean visible() { return visible; }
	public static boolean sharing() { return sharing; }
	public static boolean configured() { return service != null; }
	public static boolean busy() { return BUSY.get(); }
	public static String status() { return status; }
	public static boolean published() { return account != null && account.equals(publishedAccount) && cape.equals(publishedCape); }
	public static void equip(String id) { if (!CapeCatalog.valid(id)) return; cape = id; generation++; status = "Equipped locally. " + (sharing ? "Click Share equipped cape to update your friends." : "Sharing is off."); save(); }
	public static void toggleVisible() { visible = !visible; save(); }
	public static void toggleSharing() {
		sharing = !sharing; generation++; REMOTE.clear(); nextLookup = 0; publishedAccount = null;
		status = sharing ? "Share your equipped cape when you're ready." : "Sharing and friend lookups are off. Previously shared capes stay on the service until you share Original cape.";
		save();
	}
	private static void save() {
		try {
			Files.createDirectories(FILE.getParent());
			JsonObject config = new JsonObject(); config.addProperty("cape", cape); config.addProperty("visible", visible);
			config.addProperty("sharing", sharing); config.addProperty("service_url", serviceUrl);
			Path temp = FILE.resolveSibling("cosmetics.json.tmp"); Files.writeString(temp, JSON.toJson(config));
			Files.move(temp, FILE, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
		} catch (Exception e) { status = "Couldn't save the wardrobe. Check that the config folder is writable."; }
	}
	public static void tick(Minecraft mc) {
		UUID current = mc.getUser().getProfileId();
		if (!current.equals(account)) { account = current; generation++; REMOTE.clear(); publishedAccount = null; nextLookup = 0; }
		long now = System.nanoTime();
		if (now > remoteExpiry) REMOTE.clear();
		if (mc.level == null || !sharing || !visible || service == null || now < nextLookup || BUSY.get()) return;
		nextLookup = now + Duration.ofSeconds(20).toNanos();
		List<UUID> ids = mc.level.players().stream().map(p -> p.getUUID()).filter(id -> !id.equals(current)).distinct().limit(64).toList();
		if (ids.isEmpty() || !BUSY.compareAndSet(false, true)) return;
		int epoch = generation; URI root = service;
		WORKER.execute(() -> {
			try {
				JsonArray profiles = request(root, "GET", "v1/profiles?ids=" + String.join(",", ids.stream().map(UUID::toString).toList()), null, null).getAsJsonArray("profiles");
				if (profiles == null || profiles.size() > 64) throw new IllegalArgumentException();
				Map<UUID, String> found = new HashMap<>();
				for (var item : profiles) {
					JsonObject p = item.getAsJsonObject(); UUID id = UUID.fromString(p.get("uuid").getAsString()); String choice = p.get("cape").getAsString();
					if (ids.contains(id) && CapeCatalog.valid(choice)) found.put(id, choice);
				}
				mc.execute(() -> { if (generation == epoch && sharing) { REMOTE.clear(); REMOTE.putAll(found); remoteExpiry = System.nanoTime() + Duration.ofMinutes(2).toNanos(); } });
			} catch (Exception e) {
				mc.execute(() -> { if (generation == epoch) { nextLookup = System.nanoTime() + Duration.ofSeconds(60).toNanos(); status = "Friends' cosmetics are temporarily unavailable. Local capes still work."; } });
			} finally { BUSY.set(false); }
		});
	}

	public static void publish() {
		Minecraft mc = Minecraft.getInstance();
		if (service == null) { status = "The owner needs to connect the cosmetic service first."; return; }
		if (!sharing) { status = "Turn on Share with friends first."; return; }
		if (!BUSY.compareAndSet(false, true)) return;
		User user = mc.getUser(); String choice = cape; URI root = service; int epoch = generation;
		if (user.getAccessToken().length() < 20) { BUSY.set(false); status = "Use a Microsoft-authenticated Minecraft session to share a cape."; return; }
		status = "Verifying your Minecraft account…";
		WORKER.execute(() -> {
			try {
				byte[] nonce = new byte[20]; new java.security.SecureRandom().nextBytes(nonce);
				String requestedDigest = java.util.HexFormat.of().formatHex(nonce);
				JsonObject who = new JsonObject(); who.addProperty("name", user.getName()); who.addProperty("uuid", user.getProfileId().toString());
				who.addProperty("serverId", requestedDigest);
				JsonObject challenge = request(root, "POST", "v1/challenge", who, null);
				if (generation != epoch) return;
				String digest = challenge.get("serverId").getAsString();
				if (!digest.equals(requestedDigest)) throw new IllegalArgumentException();
				// This account token goes to Mojang through authlib; it is never sent to our service or saved here.
				mc.services().sessionService().joinServer(user.getProfileId(), user.getAccessToken(), digest);
				JsonObject proof = new JsonObject(); proof.addProperty("challenge", challenge.get("challenge").getAsString());
				String token = request(root, "POST", "v1/verify", proof, null).get("token").getAsString();
				if (!token.matches("[a-f0-9]{64}")) throw new IllegalArgumentException();
				if (generation != epoch) return;
				JsonObject selection = new JsonObject(); selection.addProperty("cape", choice);
				JsonObject result = request(root, "PUT", "v1/me", selection, token);
				if (!choice.equals(result.get("cape").getAsString())) throw new IllegalArgumentException();
				mc.execute(() -> { if (generation == epoch && sharing && account.equals(user.getProfileId())) {
					publishedAccount = user.getProfileId(); publishedCape = choice;
					status = choice.equals("none") ? "Shared cape removed. Your Minecraft cape is unchanged." : "Shared! Friends see this cape on their next refresh (up to 20 seconds).";
				} });
			} catch (Exception e) { mc.execute(() -> { if (generation == epoch) status = "Couldn't share. Check your Minecraft session, service connection and friend access."; }); }
			finally { BUSY.set(false); }
		});
	}

	private static JsonObject request(URI root, String method, String path, JsonObject body, String token) throws Exception {
		HttpRequest.Builder builder = HttpRequest.newBuilder(root.resolve(path)).timeout(Duration.ofSeconds(10))
			.header("Accept", "application/json").header("User-Agent", "GoonClient-Cosmetics/1");
		if (token != null) builder.header("Authorization", "Bearer " + token);
		if (body != null) builder.header("Content-Type", "application/json");
		builder.method(method, body == null ? HttpRequest.BodyPublishers.noBody() : HttpRequest.BodyPublishers.ofString(JSON.toJson(body)));
		var pending = HTTP.sendAsync(builder.build(), HttpResponse.BodyHandlers.limiting(HttpResponse.BodyHandlers.ofByteArray(), 65536));
		try {
			HttpResponse<byte[]> response = pending.get(12, java.util.concurrent.TimeUnit.SECONDS);
			if (response.statusCode() != 200) throw new IllegalStateException("Cosmetic service rejected the request.");
			return JsonParser.parseString(new String(response.body(), StandardCharsets.UTF_8)).getAsJsonObject();
		} finally { if (!pending.isDone()) pending.cancel(true); }
	}

	/** Called only during extraction: immutable replacement of the cape field, preserving skin and elytra. */
	public static PlayerSkin skin(UUID uuid, PlayerSkin original) {
		if (!visible) return original;
		String selected = Minecraft.getInstance().getUser().getProfileId().equals(uuid) ? cape : sharing ? REMOTE.get(uuid) : null;
		if (selected == null || selected.equals("none") || !CapeCatalog.valid(selected)) return original;
		return new PlayerSkin(original.body(), CapeTextures.texture(selected), original.elytra(), original.model(), original.secure());
	}
	public static void disconnect() { generation++; REMOTE.clear(); nextLookup = 0; }
	public static void stop() { WORKER.shutdownNow(); HTTP.shutdownNow(); }
}
