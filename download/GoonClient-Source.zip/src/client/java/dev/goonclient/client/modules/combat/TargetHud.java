/*
 * This file incorporates code from the Combatant Client distribution.
 * Copyright (c) 2026 pivosos2007.
 * Licensed under the GNU General Public License v3.0.
 * Modified for Goon Client, 2026-10-04: TargetHud.java card geometry (112 x 40 units at scale 3.28,
 * 2-unit panel inset, 24-unit face, Inter Bold name/health at 0.34, 64 x 4 health bar) and theme palette,
 * drawn with Goon's renderer; Goon's own target picking and mob previews.
 */
package dev.goonclient.client.modules.combat;

import dev.goonclient.client.hud.HudPosition;
import dev.goonclient.client.gui.Ui;
import dev.goonclient.client.gui.render.Shapes;
import dev.goonclient.client.hud.HudRenderUtil;
import net.minecraft.client.gui.components.PlayerFaceExtractor;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.player.AbstractClientPlayer;
import org.joml.Matrix3x2f;
import dev.goonclient.client.hud.HudModule;
import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.setting.NumberSetting;
import java.util.Optional;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.NeutralMob;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** The player or mob you're looking at: face, name, health and a health bar. */
public class TargetHud extends HudModule {
	// TargetHud.java, in its own units (the reference screenshot predates CONTENT_X/Y_OFFSET)
	private static final float SCALE = 3.28f, BASE_WIDTH = 112, BASE_HEIGHT = 40, PANEL_INSET = 2, PANEL_RADIUS = 6,
		FACE_X = 9, FACE_Y = 8, FACE_SIZE = 24, FACE_RADIUS = 4, CONTENT_GAP = 6, NAME_Y = 13, BAR_Y_OFFSET = 12,
		BAR_WIDTH = 64, BAR_HEIGHT = 4, TEXT_SCALE = .34f;
	private static final int BG_ALPHA = 162, SHADOW_ALPHA = 96;
	private static final long LINGER_MS = 1500;

	private final NumberSetting range = add(new NumberSetting("range", "Range", 32, 4, 64, 2, " blocks"));
	private LivingEntity target;
	private long lastSeen;

	public TargetHud() {
		super("target", "Mob Info", "Look at a mob to see its health, type, armour and distance", Category.COMBAT, true, new HudPosition(.5, .715, 0, 0, .5, .5));
	}

	@Override
	public boolean isVisible(Minecraft mc) {
		return mc.player != null;
	}

	@Override
	protected boolean isTransient() {
		return true;
	}

	@Override protected void measure(Minecraft mc, boolean editing) {

		if (mc.player == null || mc.level == null) target = null;
		LivingEntity looked = mc.player != null && mc.level != null ? findTarget(mc, range.get()) : null;
		long now = System.currentTimeMillis();
		if (looked != null) {
			target = looked;
			lastSeen = now;
		} else if (target != null && (now - lastSeen > LINGER_MS || !target.isAlive())) {
			target = null;
		}

        float k = HudRenderUtil.resolutionScale() * SCALE;
        setSize(target == null && !editing ? 1 : Math.round(BASE_WIDTH * k), target == null && !editing ? 1 : Math.round(BASE_HEIGHT * k));
	}

	@Override
	protected void render(GuiGraphicsExtractor g, Minecraft mc, boolean editing) {
		long now = System.currentTimeMillis();
		float alpha = target == null ? 1f : 1f - Math.max(0f, (now - lastSeen - LINGER_MS / 2f) / (LINGER_MS / 2f));
		if (target == null && !editing) {
			setSize(1, 1);
			return;
		}

		String name = target != null ? target.getDisplayName().getString() : mc.player != null ? mc.player.getName().getString() : "Steve";
		float health = target != null ? target.getHealth() : 20f;
		float maxHealth = target != null ? target.getMaxHealth() : 20f;

		float k = HudRenderUtil.resolutionScale() * SCALE;
		setSize(Math.round(BASE_WIDTH * k), Math.round(BASE_HEIGHT * k));
		g.pose().pushMatrix();
		g.pose().scale(k, k);
		drawCard(g, mc, name, health, maxHealth, alpha);
		g.pose().popMatrix();
	}

	private void drawCard(GuiGraphicsExtractor g, Minecraft mc, String name, float health, float maxHealth, float alpha) {
		float px = PANEL_INSET, py = PANEL_INSET, pw = BASE_WIDTH - PANEL_INSET * 2, ph = BASE_HEIGHT - PANEL_INSET * 2;
		var palette = HudRenderUtil.CompactPalette.current();
		int bgTop = HudRenderUtil.setAlpha(palette.bgPrimary(), BG_ALPHA), bgBottom = HudRenderUtil.setAlpha(palette.bgSecondary(), BG_ALPHA);
		HudRenderUtil.shadow(g, px, py, pw, ph, PANEL_RADIUS, Math.round(SHADOW_ALPHA * alpha));
		HudRenderUtil.glassFill(g, px, py, pw, ph, PANEL_RADIUS, PANEL_RADIUS, HudRenderUtil.scaleAlpha(bgTop, alpha),
			HudRenderUtil.scaleAlpha(bgBottom, alpha), dev.goonclient.client.gui.render.BackdropBlur.available(), alpha);
		HudRenderUtil.glint(g, px + 1, py + 1, pw - 2, ph * .42f, PANEL_RADIUS - 1, Math.max(HudRenderUtil.alpha01(bgTop), HudRenderUtil.alpha01(bgBottom)) * alpha);
		HudRenderUtil.rim(g, px, py, pw, ph, PANEL_RADIUS, alpha);

		Shapes.roundRect(g, FACE_X, FACE_Y, FACE_X + FACE_SIZE, FACE_Y + FACE_SIZE, FACE_RADIUS, Ui.withAlpha(0xFF2B2622, alpha));
		if (target instanceof AbstractClientPlayer player) {
			face(g, player);
		} else if (target != null) {
			// Mobs: a live model in the face box. Entity previews ignore the pose, so convert to screen coordinates.
			Matrix3x2f pose = g.pose();
			int x0 = Math.round(pose.m00 * FACE_X + pose.m20), y0 = Math.round(pose.m11 * FACE_Y + pose.m21);
			int x1 = Math.round(pose.m00 * (FACE_X + FACE_SIZE) + pose.m20), y1 = Math.round(pose.m11 * (FACE_Y + FACE_SIZE) + pose.m21);
			float size = Math.max(target.getBbWidth(), target.getBbHeight());
			int scale = Math.max(3, Math.round((x1 - x0) * .78f / Math.max(.4f, size)));
			InventoryScreen.extractEntityInInventoryFollowsMouse(g, x0, y0, x1, y1, scale, .0625f, (x0 + x1) / 2f, (y0 + y1) / 2f, target);
		} else if (mc.player != null) {
			face(g, mc.player);
		}

		// Name and health share Inter Bold at 0.34; health is right-aligned to the panel's inner edge
		float textSize = HudRenderUtil.COMPACT_TEXT * TEXT_SCALE;
		float contentX = FACE_X + FACE_SIZE + CONTENT_GAP, panelRight = BASE_WIDTH - PANEL_INSET * 4;
		String hp = String.format("%.1f", health);
		float hpWidth = HudRenderUtil.width(hp, textSize, HudRenderUtil.Font.INTER_BOLD);
		float maxName = Math.max(12, panelRight - contentX - hpWidth - 12);
		HudRenderUtil.text(g, Ui.ellipsize(name, maxName, textSize / 1.21f, dev.goonclient.client.gui.render.GoonFont.Weight.BOLD), contentX, NAME_Y,
			textSize, HudRenderUtil.Font.INTER_BOLD, Ui.withAlpha(HudRenderUtil.TEXT_PRIMARY, alpha));
		HudRenderUtil.text(g, hp, panelRight - hpWidth, NAME_Y, textSize, HudRenderUtil.Font.INTER_BOLD,
			HudRenderUtil.scaleAlpha(HudRenderUtil.TEXT_MUTED, alpha));

		float fraction = maxHealth > 0 ? Math.max(0f, Math.min(1f, health / maxHealth)) : 0f;
		float shown = Ui.animate("target:health", fraction, .5f);
		float barY = NAME_Y + BAR_Y_OFFSET;
		Shapes.roundRect(g, contentX, barY, contentX + BAR_WIDTH, barY + BAR_HEIGHT, BAR_HEIGHT / 2,
			HudRenderUtil.scaleAlpha(HudRenderUtil.BAR_BACKGROUND, alpha));
		if (shown > .001f) {
			int accent = HudRenderUtil.accent();
			Shapes.gradientRect(g, contentX, barY, contentX + Math.max(BAR_HEIGHT, BAR_WIDTH * shown), barY + BAR_HEIGHT, BAR_HEIGHT / 2, BAR_HEIGHT / 2,
				Ui.withAlpha(HudRenderUtil.mixColor(accent, 0xFFFFFFFF, .18f), alpha), Ui.withAlpha(accent, alpha));
		}
	}

	private static void face(GuiGraphicsExtractor g, AbstractClientPlayer player) {
		// PlayerFaceExtractor takes whole units: draw at 1/4 unit resolution so the 24-unit face lands exactly
		g.pose().pushMatrix();
		g.pose().scale(.25f, .25f);
		PlayerFaceExtractor.extractRenderState(g, player.getSkin(), Math.round(FACE_X * 4), Math.round(FACE_Y * 4), Math.round(FACE_SIZE * 4));
		g.pose().popMatrix();
	}

	/** The living entity under the crosshair within range, only if you can actually see it. */
	private static LivingEntity findTarget(Minecraft mc, double range) {
		if (mc.crosshairPickEntity instanceof LivingEntity living && living.isAlive()) {
			return living;
		}
		Vec3 eye = mc.player.getEyePosition();
		Vec3 look = mc.player.getViewVector(1f);
		Vec3 end = eye.add(look.scale(range));
		AABB search = mc.player.getBoundingBox().expandTowards(look.scale(range)).inflate(1.0);
		LivingEntity best = null;
		double bestDistance = range * range;
		for (Entity entity : mc.level.getEntities(mc.player, search, e -> e instanceof LivingEntity && e.isAlive())) {
			Optional<Vec3> hit = entity.getBoundingBox().inflate(0.3).clip(eye, end);
			if (hit.isPresent()) {
				double distance = eye.distanceToSqr(hit.get());
				if (distance < bestDistance && mc.player.hasLineOfSight(entity)) {
					best = (LivingEntity) entity;
					bestDistance = distance;
				}
			}
		}
		return best;
	}
}
