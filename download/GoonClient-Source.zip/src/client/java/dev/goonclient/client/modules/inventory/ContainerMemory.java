package dev.goonclient.client.modules.inventory;

import dev.goonclient.client.GoonClient;
import dev.goonclient.client.gui.ContainerBookmarksScreen;
import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.Module;
import dev.goonclient.client.module.setting.ButtonSetting;
import dev.goonclient.client.tracker.ContainerBookmarks;
import net.minecraft.client.Minecraft;

public final class ContainerMemory extends Module {
    private static ContainerMemory instance;
    public ContainerMemory(){
        super("container_bookmarks","Container Bookmarks","Remember and search contents of containers you've opened",Category.INVENTORY,false);instance=this;
        add(new ButtonSetting("browse","Search remembered contents","Open",()->GoonClient.openNextTick(new ContainerBookmarksScreen(Minecraft.getInstance().gui.screen()))));
    }
    public static boolean recording(){return instance!=null&&instance.isEnabled();}
    public static void setRecording(boolean value){if(instance!=null)instance.setEnabled(value);}
    @Override protected void onDisable(){ContainerBookmarks.cancel();}
}
