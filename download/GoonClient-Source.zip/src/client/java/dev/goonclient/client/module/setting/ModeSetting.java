package dev.goonclient.client.module.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import java.util.List;

/** One choice out of a fixed list, cycled with arrows in the GUI. */
public class ModeSetting extends Setting<String> {
	private final List<String> modes;

	public ModeSetting(String id, String name, String defaultValue, String... modes) {
		super(id, name, defaultValue);
		this.modes = List.of(modes);
	}

	public List<String> modes() {
		return modes;
	}

	public boolean is(String mode) {
		return value.equals(mode);
	}

	public void cycle(int direction) {
		int index = modes.indexOf(value);
		set(modes.get(Math.floorMod(index + direction, modes.size())));
	}

	@Override
	public void set(String value) {
		if (modes.contains(value)) {
			super.set(value);
		}
	}

	@Override
	public JsonElement toJson() {
		return new JsonPrimitive(value);
	}

	@Override
	public void fromJson(JsonElement json) {
		if (json.isJsonPrimitive()) {
			set(json.getAsString());
		}
	}
}
