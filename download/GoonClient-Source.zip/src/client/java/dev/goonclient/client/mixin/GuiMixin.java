package dev.goonclient.client.mixin;

import dev.goonclient.client.gui.GoonPauseScreen;
import dev.goonclient.client.gui.GoonTitleScreen;
import dev.goonclient.client.gui.GoonOptionsScreen;
import dev.goonclient.client.modules.utility.Interface;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.gui.screens.options.OptionsScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(Gui.class)
public class GuiMixin {
	/** Swap the vanilla title and pause screens for the Goon Client ones whenever the game opens them. */
	@ModifyVariable(method = "setScreen", at = @At("HEAD"), argsOnly = true)
	private Screen goonclient$menus(Screen screen) {
		if (screen != null && dev.goonclient.client.modules.hud.MinimapHud.integrated()
			&& screen.getClass().getName().equals("xaero.common.gui.GuiEditMode")) {
			return new dev.goonclient.client.gui.HudEditorScreen(net.minecraft.client.Minecraft.getInstance().gui.screen());
		}
		if (screen instanceof OptionsScreen options) {
			return new GoonOptionsScreen(options.getLastScreen());
		}
		if (screen instanceof TitleScreen && Interface.customMainMenu()) {
			return new GoonTitleScreen();
		}
		// F3 + Esc pauses without a menu; leave that one alone
		if (screen instanceof PauseScreen pause && pause.showsPauseMenu() && Interface.customPauseMenu()) {
			return new GoonPauseScreen();
		}
		return screen;
	}
}
