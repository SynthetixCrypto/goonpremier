package dev.goonclient.client.cosmetics;

import com.mojang.blaze3d.platform.NativeImage;
import dev.goonclient.Goon;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.renderpearl.api.textures.FilterMode;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.core.ClientAsset;
import net.minecraft.resources.Identifier;

/** Cape textures: {@link CapeArt} faces laid out on vanilla's cape UV map and uploaded as smooth dynamic textures. */
public final class CapeTextures {
    public static final int WIDTH = 1024, HEIGHT = 512, UV_SCALE = 16;
    private static final Map<String, ClientAsset.ResourceTexture> TEXTURES = new HashMap<>();
    private CapeTextures() {}

    public static ClientAsset.ResourceTexture texture(String id) {
        if (id.equals("none") || !CapeCatalog.valid(id)) return null;
        return TEXTURES.computeIfAbsent(id, key -> {
            var cape = CapeCatalog.find(key);
            BufferedImage art = new BufferedImage(WIDTH, HEIGHT, BufferedImage.TYPE_INT_ARGB);
            Graphics2D g = art.createGraphics();
            g.setColor(CapeArt.EDGE); g.fillRect(0, 0, WIDTH, HEIGHT);
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
            // Back: u=12; front: u=1. Insets leave the surrounding edge/top/bottom UV strips intact.
            CapeArt.face(g, cape, 12 * UV_SCALE, true);
            CapeArt.face(g, cape, UV_SCALE, false);
            // The hem strip under the back face, in the cape colour
            g.setColor(new Color(cape.color()));
            g.fillRect(UV_SCALE, 17 * UV_SCALE, 21 * UV_SCALE, 2);
            g.dispose();
            NativeImage pixels = new NativeImage(WIDTH, HEIGHT, true);
            for (int y = 0; y < HEIGHT; y++) for (int x = 0; x < WIDTH; x++) pixels.setPixel(x, y, art.getRGB(x, y));
            Identifier location = Goon.id("dynamic/capes/" + key);
            Minecraft.getInstance().getTextureManager().register(location, new CapeTexture(key, pixels));
            return new ClientAsset.ResourceTexture(location, location);
        });
    }

    private static final class CapeTexture extends DynamicTexture {
        CapeTexture(String key, NativeImage pixels) {
            super(() -> "Goon cape " + key, pixels);
            this.sampler = RenderSystem.getSamplerCache().getClampToEdge(FilterMode.LINEAR);
            upload();
        }
    }

}
