package dev.goonclient.client.utility;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.UUID;

/** Small local stores report failures to callers; write a replacement before touching the existing file. */
public final class LocalFiles {
    private LocalFiles() {}
    public static String read(Path path,long limit)throws IOException{
        if(limit<1||limit>=Integer.MAX_VALUE||!Files.isRegularFile(path,LinkOption.NOFOLLOW_LINKS)||Files.size(path)>limit)throw new IOException("Invalid local file");
        // Enforce the allowance on the open stream too, even if a concurrent writer grows the file.
        try(var input=Files.newInputStream(path,LinkOption.NOFOLLOW_LINKS)){
            byte[] bytes=input.readNBytes((int)limit+1);
            if(bytes.length>limit)throw new IOException("Local file exceeds allowance");
            return StandardCharsets.UTF_8.newDecoder().decode(java.nio.ByteBuffer.wrap(bytes)).toString();
        }
    }
    public static void write(Path path,String text)throws IOException{
        Files.createDirectories(path.getParent());
        Path tmp=path.resolveSibling(path.getFileName()+"."+UUID.randomUUID()+".tmp");
        try{
            Files.writeString(tmp,text,StandardCharsets.UTF_8,StandardOpenOption.CREATE_NEW);
            try{Files.move(tmp,path,StandardCopyOption.REPLACE_EXISTING,StandardCopyOption.ATOMIC_MOVE);}
            catch(AtomicMoveNotSupportedException e){Files.move(tmp,path,StandardCopyOption.REPLACE_EXISTING);}
        }finally{Files.deleteIfExists(tmp);}
    }
}
