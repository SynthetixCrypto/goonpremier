package dev.goonclient.client.modules.visual;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.Module;
import dev.goonclient.client.module.setting.BooleanSetting;
import dev.goonclient.client.module.setting.NumberSetting;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.HumanoidArm;

/** First-person rendering only; arm side mirrors the horizontal offsets. */
public final class ViewModel extends Module {
    private static ViewModel instance;
    private final NumberSetting horizontal = add(new NumberSetting("horizontal", "Horizontal offset", 0, -.5, .5, .025));
    private final NumberSetting vertical = add(new NumberSetting("vertical", "Vertical offset", 0, -.5, .5, .025));
    private final NumberSetting depth = add(new NumberSetting("depth", "Depth offset", 0, -.5, .5, .025));
    private final NumberSetting scale = add(new NumberSetting("scale", "Hand and item size", 100, 50, 150, 5, "%"));
    private final NumberSetting rotation = add(new NumberSetting("rotation", "Hand roll", 0, -45, 45, 1, " deg"));
    private final BooleanSetting offhand = add(new BooleanSetting("offhand", "Apply to offhand", true));
    public ViewModel() {
        super("view_model", "View Model", "Adjust first-person item and hand position, size and roll. Maps keep their native layout.", Category.VISUAL, false);
        instance = this;
    }
    public static void apply(PoseStack pose, InteractionHand hand, HumanoidArm arm) {
        if (instance == null || !instance.isEnabled() || (hand == InteractionHand.OFF_HAND && !instance.offhand.isOn())) return;
        float side = arm == HumanoidArm.RIGHT ? 1 : -1;
        pose.translate(side * instance.horizontal.get(), instance.vertical.get(), instance.depth.get());
        pose.rotateDegrees(Axis.ZP, side * instance.rotation.floatValue());
        float size = instance.scale.floatValue() / 100;
        pose.scale(size, size, size);
    }
}
