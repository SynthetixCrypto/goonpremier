package dev.goonclient.client.modules.inventory;

import dev.goonclient.client.GoonChat;
import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.Module;
import dev.goonclient.client.module.setting.BooleanSetting;
import dev.goonclient.client.module.setting.NumberSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.entity.player.Player;

/** Stops locally initiated mining/melee actions; never changes the selected slot or repairs items. */
public final class ToolSaver extends Module {
    private static ToolSaver instance;
    private final NumberSetting reserve = add(new NumberSetting("reserve", "Stop at remaining durability", 10, 1, 100, 1));
    private final BooleanSetting mining = add(new BooleanSetting("mining", "Protect while mining", true));
    private final BooleanSetting melee = add(new BooleanSetting("melee", "Protect melee attacks", true));
    private final BooleanSetting notify = add(new BooleanSetting("notify", "Explain stopped actions in chat", true));
    private long lastNotice;

    public ToolSaver() {
        super("tool_saver", "Tool Saver", "Stops mining and melee attacks with a nearly broken held item", Category.INVENTORY, false);
        instance = this;
    }

    public static boolean blockAction(Player player, boolean miningAction) {
        var self = instance;
        var mc = Minecraft.getInstance();
        if (self == null || !self.isEnabled() || mc.level == null || player == null || player != mc.player
                || player.getAbilities().instabuild || player.isSpectator()
                || !(miningAction ? self.mining.isOn() : self.melee.isOn())) return false;
        var stack = player.getMainHandItem();
        if (stack.isEmpty() || !stack.isDamageableItem() || stack.has(DataComponents.UNBREAKABLE)) return false;
        int left = Math.max(0, stack.getMaxDamage() - stack.getDamageValue());
        if (left > self.reserve.intValue()) return false;
        long now = System.nanoTime();
        if (self.notify.isOn() && (self.lastNotice == 0 || now - self.lastNotice >= 2_000_000_000L)) {
            self.lastNotice = now;
            GoonChat.info("Tool Saver stopped " + (miningAction ? "mining" : "an attack") + " (" + left
                    + " durability left). Repair or switch the held item, or disable Tool Saver.");
        }
        return true;
    }

    @Override protected void onDisable() { lastNotice = 0; }
}
