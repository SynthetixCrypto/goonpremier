package dev.goonclient.client.cosmetics;

import dev.goonclient.client.gui.render.LogoArt;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.geom.Path2D;
import java.awt.geom.RoundRectangle2D;
import java.io.InputStream;

/**
 * Original cape artwork in the Noir look, as plain Java2D: charcoal cloth with a faint glass sheen, the Goon mark (glass
 * tile and rounded-square G) in the cape's colour, a motif fading up from the hem and a "GOON NATION" line.
 */
public final class CapeArt {
    static final int UV_SCALE = CapeTextures.UV_SCALE, FACE_W = 10 * UV_SCALE, FACE_H = 16 * UV_SCALE;
    static final Color CLOTH_TOP = new Color(0x17191F), CLOTH_BOTTOM = new Color(0x0C0D10), EDGE = new Color(0x101216);
    private static Font brandFont;

    private CapeArt() {}

    private static Color alpha(int rgb, int alpha) {
        return new Color(rgb & 0xFFFFFF | (Math.max(0, Math.min(255, alpha)) << 24), true);
    }

    /** Draws one cape face (10 x 16 UV units) with its top-left at ({@code origin}, one unit down). */
    public static void face(Graphics2D canvas, CapeCatalog.Cape cape, int origin, boolean back) {
        Graphics2D g = (Graphics2D) canvas.create();
        g.translate(origin, UV_SCALE); g.clipRect(0, 0, FACE_W, FACE_H);
        int color = cape.color();
        // Charcoal cloth, a little lighter at the shoulders
        g.setPaint(new GradientPaint(0, 0, CLOTH_TOP, 0, FACE_H, CLOTH_BOTTOM)); g.fillRect(0, 0, FACE_W, FACE_H);
        // Fine pinstripes, barely there, so the cloth reads as fabric
        g.setColor(new Color(255, 255, 255, 6));
        for (int y = 3; y < FACE_H; y += 5) g.drawLine(0, y, FACE_W, y);
        // A diagonal glass sheen across the upper half
        Path2D sheen = new Path2D.Float(); sheen.moveTo(0, 30); sheen.lineTo(FACE_W, -10); sheen.lineTo(FACE_W, 40); sheen.lineTo(0, 80); sheen.closePath();
        g.setPaint(new GradientPaint(0, 0, new Color(255, 255, 255, 14), 0, 80, new Color(255, 255, 255, 0))); g.fill(sheen);

        motif(g, cape.motif(), color);

        // The mark: glass tile with the G in the cape's colour, larger on the back
        int size = back ? 88 : 70;
        int mx = (FACE_W - size) / 2, my = back ? 46 : 54;
        // Soft accent halo behind the tile
        for (int i = 6; i >= 1; i--) {
            g.setColor(alpha(color, 5 + (6 - i) * 2));
            g.fill(new RoundRectangle2D.Float(mx - i * 4, my - i * 4, size + i * 8, size + i * 8, 26 + i * 6, 26 + i * 6));
        }
        g.drawImage(LogoArt.image(size, color), mx, my, null);
        // GOON NATION under the mark
        Font font = brandFont(back ? 13f : 11f);
        if (font != null) {
            g.setFont(font);
            String text = "GOON  NATION";
            int tw = g.getFontMetrics().stringWidth(text);
            g.setColor(alpha(color, 200));
            g.drawString(text, (FACE_W - tw) / 2f, my + size + (back ? 24 : 20));
        }

        // A rounded accent rim and a dashed hem, like the panels in the client
        g.setStroke(new BasicStroke(2));
        g.setColor(alpha(color, 120)); g.draw(new RoundRectangle2D.Float(8, 8, FACE_W - 17, FACE_H - 17, 14, 14));
        g.setColor(alpha(color, 36)); g.draw(new RoundRectangle2D.Float(12, 12, FACE_W - 25, FACE_H - 25, 10, 10));
        g.setColor(alpha(color, 150));
        for (int x = 18; x < FACE_W - 18; x += 8) g.fillRect(x, FACE_H - 22, 4, 2);
        if (back) { g.fillRoundRect(FACE_W / 2 - 18, FACE_H - 15, 36, 3, 3, 3); }
        g.dispose();
    }

    /** Each cape's pattern, in its colour, strongest at the hem and fading towards the shoulders. */
    private static void motif(Graphics2D canvas, int motif, int color) {
        Graphics2D g = (Graphics2D) canvas.create();
        g.setStroke(new BasicStroke(2, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g.setPaint(new GradientPaint(0, 120, alpha(color, 0), 0, FACE_H, alpha(color, 92)));
        switch (motif) {
            case 1 -> { for (int i = 0; i < 4; i++) g.drawLine(26 + i * 36, 168, 26 + i * 36, 228); }
            case 2 -> { for (int r = 40; r < 170; r += 20) g.drawOval(80 - r, 96 - r, r * 2, r * 2); }
            case 3 -> { for (int y = 176; y < 248; y += 16) { g.drawLine(14, y - 16, 80, y); g.drawLine(80, y, 146, y - 16); } }
            case 4 -> { for (int i = -2; i < 6; i++) { Path2D p = new Path2D.Float(); p.moveTo(i * 36, 256); p.lineTo(i * 36 + 72, 146); p.lineTo(i * 36 + 108, 256); g.draw(p); } }
            case 5 -> { g.setStroke(new BasicStroke(8, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND)); for (int i = 0; i < 3; i++) g.drawLine(-30 + i * 46, 236, 54 + i * 46, 166); }
            case 6 -> { for (int i = 0; i < 7; i++) { Path2D p = new Path2D.Float(); p.moveTo(-10, 156 + i * 13); p.curveTo(60, 120 + i * 13, 100, 230 + i * 7, 180, 186 + i * 13); g.draw(p); } }
            case 7 -> { for (int i = 0; i < 8; i++) { g.rotate(Math.PI / 4, 80, 200); g.drawOval(68, 150, 24, 56); } }
            case 8 -> { for (int i = -256; i < 160; i += 20) { g.drawLine(i, 120, i + 136, 256); g.drawLine(i + 136, 120, i, 256); } }
            case 9 -> { for (int i = 0; i < 8; i++) { g.fillRoundRect(18, 168 + i * 9, 124, 3, 3, 3); } }
            case 10 -> {
                // Nation Noir: nested rounded squares, the mark's own shape, rising from the hem
                for (int i = 0; i < 5; i++) { int inset = i * 12; g.drawRoundRect(18 + inset, 150 + inset / 2, 124 - inset * 2, 96, 22, 22); }
            }
            default -> { }
        }
        g.dispose();
    }

    private static Font brandFont(float size) {
        if (brandFont == null) {
            try (InputStream in = CapeArt.class.getResourceAsStream("/assets/goonclient/font/inter-bold.ttf")) {
                brandFont = in == null ? new Font(Font.SANS_SERIF, Font.BOLD, 12) : Font.createFont(Font.TRUETYPE_FONT, in);
            } catch (Exception e) {
                brandFont = new Font(Font.SANS_SERIF, Font.BOLD, 12);
            }
        }
        return brandFont.deriveFont(size);
    }
}
