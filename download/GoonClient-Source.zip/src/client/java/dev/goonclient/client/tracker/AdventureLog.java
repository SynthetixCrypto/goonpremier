package dev.goonclient.client.tracker;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.goonclient.Goon;
import dev.goonclient.client.config.ConfigManager;
import dev.goonclient.client.gui.Ui;
import dev.goonclient.client.modules.world.WorldHuds;
import dev.goonclient.client.waypoint.WaypointManager;
import java.io.IOException;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import net.minecraft.advancements.AdvancementHolder;
import net.minecraft.advancements.AdvancementType;
import net.minecraft.advancements.DisplayInfo;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.item.ItemStack;

/**
 * A diary of your adventure in each world or server: deaths, bosses, rare finds, advancements, trips between
 * dimensions and play sessions. Saved per world in config/goonclient/adventure/.
 */
public final class AdventureLog {
	private static final int MAX_ENTRIES = 2000;
	private static final long MERGE_DROPS_MS = 60_000;

	public enum Type {
		DEATH("Deaths", Ui.BAD),
		BOSS("Bosses", 0xFFFF8A3D),
		DROP("Rare finds", 0xFF4DA3FF),
		ADVANCEMENT("Advancements", Ui.WARN),
		TRAVEL("Travel", 0xFF9D8CFF),
		SESSION("Sessions", Ui.MUTED);

		private final String label;
		private final int color;

		Type(String label, int color) {
			this.label = label;
			this.color = color;
		}

		public String label() {
			return label;
		}

		public int color() {
			return color;
		}
	}

	public record Entry(Type type, String title, String detail, long time, String dimension, int x, int y, int z, boolean hasPosition, int count) {
		public String place() {
			return hasPosition ? x + " " + y + " " + z + "  " + WorldHuds.dimensionName(dimension) : "";
		}
	}

	private static final List<Entry> ENTRIES = new ArrayList<>();
	private static String worldKey;
	private static String worldName = "";
	private static long sessionStart;
	/** Asks the Adventure Log module whether to take a screenshot for this kind of event. */
	private static Consumer<Type> screenshotHook = type -> {
	};
	/** The Adventure Log module turns recording on and off. */
	private static BooleanSupplier enabled = () -> true;

	private AdventureLog() {
	}

	public static void setScreenshotHook(Consumer<Type> hook) {
		screenshotHook = hook;
	}

	public static void setEnabledCheck(BooleanSupplier check) {
		enabled = check;
	}

	public static void onJoin(Minecraft mc) {
		worldKey = WaypointManager.worldKey();
		worldName = WaypointManager.worldName();
		sessionStart = System.currentTimeMillis();
		ENTRIES.clear();
		Path file = file();
		if (file == null || !Files.exists(file)) {
			return;
		}
		try (Reader reader = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
			for (JsonElement element : JsonParser.parseReader(reader).getAsJsonArray()) {
				JsonObject o = element.getAsJsonObject();
				ENTRIES.add(new Entry(Type.valueOf(o.get("type").getAsString()), o.get("title").getAsString(), o.get("detail").getAsString(),
					o.get("time").getAsLong(), o.has("dimension") ? o.get("dimension").getAsString() : "", o.has("x") ? o.get("x").getAsInt() : 0,
					o.has("y") ? o.get("y").getAsInt() : 0, o.has("z") ? o.get("z").getAsInt() : 0, o.has("x"),
					o.has("count") ? o.get("count").getAsInt() : 1));
			}
		} catch (IOException | RuntimeException e) {
			Goon.LOGGER.error("Couldn't read the adventure log {}", file, e);
		}
	}

	/** Closes the session: one entry with how long you played and what happened. */
	public static void onLeave() {
		if (worldKey == null) {
			return;
		}
		long played = System.currentTimeMillis() - sessionStart;
		if (played > 60_000) {
			String detail = SessionStats.mobsKilled() + " kills, " + SessionStats.deaths() + " deaths, " + SessionStats.blocksMined() + " blocks mined, "
				+ SessionStats.formatDistance(SessionStats.distance()) + " travelled";
			add(new Entry(Type.SESSION, "Played for " + SessionStats.formatDuration(played), detail, System.currentTimeMillis(), "", 0, 0, 0, false, 1), false);
		}
		worldKey = null;
		ENTRIES.clear();
	}

	public static boolean active() {
		return worldKey != null;
	}

	public static String worldName() {
		return worldName;
	}

	public static List<Entry> entries() {
		return Collections.unmodifiableList(ENTRIES);
	}

	/** Empties this world's log (used by the dev screenshots so test runs don't pile up). */
	public static void clear() {
		ENTRIES.clear();
		save();
	}

	public static void add(Type type, String title, String detail, String dimension, BlockPos pos) {
		add(new Entry(type, title, detail, System.currentTimeMillis(), dimension, pos.getX(), pos.getY(), pos.getZ(), true, 1), true);
	}

	private static void add(Entry entry, boolean screenshot) {
		if (worldKey == null || !enabled.getAsBoolean()) {
			return;
		}
		ENTRIES.add(entry);
		while (ENTRIES.size() > MAX_ENTRIES) {
			ENTRIES.remove(0);
		}
		save();
		if (screenshot) {
			screenshotHook.accept(entry.type());
		}
	}

	public static void onDeath(BlockPos pos, String dimension, String cause) {
		add(Type.DEATH, "Died", cause.isEmpty() ? "Cause unknown" : cause, dimension, pos);
	}

	public static void onBossKilled(String boss, BlockPos pos, String dimension) {
		add(Type.BOSS, "Defeated " + boss, "Boss fight", dimension, pos);
	}

	public static void onTravel(String toDimension, BlockPos pos) {
		add(Type.TRAVEL, "Entered " + WorldHuds.dimensionName(toDimension), "", toDimension, pos);
	}

	/** Valuable pickups; repeats of the same item within a minute are merged into one line ("Found 7 Diamonds"). */
	public static void onPickup(ItemStack stack, int amount) {
		Minecraft mc = Minecraft.getInstance();
		if (worldKey == null || !enabled.getAsBoolean() || mc.player == null || mc.level == null || !LootTracker.isValuable(stack)) {
			return;
		}
		String name = stack.getHoverName().getString();
		long now = System.currentTimeMillis();
		if (!ENTRIES.isEmpty()) {
			Entry last = ENTRIES.get(ENTRIES.size() - 1);
			if (last.type() == Type.DROP && last.detail().equals(name) && now - last.time() < MERGE_DROPS_MS) {
				int total = last.count() + amount;
				ENTRIES.set(ENTRIES.size() - 1, new Entry(Type.DROP, "Found " + name + " ×" + total, name, now, last.dimension(),
					last.x(), last.y(), last.z(), true, total));
				save();
				return;
			}
		}
		BlockPos pos = mc.player.blockPosition();
		add(new Entry(Type.DROP, "Found " + name + (amount > 1 ? " ×" + amount : ""), name, now, mc.level.dimension().identifier().toString(),
			pos.getX(), pos.getY(), pos.getZ(), true, amount), true);
	}

	/** Called when the game shows an advancement toast, i.e. you just earned it. */
	public static void onAdvancement(AdvancementHolder holder) {
		Minecraft mc = Minecraft.getInstance();
		if (worldKey == null || mc.player == null || mc.level == null) {
			return;
		}
		DisplayInfo display = holder.value().display().orElse(null);
		if (display == null) {
			return;
		}
		String kind = display.type() == AdvancementType.CHALLENGE ? "Challenge complete" : display.type() == AdvancementType.GOAL ? "Goal reached" : "Advancement made";
		add(Type.ADVANCEMENT, display.title().getString(), kind + ": " + display.description().getString(), mc.level.dimension().identifier().toString(), mc.player.blockPosition());
	}

	private static Path file() {
		return worldKey == null ? null : ConfigManager.dir().resolve("adventure").resolve(worldKey + ".json");
	}

	private static void save() {
		Path file = file();
		if (file == null) {
			return;
		}
		JsonArray array = new JsonArray();
		for (Entry entry : ENTRIES) {
			JsonObject o = new JsonObject();
			o.addProperty("type", entry.type().name());
			o.addProperty("title", entry.title());
			o.addProperty("detail", entry.detail());
			o.addProperty("time", entry.time());
			if (entry.hasPosition()) {
				o.addProperty("dimension", entry.dimension());
				o.addProperty("x", entry.x());
				o.addProperty("y", entry.y());
				o.addProperty("z", entry.z());
			}
			if (entry.count() > 1) {
				o.addProperty("count", entry.count());
			}
			array.add(o);
		}
		ConfigManager.writeAtomically(file, ConfigManager.GSON.toJson(array));
	}
}
