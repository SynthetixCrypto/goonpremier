package dev.goonclient.client.modules.visual;

import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.Module;
import dev.goonclient.client.module.setting.ModeSetting;
import dev.goonclient.client.module.setting.NumberSetting;
import java.util.Set;
import net.minecraft.client.Minecraft;
import net.minecraft.world.attribute.EnvironmentAttribute;
import net.minecraft.world.attribute.EnvironmentAttributes;
import net.minecraft.world.clock.ClockInstance;
import net.minecraft.world.clock.ClockManager;
import net.minecraft.world.clock.WorldClocks;

/** An alternate clock exclusively for visual environment tracks. The server clock and gameplay tracks stay real. */
public final class TimeChanger extends Module {
	private static TimeChanger instance;
	private static final Set<EnvironmentAttribute<?>> VISUALS = Set.of(EnvironmentAttributes.SKY_COLOR, EnvironmentAttributes.FOG_COLOR,
		EnvironmentAttributes.SUNRISE_SUNSET_COLOR, EnvironmentAttributes.CLOUD_COLOR, EnvironmentAttributes.SUN_ANGLE,
		EnvironmentAttributes.MOON_ANGLE, EnvironmentAttributes.STAR_ANGLE, EnvironmentAttributes.STAR_BRIGHTNESS,
		EnvironmentAttributes.SKY_LIGHT_COLOR, EnvironmentAttributes.SKY_LIGHT_FACTOR, EnvironmentAttributes.AMBIENT_LIGHT_COLOR);
	private final ModeSetting mode = add(new ModeSetting("time", "Time of day", "Day", "Day", "Sunrise", "Sunset", "Night", "Custom"));
	private final NumberSetting custom = add(new NumberSetting("custom_ticks", "Custom time (ticks)", 6000, 0, 23900, 100));
	private int previous = -1;

	public TimeChanger() {
		super("time_changer", "Time Changer", "Choose your local sky and daylight. Server time, sleeping, spawns and World Time HUD stay real. Opt-in.", Category.VISUAL, false);
		instance = this;
	}

	public static boolean active() {
		return instance != null && instance.isEnabled();
	}

	public static int ticks() {
		if (instance == null) return 6000;
		return switch (instance.mode.get()) {
			case "Sunrise" -> 0;
			case "Sunset" -> 12000;
			case "Night" -> 18000;
			case "Custom" -> instance.custom.intValue();
			default -> 6000;
		};
	}

	public static boolean visual(EnvironmentAttribute<?> attribute) {
		return VISUALS.contains(attribute);
	}

	public static ClockManager visualClock(ClockManager original) {
		return definition -> {
			ClockInstance real = original.getInstance(definition);
			if (!definition.is(WorldClocks.OVERWORLD)) return real;
			// Every sky, fog and light sample asks for the clock; reuse one wrapper per real clock instead of allocating each time
			Wrapped cached = wrapped;
			if (cached == null || cached.real() != real) {
				cached = new Wrapped(real, new ClockInstance() {
					@Override public long totalTicks() { return active() ? Math.floorDiv(real.totalTicks(), 24000) * 24000 + ticks() : real.totalTicks(); }
					@Override public float partialTick() { return active() ? 0 : real.partialTick(); }
					@Override public float rate() { return active() ? 0 : real.rate(); }
					@Override public boolean isPaused() { return active() || real.isPaused(); }
				});
				wrapped = cached;
			}
			return cached.visual();
		};
	}

	/** The last real overworld clock and its visual wrapper, swapped as one so readers never pair them wrongly. */
	private record Wrapped(ClockInstance real, ClockInstance visual) {
	}

	private static volatile Wrapped wrapped;

	@Override
	public void onTick(Minecraft mc) {
		if (previous != ticks()) {
			previous = ticks();
			refresh();
		}
	}

	@Override protected void onEnable() { refresh(); }
	@Override protected void onDisable() { refresh(); }

	private static void refresh() {
		var level = Minecraft.getInstance().level;
		if (level != null) level.environmentAttributes().invalidateTickCache();
	}
}
