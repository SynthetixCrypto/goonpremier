package dev.goonclient.client.dev;

import com.mojang.blaze3d.platform.InputConstants;
import dev.goonclient.Goon;
import dev.goonclient.client.gui.ClickGuiScreen;
import dev.goonclient.client.module.Module;
import dev.goonclient.client.module.ModuleManager;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.stream.Collectors;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.input.MouseButtonInfo;

/**
 * Dev-tour regression checks exercise the actual input handlers using the screen's computed layout. The browser view
 * (centered card grid) and a module's settings page have separate layouts, so each check picks the one on screen.
 */
public final class ClickGuiChecks {
	private ClickGuiChecks() {}
	private static float field(ClickGuiScreen screen, String name) {
		try {
            Field field = ClickGuiScreen.class.getDeclaredField(name); field.setAccessible(true); return field.getFloat(screen); }
		catch (Exception e) { throw new IllegalStateException(e); }
	}
	private static boolean inSettings(ClickGuiScreen screen) {
		try { Field field = ClickGuiScreen.class.getDeclaredField("settingsFor"); field.setAccessible(true); return field.get(screen) != null; }
		catch (Exception e) { throw new IllegalStateException(e); }
	}
	private static void call(ClickGuiScreen screen, String name) {
		try { Method method = ClickGuiScreen.class.getDeclaredMethod(name); method.setAccessible(true); method.invoke(screen); }
		catch (Exception e) { throw new IllegalStateException(e); }
	}
	private static double x(ClickGuiScreen screen, float value) { return value * field(screen,"s"); }
	private static double y(ClickGuiScreen screen, float value) { return value * field(screen,"s"); }
	private static MouseButtonEvent event(ClickGuiScreen screen, float x, float y) {
		return new MouseButtonEvent(x(screen,x), y(screen,y), new MouseButtonInfo(InputConstants.MOUSE_BUTTON_LEFT,0));
	}
	    /** Exercise the card's two real actions separately; called on adjacent rendered ticks in the dev tour. */
    private static Object objectField(ClickGuiScreen screen,String name) {
        try {Field f=ClickGuiScreen.class.getDeclaredField(name);f.setAccessible(true);return f.get(screen);}
        catch(Exception e){throw new IllegalStateException(e);}
    }
    private static Module cardModule(ClickGuiScreen screen) {
        try {
            Method read=ClickGuiScreen.class.getDeclaredMethod("visibleModules");read.setAccessible(true);
            @SuppressWarnings("unchecked") java.util.List<Module> shown=(java.util.List<Module>)read.invoke(screen);
            return shown.stream().filter(m->m.id().equals("coordinates")).findFirst().orElseThrow();
        } catch(Exception e){throw new IllegalStateException(e);}
    }
    private static MouseButtonEvent cardButton(ClickGuiScreen screen,Module module,float fromBottom) {
        try {
            Method read=ClickGuiScreen.class.getDeclaredMethod("visibleModules");read.setAccessible(true);
            @SuppressWarnings("unchecked") java.util.List<Module> shown=(java.util.List<Module>)read.invoke(screen);
            int index=shown.indexOf(module), cols=3;
            float cardW=(field(screen,"gridRight")-field(screen,"gridLeft")-5-8*(cols-1))/cols;
            float px=field(screen,"gridLeft")+index%cols*(cardW+8)+cardW/2;
            float py=field(screen,"gridTop")+index/cols*98-field(screen,"gridScroll")+90-fromBottom;
            return event(screen,px,py);
        } catch(Exception e){throw new IllegalStateException(e);}
    }
    public static void cardOptions(ClickGuiScreen screen) {
        Module module=cardModule(screen);boolean before=module.isEnabled();
        screen.mouseClicked(cardButton(screen,module,21),false);
        if(objectField(screen,"settingsFor")!=module||module.isEnabled()!=before)throw new IllegalStateException("Card Options did not open settings independently");
        call(screen,"leaveSettings");
        Goon.LOGGER.info("Dev card controls: Options opens settings without toggling");
    }
    public static void cardToggle(ClickGuiScreen screen) {
        Module module=cardModule(screen);boolean before=module.isEnabled();
        try {
            screen.mouseClicked(cardButton(screen,module,7),false);
            if(inSettings(screen)||module.isEnabled()==before)throw new IllegalStateException("Card state button did not toggle independently");
        } finally {module.setEnabled(before);}
        Goon.LOGGER.info("Dev card controls: state button toggles without opening settings; original state restored");
    }


	public static void all(ClickGuiScreen screen) {
		try { Field selected=ClickGuiScreen.class.getDeclaredField("selected"); selected.setAccessible(true); selected.set(null,null); call(screen,"changeView"); }
		catch(Exception e) { throw new IllegalStateException(e); }
	}
	public static void bottom(ClickGuiScreen screen) {
		if (inSettings(screen)) {
			screen.mouseScrolled(x(screen,field(screen,"contentLeft")+40),y(screen,field(screen,"contentTop")+40),0,-10000);
		} else {
			screen.mouseScrolled(x(screen,field(screen,"gridLeft")+40),y(screen,field(screen,"gridTop")+40),0,-10000);
		}
	}
	public static void middle(ClickGuiScreen screen) {
		if (inSettings(screen)) {
			screen.mouseScrolled(x(screen,field(screen,"contentLeft")+40),y(screen,field(screen,"contentTop")+40),0,3);
		} else {
			screen.mouseScrolled(x(screen,field(screen,"gridLeft")+40),y(screen,field(screen,"gridTop")+40),0,3);
		}
	}
	public static void verify(ClickGuiScreen screen) {
		Map<Module,Boolean> enabled=ModuleManager.all().stream().collect(Collectors.toMap(m->m,Module::isEnabled));
		if (inSettings(screen)) {
			float before=field(screen,"scrollTarget");
			screen.mouseScrolled(x(screen,field(screen,"px")+25),y(screen,field(screen,"py")+85),0,-10000);
			if(before!=field(screen,"scrollTarget")) Goon.LOGGER.warn("Dev ClickGUI: Sidebar wheel scrolled settings");
			screen.mouseScrolled(x(screen,field(screen,"contentLeft")+35),y(screen,field(screen,"py")+30),0,10000);
			if(before!=field(screen,"scrollTarget")) Goon.LOGGER.warn("Dev ClickGUI: Header wheel scrolled settings");
			screen.mouseClicked(event(screen,field(screen,"contentLeft")+25,field(screen,"py")+46),false);
			screen.mouseClicked(event(screen,field(screen,"contentLeft")+25,field(screen,"contentBottom")+4),false);
		} else {
			float prior=field(screen,"gridTarget"), cx=field(screen,"gridLeft")+25;
            screen.mouseScrolled(x(screen,cx),y(screen,field(screen,"gridTop")-5),0,-1000);
            screen.mouseScrolled(x(screen,cx),y(screen,field(screen,"gridBottom")+5),0,-1000);
            screen.mouseScrolled(x(screen,field(screen,"winX")-5),y(screen,field(screen,"gridTop")+20),0,-1000);
            if(prior!=field(screen,"gridTarget"))throw new IllegalStateException("Header/footer/outside wheel scrolled the cards");
            // Cards are clipped to the grid: the strips just above and below it (header and footer of the window) must not
			// reach a card that is partly scrolled out of view.
			float left=field(screen,"gridLeft")+25;
			screen.mouseClicked(event(screen,left,field(screen,"gridTop")-3),false);
			screen.mouseClicked(event(screen,left,field(screen,"gridBottom")+3),false);
		}
		// Restore anything a stray click toggled and report it instead of stopping the tour
		for(var entry:enabled.entrySet()) if(entry.getKey().isEnabled()!=entry.getValue()) {
			Goon.LOGGER.warn("Dev ClickGUI: click outside the list toggled {}", entry.getKey().id());
			entry.getKey().loadEnabled(entry.getValue());
		}
		Goon.LOGGER.info("Dev ClickGUI: hidden-region clicks and wheel isolation checked at GUI scale {} ({})", net.minecraft.client.Minecraft.getInstance().getWindow().getGuiScale(), inSettings(screen) ? "settings" : "grid");
	}
	public static void dragTop(ClickGuiScreen screen) {
		if (inSettings(screen)) {
			float bx=field(screen,"px")+field(screen,"pw")-6, top=field(screen,"contentTop"), bottom=field(screen,"contentBottom");
			MouseButtonEvent press=event(screen,bx,bottom-3); screen.mouseClicked(press,false);
			MouseButtonEvent drag=event(screen,bx,top-100); screen.mouseDragged(drag,0,-100); screen.mouseReleased(drag);
			if(field(screen,"scrollTarget")!=0) { Goon.LOGGER.warn("Dev ClickGUI: Scrollbar drag did not reach top"); return; }
		} else {
			float bx=field(screen,"gridRight")-1.7f, top=field(screen,"gridTop"), bottom=field(screen,"gridBottom");
			MouseButtonEvent press=event(screen,bx,bottom-3); screen.mouseClicked(press,false);
			MouseButtonEvent drag=event(screen,bx,top-100); screen.mouseDragged(drag,0,-100); screen.mouseReleased(drag);
			if(field(screen,"gridTarget")!=0) { Goon.LOGGER.warn("Dev ClickGUI: Grid scrollbar drag did not reach top"); return; }
		}
		Goon.LOGGER.info("Dev ClickGUI: scrollbar drag reaches exact top");
	}
}
