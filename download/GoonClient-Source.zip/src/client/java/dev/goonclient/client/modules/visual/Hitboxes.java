package dev.goonclient.client.modules.visual;

import dev.goonclient.client.gui.Ui;
import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.Module;
import dev.goonclient.client.module.setting.BooleanSetting;
import dev.goonclient.client.module.setting.NumberSetting;
import dev.goonclient.client.render.WorldRender;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.gizmos.GizmoStyle;
import net.minecraft.gizmos.Gizmos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;

/** Draws real collision boxes; never changes reach, collisions or attack targeting. */
public final class Hitboxes extends Module implements WorldRender.Renderable {
    private final BooleanSetting mobs = add(new BooleanSetting("mobs", "Mobs and animals", true));
    private final BooleanSetting players = add(new BooleanSetting("players", "Other players", false));
    private final BooleanSetting items = add(new BooleanSetting("items", "Dropped items", false));
    private final BooleanSetting projectiles = add(new BooleanSetting("projectiles", "Projectiles", true));
    private final NumberSetting range = add(new NumberSetting("range", "Maximum distance", 24, 4, 48, 1, " m"));
    private final NumberSetting maximum = add(new NumberSetting("maximum", "Maximum boxes", 32, 4, 64, 1));
    private final NumberSetting width = add(new NumberSetting("width", "Line width", 1.5, 1, 3, .25));
    private final List<Entity> visible = new ArrayList<>();
    private ClientLevel level;
    public Hitboxes() { super("hitboxes", "Hitboxes", "Draw the real bounds of visible mobs, projectiles, items and optional players", Category.VISUAL, false); }
    @Override protected void onDisable() { visible.clear(); level = null; }
    private boolean allowed(Entity entity) {
        if (entity instanceof Player) return players.isOn();
        if (entity instanceof ArmorStand) return false;
        if (entity instanceof LivingEntity) return mobs.isOn();
        if (entity instanceof ItemEntity) return items.isOn();
        return entity instanceof Projectile && projectiles.isOn();
    }
    @Override public void onTick(Minecraft mc) {
        visible.clear(); level = mc.level;
        if (mc.level == null || mc.player == null) return;
        int inspected = 0;
        for (Entity entity : mc.level.entitiesForRendering()) {
            if (++inspected > 2048) break;
            if (entity != mc.player && entity.isAlive() && !entity.isInvisible() && !entity.isSpectator() && allowed(entity)
                && entity.distanceToSqr(mc.player) <= range.get() * range.get()) visible.add(entity);
        }
        visible.sort(Comparator.comparingDouble(e -> e.distanceToSqr(mc.player)));
        if (visible.size() > maximum.intValue()) visible.subList(maximum.intValue(), visible.size()).clear();
        visible.removeIf(e -> !mc.player.hasLineOfSight(e));
    }
    @Override public void renderWorld(Minecraft mc, Camera camera, float partialTick) {
        if (mc.player == null || level != mc.level) return;
        for (Entity entity : visible) {
            if (!entity.isAlive() || entity.isInvisible() || !allowed(entity)) continue;
            int color = entity instanceof ItemEntity ? Ui.WARN : entity instanceof Projectile ? Ui.TEXT : Ui.accent();
            var movement = entity.getPosition(partialTick).subtract(entity.position());
            Gizmos.cuboid(entity.getBoundingBox().move(movement), GizmoStyle.stroke(Ui.withAlpha(color, .8f), width.floatValue()));
        }
    }
}
