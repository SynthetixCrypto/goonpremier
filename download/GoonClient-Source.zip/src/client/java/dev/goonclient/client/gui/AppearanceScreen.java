package dev.goonclient.client.gui;

import net.minecraft.client.gui.screens.Screen;

/** Existing appearance entry points open the unified live theme gallery. */
public final class AppearanceScreen extends StudioScreen {
    public AppearanceScreen(Screen parent) { super(parent,Page.THEMES); }
}
