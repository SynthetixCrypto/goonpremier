package dev.goonclient.client.mixin.xaero;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import dev.goonclient.client.hud.HudLayout;
import dev.goonclient.client.hud.HudModule;
import dev.goonclient.client.modules.hud.MinimapHud;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.network.chat.Component;
import org.joml.Vector2f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(targets = "xaero.hud.minimap.info.render.InfoDisplayRenderer", remap = false)
public class XaeroInfoMixin {
	@WrapOperation(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/GuiGraphicsExtractor;text(Lnet/minecraft/client/gui/Font;Lnet/minecraft/network/chat/Component;IIIZ)V"))
	private void goonclient$reserveInfo(GuiGraphicsExtractor g, Font font, Component text, int x, int y, int color, boolean shadow, Operation<Void> original) {
		if (MinimapHud.integrated()) {
			Vector2f start = g.pose().transformPosition(x - 1, y - 1, new Vector2f());
			Vector2f end = g.pose().transformPosition(x + font.width(text) + 1, y + font.lineHeight + 1, new Vector2f());
			HudModule.reserveNative(new HudLayout.Rect((int) Math.floor(start.x), (int) Math.floor(start.y),
				(int) Math.ceil(end.x - start.x), (int) Math.ceil(end.y - start.y)));
		}
		original.call(g, font, text, x, y, color, shadow);
	}
}
