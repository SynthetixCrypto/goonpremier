package dev.goonclient.client;

import dev.goonclient.Goon;
import dev.goonclient.client.config.ConfigManager;
import dev.goonclient.client.dev.DevSnapshots;
import dev.goonclient.client.hud.HudRenderer;
import dev.goonclient.client.module.ModuleManager;
import dev.goonclient.client.modules.inventory.ContainerPreview;
import dev.goonclient.client.modules.inventory.ContainerPreviewComponent;
import dev.goonclient.client.modules.visual.CustomCrosshair;
import dev.goonclient.client.render.WorldRender;
import dev.goonclient.client.tracker.AdventureLog;
import dev.goonclient.client.tracker.LootTracker;
import dev.goonclient.client.tracker.SessionStats;
import dev.goonclient.client.waypoint.WaypointManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.ClientTooltipComponentCallback;
import net.fabricmc.fabric.api.event.client.player.ClientPlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.world.InteractionResult;

public class GoonClient implements ClientModInitializer {
	private static Screen pendingScreen;

	@Override
	public void onInitializeClient() {
		ModuleManager.init();
		ConfigManager.load();
		dev.goonclient.client.cosmetics.Cosmetics.init();
		dev.goonclient.client.social.DiscordPresence.init();
		GoonKeys.init();
		dev.goonclient.client.input.ModuleBindings.load();
		GoonCommands.register();
		HudRenderer.register();
		WorldRender.register();
		CustomCrosshair.register();
        dev.goonclient.client.modules.inventory.ItemDetails.register();

		// Test and dev runs (gradle runClient) start silent: the owner is often studying while builds are checked.
		// Pass -Dgoonclient.sound=true to hear them. Never touches an installed game.
		ClientLifecycleEvents.CLIENT_STARTED.register(client -> {
			if (net.fabricmc.loader.api.FabricLoader.getInstance().isDevelopmentEnvironment() && !Boolean.getBoolean("goonclient.sound")) {
				client.options.getSoundSourceOptionInstance(net.minecraft.sounds.SoundSource.MASTER).set(0.0);
			}
		});

		ClientTickEvents.END_CLIENT_TICK.register(GoonClient::tick);
		ClientLifecycleEvents.CLIENT_STOPPING.register(client -> { ConfigManager.save(); dev.goonclient.client.cosmetics.Cosmetics.stop(); dev.goonclient.client.social.DiscordPresence.stop(); });

		ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
			SessionStats.reset();
            dev.goonclient.client.modules.utility.TotemAlerts.reset();
            dev.goonclient.client.modules.utility.ServerWatch.reset();
			LootTracker.reset();
			WaypointManager.onJoin(client);
			AdventureLog.onJoin(client);
		});
		ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
			dev.goonclient.client.cosmetics.Cosmetics.disconnect();
            dev.goonclient.client.modules.utility.TotemAlerts.reset();
            dev.goonclient.client.modules.utility.ServerWatch.reset();
			dev.goonclient.client.tracker.ClickHistory.clear();
			dev.goonclient.client.modules.combat.HitDistance.clear();
			dev.goonclient.client.modules.hud.FeedbackHud.clear();
			AdventureLog.onLeave();
			WaypointManager.onLeave();
		});

		ClientPlayerBlockBreakEvents.AFTER.register((level, player, pos, state) -> SessionStats.onBlockBroken(state));
		AttackEntityCallback.EVENT.register((player, level, hand, entity, hitResult) -> {
			if (level.isClientSide()) {
				SessionStats.onAttack(entity);
				dev.goonclient.client.modules.combat.HitDistance.attacked(entity, hitResult);
			}
			return InteractionResult.PASS;
		});

		ClientTooltipComponentCallback.EVENT.register(data ->
			data instanceof ContainerPreview.Tooltip tooltip ? new ContainerPreviewComponent(tooltip) : null);

		dev.goonclient.client.dev.DevUpdateChecks.init();
		DevSnapshots.init();
		dev.goonclient.client.dev.DevFilmCapture.init();
		dev.goonclient.client.dev.DevUiPreview.init();
		dev.goonclient.client.dev.DevMenuPreview.init();
		Goon.LOGGER.info("Goon Client loaded");
	}

	/** Opens a screen on the next tick, e.g. from a chat command (chat closes itself right after). */
	public static void openNextTick(Screen screen) {
		pendingScreen = screen;
	}

	private static void tick(Minecraft mc) {
		if (pendingScreen != null) {
			mc.gui.setScreen(pendingScreen);
			pendingScreen = null;
		}
		dev.goonclient.client.cosmetics.Cosmetics.tick(mc);
		GoonKeys.tick(mc);
		ModuleManager.tick(mc);
		SessionStats.tick(mc);
		ConfigManager.tick();
	}
}
