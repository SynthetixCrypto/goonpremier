package dev.goonclient.client.gui.render;

import com.mojang.blaze3d.Blaze3D;
import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.blaze3d.platform.Window;
import dev.goonclient.Goon;
import dev.goonclient.client.gui.Ui;
import dev.goonclient.client.modules.utility.Interface;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;
import java.util.Random;
import java.util.concurrent.CompletableFuture;
import javax.imageio.ImageIO;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/**
 * Menu backgrounds in place of the vanilla panorama: the animated Goon background (drifting light in the accent
 * colour, rising pixels, film grain) or the player's own image from config/goonclient/backgrounds.
 */
public final class Backdrop {
	private static final long START = System.nanoTime();
	private static final int PARTICLES = 72;
	private static final int MAX_IMAGE_WIDTH = 2560;

	private static SmoothTexture glow;
	private static SmoothTexture grain;
	private static final float[][] PARTICLE_SEEDS = seeds();
	private static float[] ALPHA_BY_DISTANCE;

	// Custom image state
	private static SmoothTexture custom;
	private static int customWidth;
	private static int customHeight;
	private static Path customFile;
	private static long customStamp;
	private static long lastScan;
	private static CompletableFuture<Decoded> loading;
	private static String customStatus;

	private Backdrop() {
	}

	/** Where players drop their own background images. */
	public static Path folder() {
		return FabricLoader.getInstance().getConfigDir().resolve("goonclient").resolve("backgrounds");
	}

	public static void openFolder() {
		try {
			Files.createDirectories(folder());
		} catch (IOException ignored) {
			// Opening will show the error
		}
		Blaze3D.openPath(folder());
		// Look again soon, so a freshly dropped image shows up without restarting
		lastScan = 0;
	}

	/** True when menus should use a Goon Client background instead of the vanilla panorama. */
	public static boolean replacesPanorama() {
		return !Interface.menuBackground().equals("Panorama");
	}

	/** A short note for the main menu when "Custom image" is picked but there's nothing to show yet, else null. */
	public static String customStatus() {
		return Interface.menuBackground().equals("Custom image") ? customStatus : null;
	}

	/** Draws the chosen background over the whole screen. Returns false for "Panorama" (let vanilla draw it). */
	public static boolean draw(GuiGraphicsExtractor g) {
		if (!replacesPanorama()) {
			return false;
		}
		int w = g.guiWidth();
		int h = g.guiHeight();
		if (Interface.menuBackground().equals("Solid")) {
			Shapes.rect(g, 0, 0, w, h, 0xFF0A0B0D);
			return true;
		}
		// Mouse from -1 to 1 on each axis, for a little parallax
		Minecraft mc = Minecraft.getInstance();
		Window window = mc.getWindow();
		float mx = (float) (mc.mouseHandler.xpos() / Math.max(1, window.getScreenWidth())) * 2f - 1f;
		float my = (float) (mc.mouseHandler.ypos() / Math.max(1, window.getScreenHeight())) * 2f - 1f;
		mx = Math.max(-1f, Math.min(1f, mx));
		my = Math.max(-1f, Math.min(1f, my));
		float t = (System.nanoTime() - START) / 1_000_000_000f;
		if (Interface.menuBackground().equals("Custom image") && drawCustom(g, w, h, mx, my)) {
			return true;
		}
		drawGoon(g, w, h, mx, my, t);
		return true;
	}

	// ---- Goon background -----------------------------------------------------------------------------------

	private static void drawGoon(GuiGraphicsExtractor g, int w, int h, float mx, float my, float t) {
		int accent = Interface.accent();
		g.fill(0, 0, w, h, 0xFF0A0B0D);
		float big = Math.max(w, h);
		// Slow light: two pools in the accent colour and one cool neutral, each on its own drifting path
		blob(g, w * (0.74f + 0.07f * (float) Math.sin(t * 0.071f)) - mx * 10, h * (0.30f + 0.09f * (float) Math.cos(t * 0.053f)) - my * 8,
			big * 0.70f, accent, 0.30f);
		blob(g, w * (0.10f + 0.06f * (float) Math.cos(t * 0.061f + 1.3f)) - mx * 6, h * (0.98f + 0.06f * (float) Math.sin(t * 0.083f)) - my * 5,
			big * 0.55f, accent, 0.20f);
		blob(g, w * (0.48f + 0.10f * (float) Math.sin(t * 0.044f + 2.1f)) - mx * 4, h * (0.04f + 0.05f * (float) Math.cos(t * 0.097f)) - my * 3,
			big * 0.45f, 0xFF6F8CA8, 0.13f);

		// Rising pixels in three depth layers: far ones small, slow and faint
		for (int layer = 0; layer < 3; layer++) {
			QuadBatch white = new QuadBatch(PARTICLES);
			QuadBatch tinted = new QuadBatch(PARTICLES);
			QuadBatch halos = new QuadBatch(PARTICLES);
			float depth = 0.45f + layer * 0.3f;
			for (int i = layer; i < PARTICLES; i += 3) {
				float[] seed = PARTICLE_SEEDS[i];
				float speed = (4f + seed[1] * 9f) * depth;
				float span = h + 24;
				float y = h + 12 - ((t * speed + seed[2] * span) % span) - my * 10 * depth;
				float x = seed[0] * w + (float) Math.sin(t * 0.35f + i) * 5f * depth - mx * 14 * depth;
				float size = (0.9f + seed[3] * 1.4f) * depth;
				int[] r = Px.rect(g, x, y, x + size, y + size);
				// At least one screen pixel, so far particles don't vanish
				r[2] = Math.max(r[2], r[0] + 1);
				r[3] = Math.max(r[3], r[1] + 1);
				// Each one twinkles at its own pace; the alpha comes from where it samples the soft disc
				float twinkle = 0.45f + 0.55f * (0.5f + 0.5f * (float) Math.sin(t * (0.7f + seed[3] * 1.6f) + seed[0] * 40f));
				float u = uvForAlpha(twinkle);
				boolean mint = seed[4] < 0.34f;
				(mint ? tinted : white).add(r[0], r[1], r[2], r[3], u, 0.5f, u, 0.5f);
				if (mint && layer > 0) {
					// A soft halo around the nearer mint pixels
					float halo = size * 7f;
					float cx = x + size / 2f;
					float cy = y + size / 2f;
					int[] hr = Px.rect(g, cx - halo, cy - halo, cx + halo, cy + halo);
					halos.add(hr[0], hr[1], hr[2], hr[3], 0, 0, 1, 1);
				}
			}
			float alpha = 0.10f + layer * 0.12f;
			SmoothTexture solid = glowTexture();
			Px.begin(g);
			halos.submit(g, solid, Ui.withAlpha(accent, 0.07f + layer * 0.03f));
			white.submit(g, solid, Ui.withAlpha(0xFFFFFFFF, alpha));
			tinted.submit(g, solid, Ui.withAlpha(accent, alpha * 1.6f));
			Px.end(g);
		}

		// Darker towards the bottom, then grain so the soft light doesn't band
		g.fillGradient(0, 0, w, h, 0x00000000, 0x73000000);
		drawGrain(g, w, h);
	}

	/** Texture u (at v = 0.5) where the soft disc has this alpha, so one batch can hold particles of different brightness. */
	private static float uvForAlpha(float alpha) {
		if (ALPHA_BY_DISTANCE == null) {
			ALPHA_BY_DISTANCE = new float[65];
			for (int i = 0; i <= 64; i++) {
				ALPHA_BY_DISTANCE[i] = falloff(i / 64f);
			}
		}
		int i = 0;
		while (i < 64 && ALPHA_BY_DISTANCE[i] > alpha) {
			i++;
		}
		return 0.5f + i / 64f * 0.5f;
	}

	private static float falloff(float d) {
		float a = 1f - Math.min(1f, d);
		a = a * a * (3f - 2f * a);
		return (float) Math.pow(a, 1.6f);
	}

	private static void blob(GuiGraphicsExtractor g, float cx, float cy, float radius, int color, float alpha) {
		int[] r = Px.rect(g, cx - radius, cy - radius, cx + radius, cy + radius);
		QuadBatch batch = new QuadBatch(1);
		batch.add(r[0], r[1], r[2], r[3], 0, 0, 1, 1);
		Px.begin(g);
		batch.submit(g, glowTexture(), Ui.withAlpha(color | 0xFF000000, alpha));
		Px.end(g);
	}

	private static void drawGrain(GuiGraphicsExtractor g, int w, int h) {
		SmoothTexture noise = grainTexture();
		int size = 256;
		int[] screen = Px.rect(g, 0, 0, w, h);
		int cols = (screen[2] - screen[0]) / size + 1;
		int rows = (screen[3] - screen[1]) / size + 1;
		QuadBatch batch = new QuadBatch(cols * rows);
		for (int row = 0; row < rows; row++) {
			for (int col = 0; col < cols; col++) {
				int x = screen[0] + col * size;
				int y = screen[1] + row * size;
				batch.add(x, y, x + size, y + size, 0, 0, 1, 1);
			}
		}
		Px.begin(g);
		batch.submit(g, noise, 0x0EFFFFFF);
		Px.end(g);
	}

	/** A soft white disc, fully opaque in the middle and fading to nothing at the edge. */
	private static SmoothTexture glowTexture() {
		if (glow == null) {
			int size = 256;
			NativeImage image = new NativeImage(size, size, false);
			for (int y = 0; y < size; y++) {
				for (int x = 0; x < size; x++) {
					float dx = (x + 0.5f) / size * 2f - 1f;
					float dy = (y + 0.5f) / size * 2f - 1f;
					// Smooth falloff with no visible edge
					float a = falloff((float) Math.sqrt(dx * dx + dy * dy));
					image.setPixel(x, y, (Math.round(a * 255) << 24) | 0xFFFFFF);
				}
			}
			glow = register("backdrop_glow", image);
		}
		return glow;
	}

	private static SmoothTexture grainTexture() {
		if (grain == null) {
			int size = 256;
			NativeImage image = new NativeImage(size, size, false);
			Random random = new Random(26_03L);
			for (int y = 0; y < size; y++) {
				for (int x = 0; x < size; x++) {
					image.setPixel(x, y, (random.nextInt(256) << 24) | 0xFFFFFF);
				}
			}
			grain = register("backdrop_grain", image);
		}
		return grain;
	}

	private static float[][] seeds() {
		Random random = new Random(1337L);
		float[][] seeds = new float[PARTICLES][5];
		for (float[] seed : seeds) {
			for (int i = 0; i < seed.length; i++) {
				seed[i] = random.nextFloat();
			}
		}
		return seeds;
	}

	// ---- Custom image --------------------------------------------------------------------------------------

	private record Decoded(Path file, long stamp, BufferedImage image) {
	}

	/** Draws the player's image, cover-fitted with a touch of parallax. False if there's no image (yet). */
	private static boolean drawCustom(GuiGraphicsExtractor g, int w, int h, float mx, float my) {
		pollCustom();
		if (custom == null) {
			return false;
		}
		float scale = Math.max(w / (float) customWidth, h / (float) customHeight) * 1.04f;
		float dw = customWidth * scale;
		float dh = customHeight * scale;
		float x = (w - dw) / 2f - mx * (dw - w) * 0.45f;
		float y = (h - dh) / 2f - my * (dh - h) * 0.45f;
		int[] r = Px.rect(g, x, y, x + dw, y + dh);
		QuadBatch batch = new QuadBatch(1);
		batch.add(r[0], r[1], r[2], r[3], 0, 0, 1, 1);
		g.fill(0, 0, w, h, 0xFF000000);
		Px.begin(g);
		batch.submit(g, custom, 0xFFFFFFFF);
		Px.end(g);
		return true;
	}

	/** Looks for a new or changed image about once a second and decodes it off the render thread. */
	private static void pollCustom() {
		if (loading != null) {
			if (!loading.isDone()) {
				return;
			}
			Decoded decoded = loading.getNow(null);
			loading = null;
			if (decoded != null && decoded.image() != null) {
				upload(decoded);
			}
		}
		long now = System.currentTimeMillis();
		if (now - lastScan < 1000) {
			return;
		}
		lastScan = now;
		Path newest = null;
		long newestStamp = 0;
		try {
			Files.createDirectories(folder());
			try (DirectoryStream<Path> files = Files.newDirectoryStream(folder())) {
				for (Path file : files) {
					String name = file.getFileName().toString().toLowerCase(Locale.ROOT);
					if (name.endsWith(".png") || name.endsWith(".jpg") || name.endsWith(".jpeg")) {
						long stamp = Files.getLastModifiedTime(file).toMillis();
						if (newest == null || stamp > newestStamp) {
							newest = file;
							newestStamp = stamp;
						}
					}
				}
			}
		} catch (IOException e) {
			customStatus = "Couldn't read " + folder();
			return;
		}
		if (newest == null) {
			customStatus = "Put a .png or .jpg in config/goonclient/backgrounds";
			release();
			customFile = null;
			return;
		}
		if (newest.equals(customFile) && newestStamp == customStamp) {
			return;
		}
		Path file = newest;
		long stamp = newestStamp;
		customFile = file;
		customStamp = stamp;
		customStatus = "Loading " + file.getFileName() + "...";
		loading = CompletableFuture.supplyAsync(() -> new Decoded(file, stamp, decode(file)));
	}

	private static BufferedImage decode(Path file) {
		try {
			BufferedImage source = ImageIO.read(file.toFile());
			if (source == null) {
				return null;
			}
			int w = source.getWidth();
			int h = source.getHeight();
			if (w > MAX_IMAGE_WIDTH) {
				h = Math.round(h * (MAX_IMAGE_WIDTH / (float) w));
				w = MAX_IMAGE_WIDTH;
			}
			BufferedImage scaled = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
			Graphics2D g = scaled.createGraphics();
			g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
			g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
			g.drawImage(source, 0, 0, w, h, null);
			g.dispose();
			return scaled;
		} catch (IOException | RuntimeException e) {
			Goon.LOGGER.warn("Couldn't load menu background {}", file, e);
			return null;
		}
	}

	private static void upload(Decoded decoded) {
		BufferedImage image = decoded.image();
		NativeImage pixels = new NativeImage(image.getWidth(), image.getHeight(), false);
		for (int y = 0; y < image.getHeight(); y++) {
			for (int x = 0; x < image.getWidth(); x++) {
				pixels.setPixel(x, y, image.getRGB(x, y) | 0xFF000000);
			}
		}
		release();
		custom = register("backdrop_custom", pixels);
		customWidth = image.getWidth();
		customHeight = image.getHeight();
		customStatus = null;
		Goon.LOGGER.info("Menu background: {} ({}x{})", decoded.file().getFileName(), customWidth, customHeight);
	}

	private static void release() {
		if (custom != null) {
			Minecraft.getInstance().getTextureManager().release(Goon.id("dynamic/backdrop_custom"));
			custom = null;
		}
	}

	private static SmoothTexture register(String name, NativeImage image) {
		SmoothTexture texture = new SmoothTexture(name, image);
		Minecraft.getInstance().getTextureManager().register(Goon.id("dynamic/" + name), texture);
		return texture;
	}
}
