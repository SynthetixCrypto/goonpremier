package dev.goonclient.client.gui;

import dev.goonclient.client.config.PerformancePreset;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

/** A readable preview and one-click undo for the low-resource preset. */
public final class PerformanceScreen extends Screen implements GoonScreen {
	private final Screen parent;
	private float scale;
	private int x, y;
	private String status = "Lower settings you already chose stay lower.";
	private boolean canRestore;

	public PerformanceScreen(Screen parent) {
		super(Component.literal("Low-resource preset"));
		this.parent = parent;
	}

	@Override
	protected void init() {
		scale = Ui.menuScale(width, height);
		x = (int) (width / scale - 480) / 2;
		y = (int) (height / scale - 310) / 2;
		canRestore = PerformancePreset.canRestore();
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor g, int mx, int my, float partialTick) {
		g.pose().pushMatrix();
		g.pose().scale(scale, scale);
		Ui.roundOutline(g, x, y, x + 480, y + 310, 9, Ui.BORDER, Ui.PANEL);
		Ui.scaledBold(g, font, "Low-resource preset", x + 20, y + 18, 1.4f, Ui.TEXT);
		Ui.text(g, font, "Less rendering work. A quieter, lighter client.", x + 20, y + 39, Ui.MUTED);
		String[][] rows = {{"View / simulation distance", "Up to 8 / 5 chunks"}, {"Entity distance / frame cap", "Up to 75% / 90 FPS"},
			{"Clouds / entity shadows", "Off"}, {"Particles", "Decreased"}, {"Leaves / smooth lighting", "Fast / off"},
			{"Biome blending / menu blur", "Off"}, {"Menu background", "Solid charcoal"}};
		int ry = y + 68;
		for (var row : rows) {
			Ui.text(g, font, row[0], x + 20, ry, Ui.MUTED);
			Ui.bold(g, font, row[1], x + 460 - Ui.boldWidth(font, row[1]), ry, Ui.TEXT);
			ry += 20;
		}
		Ui.text(g, font, "For best results, also switch off shader packs in Iris.", x + 20, y + 214, Ui.MUTED);
		Ui.text(g, font, status, x + 20, y + 234, Ui.TEXT);
		Menus.button(g, "Apply preset", x + 20, y + 264, 146, (int) (mx / scale), (int) (my / scale), 1, Menus.Style.NORMAL);
		Menus.button(g, canRestore ? "Restore previous" : "No backup yet", x + 174, y + 264, 146, (int) (mx / scale), (int) (my / scale), canRestore ? 1 : 0.45f, Menus.Style.NORMAL);
		Menus.button(g, "Done", x + 328, y + 264, 132, (int) (mx / scale), (int) (my / scale), 1, Menus.Style.NORMAL);
		g.pose().popMatrix();
	}

	public void applyPreset() {
		status = PerformancePreset.apply(minecraft);
		canRestore = PerformancePreset.canRestore();
	}

	public void restorePreset() {
		status = PerformancePreset.restore(minecraft);
		canRestore = PerformancePreset.canRestore();
	}

	@Override
	public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
		if (event.button() != 1) return super.mouseClicked(event, doubleClick);
		double mx = event.x() / scale, my = event.y() / scale;
		if (Ui.inside(mx, my, x + 20, y + 264, x + 166, y + 288)) applyPreset();
		else if (canRestore && Ui.inside(mx, my, x + 174, y + 264, x + 320, y + 288)) restorePreset();
		else if (Ui.inside(mx, my, x + 328, y + 264, x + 460, y + 288)) onClose();
		else return super.mouseClicked(event, doubleClick);
		return true;
	}

	@Override
	public void onClose() {
		minecraft.gui.setScreen(parent);
	}
}
