package dev.goonclient.client.mixin;

import dev.goonclient.client.gui.render.BackdropBlur;
import net.minecraft.client.gui.render.GuiRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GuiRenderer.class)
public abstract class GuiBackdropMixin {
    @Inject(method="render",at=@At(value="INVOKE",target="Lnet/minecraft/client/gui/render/GuiRenderer;prepare()V"))
    private void goon$captureBackdrop(CallbackInfo ci){BackdropBlur.capture();}
    @Inject(method="close",at=@At("HEAD"))
    private void goon$closeBackdrop(CallbackInfo ci){BackdropBlur.close();}
}
