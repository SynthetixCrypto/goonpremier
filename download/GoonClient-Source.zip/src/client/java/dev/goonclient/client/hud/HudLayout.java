package dev.goonclient.client.hud;

import java.util.ArrayList;
import java.util.List;

/** Rectangle placement shared by live HUD and editor. Overflow spills into another column, not onto the map. */
public final class HudLayout {
	public record Rect(int x, int y, int width, int height) {
		public boolean overlaps(Rect other) {
			return x < other.x + other.width + 2 && x + width + 2 > other.x
				&& y < other.y + other.height + 2 && y + height + 2 > other.y;
		}
	}

	private HudLayout() { }

    public record Item(String id, int width, int height, boolean right, boolean bottom) { }
    public record Arrangement(java.util.Map<String, Rect> positions, float scale) { }

    /** Pack both edges, adding inner columns only when an edge fills. Scale to fit instead of overlapping. */
    public static Arrangement arrange(List<Item> items, int width, int height, List<Rect> obstacles) {
        Arrangement last = null;
        for (int step = 0; step <= 15; step++) {
            float scale = 1f - step * .05f;
            List<Rect> occupied = new ArrayList<>(obstacles);
            // Keep the world and aim unobstructed. Small clock/compass/attack controls are placed separately.
            occupied.add(new Rect(width * 34 / 100, height * 18 / 100,
                width * 32 / 100, height * 60 / 100));
            java.util.Map<String, Rect> positions = new java.util.LinkedHashMap<>();
            boolean fits = true;
            for (Item item : items) {
                int w = Math.max(1, Math.round(item.width * scale));
                int h = Math.max(1, Math.round(item.height * scale));
                Rect preferred = new Rect(item.right ? width - w - 6 : 6,
                    item.bottom ? height - h - 6 : 6, w, h);
                Rect placed = find(preferred, width, height, occupied);
                if (placed == null) { fits = false; break; }
                positions.put(item.id, placed); occupied.add(placed);
            }
            last = new Arrangement(java.util.Map.copyOf(positions), scale);
            if (fits) return last;
        }
        // A physically undersized window cannot display unlimited panels. Keep only the ones that fit,
        // rather than drawing over the map, aim or other cards. All remain enabled and return on resize.
        return last;
    }


	public static boolean free(Rect rect, List<Rect> occupied) {
		// A plain loop: this runs for every panel every frame, so no stream or iterator garbage
		for (int i = 0, n = occupied.size(); i < n; i++) {
			if (rect.overlaps(occupied.get(i))) return false;
		}
		return true;
	}

	public static Rect place(Rect preferred, int screenWidth, int screenHeight, List<Rect> occupied, List<Rect> hard) {
		Rect result = find(preferred, screenWidth, screenHeight, occupied);
		if (result == null) result = find(preferred, screenWidth, screenHeight, hard);
		return result == null ? preferred : result;
	}

	private static Rect find(Rect preferred, int width, int height, List<Rect> occupied) {
		if (preferred.x >= 0 && preferred.y >= 0 && preferred.x + preferred.width <= width && preferred.y + preferred.height <= height && free(preferred, occupied)) return preferred;
		List<Integer> ys = new ArrayList<>(List.of(preferred.y, 0, Math.max(0, height - preferred.height)));
		List<Integer> xs = new ArrayList<>(List.of(preferred.x, 0, Math.max(0, width - preferred.width)));
		for (Rect rect : occupied) {
			ys.add(rect.y + rect.height + 2);
			ys.add(rect.y - preferred.height - 2);
			xs.add(rect.x + rect.width + 2);
			xs.add(rect.x - preferred.width - 2);
		}
		Rect best = null;
		long score = Long.MAX_VALUE;
		for (int x : xs) {
			if (x < 0 || x + preferred.width > width) continue;
			for (int y : ys) {
				if (y < 0 || y + preferred.height > height) continue;
				Rect candidate = new Rect(x, y, preferred.width, preferred.height);
				long distance = Math.abs(y - preferred.y) + (long) Math.abs(x - preferred.x) * (height + 1);
				if (distance < score && free(candidate, occupied)) {
					best = candidate;
					score = distance;
				}
			}
			// Keep a panel in its column whenever there is room there.
			if (x == preferred.x && best != null) return best;
		}
		return best;
	}
}
