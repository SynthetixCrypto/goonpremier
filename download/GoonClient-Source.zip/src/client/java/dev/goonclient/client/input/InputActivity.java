package dev.goonclient.client.input;

import net.minecraft.client.Minecraft;

/** Only a local activity counter is kept. No text, key codes, coordinates, files or network requests. */
public final class InputActivity {
    private static long sequence;
    private InputActivity() {}
    public static long sequence(){return sequence;}
    public static void record(Minecraft mc,long window) {
        if(mc.player!=null&&mc.level!=null&&window!=0&&mc.getWindow().handle()==window&&mc.isWindowActive())sequence++;
    }
}
