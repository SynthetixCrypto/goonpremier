package dev.goonclient.client.gui.render;

import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.navigation.ScreenRectangle;
import net.minecraft.client.gui.render.TextureSetup;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.state.gui.GuiElementRenderState;
import net.minecraft.client.renderer.texture.AbstractTexture;
import org.joml.Matrix3x2f;

/**
 * Many textured quads from one texture, in one colour, submitted as a single GUI element. Text (one element per
 * string instead of one per glyph) and rounded rectangles (one element instead of seven) go through this, which
 * keeps the per-frame element count, and the garbage it creates, small.
 */
final class QuadBatch {
	private final float[] quads;
	private int count;
	private int minX = Integer.MAX_VALUE;
	private int minY = Integer.MAX_VALUE;
	private int maxX = Integer.MIN_VALUE;
	private int maxY = Integer.MIN_VALUE;

	QuadBatch(int capacity) {
		this.quads = new float[capacity * 8];
	}

	/** A quad in screen pixels with texture coordinates already divided by the texture size. */
	void add(int x0, int y0, int x1, int y1, float u0, float v0, float u1, float v1) {
		if (x1 <= x0 || y1 <= y0) {
			return;
		}
		int i = count * 8;
		quads[i] = x0;
		quads[i + 1] = y0;
		quads[i + 2] = x1;
		quads[i + 3] = y1;
		quads[i + 4] = u0;
		quads[i + 5] = v0;
		quads[i + 6] = u1;
		quads[i + 7] = v1;
		count++;
		minX = Math.min(minX, x0);
		minY = Math.min(minY, y0);
		maxX = Math.max(maxX, x1);
		maxY = Math.max(maxY, y1);
	}

	/** Submits the batch with the current pose (expected to be screen-pixel space, see {@link Px#begin}). */
	void submit(GuiGraphicsExtractor g, AbstractTexture texture, int color) {
		submitVertical(g, texture, color, color, 0, 1);
	}

	/** Submits the batch shaded from {@code top} to {@code bottom} across the batch's own height. */
	void submitVertical(GuiGraphicsExtractor g, AbstractTexture texture, int top, int bottom) {
		submitVertical(g, texture, top, bottom, minY, maxY);
	}

	/** Submits the batch shaded from {@code top} at y = {@code y0} to {@code bottom} at y = {@code y1} (pixels). */
	void submitVertical(GuiGraphicsExtractor g, AbstractTexture texture, int top, int bottom, float y0, float y1) {
		if (count == 0 || ((top | bottom) >>> 24) == 0) {
			return;
		}
		Matrix3x2f pose = new Matrix3x2f(g.pose());
		ScreenRectangle scissor = g.scissorStack.peek();
		ScreenRectangle bounds = new ScreenRectangle(minX, minY, maxX - minX, maxY - minY).transformMaxBounds(pose);
		if (scissor != null) {
			bounds = scissor.intersection(bounds);
			if (bounds == null) {
				// Entirely clipped away
				return;
			}
		}
		TextureSetup textures = TextureSetup.singleTexture(texture.getTextureView(), texture.getSampler());
		g.guiRenderState.addGuiElement(new State(pose, quads, count, top, bottom, y0, Math.max(y0 + 1e-3f, y1), textures, scissor, bounds));
	}

	static int lerpColor(int a, int b, float t) {
		if (a == b || t <= 0) return a;
		if (t >= 1) return b;
		int r = 0;
		for (int shift = 0; shift < 32; shift += 8) {
			int ca = (a >>> shift) & 0xFF, cb = (b >>> shift) & 0xFF;
			r |= Math.round(ca + (cb - ca) * t) << shift;
		}
		return r;
	}

	private record State(Matrix3x2f pose, float[] quads, int count, int top, int bottom, float y0, float y1, TextureSetup textureSetup,
						 ScreenRectangle scissorArea, ScreenRectangle bounds) implements GuiElementRenderState {
		private int color(float y) {
			return lerpColor(top, bottom, (y - y0) / (y1 - y0));
		}

		@Override
		public void buildVertices(VertexConsumer consumer) {
			for (int q = 0; q < count; q++) {
				int i = q * 8;
				float x0 = quads[i];
				float y0 = quads[i + 1];
				float x1 = quads[i + 2];
				float y1 = quads[i + 3];
				float u0 = quads[i + 4];
				float v0 = quads[i + 5];
				float u1 = quads[i + 6];
				float v1 = quads[i + 7];
				// Same corner order as vanilla's blit
				int c0 = color(y0), c1 = color(y1);
				consumer.addVertexWith2DPose(pose, x0, y0).setUv(u0, v0).setColor(c0);
				consumer.addVertexWith2DPose(pose, x0, y1).setUv(u0, v1).setColor(c1);
				consumer.addVertexWith2DPose(pose, x1, y1).setUv(u1, v1).setColor(c1);
				consumer.addVertexWith2DPose(pose, x1, y0).setUv(u1, v0).setColor(c0);
			}
		}

		@Override
		public com.mojang.renderpearl.api.pipeline.RenderPipeline pipeline() {
			return RenderPipelines.GUI_TEXTURED;
		}
	}
}
