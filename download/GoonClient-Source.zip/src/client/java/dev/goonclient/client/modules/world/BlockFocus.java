package dev.goonclient.client.modules.world;

import dev.goonclient.client.gui.Ui;
import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.Module;
import dev.goonclient.client.module.setting.ModeSetting;
import dev.goonclient.client.module.setting.NumberSetting;
import dev.goonclient.client.render.WorldRender;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.gizmos.GizmoStyle;
import net.minecraft.gizmos.Gizmos;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.shapes.CollisionContext;

/** Uses the block's actual selection shape, including stairs and slabs. */
public final class BlockFocus extends Module implements WorldRender.Renderable {
    private final ModeSetting style = add(new ModeSetting("style", "Highlight style", "Outline", "Outline", "Outline + fill", "Fill"));
    private final NumberSetting thickness = add(new NumberSetting("thickness", "Outline width", 2, 1, 4, .25));
    private final NumberSetting opacity = add(new NumberSetting("opacity", "Fill opacity", 12, 0, 40, 1, "%"));
    public BlockFocus() { super("block_focus", "Block Focus", "Accent outline and optional fill on the block you are looking at", Category.WORLD, false); }
    @Override public void renderWorld(Minecraft mc, Camera camera, float partialTick) {
        if (mc.level == null || mc.player == null || !(mc.hitResult instanceof BlockHitResult hit) || hit.getType() != HitResult.Type.BLOCK) return;
        var pos = hit.getBlockPos();
        var shape = mc.level.getBlockState(pos).getShape(mc.level, pos, CollisionContext.of(mc.player));
        int color = Ui.accent(), fill = Ui.withAlpha(color, opacity.floatValue() / 100f);
        var draw = style.is("Fill") ? GizmoStyle.fill(fill) : style.is("Outline + fill") ? GizmoStyle.strokeAndFill(color, thickness.floatValue(), fill) : GizmoStyle.stroke(color, thickness.floatValue());
        var boxes = shape.toAabbs();
        for (int i = 0; i < Math.min(64, boxes.size()); i++) Gizmos.cuboid(boxes.get(i).move(pos.getX(), pos.getY(), pos.getZ()).inflate(.002), draw);
    }
}
