package dev.goonclient.client.tracker;

/** Monotonic, input-only inactivity. Pausing singleplayer freezes the clock. No key or mouse values are stored. */
public final class IdleClock {
    private boolean initialized;
    private long idleNanos,lastTick,lastInput;
    public void update(long now,long inputSequence,boolean heldInput,boolean paused) {
        if(!initialized){initialized=true;lastTick=now;lastInput=inputSequence;return;}
        long elapsed=Math.max(0,now-lastTick);lastTick=now;
        if(inputSequence!=lastInput||heldInput)idleNanos=0;
        else if(!paused)idleNanos+=elapsed;
        lastInput=inputSequence;
    }
    public long idleMillis(){return idleNanos/1_000_000L;}
    public void reset(){initialized=false;idleNanos=0;}
}
