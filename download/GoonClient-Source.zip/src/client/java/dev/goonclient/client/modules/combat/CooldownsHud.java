package dev.goonclient.client.modules.combat;

import dev.goonclient.client.gui.render.Icons;
import dev.goonclient.client.hud.HudPosition;
import dev.goonclient.client.hud.TextHudModule;
import dev.goonclient.client.module.Category;
import dev.goonclient.client.tracker.CooldownTracker;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/** Item cooldowns (ender pearls, chorus fruit, wind charges, goat horns, a disabled shield) with the time left. */
public class CooldownsHud extends TextHudModule {
	public CooldownsHud() {
		super("cooldowns", "Cooldowns", "Item cooldowns like ender pearls, chorus fruit and wind charges, with the time left", Category.COMBAT, true,
			HudPosition.topRight(92, 119));
	}

	@Override
	protected Icons.Icon icon() {
		return Icons.Icon.COG;
	}

	@Override
	protected Variant variant() {
		return Variant.COOLDOWNS;
	}

	@Override
	protected String countLabel() {
		return "Active";
	}

	@Override
	public boolean isVisible(Minecraft mc) {
		return mc.player != null && !CooldownTracker.active().isEmpty();
	}

	@Override
	public void onTick(Minecraft mc) {
		if (mc.player == null) CooldownTracker.clear();
	}

	@Override
	protected void collect(Minecraft mc, List<Line> lines, boolean editing) {
		var active = CooldownTracker.active();
		if (active.isEmpty()) {
			if (editing) lines.add(new Line("Ender Pearl", "0:01").withIcon(new ItemStack(Items.ENDER_PEARL)));
			return;
		}
		long now = System.currentTimeMillis();
		for (var entry : active) {
			ItemStack icon = new ItemStack(BuiltInRegistries.ITEM.getValue(entry.group()));
			String name = icon.isEmpty() ? entry.group().getPath().replace('_', ' ') : icon.getHoverName().getString();
			long ms = entry.remainingMs(now);
			String time = ms >= 10_000 ? String.format("%d:%02d", ms / 60_000, (ms / 1000) % 60) : String.format("%.1fs", ms / 1000f);
			lines.add(new Line(name, time).withIcon(icon));
		}
	}
}
