package dev.goonclient.client.modules.world;

import dev.goonclient.client.GoonChat;
import dev.goonclient.client.gui.Ui;
import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.Module;
import dev.goonclient.client.module.setting.BooleanSetting;
import dev.goonclient.client.module.setting.ButtonSetting;
import dev.goonclient.client.module.setting.ModeSetting;
import dev.goonclient.client.module.setting.NumberSetting;
import dev.goonclient.client.render.WorldRender;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.gizmos.GizmoStyle;
import net.minecraft.gizmos.Gizmos;
import net.minecraft.gizmos.TextGizmo;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.level.NaturalSpawner;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.VoxelShape;

/** World overlays: where mobs can spawn, chunk borders and the mob spawn/despawn distances. */
public final class Overlays {
	private Overlays() {
	}

	/** Marks every block a hostile mob could spawn on: red = it can happen now, amber = only at night. */
	public static class SpawnOverlay extends Module implements WorldRender.Renderable {
		private static final int SCAN_EVERY_TICKS = 10;

		private final NumberSetting radius = add(new NumberSetting("radius", "Radius", 16, 4, 32, 1, " blocks"));
		private final BooleanSetting nightSpots = add(new BooleanSetting("night_spots", "Show night-only spots", true));
		private final ModeSetting style = add(new ModeSetting("style", "Marker", "Square", "Square", "Cross"));
		private final List<Spot> spots = new ArrayList<>();
		private int cooldown;

		public SpawnOverlay() {
			super("spawn_overlay", "Spawn Overlay", "Marks blocks where mobs can spawn: red now, amber at night", Category.WORLD, false);
		}

		@Override
		protected void onDisable() {
			spots.clear();
		}

		@Override
		public void onTick(Minecraft mc) {
			if (mc.player == null || mc.level == null || --cooldown > 0) {
				return;
			}
			cooldown = SCAN_EVERY_TICKS;
			scan(mc.level, mc.player.blockPosition());
		}

		private void scan(ClientLevel level, BlockPos centre) {
			spots.clear();
			int r = radius.intValue();
			int vertical = Math.max(6, r / 2);
			int blockLightLimit = level.dimensionType().monsterSpawnBlockLightLimit();
			BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
			for (int dx = -r; dx <= r; dx++) {
				for (int dz = -r; dz <= r; dz++) {
					for (int dy = -vertical; dy <= vertical; dy++) {
						pos.set(centre.getX() + dx, centre.getY() + dy, centre.getZ() + dz);
						if (!level.hasChunkAt(pos)) {
							continue;
						}
						BlockState state = level.getBlockState(pos);
						// Same tests the game uses: room for a mob here and above, and a solid block to stand on
						if (!NaturalSpawner.isValidEmptySpawnBlock(level, pos, state, state.getFluidState(), EntityTypes.ZOMBIE)) {
							continue;
						}
						BlockPos below = pos.below();
						if (!level.getBlockState(below).isValidSpawn(level, below, EntityTypes.ZOMBIE)) {
							continue;
						}
						BlockPos above = pos.above();
						BlockState aboveState = level.getBlockState(above);
						if (!NaturalSpawner.isValidEmptySpawnBlock(level, above, aboveState, aboveState.getFluidState(), EntityTypes.ZOMBIE)) {
							continue;
						}
						if (level.getBrightness(LightLayer.BLOCK, pos) > blockLightLimit) {
							continue;
						}
						// Dark enough right now (sky light minus the current darkening), or only once night falls
						boolean now = level.getRawBrightness(pos, level.getSkyDarken()) <= 7;
						if (!now && !nightSpots.isOn()) {
							continue;
						}
						VoxelShape shape = state.getCollisionShape(level, pos);
						double surface = pos.getY() + (shape.isEmpty() ? 0 : shape.max(Direction.Axis.Y)) + 0.02;
						spots.add(new Spot(pos.getX(), surface, pos.getZ(), now));
					}
				}
			}
		}

		@Override
		public void renderWorld(Minecraft mc, Camera camera, float partialTick) {
			boolean cross = style.is("Cross");
			for (Spot spot : spots) {
				int color = spot.now ? Ui.BAD : Ui.WARN;
				if (cross) {
					Gizmos.line(new Vec3(spot.x + 0.15, spot.y, spot.z + 0.15), new Vec3(spot.x + 0.85, spot.y, spot.z + 0.85), color, 2f);
					Gizmos.line(new Vec3(spot.x + 0.85, spot.y, spot.z + 0.15), new Vec3(spot.x + 0.15, spot.y, spot.z + 0.85), color, 2f);
				} else {
					Gizmos.rect(new Vec3(spot.x + 0.08, spot.y, spot.z + 0.08), new Vec3(spot.x + 0.92, spot.y, spot.z + 0.92), Direction.UP,
						GizmoStyle.strokeAndFill(Ui.withAlpha(color, 0.85f), 1.5f, Ui.withAlpha(color, 0.25f)));
				}
			}
		}

		private record Spot(int x, double y, int z, boolean now) {
		}
	}

	/** Lines along the edges of the chunk you're in, plus the corners of the chunks around it. */
	public static class ChunkBorders extends Module implements WorldRender.Renderable {
		private final ModeSetting height = add(new ModeSetting("height", "Height", "Around you", "Around you", "Full height"));
		private final BooleanSetting grid = add(new BooleanSetting("grid", "Grid on the walls", true));
		private final BooleanSetting neighbours = add(new BooleanSetting("neighbours", "Neighbouring chunks", true));

		public ChunkBorders() {
			super("chunk_borders", "Chunk Borders", "Shows the edges of the chunk you're standing in", Category.WORLD, false);
		}

		@Override
		public void renderWorld(Minecraft mc, Camera camera, float partialTick) {
			ClientLevel level = mc.level;
			int x0 = (mc.player.getBlockX() >> 4) << 4;
			int z0 = (mc.player.getBlockZ() >> 4) << 4;
			boolean full = height.is("Full height");
			int playerY = mc.player.getBlockY();
			int minY = full ? level.getMinY() : Math.max(level.getMinY(), playerY - 16);
			int maxY = full ? level.getMaxY() + 1 : Math.min(level.getMaxY() + 1, playerY + 17);

			int corner = Ui.accent();
			int wall = 0x66FFFFFF;
			int faint = 0x40FFFFFF;
			for (int cx = 0; cx <= 16; cx += 16) {
				for (int cz = 0; cz <= 16; cz += 16) {
					Gizmos.line(new Vec3(x0 + cx, minY, z0 + cz), new Vec3(x0 + cx, maxY, z0 + cz), corner, 2.5f);
				}
			}
			if (grid.isOn()) {
				// Vertical lines every 2 blocks along each wall
				for (int i = 2; i < 16; i += 2) {
					Gizmos.line(new Vec3(x0 + i, minY, z0), new Vec3(x0 + i, maxY, z0), wall, 1f);
					Gizmos.line(new Vec3(x0 + i, minY, z0 + 16), new Vec3(x0 + i, maxY, z0 + 16), wall, 1f);
					Gizmos.line(new Vec3(x0, minY, z0 + i), new Vec3(x0, maxY, z0 + i), wall, 1f);
					Gizmos.line(new Vec3(x0 + 16, minY, z0 + i), new Vec3(x0 + 16, maxY, z0 + i), wall, 1f);
				}
				// Horizontal rings: every 2 blocks near you, every 16 over the full height
				int step = full ? 16 : 2;
				for (int y = (minY / step) * step; y <= maxY; y += step) {
					if (y < minY) {
						continue;
					}
					Gizmos.line(new Vec3(x0, y, z0), new Vec3(x0 + 16, y, z0), wall, 1f);
					Gizmos.line(new Vec3(x0 + 16, y, z0), new Vec3(x0 + 16, y, z0 + 16), wall, 1f);
					Gizmos.line(new Vec3(x0 + 16, y, z0 + 16), new Vec3(x0, y, z0 + 16), wall, 1f);
					Gizmos.line(new Vec3(x0, y, z0 + 16), new Vec3(x0, y, z0), wall, 1f);
				}
			}
			if (neighbours.isOn()) {
				for (int cx = -16; cx <= 32; cx += 16) {
					for (int cz = -16; cz <= 32; cz += 16) {
						boolean own = (cx == 0 || cx == 16) && (cz == 0 || cz == 16);
						if (!own) {
							Gizmos.line(new Vec3(x0 + cx, minY, z0 + cz), new Vec3(x0 + cx, maxY, z0 + cz), faint, 1.5f);
						}
					}
				}
			}
		}
	}

	/**
	 * Rings for the distances that matter when building a mob farm: nothing spawns within 24 blocks of you,
	 * mobs past 32 can randomly despawn, and past 128 they despawn straight away.
	 */
	public static class SpawnRange extends Module implements WorldRender.Renderable {
		private final ModeSetting centre = add(new ModeSetting("centre", "Centre", "Follow me", "Follow me", "Fixed spot"));
		private final BooleanSetting farRing = add(new BooleanSetting("far_ring", "Show the 128 block ring", true));
		private final BooleanSetting labels = add(new BooleanSetting("labels", "Labels", true));
		private Vec3 anchor;

		public SpawnRange() {
			super("spawn_range", "Mob Spawn Range", "Rings at 24, 32 and 128 blocks for planning AFK spots and farms", Category.WORLD, false);
			add(new ButtonSetting("set_centre", "Fixed spot", "Set to here", () -> {
				Minecraft mc = Minecraft.getInstance();
				if (mc.player != null) {
					anchor = mc.player.position();
					centre.set("Fixed spot");
					GoonChat.info("Spawn range centred on " + mc.player.getBlockX() + " " + mc.player.getBlockY() + " " + mc.player.getBlockZ());
				}
			}));
		}

		@Override
		protected void onEnable() {
			Minecraft mc = Minecraft.getInstance();
			if (anchor == null && mc.player != null) {
				anchor = mc.player.position();
			}
		}

		@Override
		public void renderWorld(Minecraft mc, Camera camera, float partialTick) {
			Vec3 middle = centre.is("Fixed spot") && anchor != null ? anchor : mc.player.getPosition(partialTick);
			Vec3 ground = middle.add(0, 0.05, 0);
			ring(ground, 24, Ui.BAD, "24 blocks: nothing spawns closer");
			ring(ground, 32, Ui.WARN, "32 blocks: mobs may despawn further out");
			if (farRing.isOn()) {
				ring(ground, 128, Ui.MUTED, "128 blocks: mobs despawn further out");
			}
		}

		private void ring(Vec3 centre, double radius, int color, String label) {
			int segments = radius > 64 ? 160 : 72;
			Vec3 previous = null;
			for (int i = 0; i <= segments; i++) {
				double angle = Math.PI * 2 * i / segments;
				Vec3 point = centre.add(Math.cos(angle) * radius, 0, Math.sin(angle) * radius);
				if (previous != null) {
					Gizmos.line(previous, point, color, 2f);
				}
				previous = point;
			}
			if (labels.isOn()) {
				Gizmos.billboardText(label, centre.add(0, 1.2, -radius), TextGizmo.Style.forColorAndCentered(color));
			}
		}
	}
}
