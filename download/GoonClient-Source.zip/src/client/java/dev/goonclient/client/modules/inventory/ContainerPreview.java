package dev.goonclient.client.modules.inventory;

import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.Module;
import dev.goonclient.client.module.setting.BooleanSetting;
import java.util.Optional;
import net.minecraft.client.Minecraft;
import net.minecraft.core.NonNullList;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.inventory.tooltip.TooltipComponent;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.ItemContainerContents;

/** Adds a slot grid to the tooltip of shulker boxes and other filled containers. */
public class ContainerPreview extends Module {
	private static ContainerPreview instance;

	private final BooleanSetting requireShift = add(new BooleanSetting("require_shift", "Only while holding Shift", false));

	public ContainerPreview() {
		super("container_preview", "Container Preview", "See shulker box contents as a grid when you hover them", Category.INVENTORY, true);
		instance = this;
	}

	/** Called from the ItemStack#getTooltipImage mixin. */
	public static Optional<TooltipComponent> tooltipFor(ItemStack stack) {
		if (instance == null || !instance.isEnabled()) {
			return Optional.empty();
		}
		if (instance.requireShift.isOn() && !Minecraft.getInstance().hasShiftDown()) {
			return Optional.empty();
		}
		ItemContainerContents contents = stack.get(DataComponents.CONTAINER);
		if (contents == null || contents.nonEmptyItemCopyStream().findAny().isEmpty()) {
			return Optional.empty();
		}
		NonNullList<ItemStack> slots = NonNullList.withSize(27, ItemStack.EMPTY);
		contents.copyInto(slots);
		return Optional.of(new Tooltip(slots));
	}

	public record Tooltip(NonNullList<ItemStack> slots) implements TooltipComponent {
	}
}
