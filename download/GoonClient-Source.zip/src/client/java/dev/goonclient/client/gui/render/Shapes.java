package dev.goonclient.client.gui.render;

import com.mojang.blaze3d.platform.NativeImage;
import dev.goonclient.Goon;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.resources.Identifier;

/**
 * Anti-aliased rounded shapes drawn on screen pixels. Corners come from small cached textures (a circle, a ring, a
 * blurred shadow) tinted to the wanted colour, and the straight parts are plain fills. A rounded rectangle is about
 * seven draw calls, instead of the hundreds of 1-pixel rows the old renderer used.
 */
public final class Shapes {
	private static final int SUPERSAMPLE = 4;
	// Any disc with a solid middle texel works as a plain white texture
	private static final int SOLID_RADIUS = 4;
	private static final Map<Integer, Disc> CIRCLES = new HashMap<>();
	private static final Map<Long, Disc> RINGS = new HashMap<>();
	private static final Map<Long, ShadowTexture> SHADOWS = new HashMap<>();

	private Shapes() {
	}

	// ---- Public shapes (coordinates in the current pose) ---------------------------------------------------

	/** A crisp rectangle snapped to screen pixels. */
	public static void rect(GuiGraphicsExtractor g, float x1, float y1, float x2, float y2, int color) {
		if ((color >>> 24) == 0) {
			return;
		}
		int[] r = Px.rect(g, x1, y1, x2, y2);
		Px.begin(g);
		g.fill(r[0], r[1], r[2], r[3], color);
		Px.end(g);
	}

	public static void roundRect(GuiGraphicsExtractor g, float x1, float y1, float x2, float y2, float radius, int color) {
		if ((color >>> 24) == 0 || x2 <= x1 || y2 <= y1) {
			return;
		}
		int[] r = Px.rect(g, x1, y1, x2, y2);
		int rad = Math.round(Px.length(g, radius));
		Px.begin(g);
		roundRectPx(g, r[0], r[1], r[2], r[3], rad, color);
		Px.end(g);
	}

	/**
	 * A rounded rectangle shaded from {@code top} to {@code bottom}, with its own radius for the top and the bottom
	 * corners (0 for square ones), e.g. the two halves of a split panel.
	 */
	public static void gradientRect(GuiGraphicsExtractor g, float x1, float y1, float x2, float y2, float radiusTop, float radiusBottom, int top, int bottom) {
		gradientRect(g, x1, y1, x2, y2, radiusTop, radiusTop, radiusBottom, radiusBottom, top, bottom);
	}

	/** As above with a radius per corner: top-left, top-right, bottom-right, bottom-left. */
	public static void gradientRect(GuiGraphicsExtractor g, float x1, float y1, float x2, float y2, float radiusTL, float radiusTR, float radiusBR,
									float radiusBL, int top, int bottom) {
		if (((top | bottom) >>> 24) == 0 || x2 <= x1 || y2 <= y1) {
			return;
		}
		int[] r = Px.rect(g, x1, y1, x2, y2);
		int w = r[2] - r[0], h = r[3] - r[1];
		if (w <= 0 || h <= 0) {
			return;
		}
		int max = Math.min(w / 2, h / 2);
		int tl = Math.max(0, Math.min(Math.round(Px.length(g, radiusTL)), max)), tr = Math.max(0, Math.min(Math.round(Px.length(g, radiusTR)), max));
		int br = Math.max(0, Math.min(Math.round(Px.length(g, radiusBR)), max)), bl = Math.max(0, Math.min(Math.round(Px.length(g, radiusBL)), max));
		int bandTop = Math.max(tl, tr), bandBottom = Math.max(bl, br);
		Disc disc = circleTexture(Math.max(Math.max(bandTop, bandBottom), SOLID_RADIUS));
		float c = 0.5f;
		QuadBatch batch = new QuadBatch(16);
		// Top band: corner quads sample the disc's quadrants; square corners and the gaps under a smaller corner are solid
		if (bandTop > 0) {
			corner(batch, r[0], r[1], tl, bandTop, 0, 0, false);
			corner(batch, r[2] - tr, r[1], tr, bandTop, 0.5f, 0, false);
			batch.add(r[0] + tl, r[1], r[2] - tr, r[1] + bandTop, c, c, c, c);
		}
		batch.add(r[0], r[1] + bandTop, r[2], r[3] - bandBottom, c, c, c, c);
		if (bandBottom > 0) {
			corner(batch, r[0], r[3] - bandBottom, bl, bandBottom, 0, 0.5f, true);
			corner(batch, r[2] - br, r[3] - bandBottom, br, bandBottom, 0.5f, 0.5f, true);
			batch.add(r[0] + bl, r[3] - bandBottom, r[2] - br, r[3], c, c, c, c);
		}
		Px.begin(g);
		batch.submitVertical(g, disc.texture, top, bottom, r[1], r[3]);
		Px.end(g);
	}

	/** One corner cell of a band {@code band} pixels tall: a radius-{@code rad} quadrant plus solid fill beside it. */
	private static void corner(QuadBatch batch, int x, int y, int rad, int band, float u, float v, boolean bottom) {
		float c = 0.5f;
		if (rad <= 0) {
			return;
		}
		int qy = bottom ? y + band - rad : y;
		batch.add(x, qy, x + rad, qy + rad, u, v, u + 0.5f, v + 0.5f);
		if (band > rad) {
			if (bottom) batch.add(x, y, x + rad, qy, c, c, c, c);
			else batch.add(x, y + rad, x + rad, y + band, c, c, c, c);
		}
	}

	/**
	 * Many plain rectangles in one colour as a single GUI element (graphs, meters). {@code boxes} holds
	 * x1, y1, x2, y2 per rectangle in the current pose; only the first {@code count} are drawn.
	 */
	public static void rects(GuiGraphicsExtractor g, float[] boxes, int count, int color) {
		if ((color >>> 24) == 0 || count <= 0) {
			return;
		}
		QuadBatch batch = new QuadBatch(count);
		for (int i = 0; i < count; i++) {
			int[] r = Px.rect(g, boxes[i * 4], boxes[i * 4 + 1], boxes[i * 4 + 2], boxes[i * 4 + 3]);
			batch.add(r[0], r[1], r[2], r[3], 0.5f, 0.5f, 0.5f, 0.5f);
		}
		Px.begin(g);
		batch.submit(g, circleTexture(SOLID_RADIUS).texture, color);
		Px.end(g);
	}

	/** A 1 screen-pixel outline around a rounded rectangle. */
	public static void outline(GuiGraphicsExtractor g, float x1, float y1, float x2, float y2, float radius, int color) {
		if ((color >>> 24) == 0) {
			return;
		}
		int[] r = Px.rect(g, x1, y1, x2, y2);
		int rad = Math.round(Px.length(g, radius));
		Px.begin(g);
		outlinePx(g, r[0], r[1], r[2], r[3], rad, color);
		Px.end(g);
	}

	/** A filled rounded rectangle with a hairline border inside its edge. Works with see-through colours too. */
	public static void panel(GuiGraphicsExtractor g, float x1, float y1, float x2, float y2, float radius, int fill, int border) {
		int[] r = Px.rect(g, x1, y1, x2, y2);
		int rad = Math.round(Px.length(g, radius));
		Px.begin(g);
		if ((border >>> 24) != 0) {
			roundRectPx(g, r[0] + 1, r[1] + 1, r[2] - 1, r[3] - 1, Math.max(0, rad - 1), fill);
			outlinePx(g, r[0], r[1], r[2], r[3], rad, border);
		} else {
			roundRectPx(g, r[0], r[1], r[2], r[3], rad, fill);
		}
		Px.end(g);
	}

	public static void circle(GuiGraphicsExtractor g, float cx, float cy, float radius, int color) {
		roundRect(g, cx - radius, cy - radius, cx + radius, cy + radius, radius, color);
	}

	/**
	 * A soft shadow around a rounded rectangle that stays at {@code inner} of its strength underneath the shape, so
	 * see-through panels on top aren't darkened (Combatant's roundedRectSoftShadow with innerAlpha).
	 */
	public static void glow(GuiGraphicsExtractor g, float x1, float y1, float x2, float y2, float radius, float blur, float alpha, float inner) {
		if (alpha <= 0.005f) {
			return;
		}
		int[] r = Px.rect(g, x1, y1, x2, y2);
		int rad = Math.max(1, Math.round(Px.length(g, radius)));
		int spread = Math.max(2, Math.round(Px.length(g, blur)));
		ShadowTexture tex = shadowTexture(rad, spread, inner);
		drawShadow(g, tex, r[0] - spread, r[1] - spread, r[2] + spread, r[3] + spread, Math.min(1f, alpha));
	}

	/** A soft drop shadow under a rounded rectangle: {@code blur} wide, shifted down by {@code drop}. */
	public static void shadow(GuiGraphicsExtractor g, float x1, float y1, float x2, float y2, float radius, float blur, float drop, float alpha) {
		if (alpha <= 0.01f) {
			return;
		}
		int[] r = Px.rect(g, x1, y1 + drop, x2, y2 + drop);
		int rad = Math.max(1, Math.round(Px.length(g, radius)));
		int spread = Math.max(2, Math.round(Px.length(g, blur)));
		ShadowTexture tex = shadowTexture(rad, spread, 1f);
		drawShadow(g, tex, r[0] - spread, r[1] - spread, r[2] + spread, r[3] + spread, Math.min(1f, alpha));
	}

	/**
	 * Nine-slices a shadow texture over the outer box (screen pixels) as ONE GUI element. Vanilla compares every new
	 * element against those already submitted, so nine separate blits per shadow made menus and HUDs cost far more
	 * than their pixels.
	 */
	private static void drawShadow(GuiGraphicsExtractor g, ShadowTexture tex, int ox1, int oy1, int ox2, int oy2, float alpha) {
		int c = tex.corner;
		if (ox2 - ox1 < c * 2 || oy2 - oy1 < c * 2) {
			return;
		}
		float size = tex.size, a = c / size, b = (c - 1) / size, mid = .5f;
		QuadBatch batch = new QuadBatch(9);
		// Corners
		batch.add(ox1, oy1, ox1 + c, oy1 + c, 0, 0, a, a);
		batch.add(ox2 - c, oy1, ox2, oy1 + c, a, 0, 2 * a, a);
		batch.add(ox1, oy2 - c, ox1 + c, oy2, 0, a, a, 2 * a);
		batch.add(ox2 - c, oy2 - c, ox2, oy2, a, a, 2 * a, 2 * a);
		// Edges: one texel column/row from the middle, stretched
		batch.add(ox1 + c, oy1, ox2 - c, oy1 + c, b, 0, a, a);
		batch.add(ox1 + c, oy2 - c, ox2 - c, oy2, b, a, a, 2 * a);
		batch.add(ox1, oy1 + c, ox1 + c, oy2 - c, 0, b, a, a);
		batch.add(ox2 - c, oy1 + c, ox2, oy2 - c, a, b, 2 * a, a);
		// Middle (under the panel; matters for see-through panels): the texture's own centre texel
		batch.add(ox1 + c, oy1 + c, ox2 - c, oy2 - c, mid, mid, mid, mid);
		batch.submit(g, tex.texture, Math.round(Math.min(1f, alpha) * 255) << 24);
	}

	// ---- Screen-pixel primitives ---------------------------------------------------------------------------

	/** A rounded rectangle as one GUI element: four corner quads plus three fills sampled from the disc's solid middle. */
	private static void roundRectPx(GuiGraphicsExtractor g, int x1, int y1, int x2, int y2, int radius, int color) {
		int r = Math.max(0, Math.min(radius, Math.min((x2 - x1) / 2, (y2 - y1) / 2)));
		if (x2 <= x1 || y2 <= y1) {
			return;
		}
		if (r <= 0) {
			g.fill(x1, y1, x2, y2, color);
			return;
		}
		Disc disc = circleTexture(r);
		if (r <= 2) {
			// Tiny discs have no fully solid middle texel to borrow for the fills: corners from the disc in one
			// element, the straight parts from a solid texture in another
			QuadBatch corners = new QuadBatch(4);
			corners.add(x1, y1, x1 + r, y1 + r, 0, 0, 0.5f, 0.5f);
			corners.add(x2 - r, y1, x2, y1 + r, 0.5f, 0, 1, 0.5f);
			corners.add(x1, y2 - r, x1 + r, y2, 0, 0.5f, 0.5f, 1);
			corners.add(x2 - r, y2 - r, x2, y2, 0.5f, 0.5f, 1, 1);
			corners.submit(g, disc.texture, color);
			QuadBatch fills = new QuadBatch(3);
			fills.add(x1 + r, y1, x2 - r, y2, 0.5f, 0.5f, 0.5f, 0.5f);
			fills.add(x1, y1 + r, x1 + r, y2 - r, 0.5f, 0.5f, 0.5f, 0.5f);
			fills.add(x2 - r, y1 + r, x2, y2 - r, 0.5f, 0.5f, 0.5f, 0.5f);
			fills.submit(g, circleTexture(SOLID_RADIUS).texture, color);
			return;
		}
		QuadBatch batch = new QuadBatch(7);
		// The centre texel of the disc is fully opaque, so the straight parts sample just that
		float c = 0.5f;
		batch.add(x1, y1, x1 + r, y1 + r, 0, 0, 0.5f, 0.5f);
		batch.add(x2 - r, y1, x2, y1 + r, 0.5f, 0, 1, 0.5f);
		batch.add(x1, y2 - r, x1 + r, y2, 0, 0.5f, 0.5f, 1);
		batch.add(x2 - r, y2 - r, x2, y2, 0.5f, 0.5f, 1, 1);
		batch.add(x1 + r, y1, x2 - r, y2, c, c, c, c);
		batch.add(x1, y1 + r, x1 + r, y2 - r, c, c, c, c);
		batch.add(x2 - r, y1 + r, x2, y2 - r, c, c, c, c);
		batch.submit(g, disc.texture, color);
	}

	private static void outlinePx(GuiGraphicsExtractor g, int x1, int y1, int x2, int y2, int radius, int color) {
		int r = Math.max(0, Math.min(radius, Math.min((x2 - x1) / 2, (y2 - y1) / 2)));
		if (x2 - x1 < 2 || y2 - y1 < 2) {
			return;
		}
		if (r <= 0) {
			QuadBatch edges = new QuadBatch(4);
			edges.add(x1, y1, x2, y1 + 1, 0.5f, 0.5f, 0.5f, 0.5f);
			edges.add(x1, y2 - 1, x2, y2, 0.5f, 0.5f, 0.5f, 0.5f);
			edges.add(x1, y1 + 1, x1 + 1, y2 - 1, 0.5f, 0.5f, 0.5f, 0.5f);
			edges.add(x2 - 1, y1 + 1, x2, y2 - 1, 0.5f, 0.5f, 0.5f, 0.5f);
			edges.submit(g, circleTexture(SOLID_RADIUS).texture, color);
			return;
		}
		// Four corner quadrants of a one-pixel ring plus four stretched cardinal pixels (forced solid), one element
		Disc ring = ringTexture(r, 1);
		float size = r * 2f, low = (r - 1) / size, mid = r / size, pad = .5f / size, far = (size - .5f) / size;
		QuadBatch batch = new QuadBatch(8);
		batch.add(x1, y1, x1 + r, y1 + r, 0, 0, 0.5f, 0.5f);
		batch.add(x2 - r, y1, x2, y1 + r, 0.5f, 0, 1, 0.5f);
		batch.add(x1, y2 - r, x1 + r, y2, 0, 0.5f, 0.5f, 1);
		batch.add(x2 - r, y2 - r, x2, y2, 0.5f, 0.5f, 1, 1);
		batch.add(x1 + r, y1, x2 - r, y1 + 1, mid, pad, mid, pad);
		batch.add(x1 + r, y2 - 1, x2 - r, y2, mid, far, mid, far);
		batch.add(x1, y1 + r, x1 + 1, y2 - r, pad, mid, pad, mid);
		batch.add(x2 - 1, y1 + r, x2, y2 - r, far, mid, far, mid);
		batch.submit(g, ring.texture, color);
	}

	// ---- Generated textures --------------------------------------------------------------------------------

	/** A white disc of radius r in a 2r x 2r texture; the four quadrants are the four corners. */
	private static Disc circleTexture(int r) {
		return CIRCLES.computeIfAbsent(r, radius -> register("circle_" + radius, coverage(radius, radius, 0)));
	}

	private static Disc ringTexture(int r, int thickness) {
		long key = ((long) r << 16) | thickness;
		return RINGS.computeIfAbsent(key, k -> {
			float[][] alpha = coverage(r, r, r - thickness);
			int size = r * 2;
			// The flat middle of each side joins a straight edge, so it must be fully covered
			for (int i = r - 1; i <= r; i++) {
				alpha[0][i] = 1f;
				alpha[size - 1][i] = 1f;
				alpha[i][0] = 1f;
				alpha[i][size - 1] = 1f;
			}
			return register("ring_" + r + "_" + thickness, alpha);
		});
	}

	/** Coverage of a disc (outer radius, minus an inner radius for rings) per pixel, 4x4 supersampled. */
	private static float[][] coverage(int r, float outer, float inner) {
		int size = r * 2;
		float[][] alpha = new float[size][size];
		float centre = r;
		int samples = SUPERSAMPLE * SUPERSAMPLE;
		for (int y = 0; y < size; y++) {
			for (int x = 0; x < size; x++) {
				int inside = 0;
				for (int sy = 0; sy < SUPERSAMPLE; sy++) {
					for (int sx = 0; sx < SUPERSAMPLE; sx++) {
						float px = x + (sx + 0.5f) / SUPERSAMPLE - centre;
						float py = y + (sy + 0.5f) / SUPERSAMPLE - centre;
						float d = (float) Math.sqrt(px * px + py * py);
						if (d <= outer && d >= inner) {
							inside++;
						}
					}
				}
				alpha[y][x] = inside / (float) samples;
			}
		}
		return alpha;
	}

	/** {@code inner} &lt; 1 fades the shadow under the shape itself to that fraction. */
	private static ShadowTexture shadowTexture(int radius, int spread, float inner) {
		int innerKey = Math.round(Math.max(0f, Math.min(1f, inner)) * 1000);
		long key = ((long) innerKey << 40) | ((long) radius << 20) | spread;
		return SHADOWS.computeIfAbsent(key, k -> {
			// A rounded square (corners + a 2px middle) with padding, blurred: the 9-slice source for any size
			int core = radius * 2 + 2;
			int size = core + spread * 2;
			float[][] mask = new float[size][size];
			float[][] disc = coverage(radius, radius, 0);
			for (int y = 0; y < core; y++) {
				for (int x = 0; x < core; x++) {
					int cx = x < radius ? x : x >= core - radius ? x - (core - 2 * radius) : -1;
					int cy = y < radius ? y : y >= core - radius ? y - (core - 2 * radius) : -1;
					mask[y + spread][x + spread] = cx >= 0 && cy >= 0 ? disc[cy][cx] : 1f;
				}
			}
			// Three box blurs approximate a Gaussian
			float[][] shape = mask;
			int pass = Math.max(1, spread / 3);
			for (int i = 0; i < 3; i++) {
				mask = boxBlur(mask, pass, true);
				mask = boxBlur(mask, pass, false);
			}
			if (innerKey < 1000) {
				float keep = innerKey / 1000f;
				for (int y = 0; y < size; y++) {
					for (int x = 0; x < size; x++) {
						mask[y][x] *= 1f - shape[y][x] * (1f - keep);
					}
				}
			}
			int corner = size / 2;
			Disc registered = register("shadow_" + radius + "_" + spread + "_" + innerKey, mask);
			return new ShadowTexture(registered.id, registered.texture, size, corner, mask[corner][corner]);
		});
	}

	private static float[][] boxBlur(float[][] in, int radius, boolean horizontal) {
		int size = in.length;
		float[][] out = new float[size][size];
		for (int y = 0; y < size; y++) {
			for (int x = 0; x < size; x++) {
				float sum = 0;
				int count = 0;
				for (int k = -radius; k <= radius; k++) {
					int sx = horizontal ? x + k : x;
					int sy = horizontal ? y : y + k;
					if (sx >= 0 && sy >= 0 && sx < size && sy < size) {
						sum += in[sy][sx];
					}
					count++;
				}
				out[y][x] = sum / count;
			}
		}
		return out;
	}

	private static Disc register(String name, float[][] alpha) {
		int h = alpha.length;
		int w = alpha[0].length;
		NativeImage pixels = new NativeImage(w, h, false);
		for (int y = 0; y < h; y++) {
			for (int x = 0; x < w; x++) {
				int a = Math.round(Math.max(0f, Math.min(1f, alpha[y][x])) * 255);
				pixels.setPixel(x, y, (a << 24) | 0xFFFFFF);
			}
		}
		Identifier id = Goon.id("dynamic/" + name);
		SmoothTexture texture = new SmoothTexture(id.toString(), pixels);
		Minecraft.getInstance().getTextureManager().register(id, texture);
		return new Disc(id, texture);
	}

	private record Disc(Identifier id, SmoothTexture texture) {
	}

	private record ShadowTexture(Identifier id, SmoothTexture texture, int size, int corner, float coreAlpha) {
	}
}
