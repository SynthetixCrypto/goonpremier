package dev.goonclient.client.dev;

import com.mojang.blaze3d.platform.InputConstants;
import dev.goonclient.Goon;
import dev.goonclient.client.config.ConfigManager;
import dev.goonclient.client.gui.ClickGuiScreen;
import dev.goonclient.client.gui.HudEditorScreen;
import dev.goonclient.client.input.ModuleBindings;
import dev.goonclient.client.module.Module;
import dev.goonclient.client.module.ModuleManager;
import dev.goonclient.client.modules.hud.FeedbackHud;
import java.lang.reflect.Field;
import java.util.Set;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/** Opt-in regression checks and screenshots, confined to a disposable development world. */
public final class DevUpdateChecks {
    private static int ticks, key;
    private static volatile boolean pending;
    private static ClickGuiScreen screen;
    private DevUpdateChecks() { }
    public static void init() {
        if (!Boolean.getBoolean("goonclient.updateChecks")) return;
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (!mc.gameDirectory.getName().equals("run-update-checks")) throw new IllegalStateException("Disposable world required");
            if (mc.player == null || mc.level == null || pending) return;
            mc.getFramerateLimitTracker().onInputReceived(); ticks++;
            switch (ticks) {
                case 40 -> setup(mc);
                case 65 -> { gameplay(mc); open(mc, "fullbright"); }
                case 85 -> capture(mc, "shortcut");
                case 90 -> { field("bindingFor", module("fullbright")); screen.keyPressed(new KeyEvent(InputConstants.KEY_W,0,0)); require(ModuleBindings.key(module("fullbright"))==key,"Conflict changed shortcut"); require(get("bindingFor")!=null,"Conflict stopped capture"); }
                case 95 -> capture(mc,"shortcut-conflict");
                case 100 -> {
                    screen.keyPressed(new KeyEvent(InputConstants.KEY_ESCAPE,0,0)); require(mc.gui.screen()==screen && get("bindingFor")==null,"Esc closed settings instead of cancelling capture");
                    field("bindingFor",module("fullbright")); screen.keyPressed(new KeyEvent(InputConstants.KEY_DELETE,0,0)); require(ModuleBindings.key(module("fullbright"))<0,"Delete did not clear");
                    field("bindingFor",module("fullbright")); screen.keyPressed(new KeyEvent(key,0,0)); require(ModuleBindings.key(module("fullbright"))==key,"UI assignment failed");
                    Goon.LOGGER.info("UPDATE CHECKS: shortcut capture/conflict/cancel/delete passed");
                    mc.gui.setScreen(new HudEditorScreen(null));
                }
                case 125 -> capture(mc,"hud-editor");
                case 130 -> { mc.options.guiScale().set(3); mc.resizeGui(); open(mc,"fullbright"); }
                case 155 -> capture(mc,"shortcut-scale3");
                case 160 -> { screen = new ClickGuiScreen(null); ClickGuiChecks.all(screen); mc.gui.setScreen(screen); }
                case 185 -> { ClickGuiChecks.bottom(screen); }
                case 200 -> { ClickGuiChecks.verify(screen); capture(mc,"scroll-scale3"); }
                case 205 -> { mc.options.guiScale().set(2); mc.resizeGui(); mc.gui.setScreen(null); }
                case 225 -> { FeedbackHud.post("demo","Fullbright","Enabled",true); capture(mc,"live-huds"); }
                case 230 -> mc.gui.setScreen(new InventoryScreen(mc.player));
                case 250 -> capture(mc,"inventory-native");
                case 255 -> { mc.gui.setScreen(null); FeedbackHud.clear(); for(int i=0;i<5;i++)FeedbackHud.post("n"+i,"Bounded queue","Example "+i,true); require(FeedbackHud.count()==3,"Unbounded notification queue"); FeedbackHud.clear();
                    module("potions").onTick(mc); require(FeedbackHud.count()==0,"Potion re-alerted during same effect");
                    mc.player.removeEffect(MobEffects.SPEED); module("potions").onTick(mc);
                    mc.player.addEffect(new MobEffectInstance(MobEffects.SPEED,150,0)); module("potions").onTick(mc); require(FeedbackHud.count()==1,"New effect was not re-armed");
                    Goon.LOGGER.info("UPDATE CHECKS: notification dedupe/bounds and potion re-arm passed");
                }
                case 275 -> { Goon.LOGGER.info("UPDATE CHECKS COMPLETE: all assertions passed"); mc.stop(); }
            }
        });
    }
    private static Module module(String id) { return ModuleManager.all().stream().filter(m->m.id().equals(id)).findFirst().orElseThrow(); }
    private static void require(boolean ok,String message) { if(!ok)throw new IllegalStateException(message); }
    private static void key(Minecraft mc,int action,int modifiers) { mc.keyboardHandler.keyPress(mc.getWindow().handle(),action,new KeyEvent(key,0,modifiers)); }
    private static void setup(Minecraft mc) {
        mc.options.guiScale().set(2); mc.options.pauseOnLostFocus=false; mc.resizeGui(); mc.gui.setScreen(null);
        var active=Set.of("interface","minimap","coordinates","tool_info","inventory_hud","potions","notifications","active_modules");
        for(var m:ModuleManager.all())m.setEnabled(active.contains(m.id()));
        for(var h:ModuleManager.hudModules()){h.resetPosition();h.scale.set(1d);}
        ModuleBindings.restore(new com.google.gson.JsonObject());
        for(int candidate=4;candidate<=120;candidate++)if(ModuleBindings.conflict(mc,module("fullbright"),candidate).isEmpty()){key=candidate;break;}
        require(key!=0,"No free test key");
        require(!ModuleBindings.assign(mc,module("fullbright"),InputConstants.KEY_W).ok(),"Movement conflict allowed");
        require(ModuleBindings.assign(mc,module("fullbright"),key).ok(),"Free key rejected");
        require(!ModuleBindings.assign(mc,module("spawn_overlay"),key).ok(),"Duplicate key allowed");
        var saved=ModuleBindings.capture(); ModuleBindings.restore(new com.google.gson.JsonObject()); ModuleBindings.load(); require(ModuleBindings.capture().equals(saved),"Persistence failed");
        mc.player.getInventory().clearContent();
        var items=java.util.List.of(Items.OAK_PLANKS,Items.GLASS,Items.DIAMOND,Items.CARROT,Items.REDSTONE,Items.TORCH,Items.IRON_INGOT,Items.GOLD_INGOT,Items.COBBLESTONE);
        for(int i=0;i<items.size();i++)mc.player.getInventory().setItem(9+i,new ItemStack(items.get(i),i+1));
        for(int i=0;i<items.size();i++)require(mc.player.getInventory().getItem(9+i).is(items.get(i)),"Local inventory item mismatch");
        Goon.LOGGER.info("UPDATE CHECKS: nine distinct local inventory stacks installed; movement/duplicate bindings and persistence passed");
        mc.player.setItemInHand(net.minecraft.world.InteractionHand.MAIN_HAND,new ItemStack(Items.DIAMOND_PICKAXE));
        mc.player.getMainHandItem().setDamageValue(420);
        var registry=mc.level.registryAccess().lookupOrThrow(net.minecraft.core.registries.Registries.ENCHANTMENT);
        mc.player.getMainHandItem().enchant(registry.getOrThrow(net.minecraft.world.item.enchantment.Enchantments.EFFICIENCY),5);
        mc.player.addEffect(new MobEffectInstance(MobEffects.SPEED,100000,1));
        for(var s:module("potions").settings())if(s.id().equals("expiry_alerts"))((dev.goonclient.client.module.setting.BooleanSetting)s).set(true);
    }
    private static void gameplay(Minecraft mc) {
        var fullbright=module("fullbright"); fullbright.setEnabled(false); FeedbackHud.clear();
        key(mc,InputConstants.PRESS,0); require(fullbright.isEnabled(),"Raw key did not toggle");
        key(mc,InputConstants.REPEAT,0); key(mc,InputConstants.RELEASE,0); require(fullbright.isEnabled(),"Repeat/release toggled module");
        key(mc,InputConstants.PRESS,InputConstants.MOD_CONTROL); require(fullbright.isEnabled(),"Modifier toggled module");
        key(mc,InputConstants.PRESS,InputConstants.MOD_CAPS_LOCK); require(!fullbright.isEnabled(),"CapsLock blocked shortcut");
        mc.gui.setScreen(new ClickGuiScreen(null)); key(mc,InputConstants.PRESS,0); require(!fullbright.isEnabled(),"Menu key toggled module"); mc.gui.setScreen(null);
        ModuleBindings.press(mc,mc.getWindow().handle()+1,InputConstants.PRESS,new KeyEvent(key,0,0)); require(!fullbright.isEnabled(),"Wrong window accepted");
        key(mc,InputConstants.PRESS,0); require(fullbright.isEnabled(),"Second key press failed");
        FeedbackHud.clear(); mc.player.removeEffect(MobEffects.SPEED); mc.player.addEffect(new MobEffectInstance(MobEffects.SPEED,150,1));
        module("potions").onTick(mc); require(FeedbackHud.count()==1,"Missing potion warning"); module("potions").onTick(mc); require(FeedbackHud.count()==1,"Repeated potion warning");
        mc.player.removeEffect(MobEffects.SPEED); mc.player.addEffect(new MobEffectInstance(MobEffects.SPEED,100000,1)); module("potions").onTick(mc); FeedbackHud.clear();
        Goon.LOGGER.info("UPDATE CHECKS: raw keyboard injection, repeat/release/modifier/menu/window guards and potion dedupe passed");
    }
    private static void open(Minecraft mc,String id) { screen=new ClickGuiScreen(null);screen.openSettingsFor(module(id));mc.gui.setScreen(screen); }
    private static Object get(String name){try{Field f=ClickGuiScreen.class.getDeclaredField(name);f.setAccessible(true);return f.get(screen);}catch(Exception e){throw new IllegalStateException(e);}}
    private static void field(String name,Object value){try{Field f=ClickGuiScreen.class.getDeclaredField(name);f.setAccessible(true);f.set(screen,value);}catch(Exception e){throw new IllegalStateException(e);}}
    private static void capture(Minecraft mc,String name){pending=true;Screenshot.grab(mc.gameDirectory,"goon-080-"+name+".png",mc.gameRenderer.mainRenderTarget(),1,message->pending=false);}
}


