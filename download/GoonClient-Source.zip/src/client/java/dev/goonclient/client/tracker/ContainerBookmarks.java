package dev.goonclient.client.tracker;

import com.google.gson.JsonParser;
import dev.goonclient.Goon;
import dev.goonclient.client.config.ConfigManager;
import dev.goonclient.client.modules.inventory.ContainerMemory;
import dev.goonclient.client.utility.LocalFiles;
import dev.goonclient.client.utility.WorldScope;
import java.nio.file.*;
import java.util.*;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.protocol.game.ClientboundOpenScreenPacket;
import net.minecraft.world.inventory.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.properties.ChestType;
import net.minecraft.world.phys.BlockHitResult;

/** Records only server-supplied slots after a local use of a known container block. Never reads block-entity inventories. */
public final class ContainerBookmarks {
    public record ItemCount(String id,String name,long count){}
    public record Entry(String id,String title,String dimension,int x,int y,int z,long seen,List<ItemCount> items){}
    private record Pending(Object world,BlockPos pos,String kind,String dimension,long at){}
    private static final LinkedHashMap<String,Entry> entries=new LinkedHashMap<>();
    private static WorldScope scope;
    private static Path file;
    private static Pending pending;
    private static Pending opened;
    private static String title="",error="";
    private static int menuId=-1,slots;
    private static boolean dirty,readable=true,received;
    private static long revision,lastSave;
    private static long snapshotRevision=-1;
    private static List<Entry> snapshot=List.of();
    private ContainerBookmarks(){}
    public static boolean active(){return scope!=null;}
    public static String worldName(){return scope==null?"":scope.name();}
    public static String error(){return error;}
    public static long revision(){return revision;}
    public static int size(){return entries.size();}
    public static List<Entry> all(){if(snapshotRevision!=revision){snapshot=List.copyOf(entries.values());snapshotRevision=revision;}return snapshot;}
    public static void onJoin(Minecraft mc){
        onLeave();scope=WorldScope.current(mc);if(scope==null)return;
        file=ConfigManager.dir().resolve("containers").resolve(WorldScope.hash(scope.key()+":"+mc.getUser().getProfileId())+".json");
        readable=true;error="";
        if(!Files.exists(file))return;
        try{
            var root=JsonParser.parseString(LocalFiles.read(file,4*1024*1024)).getAsJsonObject();
            if(root.get("version").getAsInt()!=1)throw new IllegalArgumentException();
            for(var row:root.getAsJsonArray("containers")){
                if(entries.size()>=256)break;
                Entry e=ConfigManager.GSON.fromJson(row,Entry.class);validate(e);
                entries.put(e.id(),new Entry(e.id(),WorldScope.clean(e.title(),64),e.dimension(),e.x(),e.y(),e.z(),e.seen(),List.copyOf(e.items())));
            }
            revision++;
        }catch(Exception e){entries.clear();readable=false;error="Couldn't read container bookmarks. Existing file kept; recording is paused.";Goon.LOGGER.warn("Couldn't read local container bookmarks; existing file retained.");}
    }
    private static void validate(Entry e){
        if(e==null||e.dimension()==null||!e.dimension().matches("[a-z0-9_.-]+:[a-z0-9/._-]+")||Math.abs((long)e.x())>30_000_000||Math.abs((long)e.z())>30_000_000||Math.abs((long)e.y())>4096||e.seen()<0||e.title()==null||e.title().length()>128||e.items()==null||e.items().size()>64||!id(e.dimension(),new BlockPos(e.x(),e.y(),e.z())).equals(e.id()))throw new IllegalArgumentException();
        for(var item:e.items())if(item==null||item.id()==null||item.id().length()>256||!item.id().matches("[a-z0-9_.-]+:[a-z0-9/._-]+")||item.name()==null||item.name().length()>128||item.count()<=0||item.count()>Integer.MAX_VALUE)throw new IllegalArgumentException();
    }
    public static void onLeave(){save();scope=null;file=null;entries.clear();cancel();revision++;dirty=false;}
    public static void cancel(){pending=null;opened=null;menuId=-1;slots=0;received=false;}
    private static String id(String dimension,BlockPos pos){return dimension+":"+pos.getX()+","+pos.getY()+","+pos.getZ();}
    private static String kind(net.minecraft.world.level.block.state.BlockState state){
        var b=state.getBlock();
        if(b instanceof ChestBlock||b instanceof BarrelBlock)return "chest";
        if(b instanceof ShulkerBoxBlock)return "shulker";
        if(b instanceof HopperBlock)return "hopper";
        if(b instanceof DispenserBlock)return "dispenser";
        if(b instanceof AbstractFurnaceBlock)return "furnace";
        if(b instanceof BrewingStandBlock)return "brewing";
        return "";
    }
    public static void used(Minecraft mc,BlockHitResult hit){
        if(!ContainerMemory.recording()||!readable||scope==null||mc.level==null||mc.player==null)return;
        var state=mc.level.getBlockState(hit.getBlockPos());String kind=kind(state);pending=null;
        if(kind.isEmpty())return;
        BlockPos pos=hit.getBlockPos();
        if(state.getBlock() instanceof ChestBlock&&state.getValue(ChestBlock.TYPE)!=ChestType.SINGLE){
            BlockPos other=pos.relative(ChestBlock.getConnectedDirection(state));
            if(other.getX()<pos.getX()||other.getX()==pos.getX()&&other.getZ()<pos.getZ())pos=other;
        }
        pending=new Pending(mc.level,pos.immutable(),kind,mc.level.dimension().identifier().toString(),System.nanoTime());
    }
    private static boolean matches(String kind,AbstractContainerMenu menu){
        return switch(kind){case "chest"->menu instanceof ChestMenu;case "shulker"->menu instanceof ShulkerBoxMenu;case "hopper"->menu instanceof HopperMenu;case "dispenser"->menu instanceof DispenserMenu;case "furnace"->menu instanceof AbstractFurnaceMenu;case "brewing"->menu instanceof BrewingStandMenu;default->false;};
    }
    public static void opened(Minecraft mc,ClientboundOpenScreenPacket packet){
        opened=null;menuId=-1;received=false;
        if(!ContainerMemory.recording()||!readable||pending==null||mc.player==null||mc.level!=pending.world()||System.nanoTime()-pending.at()>5_000_000_000L)return;
        var menu=mc.player.containerMenu;
        if(menu.containerId!=packet.getContainerId()||!matches(pending.kind(),menu)||mc.player.distanceToSqr(pending.pos().getX()+.5,pending.pos().getY()+.5,pending.pos().getZ()+.5)>100)return;
        int size=menu.slots.size()-36;if(size<=0||size>64)return;
        for(int i=0;i<size;i++)if(menu.slots.get(i).container==mc.player.getInventory())return;
        opened=pending;pending=null;menuId=menu.containerId;slots=size;title=WorldScope.clean(packet.getTitle().getString(),64);
    }
    public static void contents(Minecraft mc,int id){
        if(!ContainerMemory.recording()||!readable||opened==null||scope==null||mc.player==null||mc.level!=opened.world()||id!=menuId||mc.player.containerMenu.containerId!=id)return;
        boolean first=!received;received=true;
        var totals=new LinkedHashMap<String,Long>();
        var lastStacks=new HashMap<String,net.minecraft.world.item.ItemStack>();
        for(int i=0;i<slots;i++){
            var stack=mc.player.containerMenu.slots.get(i).getItem();if(stack.isEmpty())continue;
            String key=BuiltInRegistries.ITEM.getKey(stack.getItem()).toString();
            totals.merge(key,(long)stack.getCount(),Long::sum);lastStacks.put(key,stack);
        }
        // Preserve the previous last-stack label semantics, resolving each distinct item's name once.
        var counts=new ArrayList<ItemCount>(totals.size());
        totals.forEach((key,count)->counts.add(new ItemCount(key,WorldScope.clean(lastStacks.get(key).getHoverName().getString(),64),count)));
        var p=opened.pos();Entry entry=new Entry(id(opened.dimension(),p),title,opened.dimension(),p.getX(),p.getY(),p.getZ(),System.currentTimeMillis(),List.copyOf(counts));
        Entry previous=entries.get(entry.id());
        if(!first&&previous!=null&&previous.title().equals(entry.title())&&previous.items().equals(entry.items()))return;
        entries.remove(entry.id());entries.put(entry.id(),entry);
        while(entries.size()>256)entries.remove(entries.keySet().iterator().next());
        dirty=true;revision++;
    }
    public static void slot(Minecraft mc,int id,int slot){if(received&&slot>=0&&slot<slots)contents(mc,id);}
    public static void tick(Minecraft mc){
        if(!ContainerMemory.recording()){pending=null;opened=null;menuId=-1;}
        if(pending!=null&&(mc.level!=pending.world()||System.nanoTime()-pending.at()>5_000_000_000L))pending=null;
        if(opened!=null&&(mc.player==null||mc.level!=opened.world()||mc.player.containerMenu.containerId!=menuId)){opened=null;menuId=-1;}
        if(dirty&&System.nanoTime()-lastSave>=2_000_000_000L){lastSave=System.nanoTime();save();}
    }
    public static boolean remove(String id){Entry old=entries.remove(id);if(old==null)return false;dirty=true;revision++;save();return true;}
    private static void save(){
        if(!dirty||file==null||!readable)return;
        try{var data=new com.google.gson.JsonObject();data.addProperty("version",1);data.add("containers",ConfigManager.GSON.toJsonTree(entries.values()));String text=ConfigManager.GSON.toJson(data);if(text.getBytes(java.nio.charset.StandardCharsets.UTF_8).length>4*1024*1024)throw new java.io.IOException();LocalFiles.write(file,text);dirty=false;error="";}
        catch(Exception e){error="Couldn't save bookmarks. Check your config folder.";Goon.LOGGER.warn("Couldn't save local container bookmarks.");}
    }
}
