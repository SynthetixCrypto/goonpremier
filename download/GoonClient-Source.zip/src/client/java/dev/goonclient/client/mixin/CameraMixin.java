package dev.goonclient.client.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import dev.goonclient.client.modules.visual.Freelook;
import dev.goonclient.client.modules.visual.Zoom;
import net.minecraft.client.Camera;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Camera.class)
public abstract class CameraMixin {
	/** Zoom: shrink the field of view. In 26.3 the FOV is computed by the camera. */
	@Inject(method = "calculateFov", at = @At("RETURN"), cancellable = true)
	private void goonclient$zoom(float partialTick, CallbackInfoReturnable<Float> cir) {
		cir.setReturnValue(Zoom.modifyFov(cir.getReturnValueF()));
	}

	/**
	 * Freelook: point the camera where the freelook angles say, not where the player faces.
	 * WrapOperation (not Redirect) so other camera mods hooking the same call still work.
	 */
	@WrapOperation(method = "alignWithEntity", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/Camera;setRotation(FF)V"))
	private void goonclient$freelook(Camera camera, float yRot, float xRot, Operation<Void> original) {
		if (Freelook.isActive()) {
			original.call(camera, Freelook.yaw(), Freelook.pitch());
		} else {
			original.call(camera, yRot, xRot);
		}
	}
}
