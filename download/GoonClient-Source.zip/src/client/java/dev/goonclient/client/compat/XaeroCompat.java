package dev.goonclient.client.compat;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import xaero.hud.minimap.BuiltInHudModules;
import xaero.hud.minimap.module.MinimapSession;
import xaero.hud.render.module.ModuleRenderContext;

/** Native map data, radar and waypoints; Goon owns only the HUD placement and visibility gate. */
public final class XaeroCompat {
	private static Object config;
	private static java.lang.reflect.Method activeGetter;
	private static java.lang.reflect.Method activeSetter;
	private static Boolean lastNative;
	private static boolean failed;
	private XaeroCompat() { }

	/** Keep Xaero's native hotkey/settings and Goon's switch in sync, including while the switch is off. */
	public static void syncVisibility(dev.goonclient.client.module.Module goon) {
		if (failed || xaero.common.HudMod.INSTANCE == null || !xaero.common.HudMod.INSTANCE.isLoadedClient()) return;
		try {
			// XaeroLib is nested in the optional mod, so avoid a hard classpath dependency on its config classes.
			if (config == null) {
				Object channel = xaero.common.HudMod.class.getMethod("getHudConfigs").invoke(xaero.common.HudMod.INSTANCE);
				config = channel.getClass().getMethod("getClientConfigManager").invoke(channel);
				for (var method : BuiltInHudModules.MINIMAP.getClass().getMethods()) {
					if (method.getName().equals("isActive")) activeGetter = method;
					if (method.getName().equals("setActive")) activeSetter = method;
				}
			}
			boolean nativeOn = (boolean) activeGetter.invoke(BuiltInHudModules.MINIMAP, config);
			if (lastNative != null && nativeOn != lastNative) {
				goon.loadEnabled(nativeOn);
				dev.goonclient.client.config.ConfigManager.markDirty();
			} else if (nativeOn != goon.isEnabled()) {
				activeSetter.invoke(BuiltInHudModules.MINIMAP, config, goon.isEnabled());
				nativeOn = (boolean) activeGetter.invoke(BuiltInHudModules.MINIMAP, config);
			}
			lastNative = nativeOn;
		} catch (ReflectiveOperationException | RuntimeException e) {
			failed = true;
			dev.goonclient.Goon.LOGGER.error("Couldn't synchronize Xaero minimap visibility", e);
		}
	}

	private static MinimapSession session() {
		return BuiltInHudModules.MINIMAP.getCurrentSession();
	}

	public static int size(Minecraft mc) {
		if (mc.player == null || mc.level == null) return Math.round(80 * dev.goonclient.client.modules.hud.MinimapHud.mapScale());
		var session = session();
		if (session == null) return 80;
		session.prePotentialRender();
		return session.getWidth(mc.getWindow().getGuiScale());
	}

	public static boolean visible(Minecraft mc) {
		if (mc.player == null || mc.level == null) return false;
		var session = session();
		if (session != null) session.prePotentialRender();
		if (session == null || !session.isActive()) return false;
		if (session.getHideMinimapUnderF3() && mc.getDebugOverlay().showDebugScreen()) return false;
		if (session.getHideMinimapUnderScreen() && mc.gui.screen() != null
			&& !(mc.gui.screen() instanceof net.minecraft.client.gui.screens.ChatScreen)) return false;
		return !session.getProcessor().getNoMinimapMessageReceived()
			&& !xaero.common.misc.Misc.hasEffect(mc.player, xaero.common.effect.Effects.NO_MINIMAP)
			&& !xaero.common.misc.Misc.hasEffect(mc.player, xaero.common.effect.Effects.NO_MINIMAP_HARMFUL);
	}

	public static void enlarged(boolean enlarged) {
		if (session() != null) session().getProcessor().setEnlargedMap(enlarged);
	}

	public static net.minecraft.client.gui.navigation.ScreenRectangle drawnBounds() {
		var session = session();
		return (session.getProcessor().isEnlargedMap() ? session.getProcessor().getEnlargedRenderState()
			: session.getProcessor().getRenderState()).bounds();
	}

	public static void render(GuiGraphicsExtractor g, Minecraft mc, int x, int y, int size) {
		if (mc.player == null || mc.level == null) return;
		var session = session();
		if (session == null || !session.isActive()) return;
		var context = new ModuleRenderContext(g.guiWidth(), g.guiHeight(), mc.getWindow().getGuiScale());
		context.x = x;
		context.y = y;
		context.w = size;
		context.h = size;
		BuiltInHudModules.MINIMAP.getRenderer().render(session, context, g, mc.getDeltaTracker().getGameTimeDeltaPartialTick(false));
	}

	public static Screen settings(Screen parent) {
		Screen screen = BuiltInHudModules.MINIMAP.getConfigScreenFactory().apply(parent);
		try {
			// Native factories use Esc-to-game even with a parent. Both Back and Esc should return to our settings.
			screen.getClass().getField("escape").set(screen, parent);
		} catch (ReflectiveOperationException e) {
			dev.goonclient.Goon.LOGGER.warn("Couldn't set the minimap settings return screen", e);
		}
		return screen;
	}
}
