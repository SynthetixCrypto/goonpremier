package dev.goonclient.client.mixin;

import dev.goonclient.client.modules.utility.UtilityModules;
import java.util.List;
import net.minecraft.client.gui.components.ChatComponent;
import net.minecraft.client.multiplayer.chat.GuiMessage;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ChatComponent.class)
public class ChatComponentMixin {
	@Shadow
	@Final
	private List<GuiMessage> allMessages;

	@Shadow
	@Final
	private List<GuiMessage.Line> trimmedMessages;

	/** The last message added, its text before any decoration, and how many times in a row it arrived. */
	@Unique
	private GuiMessage goonclient$lastMessage;
	@Unique
	private String goonclient$lastText;
	@Unique
	private int goonclient$repeats;

	@ModifyVariable(
		method = "addMessage(Lnet/minecraft/network/chat/Component;Lnet/minecraft/network/chat/MessageSignature;Lnet/minecraft/client/multiplayer/chat/GuiMessageSource;Lnet/minecraft/client/multiplayer/chat/GuiMessageTag;)V",
		at = @At("HEAD"), argsOnly = true, ordinal = 0)
	private Component goonclient$decorate(Component message) {
		String text = message.getString();
		GuiMessage previous = goonclient$lastMessage;
		// Better Chat: the same text again replaces the previous line, with a counter
		if (UtilityModules.BetterChat.stacksRepeats() && previous != null && text.equals(goonclient$lastText)
			&& !allMessages.isEmpty() && allMessages.getFirst() == previous) {
			goonclient$repeats++;
			allMessages.removeFirst();
			trimmedMessages.removeIf(line -> line.parent() == previous);
			message = UtilityModules.BetterChat.withCount(message, goonclient$repeats);
		} else {
			goonclient$repeats = 1;
		}
		goonclient$lastText = text;
		return UtilityModules.ChatTimestamps.decorate(message);
	}

	@Inject(method = "addMessageToQueue", at = @At("HEAD"))
	private void goonclient$remember(GuiMessage message, CallbackInfo ci) {
		goonclient$lastMessage = message;
	}

	@ModifyConstant(method = {"addMessageToQueue", "addMessageToDisplayQueue"}, constant = @Constant(intValue = 100))
	private int goonclient$historySize(int vanilla) {
		return UtilityModules.BetterChat.historySize();
	}
}
