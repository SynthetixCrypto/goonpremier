package dev.goonclient.client.modules.hud;

import dev.goonclient.client.gui.render.Icons;
import dev.goonclient.client.gui.Ui;
import dev.goonclient.client.hud.HudPosition;
import dev.goonclient.client.hud.TextHudModule;
import dev.goonclient.client.input.ModuleBindings;
import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.Module;
import dev.goonclient.client.module.ModuleManager;
import dev.goonclient.client.module.setting.BooleanSetting;
import dev.goonclient.client.module.setting.NumberSetting;
import java.util.Comparator;
import java.util.List;
import net.minecraft.client.Minecraft;

/** Original compact equivalent of client array lists, integrated with Goon's normal HUD layout. */
public final class ActiveModulesHud extends TextHudModule {
    private final BooleanSetting boundOnly = add(new BooleanSetting("bound_only", "Only modules with shortcuts", true));
    private final NumberSetting maximum = add(new NumberSetting("maximum", "Maximum rows", 8, 3, 15, 1));
    public ActiveModulesHud() {
        super("active_modules", "Keybinds", "Enabled features and their shortcut keys, with an optional full module list", Category.HUD, true, HudPosition.topRight(92, 64));
    }

    @Override
    protected Icons.Icon icon() {
    	return Icons.Icon.KEYBOARD;
    }

    @Override
    protected Variant variant() {
        return Variant.KEYBINDS;
    }

    @Override
    protected String countLabel() {
    	return "Active";
    }
    @Override protected void collect(Minecraft mc, List<Line> lines, boolean editing) {
        var active = ModuleManager.all().stream().filter(m -> m != this && m.isEnabled() && (!boundOnly.isOn() || ModuleBindings.key(m) >= 0))
            .sorted(Comparator.comparing(Module::name)).toList();
        if (active.isEmpty()) {
            if (editing) { lines.add(new Line("Fullbright", "F8", Ui.accent())); lines.add(new Line("Spawn Overlay", "F9", Ui.accent())); }
            return;
        }
        for (int i = 0; i < Math.min(active.size(), maximum.intValue()); i++) {
            var m = active.get(i); lines.add(new Line(m.name(), ModuleBindings.key(m) < 0 ? "On" : ModuleBindings.label(m), Ui.accent(), Ui.TEXT).withIcon(dev.goonclient.client.gui.render.Icons.forCategory(m.category())));
        }
        if (active.size() > maximum.intValue()) lines.add(new Line("", "+" + (active.size() - maximum.intValue()) + " more", Ui.MUTED));
    }
}
