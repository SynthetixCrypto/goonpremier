package dev.goonclient.client.dev;

import dev.goonclient.Goon;
import dev.goonclient.client.config.ConfigManager;
import dev.goonclient.client.gui.HudEditorScreen;
import dev.goonclient.client.module.ModuleManager;
import dev.goonclient.client.module.setting.ModeSetting;
import dev.goonclient.client.modules.hud.SimpleHuds;
import dev.goonclient.client.util.MemoryStats;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;

/** Explicit isolated development check; never runs for normal players. */
public final class DevMemoryChecks {
    private static int tick, scale;
    private static boolean hidden;
    private static volatile boolean pending;
    private static com.google.gson.JsonObject before;
    private static SimpleHuds.Memory memory;
    private static ModeSetting metric;
    private DevMemoryChecks() {}
    public static void init() {
        if (Boolean.getBoolean("goonclient.memoryChecks")) ClientTickEvents.END_CLIENT_TICK.register(DevMemoryChecks::tick);
    }
    private static void tick(Minecraft mc) {
        if (!mc.isGameLoadFinished() || mc.gui.overlay() != null || pending) return;
        mc.getFramerateLimitTracker().onInputReceived();tick++;
        if(tick==1){
            before=ConfigManager.capture();scale=mc.options.guiScale().get();hidden=mc.gui.hud.isHidden();if(hidden)mc.gui.hud.toggle();
            memory=(SimpleHuds.Memory)ModuleManager.all().stream().filter(m->m.id().equals("memory")).findFirst().orElseThrow();
            metric=(ModeSetting)memory.settings().stream().filter(s->s.id().equals("metric")).findFirst().orElseThrow();
            for(var hud:ModuleManager.hudModules())hud.loadEnabled(hud==memory);
            metric.set("Private RAM");mc.options.guiScale().set(2);mc.resizeGui();mc.gui.setScreen(new HudEditorScreen(null));
        }
        if(tick==15||tick==35||tick==70||tick==110) {
            var s=MemoryStats.sample();
            if(s.processBytes()<=0||s.privateBytes()<=0||s.privateBytes()>s.processBytes()||s.heapLimit()<s.heapUsed())throw new IllegalStateException("Bad game memory sample: "+s);
            Goon.LOGGER.info("MEMORY LIVE SAMPLE pid={} {}",ProcessHandle.current().pid(),s);
        }
        if(tick==15)verifyRows(mc);
        if(tick==20)shot(mc,"private-scale2");
        if(tick==35)metric.set("Process RAM");
        if(tick==55)shot(mc,"resident-scale2");
        if(tick==70)metric.set("Java heap");
        if(tick==90)shot(mc,"heap-scale2");
        if(tick==100){metric.set("Private RAM");mc.options.guiScale().set(4);mc.resizeGui();}
        if(tick==120)shot(mc,"private-scale4");
        if(tick==125){
            ConfigManager.apply(before,true,false);mc.options.guiScale().set(scale);if(mc.gui.hud.isHidden()!=hidden)mc.gui.hud.toggle();mc.resizeGui();
            Goon.LOGGER.info("MEMORY GAME CHECKS PASSED: three actual HUD readings, shared cache, private/resident/heap bounds, scales 2/4, no-world editor, config restoration");mc.stop();
        }
    }
    private static void verifyRows(Minecraft mc){
        try{
            var method=SimpleHuds.Memory.class.getDeclaredMethod("collect",Minecraft.class,java.util.List.class,boolean.class);method.setAccessible(true);
            String selected=metric.get();var s=MemoryStats.sample();
            for(String option:java.util.List.of("Private RAM","Process RAM","Java heap")){
                metric.set(option);var rows=new java.util.ArrayList<dev.goonclient.client.hud.TextHudModule.Line>();method.invoke(memory,mc,rows,true);
                if(rows.size()!=1)throw new IllegalStateException("Missing RAM row");
                String text=rows.getFirst().segments().stream().map(p->p.text()).collect(java.util.stream.Collectors.joining(" "));
                String number=option.equals("Private RAM")?Long.toString(s.privateBytes()>>20):option.equals("Process RAM")?Long.toString(s.processBytes()>>20):(s.heapUsed()>>20)+"/"+(s.heapLimit()>>20);
                if(!text.contains(number)||!text.contains(option.equals("Java heap")?"heap":option.equals("Private RAM")?"private RAM":"resident RAM"))throw new IllegalStateException("Wrong RAM HUD row: "+text);
                Goon.LOGGER.info("MEMORY HUD {}: {}",option,text);
            }
            if(s!=MemoryStats.sample())throw new IllegalStateException("Memory cache refreshed too often");metric.set(selected);
        }catch(ReflectiveOperationException ex){throw new IllegalStateException(ex);}
    }
    private static void shot(Minecraft mc,String name){pending=true;Screenshot.grab(mc.gameDirectory,"goon-memory-0183-"+name+".png",mc.gameRenderer.mainRenderTarget(),1,message->pending=false);}
}
