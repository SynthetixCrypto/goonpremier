/*
 * This file incorporates geometry from the Combatant Client distribution.
 * Copyright (c) 2026 pivosos2007. Licensed under the GNU General Public License v3.0.
 * Modified for Goon Client, 2026-10-07: ModulesMenuScreen column geometry and row layout
 * adapted to the native 26.3 renderer and input clipping. Modified 2026-10-07: replace dropdown columns
 * with an original centered, tabbed icon-card workspace; retain the shared Combatant-derived glass material.
 */
package dev.goonclient.client.gui;

import com.mojang.blaze3d.platform.InputConstants;
import dev.goonclient.Goon;
import dev.goonclient.client.GoonKeys;
import dev.goonclient.client.config.ConfigManager;
import dev.goonclient.client.gui.render.GoonFont;
import dev.goonclient.client.gui.render.Icons;
import dev.goonclient.client.gui.render.Shapes;
import dev.goonclient.client.hud.HudModule;
import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.Module;
import dev.goonclient.client.module.ModuleManager;
import dev.goonclient.client.module.setting.BooleanSetting;
import dev.goonclient.client.module.setting.ButtonSetting;
import dev.goonclient.client.module.setting.ModeSetting;
import dev.goonclient.client.module.setting.NumberSetting;
import dev.goonclient.client.module.setting.Setting;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;

/**
 * Combatant reference columns or the classic Goon workspace, with shared-frame blur and clipped input.
 * all on one frosted window. Each card toggles, opens its settings and stars as a favorite. Settings, bindings and
 * profiles remain Goon's controls.
 */
public class ClickGuiScreen extends Screen implements GoonScreen {
	
	
	
	private static final long OPEN_MS = 240;
	private static final long CLOSE_MS = 150;

	private static final float TITLE = 12.5f;
	private static final float NAME = 9.2f;
	private static final float BODY = 8.2f;
	private static final float SMALL = 7.4f;

	/** Remembered between openings; null means "All". */
	private static Category selected = null;

	private final Screen parent;
	private final String version;
	private final List<Hit> hits = new ArrayList<>();
	private final Map<String, List<String>> wrapCache = new HashMap<>();

	private String search = "";
	private boolean searching;
	private Module bindingFor;
    private Module keyboardModule;
	private String bindMessage = "";
	private boolean suppressCharacter;
	private enum Filter { ALL, ENABLED, FAVORITES }
	private static Filter filter = Filter.ALL;
	private float renderedView;
	private String tooltipText, lastHelp = "", resetArmed = "";
	private long helpSince, resetAt;
	private Module settingsFor;
	/** The settings page that is sliding out, kept so it can still be drawn during the transition. */
	private Module lastSettings;
	private float scroll;
	private float scrollTarget;
	private float contentHeight;
	private long lastScrollAt;
	private long openedAt;
	private long closingAt;
	private long viewChangedAt;
	private NumberSetting dragging;
	private float dragX;
	private float dragWidth;
	private boolean draggingScrollbar;
	private float scrollbarGrab;
	private float renderScale = 1;
	private float renderRise;

	/** Menu scale: the menu lays out in a virtual space of (vw x vh) GUI units, see Ui#menuScale. */
	private float s = 1;
	private float vw;
	private float vh;
	private float px;
	private float py;
	private float pw;
	private float ph;
	private float contentLeft;
	private float contentRight;
	private float contentTop;
	private float contentBottom;

	public ClickGuiScreen(Screen parent) {
		super(Component.literal("Goon Client"));
		this.parent = parent;
		this.version = FabricLoader.getInstance().getModContainer(Goon.MOD_ID)
			.map(container -> container.getMetadata().getVersion().getFriendlyString()).orElse("dev");
	}

	@Override
	protected void init() {
		clearInputState();
		// Fit the centered workspace even below the usual menu scale floor.
		s = GlassUi.canvasScale(width, height);
		GlassUi.hideHud(minecraft);
		vw = width / s;
		vh = height / s;
		layoutWindow();
		pw = Math.min(vw - 48f, 240f);
		ph = Math.max(150, Math.min(vh - 56f, 252f));
		px = (vw - pw) / 2f;
		py = (vh - ph) / 2f + 8;
		contentLeft = px + 9;
		contentRight = px + pw - 12;
		contentTop = py + 43;
		contentBottom = py + ph - 7;
		Ui.snap("cg:view", settingsFor == null ? 0 : 1);
		renderedView = settingsFor == null ? 0 : 1;
		Ui.snap("cg:grid", gridTarget);
		scrollTarget = Math.max(0, Math.min(maxScroll(), scrollTarget));
		Ui.snap("cg:scroll", scrollTarget);
		if (openedAt == 0) {
			openedAt = System.currentTimeMillis();
			viewChangedAt = openedAt;
		}
	}

	// ---- Frame -------------------------------------------------------------------------------------------

	@Override
	public void extractRenderState(GuiGraphicsExtractor g, int realMouseX, int realMouseY, float partialTick) {
		hits.clear();
		tooltipText = null;
		int mouseX = (int) (realMouseX / s);
		int mouseY = (int) (realMouseY / s);
		long now = System.currentTimeMillis();
		float open;
		if (closingAt > 0) {
			open = 1f - Ui.easeOutCubic((now - closingAt) / (float) CLOSE_MS);
			if (open <= 0f) {
				minecraft.execute(() -> minecraft.gui.setScreen(parent));
			}
		} else {
			open = Ui.easeOutCubic((now - openedAt) / (float) OPEN_MS);
		}
		open = Math.max(0f, open);

		float scale = 0.965f + 0.035f * open;
		renderScale = scale;
		renderRise = (1 - open) * 8;
		mouseX = (int) inputX(realMouseX);
		mouseY = (int) inputY(realMouseY);
		g.pose().pushMatrix();
		g.pose().scale(s, s);
		g.pose().translate(vw / 2f, vh / 2f + (1 - open) * 8);
		g.pose().scale(scale, scale);
		g.pose().translate(-vw / 2f, -vh / 2f);

        float view = Ui.animate("cg:view", settingsFor != null ? 1f : 0f, .55f);
        renderedView = view;
        if(view < .999f) drawWorkspace(g,mouseX,mouseY,open*(1-view),now,settingsFor==null&&view<.001f&&closingAt==0);
        Module page=settingsFor!=null?settingsFor:lastSettings;
        if(view>.001f&&page!=null) {
            float alpha=open*view;
            // Element panel: dark body for readable small text, a lighter frosted header band
            GlassUi.window(g,px,py,pw,ph,alpha);
            Shapes.roundRect(g,px+.5f,py+.5f,px+pw-.5f,py+22.5f,6.5f,Ui.withAlpha(0xFFFFFFFF,.05f*alpha));
            contentHeight=measureContentHeight();
            scrollTarget=Math.max(0,Math.min(maxScroll(),scrollTarget));
            scroll=Math.max(0,Math.min(maxScroll(),Ui.animate("cg:scroll",scrollTarget,.55f)));
            g.enableScissor((int)Math.ceil(px+1),(int)Math.ceil(py+1),(int)Math.floor(px+pw-1),(int)Math.floor(py+ph-1));
            drawSettingsHeader(g,page,mouseX,mouseY,alpha,0);
            clipContent(g);
            drawSettings(g,page,mouseX,mouseY,alpha,0,settingsFor!=null&&view>.999f&&closingAt==0);
            g.disableScissor();g.disableScissor();
            if(settingsFor!=null&&view>.999f&&closingAt==0)drawScrollbar(g,alpha,now);
        }
        drawNavigation(g,mouseX,mouseY,open);

		drawHelp(g, mouseX, mouseY, open, now);

		g.pose().popMatrix();
		super.extractRenderState(g, realMouseX, realMouseY, partialTick);
	}

	// ---- Sidebar -----------------------------------------------------------------------------------------



	// ---- Grid --------------------------------------------------------------------------------------------


	private void magnifier(GuiGraphicsExtractor g, float cx, float cy, int color) {
		Shapes.outline(g, cx - 3.6f, cy - 3.6f, cx + 2.6f, cy + 2.6f, 3.1f, color);
		for (int i = 0; i < 3; i++) {
			float d = 2.4f + i * 0.8f;
			Shapes.roundRect(g, cx + d - 0.5f, cy + d - 0.5f, cx + d + 0.6f, cy + d + 0.6f, 0.5f, color);
		}
	}

    /** Search is global; state/favorite filters apply to both search and category views. */
    private List<Module> visibleModules() {
        String query=search.trim().toLowerCase(Locale.ROOT);
        List<Module> shown=new ArrayList<>();
        for(Module module:ModuleManager.all()) {
            if(query.isEmpty()) {if(selected!=null&&module.category()!=selected)continue;}
            else if(!module.name().toLowerCase(Locale.ROOT).contains(query)&&!module.description().toLowerCase(Locale.ROOT).contains(query))continue;
            if(filter==Filter.ENABLED&&!module.isEnabled()||filter==Filter.FAVORITES&&!module.isFavorite())continue;
            shown.add(module);
        }
        return shown;
    }
    // One centered glass box: category tabs, an icon-card grid, and an anchored footer.
    private static final float CARD_H = 90, CARD_GAP = 8;
    private float winX, winY, winW, winH;
    private float gridLeft, gridRight, gridTop, gridBottom, gridMax;
    private float gridScroll, gridTarget;
    private boolean gridDragging;
    private float gridGrab;

    private int columns() { return 3; }

    private void layoutWindow() {
        winW = Math.min(vw - 48, 440);
        winH = Math.min(vh - 64, 270);
        winX = (vw - winW) / 2;
        winY = (vh - winH) / 2;
    }

    private static Icons.Icon categoryIcon(Category category) {
        return switch(category) {
            case HUD -> Icons.Icon.MONITOR;
            case WORLD -> Icons.Icon.GLOBE;
            case COMBAT -> Icons.Icon.SWORDS;
            case INVENTORY -> Icons.Icon.BACKPACK;
            case VISUAL -> Icons.Icon.EYE;
            default -> Icons.Icon.SLIDERS;
        };
    }

    private static Icons.Icon moduleIcon(Module module) {
        return switch(module.id()) {
            case "minimap", "world_map", "waypoint_list", "death_tracker" -> Icons.Icon.PIN;
            case "coordinates", "chunk_borders", "block_info", "block_focus" -> Icons.Icon.CUBE;
            case "fps", "fps_graph", "frame_graph", "click_rate", "attack_indicator" -> Icons.Icon.GAUGE;
            case "memory", "hardware", "hardware_usage" -> Icons.Icon.CHIP;
            case "ping", "discord_presence" -> Icons.Icon.SATELLITE;
            case "keystrokes", "active_modules", "toggle_sprint", "toggle_sneak" -> Icons.Icon.KEYBOARD;
            case "speed", "compass", "freelook", "camera_comfort" -> Icons.Icon.WIND;
            case "clock", "cooldowns", "session_stats", "world_time", "server_watch" -> Icons.Icon.TIMER;
            case "potions", "boss_prep" -> Icons.Icon.FLASK;
            case "armor", "shield_status", "item_guard" -> Icons.Icon.SHIELD;
            case "target", "danger_meter", "totem_alerts" -> Icons.Icon.HEART;
            case "notifications", "pickup_notifier", "tool_saver" -> Icons.Icon.WARNING;
            case "inventory_hud", "container_preview", "loot_tracker", "item_counter" -> Icons.Icon.BRIEFCASE;
            case "light_level", "fullbright", "time_changer", "weather_changer" -> Icons.Icon.EYE;
            case "crosshair", "view_model", "interface" -> Icons.Icon.COG;
            case "adventure_log", "schematics" -> Icons.Icon.FOLDER;
            default -> categoryIcon(module.category());
        };
    }

    private void menuChip(GuiGraphicsExtractor g, String key, String label, float x, float y, float w, float h,
                          int mx, int my, float alpha, boolean on, boolean interactive, Runnable action) {
        boolean hover = interactive && Ui.inside(mx,my,x,y,x+w,y+h);
        float lit = Ui.animate("cg:chip:"+key, on?1:hover?.5f:0, .6f);
        int fill = on ? Ui.withAlpha(Ui.accent(), .28f) : 0x24FFFFFF;
        Shapes.roundRect(g,x,y,x+w,y+h,3.5f,Ui.withAlpha(fill,alpha*lit));
        if(on) Shapes.roundRect(g,x+5,y+h-1.5f,x+w-5,y+h-.6f,.45f,Ui.withAlpha(Ui.accent(),alpha));
        float size=6.2f;
        text(g,label,x+(w-GoonFont.width(label,size,GoonFont.Weight.MEDIUM))/2,y+(h-size)/2-.2f,size,GoonFont.Weight.MEDIUM,
            Ui.withAlpha(Ui.lerp(lit,0xFFB8BBC6,0xFFFFFFFF),alpha));
        if(interactive) hits.add(new Hit(x,y,x+w,y+h,(button,hx,hy)->{if(button==InputConstants.MOUSE_BUTTON_LEFT) action.run();}));
    }

    private void drawWorkspace(GuiGraphicsExtractor g, int mx, int my, float alpha, long now, boolean interactive) {
        List<Module> shown=visibleModules();
        GlassUi.window(g,winX,winY,winW,winH,alpha);
        // The whole header belongs to the same window; nothing floats above it.
        Ui.logoMark(g,font,winX+11,winY+7,17,alpha);
        text(g,"GOON",winX+34,winY+9,8.3f,GoonFont.Weight.BOLD,Ui.withAlpha(0xFFFFFFFF,alpha));
        float brandX=winX+37+GoonFont.width("GOON",8.3f,GoonFont.Weight.BOLD);
        text(g,"CLIENT",brandX,winY+9,8.3f,GoonFont.Weight.BOLD,Ui.withAlpha(Ui.accent(),alpha));
        text(g,"v"+version,winX+34,winY+20,4.8f,GoonFont.Weight.REGULAR,Ui.withAlpha(0xFFB8BBC6,alpha));
        float sx=winX+winW-119, sy=winY+9;
        menuChip(g,"settings","Settings",sx-98,sy,44,13,mx,my,alpha,false,interactive,
            ()->minecraft.gui.setScreen(new StudioScreen(this,StudioScreen.Page.INTERFACE)));
        menuChip(g,"wardrobe","Wardrobe",sx-51,sy,47,13,mx,my,alpha,false,interactive,
            ()->minecraft.gui.setScreen(new CosmeticsScreen(this)));
        GlassUi.searchBox(g,sx,sy,91,13,search,searching,alpha);
        if(interactive) hits.add(new Hit(sx,sy,sx+91,sy+13,(button,hx,hy)->searching=true));
        float closeX=winX+winW-22;
        boolean closeHover=interactive&&Ui.inside(mx,my,closeX,sy,closeX+13,sy+13);
        Shapes.roundRect(g,closeX,sy,closeX+13,sy+13,3,Ui.withAlpha(0xFFFFFFFF,alpha*(closeHover?.15f:.05f)));
        Icons.draw(g,Icons.Icon.CLOSE,closeX+3,sy+3,7,Ui.withAlpha(0xFFD3D5DD,alpha));
        if(interactive)hits.add(new Hit(closeX,sy,closeX+13,sy+13,(button,hx,hy)->{if(button==InputConstants.MOUSE_BUTTON_LEFT)onClose();}));
        Shapes.rect(g,winX+10,winY+30,winX+winW-10,winY+30.4f,Ui.withAlpha(0x25FFFFFF,alpha));

        float tabW=(winW-24)/7, tabY=winY+34;
        for(int i=0;i<7;i++) {
            Category category=i==0?null:Category.values()[i-1];
            String label=category==null?"All":category.displayName();
            menuChip(g,"category:"+i,label,winX+12+i*tabW,tabY,tabW-2,15,mx,my,alpha,search.isBlank()&&selected==category,interactive,
                ()->{selected=category;search="";searching=false;changeView();});
        }

        gridLeft=winX+12; gridRight=winX+winW-12; gridTop=winY+56; gridBottom=winY+winH-26;
        int cols=columns();
        float cw=(gridRight-gridLeft-5-CARD_GAP*(cols-1))/cols;
        int rows=(shown.size()+cols-1)/cols;
        float content=Math.max(0,rows*(CARD_H+CARD_GAP)-CARD_GAP), view=gridBottom-gridTop;
        gridMax=Math.max(0,content-view);
        gridTarget=Math.clamp(gridTarget,0,gridMax);
        gridScroll=Math.clamp(Ui.animate("cg:grid",gridTarget,.62f),0,gridMax);
        g.enableScissor((int)Math.ceil(gridLeft),(int)Math.ceil(gridTop),(int)Math.floor(gridRight),(int)Math.floor(gridBottom));
        if(shown.isEmpty())text(g,search.isBlank()?"No modules in this view":"No modules match your search",gridLeft+6,gridTop+8,7,GoonFont.Weight.REGULAR,Ui.withAlpha(0xFFD3D5DD,alpha));
        for(int i=0;i<shown.size();i++) {
            float x=gridLeft+i%cols*(cw+CARD_GAP), y=gridTop+i/cols*(CARD_H+CARD_GAP)-gridScroll;
            if(y+CARD_H<=gridTop||y>=gridBottom)continue;
            drawCard(g,shown.get(i),x,y,cw,mx,my,alpha,interactive);
        }
        g.disableScissor();
        if(gridMax>0) {
            float thumb=Math.min(view,Math.max(18,view*view/content)), ty=gridTop+(view-thumb)*gridScroll/gridMax, tx=gridRight-2.4f;
            Shapes.roundRect(g,tx,gridTop,tx+1.4f,gridBottom,.7f,Ui.withAlpha(0x28000000,alpha));
            Shapes.roundRect(g,tx,ty,tx+1.4f,ty+thumb,.7f,Ui.withAlpha(0x66FFFFFF,alpha));
            if(interactive)hits.add(new Hit(tx-3,gridTop,tx+4,gridBottom,(button,hx,hy)->{
                if(button!=InputConstants.MOUSE_BUTTON_LEFT)return;
                gridDragging=true;gridGrab=hy>=ty&&hy<=ty+thumb?(float)hy-ty:thumb/2;moveGridScrollbar(hy,thumb);
            }));
        }

        float fy=winY+winH-19, fx=winX+12;
        for(Filter choice:Filter.values()) {
            String label=choice==Filter.ALL?"Any state":choice==Filter.ENABLED?"Enabled":"Favorites";
            float w=choice==Filter.ALL?45:42;
            menuChip(g,"filter:"+choice,label,fx,fy,w,13,mx,my,alpha,filter==choice,interactive,()->{filter=choice;changeView();});
            fx+=w+3;
        }
        menuChip(g,"log","Adventure Log",fx+6,fy,62,13,mx,my,alpha,false,interactive,()->minecraft.gui.setScreen(new AdventureLogScreen(this)));
        text(g,shown.size()+" modules",fx+78,fy+4,5,GoonFont.Weight.REGULAR,Ui.withAlpha(0xFFB8BBC6,alpha));
        sideButton(g,"Edit HUD layout",Icons.Icon.LAYOUT,winX+winW-108,fy-1,96,15,mx,my,alpha,interactive,()->minecraft.gui.setScreen(new HudEditorScreen(this)));
    }

    private void sideButton(GuiGraphicsExtractor g,String label,Icons.Icon icon,float x,float y,float w,float h,int mx,int my,float alpha,boolean interactive,Runnable action) {
        boolean hover=interactive&&Ui.inside(mx,my,x,y,x+w,y+h);
        float hot=Ui.animate("cg:button:"+label,hover?1:0,.6f);
        int accent=Ui.accent()|0xFF000000;
        Shapes.panel(g,x,y,x+w,y+h,4,Ui.withAlpha(accent,alpha*(.68f+.18f*hot)),Ui.withAlpha(Ui.lerp(.35f,accent,0xFFFFFFFF),alpha*.6f));
        float size=6, tw=GoonFont.width(label,size,GoonFont.Weight.BOLD)+10, tx=x+(w-tw)/2;
        Icons.draw(g,icon,tx,y+(h-7)/2,7,Ui.withAlpha(0xFFFFFFFF,alpha));
        text(g,label,tx+10,y+(h-size)/2-.2f,size,GoonFont.Weight.BOLD,Ui.withAlpha(0xFFFFFFFF,alpha));
        if(interactive)hits.add(new Hit(x,y,x+w,y+h,(button,hx,hy)->{if(button==InputConstants.MOUSE_BUTTON_LEFT)action.run();}));
    }

    private void drawCard(GuiGraphicsExtractor g,Module module,float cx,float cy,float cw,int mx,int my,float alpha,boolean interactive) {
        float visTop=Math.max(cy,gridTop),visBottom=Math.min(cy+CARD_H,gridBottom);
        boolean hover=interactive&&Ui.inside(mx,my,gridLeft,gridTop,gridRight,gridBottom)&&Ui.inside(mx,my,cx,visTop,cx+cw,visBottom);
        boolean focused=interactive&&module==keyboardModule;
        float hot=Ui.animate("cg:card:hover:"+module.id(),hover||focused?1:0,.6f);
        float on=Ui.animate("cg:card:on:"+module.id(),module.isEnabled()?1:0,.55f);
        int accent=Ui.accent()|0xFF000000;
        int fill=Ui.lerp(hot,GlassUi.CONTROL,GlassUi.CONTROL_HOVER);
        int edge=Ui.lerp(on*.45f,Ui.lerp(hot,0x40FFFFFF,0x70FFFFFF),Ui.withAlpha(accent,.65f));
        Shapes.panel(g,cx,cy,cx+cw,cy+CARD_H,5,Ui.withAlpha(fill,alpha),Ui.withAlpha(focused?accent:edge,alpha));
        Icons.draw(g,moduleIcon(module),cx+(cw-18)/2,cy+8-hot*.6f,18,Ui.withAlpha(Ui.lerp(on,0xFFD0D3DD,0xFFFFFFFF),alpha));
        float favoriteHot=Ui.animate("cg:favorite:hover:"+module.id(),module.isFavorite()||hover?1:0,.6f);
        if(favoriteHot>.01f)Icons.draw(g,Icons.Icon.HEART,cx+cw-13,cy+6,6,Ui.withAlpha(module.isFavorite()?accent:0xFFAEB2BE,alpha*favoriteHot));
        List<String> names=wrap(module.name(),cw-16,7.2f,2);
        float ny=cy+31;
        for(String line:names){String fit=Ui.ellipsize(line,cw-16,7.2f,GoonFont.Weight.BOLD);text(g,fit,cx+(cw-GoonFont.width(fit,7.2f,GoonFont.Weight.BOLD))/2,ny,7.2f,GoonFont.Weight.BOLD,Ui.withAlpha(0xFFF4F4F7,alpha));ny+=8.3f;}
        List<String> description=wrap(module.description(),cw-18,5.5f,names.size()>1?1:2);
        float dy=cy+(names.size()>1?49:43);
        for(String line:description){text(g,line,cx+(cw-GoonFont.width(line,5.5f,GoonFont.Weight.REGULAR))/2,dy,5.5f,GoonFont.Weight.REGULAR,Ui.withAlpha(0xFFBEC2CD,alpha));dy+=6.5f;}

        float optionsY=cy+CARD_H-27, stateY=cy+CARD_H-14;
        boolean optionsHover=hover&&my>=optionsY&&my<stateY;
        float oh=Ui.animate("cg:options:"+module.id(),optionsHover?1:0,.6f);
        Shapes.rect(g,cx+1,optionsY,cx+cw-1,stateY,Ui.withAlpha(0xFFFFFFFF,alpha*(.055f+.06f*oh)));
        Shapes.rect(g,cx+1,optionsY,cx+cw-1,optionsY+.35f,Ui.withAlpha(0x30FFFFFF,alpha));
        Shapes.rect(g,cx+cw-22,optionsY,cx+cw-21.65f,stateY,Ui.withAlpha(0x30FFFFFF,alpha));
        text(g,"OPTIONS",cx+(cw-22-GoonFont.width("OPTIONS",5.5f,GoonFont.Weight.BOLD))/2,optionsY+4,5.5f,GoonFont.Weight.BOLD,Ui.withAlpha(0xFFE3E5EC,alpha));
        Icons.draw(g,Icons.Icon.COG,cx+cw-15,optionsY+3,7,Ui.withAlpha(0xFFE3E5EC,alpha));
        int stateFill=Ui.lerp(on,0xA0191C23,Ui.withAlpha(accent,.8f));
        Shapes.gradientRect(g,cx+1,stateY,cx+cw-1,cy+CARD_H-1,0,0,4,4,Ui.withAlpha(stateFill,alpha),Ui.withAlpha(stateFill,alpha));
        String state=module.isEnabled()?"ENABLED":"DISABLED";
        text(g,state,cx+(cw-GoonFont.width(state,5.8f,GoonFont.Weight.BOLD))/2,stateY+4,5.8f,GoonFont.Weight.BOLD,Ui.withAlpha(Ui.lerp(on,0xFFB4B9C5,0xFFFFFFFF),alpha));
        if((hover||focused)&&(description.getLast().endsWith("...")||names.getLast().endsWith("...")))tooltipText=module.name()+" — "+module.description();

        if(interactive&&visBottom>visTop) {
            hits.add(new Hit(cx,visTop,cx+cw,visBottom,(button,hx,hy)->{
                if(button==InputConstants.MOUSE_BUTTON_RIGHT)openSettings(module);
                else if(button==InputConstants.MOUSE_BUTTON_MIDDLE)module.toggleFavorite();
                else if(hy>=optionsY&&hy<stateY)openSettings(module);
                else dev.goonclient.client.input.ModuleBindings.toggle(module);
                hits.clear();
            }));
            float heartTop=Math.max(visTop,cy+3),heartBottom=Math.min(visBottom,cy+15);
            if(heartBottom>heartTop)hits.add(new Hit(cx+cw-17,heartTop,cx+cw-3,heartBottom,(button,hx,hy)->{
                if(button==InputConstants.MOUSE_BUTTON_RIGHT)openSettings(module);
                else module.toggleFavorite();
                hits.clear();
            }));
        }
    }

    private void moveGridScrollbar(double mouseY, float thumb) {
        float travel = gridBottom - gridTop - thumb;
        if (travel <= 0) return;
        gridTarget = Math.max(0, Math.min(gridMax, (float) (mouseY - gridTop - gridGrab) / travel * gridMax));
        Ui.snap("cg:grid", gridTarget);
    }

    private void drawNavigation(GuiGraphicsExtractor g,int mx,int my,float alpha) {
        if(settingsFor==null&&renderedView<.001f) {
            GlassUi.hintsRow(g,List.of("LMB - toggle","Options / RMB - settings","MMB - favorite","Ctrl+F - search","Esc - close"),vw/2,Math.min(winY+winH+8,vh-9),alpha);
            return;
        }
        float lit=Ui.animate("cg:nav:lit",settingsFor!=null?1:0,.55f);
        int hover=GlassUi.navigationHit(vw,mx,my);
        GlassUi.navigation(g,vw,lit,Ui.animate("cg:nav:hover0",hover==0?1:0,.6f),Ui.animate("cg:nav:hover1",hover==1?1:0,.6f),alpha);
        if(closingAt==0) {
            float x=vw/2-GlassUi.NAV_W/2;
            hits.add(new Hit(x,GlassUi.NAV_Y,x+GlassUi.NAV_W/2,GlassUi.NAV_Y+GlassUi.NAV_H,(button,hx,hy)->{if(button==InputConstants.MOUSE_BUTTON_LEFT){leaveSettings();hits.clear();}}));
            hits.add(new Hit(x+GlassUi.NAV_W/2,GlassUi.NAV_Y,x+GlassUi.NAV_W,GlassUi.NAV_Y+GlassUi.NAV_H,(button,hx,hy)->{
                if(button==InputConstants.MOUSE_BUTTON_LEFT){hits.clear();minecraft.gui.setScreen(new StudioScreen(this,StudioScreen.Page.THEMES));}
            }));
        }
        if(settingsFor==null)
            GlassUi.hintsRow(g,List.of("LMB - toggle","RMB - settings","MMB - favorite","Ctrl+F - search","Esc - close","Alt+H - hide hints"),vw/2,Math.min(winY+winH+6,vh-9),alpha*(1-renderedView));
        else
            GlassUi.hints(g,List.of("LMB - change setting","Wheel - scroll settings","Esc - back to modules","Alt+H - hide hints"),vh,alpha);
    }

	// ---- Settings ----------------------------------------------------------------------------------------

	private void drawSettingsHeader(GuiGraphicsExtractor g, Module module, int mouseX, int mouseY, float alpha, float shift) {
		float x = px + 9 + shift;
		boolean ready = settingsFor == module && renderedView > .999f;
		// Accent bar, title and a round close button, as in the reference element panel
		Shapes.roundRect(g, x - 2, py + 7.5f, x - .6f, py + 15, .7f, Ui.withAlpha(Ui.accent(), alpha));
		text(g, Ui.ellipsize(module.name(), pw - 40, 7.4f, GoonFont.Weight.REGULAR), x + 2, py + 7.6f, 7.4f, GoonFont.Weight.REGULAR, Ui.withAlpha(0xFFFFFFFF, alpha));
		float cx = px + pw - 13 + shift, cy = py + 11.3f;
		boolean closeHover = ready && Ui.inside(mouseX, mouseY, cx - 5.5f, cy - 5.5f, cx + 5.5f, cy + 5.5f);
		Shapes.circle(g, cx, cy, 5.5f, Ui.withAlpha(closeHover ? 0xFF3A3540 : 0xFF2A262E, .9f * alpha));
		Icons.draw(g, Icons.Icon.CLOSE, cx - 2.6f, cy - 2.6f, 5.2f, Ui.withAlpha(0xFFE8E5ED, alpha));
		if (ready) hits.add(new Hit(cx - 5.5f, cy - 5.5f, cx + 5.5f, cy + 5.5f, (button, mx, my) -> leaveSettings()));
		Shapes.rect(g, px + 4, py + 22.5f, px + pw - 4, py + 22.85f, Ui.withAlpha(0xFFFFFFFF, .14f * alpha));

		// Enabled / Favorite switch
		float sx = px + 7 + shift, sw = pw - 14, sy = py + 26.5f, sh = 11.5f, half = (sw - 2.4f) / 2;
		Shapes.panel(g, sx, sy, sx + sw, sy + sh, 3, Ui.withAlpha(0xFF1D1A20, .78f * alpha), Ui.withAlpha(0xFFFFFFFF, .1f * alpha));
		String[] labels = {module.isEnabled() ? "Enabled" : "Disabled", module.isFavorite() ? "Favorite" : "Not favorite"};
		boolean[] lit = {module.isEnabled(), module.isFavorite()};
		for (int i = 0; i < 2; i++) {
			float bx = sx + 1.2f + half * i;
			float on = Ui.animate("cg:set:seg" + i + ":" + module.id(), lit[i] ? 1 : 0, .5f);
			if (on > .01f) Shapes.roundRect(g, bx, sy + 1.2f, bx + half, sy + sh - 1.2f, 2.4f, Ui.withAlpha(Ui.lerp(.45f, 0xFF2A2026, Ui.accent()), on * alpha));
			float tw = GoonFont.width(labels[i], 5.4f, GoonFont.Weight.REGULAR);
			text(g, labels[i], bx + (half - tw) / 2, sy + 3.3f, 5.4f, GoonFont.Weight.REGULAR, Ui.withAlpha(Ui.lerp(on, 0xFFA8A3AE, 0xFFFFFFFF), alpha));
			if (ready) {
				final int index = i;
				hits.add(new Hit(bx, sy, bx + half, sy + sh, (button, mx, my) -> {
					if (index == 0) dev.goonclient.client.input.ModuleBindings.toggle(module);
					else module.toggleFavorite();
				}));
			}
		}
	}

	/** Height of one settings row; shared by drawing and scroll measurement so they always agree. */
	private float rowHeight(Setting<?> setting) {
		if (setting instanceof ModeSetting mode) return 13 + optionLines(mode) * 8.5f;
		return 21;
	}

	private int optionLines(ModeSetting mode) {
		float width = contentRight - contentLeft - 2, x = 0;
		int lines = 1;
		for (String option : mode.modes()) {
			float w = GoonFont.width(option, 6, GoonFont.Weight.REGULAR) + 3.2f;
			if (x > 0 && x + w > width) { lines++; x = 0; }
			x += w;
		}
		return lines;
	}

	private void drawSettings(GuiGraphicsExtractor g, Module module, int mouseX, int mouseY, float alpha, float shift, boolean interactive) {
		float left = contentLeft + shift;
		float right = contentRight + shift;
		float y = contentTop - scroll;
		boolean mouseIn = interactive && mouseY >= contentTop && mouseY < contentBottom;
		for (String line : wrap(module.description(), right - left, 5.4f, 3)) {
			text(g, line, left, y, 5.4f, GoonFont.Weight.REGULAR, Ui.withAlpha(0xFFB9B4C0, alpha));
			y += 6.6f;
		}
		y += 4;
		y = bindingRow(g, module, left, y, right, mouseX, mouseY, alpha, interactive);
		for (Setting<?> setting : module.settings()) {
			String key = "cg:set:" + module.id() + ":" + setting.id();
			boolean visible = y + rowHeight(setting) > contentTop && y < contentBottom;
			if (visible) {
				boolean hover = mouseIn && Ui.inside(mouseX, mouseY, left, y, right, y + rowHeight(setting));
				if (setting instanceof BooleanSetting bool) {
					toggleRow(g, setting.name(), bool.isOn(), key, left, y, right, alpha, interactive, () -> { bool.toggle(); ConfigManager.markDirty(); });
				} else if (setting instanceof NumberSetting number) {
					sliderRow(g, number, key, left, y, right, alpha, hover, interactive);
				} else if (setting instanceof ModeSetting mode) {
					modeRow(g, mode, key, left, y, right, mouseX, mouseY, alpha, interactive);
				} else if (setting instanceof ButtonSetting button) {
					buttonRow(g, button.name(), button.buttonLabel(), key, left, y, right, mouseX, mouseY, alpha, interactive, button::press);
				}
			}
			y += rowHeight(setting);
		}
		if (module instanceof HudModule hud) {
			buttonRow(g, "Position on screen", "Reset", "cg:hudreset:" + module.id(), left, y, right, mouseX, mouseY, alpha, interactive, hud::resetPosition);
			y += 21;
			buttonRow(g, "Move it around", "Edit layout", "cg:hudedit:" + module.id(), left, y, right, mouseX, mouseY, alpha, interactive,
				() -> minecraft.gui.setScreen(new HudEditorScreen(this)));
		}
	}

	/** "Toggle shortcut" with the bound key in a chip and a small clear button. Returns the next row's y. */
	private float bindingRow(GuiGraphicsExtractor g, Module module, float left, float y, float right, int mouseX, int mouseY, float alpha, boolean interactive) {
		boolean capturing = bindingFor == module;
		String label = capturing ? "Press a key" : dev.goonclient.client.input.ModuleBindings.label(module);
		text(g, "Toggle shortcut", left + 1, y + 4.6f, 6, GoonFont.Weight.REGULAR, Ui.withAlpha(0xFFF2F0F5, alpha));
		float clear = 9, bx2 = right - clear - 3, bw = Math.max(34, GoonFont.width(label, 5.2f, GoonFont.Weight.MEDIUM) + 10), bx1 = bx2 - bw;
		boolean hover = interactive && Ui.inside(mouseX, mouseY, bx1, y + 2, bx2, y + 13);
		Shapes.panel(g, bx1, y + 2, bx2, y + 13, 2.5f, Ui.withAlpha(hover ? 0xFF332E37 : 0xFF221F25, .9f * alpha),
			Ui.withAlpha(capturing ? Ui.accent() : 0xFFFFFFFF, (capturing ? .8f : .16f) * alpha));
		text(g, label, bx1 + (bw - GoonFont.width(label, 5.2f, GoonFont.Weight.MEDIUM)) / 2, y + 4.9f, 5.2f, GoonFont.Weight.MEDIUM, Ui.withAlpha(capturing ? Ui.accent() : 0xFFFFFFFF, alpha));
		float cx = right - clear / 2 - 1, cy = y + 7.5f;
		Icons.draw(g, Icons.Icon.CLOSE, cx - 2.4f, cy - 2.4f, 4.8f, Ui.withAlpha(0xFFA8A3AE, alpha));
		String hint = !bindMessage.isEmpty() ? bindMessage : capturing ? "Esc cancels, Backspace clears" : "Works in a world; gameplay keys are protected";
		text(g, Ui.ellipsize(hint, right - left - 2, 4.8f, GoonFont.Weight.REGULAR), left + 1, y + 15, 4.8f, GoonFont.Weight.REGULAR, Ui.withAlpha(0xFFB3AEBA, alpha));
		if (interactive) {
			addContentHit(bx1, y + 2, bx2, y + 13, (button, mx, my) -> { bindingFor = module; bindMessage = ""; });
			addContentHit(right - clear - 2, y + 2, right, y + 13, (button, mx, my) -> {
				if (capturing) bindingFor = null;
				else dev.goonclient.client.input.ModuleBindings.clear(module);
				bindMessage = "";
			});
		}
		return y + 24;
	}

	/** Outlined row with an accent switch on the left of the label. */
	private void toggleRow(GuiGraphicsExtractor g, String name, boolean value, String key, float left, float y, float right, float alpha,
						   boolean interactive, Runnable onToggle) {
		float on = Ui.animate(key, value ? 1f : 0f, 0.42f);
		Shapes.panel(g, left, y, right, y + 17, 3, Ui.withAlpha(0xFF141217, .35f * alpha), Ui.withAlpha(Ui.lerp(on, 0x50FFFFFF, Ui.accent()), (.55f + .25f * on) * alpha));
		float sx = left + 4, sy = y + 4.5f;
		Shapes.roundRect(g, sx, sy, sx + 15, sy + 8, 4, Ui.withAlpha(Ui.lerp(on, 0xFF4A4650, Ui.accent()), alpha));
		Shapes.circle(g, sx + 4 + on * 7, sy + 4, 2.9f, Ui.withAlpha(0xFFFFFFFF, alpha));
		text(g, Ui.ellipsize(name, right - left - 30, 6.2f, GoonFont.Weight.REGULAR), left + 24, y + 5.4f, 6.2f, GoonFont.Weight.REGULAR, Ui.withAlpha(0xFFF4F2F7, alpha));
		if (interactive) addContentHit(left, y, right, y + 17, (button, mx, my) -> onToggle.run());
	}

	/** Label and value on one line, a hairline accent slider with a tick knob below. */
	private void sliderRow(GuiGraphicsExtractor g, NumberSetting setting, String key, float left, float y, float right,
						   float alpha, boolean hover, boolean interactive) {
		text(g, setting.name(), left + 1, y + 1.5f, 5.8f, GoonFont.Weight.REGULAR, Ui.withAlpha(0xFFF2F0F5, alpha));
		String value = setting.display();
		text(g, value, right - 1 - GoonFont.width(value, 5.8f, GoonFont.Weight.REGULAR), y + 1.5f, 5.8f, GoonFont.Weight.REGULAR, Ui.withAlpha(0xFFF2F0F5, alpha));
		float trackX1 = left + 1, trackX2 = right - 1, trackY = y + 12.5f;
		if (dragging == setting) Ui.snap(key, (float) setting.fraction());
		float fraction = Ui.animate(key, (float) setting.fraction(), 0.45f);
		float filled = trackX1 + (trackX2 - trackX1) * fraction;
		Shapes.roundRect(g, trackX1, trackY - .45f, trackX2, trackY + .45f, .45f, Ui.withAlpha(0x40FFFFFF, alpha));
		Shapes.roundRect(g, trackX1, trackY - .45f, Math.max(trackX1 + 1, filled), trackY + .45f, .45f, Ui.withAlpha(Ui.accent(), alpha));
		float k = Ui.animate(key + ":knob", dragging == setting || hover ? 1f : 0f, 0.55f);
		Shapes.roundRect(g, filled - .55f, trackY - 2.2f - k * .5f, filled + .55f, trackY + 2.2f + k * .5f, .5f, Ui.withAlpha(Ui.accent(), alpha));
		if (interactive) {
			addContentHit(left, y + 7, right, y + 19, (button, mx, my) -> {
				dragging = setting;
				dragX = trackX1;
				dragWidth = trackX2 - trackX1;
			});
		}
	}

	/** Label, then every option inline: the selected one in the accent colour. */
	private void modeRow(GuiGraphicsExtractor g, ModeSetting setting, String key, float left, float y, float right, int mouseX, int mouseY,
						 float alpha, boolean interactive) {
		text(g, setting.name(), left + 1, y + 1, 6.2f, GoonFont.Weight.REGULAR, Ui.withAlpha(0xFFF2F0F5, alpha));
		float ox = left + 1.5f, oy = y + 10, width = right - left - 2;
		for (String option : setting.modes()) {
			float ow = GoonFont.width(option, 6, GoonFont.Weight.REGULAR);
			if (ox > left + 1.5f && ox + ow - left > width) { ox = left + 1.5f; oy += 8.5f; }
			boolean selected = option.equals(setting.get());
			boolean hover = interactive && Ui.inside(mouseX, mouseY, ox - 1, oy - 1, ox + ow + 1, oy + 7.5f);
			int color = selected ? Ui.accent() : hover ? 0xFFFFFFFF : 0xFFCFCBD5;
			text(g, option, ox, oy, 6, GoonFont.Weight.REGULAR, Ui.withAlpha(color, alpha));
			if (interactive) {
				addContentHit(ox - 1, oy - 1, ox + ow + 1, oy + 7.5f, (button, mx, my) -> { setting.set(option); ConfigManager.markDirty(); });
			}
			ox += ow + 3.2f;
		}
	}

	private void cycle(ModeSetting setting, int direction) {
		setting.cycle(direction);
		ConfigManager.markDirty();
	}

	/** Outlined row: name on the left, the action in the accent colour on the right. */
	private void buttonRow(GuiGraphicsExtractor g, String name, String label, String key, float left, float y, float right,
						   int mouseX, int mouseY, float alpha, boolean interactive, Runnable action) {
		boolean hover = interactive && Ui.inside(mouseX, mouseY, left, y, right, y + 17);
		float h = Ui.animate(key, hover ? 1f : 0f, 0.6f);
		Shapes.panel(g, left, y, right, y + 17, 3, Ui.withAlpha(Ui.lerp(h, 0xFF141217, 0xFF2A2730), (.35f + .3f * h) * alpha), Ui.withAlpha(0xFFFFFFFF, .16f * alpha));
		text(g, Ui.ellipsize(name, right - left - 50, 6, GoonFont.Weight.REGULAR), left + 5, y + 5.4f, 6, GoonFont.Weight.REGULAR, Ui.withAlpha(0xFFF4F2F7, alpha));
		float lw = GoonFont.width(label, 5.6f, GoonFont.Weight.MEDIUM);
		text(g, label, right - lw - 6, y + 5.7f, 5.6f, GoonFont.Weight.MEDIUM, Ui.withAlpha(Ui.accent(), alpha));
		if (interactive) addContentHit(left, y, right, y + 17, (button, mx, my) -> action.run());
	}

	// ---- Shared ------------------------------------------------------------------------------------------

	private void drawScrollbar(GuiGraphicsExtractor g, float alpha, long now) {
		float view = contentBottom - contentTop;
		float maxScroll = maxScroll();
		scrollTarget = Math.max(0, Math.min(maxScroll, scrollTarget));
		if (maxScroll <= 0) {
			return;
		}
		// Bright while scrolling, then fades back
		float recent = 1f - Math.min(1f, Math.max(0f, (now - lastScrollAt - 700) / 400f));
		float visible = Ui.animate("cg:scrollbar", recent, 0.5f);
		float thumb = Math.max(24, view * view / contentHeight);
		float thumbY = contentTop + (view - thumb) * (scroll / maxScroll);
		float x = px + pw - 6.5f;
		Shapes.roundRect(g, x, contentTop, x + 1.3f, contentBottom, .65f, Ui.withAlpha(0x30000000, alpha));
		Shapes.roundRect(g, x, thumbY, x + 1.3f, thumbY + thumb, .65f, Ui.withAlpha(0x66FFFFFF, alpha * Math.max(0.4f, visible)));
		hits.add(new Hit(x - 3, contentTop, x + 5, contentBottom, (button, mx, my) -> {
			if (button != InputConstants.MOUSE_BUTTON_LEFT) return;
			draggingScrollbar = true;
			scrollbarGrab = my >= thumbY && my <= thumbY + thumb ? (float) my - thumbY : thumb / 2;
			updateScrollbar(my);
		}));
	}

	private void headerChip(GuiGraphicsExtractor g,String label,float x,float y,float w,int mx,int my,float alpha,boolean selected,boolean interactive,Runnable action) {
		boolean hover=interactive&&Ui.inside(mx,my,x,y,x+w,y+19);
		Shapes.panel(g,x,y,x+w,y+19,5,Ui.withAlpha(selected?Ui.RAISED_HOVER:hover?Ui.RAISED:Ui.PANEL,alpha),Ui.withAlpha(selected?Ui.accent():hover?Ui.BORDER_STRONG:Ui.BORDER,alpha));
		text(g,label,x+(w-GoonFont.width(label,SMALL,GoonFont.Weight.BOLD))/2,y+5.5f,SMALL,GoonFont.Weight.BOLD,Ui.withAlpha(selected?Ui.TEXT:Ui.MUTED,alpha));
		if(interactive)hits.add(new Hit(x,y,x+w,y+19,(button,px,py)->{if(button==InputConstants.MOUSE_BUTTON_LEFT)action.run();}));
	}


	/** A small glass tooltip, only for descriptions the cards had to cut short. */
	private void drawHelp(GuiGraphicsExtractor g,int mx,int my,float alpha,long now) {
		if(tooltipText==null){lastHelp="";return;}
		if(!tooltipText.equals(lastHelp)){lastHelp=tooltipText;helpSince=now;return;}
		if(now-helpSince<450||closingAt>0)return;
		float tw=Math.min(190,vw-28);List<String> lines=wrap(tooltipText,tw-14,5.6f,8);
		float th=lines.size()*7.6f+10,tx=Math.max(8,Math.min(mx+10,vw-tw-8)),ty=Math.max(8,Math.min(my+12,vh-th-8));
		Shapes.glow(g,tx,ty,tx+tw,ty+th,5,10,.4f*alpha,.1f);
		Shapes.panel(g,tx,ty,tx+tw,ty+th,5,Ui.withAlpha(0xF0101216,alpha),Ui.withAlpha(0x55FFFFFF,alpha));
		float yy=ty+5.4f;for(String line:lines){text(g,line,tx+7,yy,5.6f,GoonFont.Weight.REGULAR,Ui.withAlpha(0xFFE9EAEE,alpha));yy+=7.6f;}
	}

	private void text(GuiGraphicsExtractor g, String text, float x, float y, float size, GoonFont.Weight weight, int color) {
		GoonFont.draw(g, text, x, y, size, weight, color, false);
	}

    /** Bounded wrapping with explicit paragraph breaks, shared by names, settings and hover help. */
    private List<String> wrap(String value, float maxWidth, float size, int maxLines) {
        String key=value+"|"+Math.round(maxWidth)+"|"+size+"|"+maxLines;
        var cached=wrapCache.get(key);if(cached!=null)return cached;
        List<String> lines=new ArrayList<>();
        for(String paragraph:value.split("\\n",-1)) {
            String line="";
            for(String word:paragraph.split(" +")) {
                String candidate=line.isEmpty()?word:line+" "+word;
                if(!line.isEmpty()&&GoonFont.width(candidate,size,GoonFont.Weight.REGULAR)>maxWidth) {
                    lines.add(Ui.ellipsize(line,maxWidth,size,GoonFont.Weight.REGULAR));line=word;
                } else line=candidate;
            }
            lines.add(Ui.ellipsize(line,maxWidth,size,GoonFont.Weight.REGULAR));
        }
        if(lines.size()>maxLines) {
            lines=new ArrayList<>(lines.subList(0,maxLines));
            String last=lines.get(maxLines-1);
            lines.set(maxLines-1,Ui.ellipsize(last+" ...",maxWidth,size,GoonFont.Weight.REGULAR));
        }
        if(wrapCache.size()>=256)wrapCache.clear();
        wrapCache.put(key,lines);return lines;
    }

	private void addContentHit(float x1, float y1, float x2, float y2, Click action) {
		float left = Math.max(x1, contentLeft);
		float right = Math.min(x2, contentRight);
		float top = Math.max(y1, contentTop);
		float bottom = Math.min(y2, contentBottom);
		if (bottom > top && right > left) {
			hits.add(new Hit(left, top, right, bottom, (button,mx,my)->{
                if(button==InputConstants.MOUSE_BUTTON_LEFT)action.click(button,mx,my);
            }));
		}
	}

    private void openSettings(Module module) {
        hits.clear();
		dragging = null;
		draggingScrollbar = false;
		bindingFor = null; bindMessage = "";
		settingsFor = module;
		resetArmed = "";
		lastSettings = module;
		resetScroll();
	}

    private void leaveSettings() {
        if (settingsFor != null) {
			hits.clear();
			dragging = null;
			draggingScrollbar = false;
			bindingFor = null; bindMessage = "";
			settingsFor = null;
			// Keep the outgoing page at its current scroll position throughout the fade.
		}
	}

    private void changeView() {
        keyboardModule=null;

        gridTarget=0;
        Ui.snap("cg:grid",0);
        gridDragging=false;
        hits.clear();
		viewChangedAt = System.currentTimeMillis();
		resetScroll();
	}

	private void resetScroll() {
		scrollTarget = 0;
		scroll = 0;
		Ui.snap("cg:scroll", 0);
	}

	public void openSettingsFor(Module module) {
		search = "";
		selected = module.category();
		openSettings(module);
	}

	private void updateSlider(double mouseX) {
		if (dragging != null && dragWidth > 0) {
			dragging.setFraction(Math.max(0, Math.min(1, (mouseX - dragX) / dragWidth)));
			ConfigManager.markDirty();
		}
	}

	private void clipContent(GuiGraphicsExtractor g) {
		g.enableScissor((int) Math.floor(contentLeft - 3), (int) Math.ceil(contentTop),
			(int) Math.ceil(contentRight + 3), (int) Math.floor(contentBottom));
	}

	private float measureContentHeight() {
		Module page = settingsFor != null ? settingsFor : lastSettings;
		if (page == null) {
            return 0;
		}
		float total = wrap(page.description(), contentRight - contentLeft, 5.4f, 3).size() * 6.6f + 4 + 24;
		for (Setting<?> setting : page.settings()) total += rowHeight(setting);
		return total + (page instanceof HudModule ? 42 : 0) + 4;
	}

	private float maxScroll() {
		return Math.max(0, measureContentHeight() - (contentBottom - contentTop));
	}

	private double inputX(double x) { return vw / 2 + (x / s - vw / 2) / renderScale; }
	private double inputY(double y) { return vh / 2 + (y / s - vh / 2 - renderRise) / renderScale; }

	private void updateScrollbar(double mouseY) {
		float view = contentBottom - contentTop;
		float thumb = Math.min(view, Math.max(24, view * view / Math.max(view, contentHeight)));
		float travel = view - thumb;
		if (travel <= 0) return;
		scrollTarget = Math.max(0, Math.min(maxScroll(), (float) (mouseY - contentTop - scrollbarGrab) / travel * maxScroll()));
		scroll = scrollTarget;
		Ui.snap("cg:scroll", scrollTarget);
		lastScrollAt = System.currentTimeMillis();
	}

    /** Keyboard focus walks the card grid: arrows move by card, Enter toggles, Shift+Enter opens settings. */
    private void moveKeyboard(int key) {
        var available = visibleModules();
        if (available.isEmpty()) { keyboardModule = null; return; }
        boolean initial = keyboardModule == null || !available.contains(keyboardModule);
        int cols = columns();
        int index = initial ? 0 : available.indexOf(keyboardModule);
        if (!initial) {
            index += switch (key) {
                case InputConstants.KEY_LEFT -> -1;
                case InputConstants.KEY_RIGHT -> 1;
                case InputConstants.KEY_UP -> -cols;
                default -> cols;
            };
            index = Math.max(0, Math.min(available.size() - 1, index));
        }
        keyboardModule = available.get(index);
        float top = (index / cols) * (CARD_H + CARD_GAP), bottom = top + CARD_H, view = Math.max(1, gridBottom - gridTop);
        if (top < gridTarget) gridTarget = top;
        else if (bottom > gridTarget + view) gridTarget = bottom - view;
        gridTarget = Math.max(0, Math.min(gridMax, gridTarget));
        hits.clear();
    }

	// ---- Input -------------------------------------------------------------------------------------------

	@Override
	public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
		if (closingAt > 0) {
			return true;
		}
		if (event.button() != InputConstants.MOUSE_BUTTON_LEFT && event.button() != InputConstants.MOUSE_BUTTON_RIGHT && event.button() != InputConstants.MOUSE_BUTTON_MIDDLE) return true;
        keyboardModule=null;
		double mx = inputX(event.x());
		double my = inputY(event.y());
		for (int i = hits.size() - 1; i >= 0; i--) {
			Hit hit = hits.get(i);
            if (Ui.inside(mx, my, hit.x1, hit.y1, hit.x2, hit.y2)) {
				hit.action.click(event.button(), mx, my);
				updateSlider(mx);
				minecraft.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, 1.0f));
				return true;
			}
		}
		// Clicking outside module settings returns to the category browser
        if (settingsFor != null && !Ui.inside(mx, my, px, py, px + pw, py + ph)) {
            leaveSettings();
			return true;
		}
		return super.mouseClicked(event, doubleClick);
	}

	@Override
	public boolean mouseDragged(MouseButtonEvent event, double dragX, double dragY) {

        if (gridDragging) {
            float view = gridBottom - gridTop, content = Math.max(view, gridMax + view);
            moveGridScrollbar(inputY(event.y()), Math.max(18, view * view / content));
            return true;
        }
        if (draggingScrollbar) {
            updateScrollbar(inputY(event.y()));
			return true;
		}
		if (dragging != null) {
			updateSlider(inputX(event.x()));
			return true;
		}
		return super.mouseDragged(event, dragX, dragY);
	}

	@Override
    public boolean mouseReleased(MouseButtonEvent event) {

        gridDragging = false;
        dragging = null;
		draggingScrollbar = false;
		return super.mouseReleased(event);
	}

	@Override
	public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        if (closingAt > 0 || dragging != null || draggingScrollbar || gridDragging) return true;
        if (settingsFor == null) {
            // Consume menu wheel events, but scroll only inside the visible card viewport.
            if (renderedView <= .001f && Ui.inside(inputX(mouseX),inputY(mouseY),gridLeft,gridTop,gridRight,gridBottom)) {
                keyboardModule = null;
                gridTarget = Math.max(0, Math.min(gridMax, gridTarget - (float) scrollY * (CARD_H + CARD_GAP) * .9f));
            }
            return true;
        }
        if (renderedView >= .999f
            && Ui.inside(inputX(mouseX), inputY(mouseY), contentLeft - 3, contentTop, px + pw - 1, contentBottom)) {
            scrollTarget = Math.max(0, Math.min(maxScroll(), scrollTarget - (float) scrollY * 21f));
            lastScrollAt = System.currentTimeMillis();
        }
        return true;
	}

	@Override
	public boolean keyPressed(KeyEvent event) {
        if (closingAt > 0) return true;
        int key = event.key();
        if(bindingFor==null&&event.hasControlDown()&&key==InputConstants.KEY_F){leaveSettings();searching=true;return true;}
        if(bindingFor==null&&event.hasAltDown()&&key==InputConstants.KEY_H){dev.goonclient.client.modules.utility.Interface.toggleHints();suppressCharacter=true;return true;}
		if (bindingFor != null) {
			suppressCharacter = true;
			if (key == InputConstants.KEY_ESCAPE) { bindingFor = null; bindMessage = "Binding cancelled."; }
			else if (key == InputConstants.KEY_BACKSPACE || key == InputConstants.KEY_DELETE) { dev.goonclient.client.input.ModuleBindings.clear(bindingFor); bindingFor = null; bindMessage = "Shortcut cleared."; }
			else {
				var result = dev.goonclient.client.input.ModuleBindings.assign(minecraft, bindingFor, key);
				bindMessage = result.message(); if (result.ok()) bindingFor = null;
			}
			return true;
		}
        suppressCharacter = false;
        if(settingsFor==null&&renderedView<.001f&&closingAt==0) {
            if(key==InputConstants.KEY_LEFT||key==InputConstants.KEY_RIGHT||key==InputConstants.KEY_UP||key==InputConstants.KEY_DOWN) {
                moveKeyboard(key);return true;
            }
            if(key==InputConstants.KEY_RETURN&&keyboardModule!=null) {
                if(!visibleModules().contains(keyboardModule)){keyboardModule=null;return true;}
                if(event.hasShiftDown())openSettings(keyboardModule);
                else dev.goonclient.client.input.ModuleBindings.toggle(keyboardModule);
                hits.clear();return true;
            }
        }
		if (key == InputConstants.KEY_ESCAPE) {
			if (!search.isEmpty() || searching) {
				search = "";
				searching = false;
				changeView();
			} else if (settingsFor != null) {
				leaveSettings();
			} else {
				onClose();
			}
			return true;
		}
		if (key == InputConstants.KEY_BACKSPACE && !search.isEmpty()) {
			// Ctrl+Backspace clears the whole search
			search = event.hasControlDown() ? "" : search.substring(0, search.offsetByCodePoints(search.length(), -1));
			changeView();
			return true;
		}
		if (GoonKeys.OPEN_MENU.matches(event) && search.isEmpty()) {
			onClose();
			return true;
		}
		return super.keyPressed(event);
	}

	@Override
	public boolean charTyped(CharacterEvent event) {
		if (closingAt > 0) return true;
		if(bindingFor != null || suppressCharacter) { suppressCharacter = false; return true; }
		if (event.isAllowedChatCharacter() && search.length() < 32 && closingAt == 0) {
			if (settingsFor != null) {
				leaveSettings();
			}
			search += event.codepointAsString();
			changeView();
			return true;
		}
		return super.charTyped(event);
	}

	@Override
	public void onClose() {
		clearInputState();
		ConfigManager.save();
		if (closingAt == 0) {
			closingAt = System.currentTimeMillis();
		}
	}

	/** A resize or child screen must not retain a drag, old hit boxes, or shortcut capture. */
	private void clearInputState() {

		hits.clear();
		gridDragging = false;
		dragging = null;
		draggingScrollbar = false;
		bindingFor = null;
		bindMessage = "";
		suppressCharacter = false;
		resetArmed = "";
	}

	@Override
	public void removed() {
		clearInputState();
		GlassUi.restoreHud(minecraft);
		ConfigManager.save();
		super.removed();
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}

	/** The world stays visible behind the glass: a light blur and tint instead of vanilla's dark menu backdrop. */
	@Override
	public void extractBackground(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
		if (minecraft.level == null) {
			super.extractBackground(g, mouseX, mouseY, partialTick);
			return;
		}
		extractBlurredBackground(g);
		g.fill(0, 0, width, height, 0x1E000000);
	}

	// ---- Types -------------------------------------------------------------------------------------------

	@FunctionalInterface
	private interface Click {
		void click(int button, double mouseX, double mouseY);
	}

	@FunctionalInterface
	private interface RowDrawer {
		void draw(float y, boolean hover);
	}

	private record Row(float height, RowDrawer draw) {
	}

	private record Hit(float x1, float y1, float x2, float y2, Click action) {
	}

	private record Ripple(String moduleId, float x, float y, int color, long time) {
	}
}
