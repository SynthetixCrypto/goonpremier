package dev.goonclient.client.gui.render;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.Area;
import java.awt.geom.Path2D;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;

/** Original Goon mark: a cut-corner G, on a restrained glass tile. Geometry matches marketing/brand/logo.py. */
public final class LogoArt {
    private LogoArt() {}

    /** One continuous silhouette, also used by CapeArt. Coordinates in a 100-unit square. */
    public static Area glyph() {
        float[][] points = {{31,20},{70,20},{80,30},{71,39},{65,33},{36,33},{32,37},{32,64},
            {37,69},{64,69},{68,65},{68,57},{49,57},{49,45},{81,45},{81,70},{69,82},
            {30,82},{19,71},{19,31}};
        Path2D.Float path = new Path2D.Float();
        path.moveTo(points[0][0], points[0][1]);
        for (int i = 1; i < points.length; i++) path.lineTo(points[i][0], points[i][1]);
        path.closePath();
        return new Area(path);
    }

    public static BufferedImage image(int pixels, int accent) {
        // Render four times larger so small launcher/HUD marks retain clean diagonals.
        int high = pixels * 4;
        BufferedImage artwork = new BufferedImage(high, high, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = artwork.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
        g.scale(high / 100.0, high / 100.0);
        g.setPaint(new GradientPaint(0, 3, new Color(0x24262E), 0, 97, new Color(0x111217)));
        g.fill(new RoundRectangle2D.Float(3, 3, 94, 94, 38, 38));
        g.setStroke(new BasicStroke(1));
        g.setPaint(new GradientPaint(0, 3, new Color(255,255,255,62), 0, 97, new Color(255,255,255,18)));
        g.draw(new RoundRectangle2D.Float(3.5f,3.5f,93,93,37,37));
        g.setColor(new Color(accent | 0xFF000000, true));
        g.fill(glyph());
        g.dispose();
        BufferedImage image = new BufferedImage(pixels,pixels,BufferedImage.TYPE_INT_ARGB);
        g = image.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION,RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        g.drawImage(artwork,0,0,pixels,pixels,null);
        g.dispose();
        return image;
    }
}
