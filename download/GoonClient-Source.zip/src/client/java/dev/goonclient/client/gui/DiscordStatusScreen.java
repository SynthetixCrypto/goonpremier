package dev.goonclient.client.gui;

import dev.goonclient.client.social.DiscordPresence;
import dev.goonclient.client.gui.render.GoonFont;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

/** A connection explanation, not an OAuth/password prompt. */
public final class DiscordStatusScreen extends Screen implements GoonScreen{
    private final Screen parent;private float s,x,y;
    public DiscordStatusScreen(Screen parent){super(Component.literal("Discord presence"));this.parent=parent;}
    @Override protected void init(){s=Ui.menuScale(width,height);x=(width/s-440)/2;y=(height/s-230)/2;}
    @Override public void extractRenderState(GuiGraphicsExtractor g,int mx,int my,float partial){
        g.pose().pushMatrix();g.pose().scale(s,s);
        Ui.roundOutline(g,x,y,x+440,y+230,12,Ui.BORDER_STRONG,Ui.PANEL);
        Ui.scaledBold(g,font,"Discord presence",x+22,y+20,1.6f,Ui.TEXT);
        text(g,"Show Goon Client on your Discord profile.",22,49);
        Ui.roundRect(g,x+22,y+76,x+418,y+119,7,Ui.FIELD);
        GoonFont.draw(g,Ui.ellipsize(DiscordPresence.status(),370,8.5f,GoonFont.Weight.BOLD),x+34,y+91,8.5f,GoonFont.Weight.BOLD,Ui.TEXT,false);
        text(g,"Open Discord desktop, then enable Discord Presence in Goon.",22,138);
        text(g,"Discord Settings → Activity Privacy → Share activity",22,155);
        text(g,"Server addresses, coordinates and account tokens stay private.",22,172);
        Menus.button(g,"Done",x+338,y+192,80,(int)(mx/s),(int)(my/s),1,Menus.Style.NORMAL);
        g.pose().popMatrix();
    }
    private void text(GuiGraphicsExtractor g,String value,float px,float py){GoonFont.draw(g,value,x+px,y+py,8.5f,GoonFont.Weight.REGULAR,Ui.MUTED,false);}
    @Override public boolean mouseClicked(MouseButtonEvent e,boolean doubleClick){if(e.button()==1&&Ui.inside(e.x()/s,e.y()/s,x+338,y+192,x+418,y+216)){onClose();return true;}return super.mouseClicked(e,doubleClick);}
    @Override public void onClose(){minecraft.gui.setScreen(parent);}
    @Override public boolean isPauseScreen(){return false;}
}
