package dev.goonclient.client.modules.inventory;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.inventory.tooltip.ClientTooltipComponent;
import net.minecraft.world.item.ItemStack;

/** Draws the container's slots as a 9-wide grid inside the tooltip. */
public class ContainerPreviewComponent implements ClientTooltipComponent {
	private static final int SLOT = 18;
	private static final int COLUMNS = 9;

	private final ContainerPreview.Tooltip tooltip;

	public ContainerPreviewComponent(ContainerPreview.Tooltip tooltip) {
		this.tooltip = tooltip;
	}

	private int rows() {
		return (tooltip.slots().size() + COLUMNS - 1) / COLUMNS;
	}

	@Override
	public int getHeight(Font font) {
		return rows() * SLOT + 4;
	}

	@Override
	public int getWidth(Font font) {
		return COLUMNS * SLOT;
	}

	@Override
	public void extractImage(Font font, int x, int y, int width, int height, GuiGraphicsExtractor g) {
		for (int i = 0; i < tooltip.slots().size(); i++) {
			int sx = x + (i % COLUMNS) * SLOT;
			int sy = y + (i / COLUMNS) * SLOT;
			g.fill(sx, sy, sx + SLOT - 1, sy + SLOT - 1, 0x60000000);
			ItemStack stack = tooltip.slots().get(i);
			if (!stack.isEmpty()) {
				g.item(stack, sx + 1, sy + 1);
				g.itemDecorations(font, stack, sx + 1, sy + 1);
			}
		}
	}
}
