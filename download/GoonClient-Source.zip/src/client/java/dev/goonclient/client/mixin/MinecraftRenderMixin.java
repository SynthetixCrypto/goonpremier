package dev.goonclient.client.mixin;

import dev.goonclient.client.gui.render.GoonFont;
import dev.goonclient.client.modules.hud.HardwareUsage;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.debug.DebugScreenEntryList;
import net.minecraft.client.gui.components.debug.DebugScreenEntries;
import net.minecraft.resources.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Minecraft.class)
public class MinecraftRenderMixin {
	/** Request the same GPU timing as F3 without enabling F3 or changing the player's debug configuration. */
	@WrapOperation(method = "renderFrame", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/components/debug/DebugScreenEntryList;isCurrentlyEnabled(Lnet/minecraft/resources/Identifier;)Z"))
	private boolean goonclient$gpuTimer(DebugScreenEntryList entries, Identifier id, Operation<Boolean> original) {
		return original.call(entries, id) || (id.equals(DebugScreenEntries.GPU_UTILIZATION) && HardwareUsage.needsGpuTiming());
	}

	@Inject(method = "renderFrame", at = @At("HEAD"))
	private void goonclient$releaseOldFonts(CallbackInfo ci) {
        dev.goonclient.client.tracker.PerformanceNotebook.beginFrame(Minecraft.getInstance());
		dev.goonclient.client.gui.render.BackdropBlur.beginFrame();
		dev.goonclient.client.hud.ChatFootprint.beginFrame();
		GoonFont.beginFrame();
		dev.goonclient.client.gui.render.Icons.beginFrame();
		dev.goonclient.client.gui.render.Logo.beginFrame();
	}
    @Inject(method = "renderFrame", at = @At("TAIL"))
    private void goonclient$notebookBoundary(CallbackInfo ci) {
        dev.goonclient.client.tracker.PerformanceNotebook.endFrame(Minecraft.getInstance());
    }
    @Inject(method="pauseGame",at=@At("HEAD"))
    private void goonclient$notebookPause(boolean showMenu,CallbackInfo ci){
        dev.goonclient.client.tracker.PerformanceNotebook.invalidateBoundary();
    }
}
