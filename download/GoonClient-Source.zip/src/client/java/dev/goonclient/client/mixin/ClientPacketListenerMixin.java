package dev.goonclient.client.mixin;

import dev.goonclient.client.modules.inventory.PickupNotifier;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.network.protocol.game.ClientboundTakeItemEntityPacket;
import net.minecraft.network.protocol.game.ClientboundEntityEventPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPacketListener.class)
public class ClientPacketListenerMixin {
    @Inject(method = "handleSetTime", at = @At("TAIL"))
    private void goonclient$watchClock(net.minecraft.network.protocol.game.ClientboundSetTimePacket packet, CallbackInfo ci) {
        dev.goonclient.client.modules.utility.ServerWatch.clockUpdate();
    }

    // Vanilla's handler performs the packet thread check first; TAIL runs after the local event animation.
    @Inject(method = "handleEntityEvent", at = @At("TAIL"))
    private void goonclient$totemAlert(ClientboundEntityEventPacket packet, CallbackInfo ci) {
        dev.goonclient.client.modules.utility.TotemAlerts.onEvent(packet);
    }

	/**
	 * Runs after the thread check, so only on the main thread and before the item entity is removed.
	 * This is the server telling us exactly what was picked up and by whom.
	 */
	@Inject(method = "handleTakeItemEntity", at = @At(value = "INVOKE",
		target = "Lnet/minecraft/network/protocol/PacketUtils;ensureRunningOnSameThread(Lnet/minecraft/network/protocol/Packet;Lnet/minecraft/network/PacketListener;Lnet/minecraft/network/PacketProcessor;)V",
		shift = At.Shift.AFTER))
	private void goonclient$onPickup(ClientboundTakeItemEntityPacket packet, CallbackInfo ci) {
		PickupNotifier.onTakeItem(packet.getItemId(), packet.getPlayerId(), packet.getAmount());
	}
}
