package dev.goonclient.client.module;

public enum Category {
	HUD("HUD", "Info panels on your screen"),
	WORLD("World", "Exploration, waypoints and spawning"),
	COMBAT("Combat", "Gear, effects and danger"),
	INVENTORY("Inventory", "Items and containers"),
	VISUAL("Visual", "Camera and lighting"),
	UTILITY("Utility", "Quality of life");

	private final String displayName;
	private final String description;

	Category(String displayName, String description) {
		this.displayName = displayName;
		this.description = description;
	}

	public String displayName() {
		return displayName;
	}

	public String description() {
		return description;
	}
}
