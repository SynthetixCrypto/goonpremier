package dev.goonclient.client.modules.visual;

import dev.goonclient.Goon;
import dev.goonclient.client.config.ConfigManager;
import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.Module;
import dev.goonclient.client.module.setting.ButtonSetting;
import dev.goonclient.client.modules.hud.FeedbackHud;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.irisshaders.iris.api.v0.IrisApi;

/** Iris owns pack selection; the Goon switch and native Iris controls stay in sync. */
public final class Shaders extends Module {
    private static Shaders instance;
    public Shaders(){super("shaders","Shaders","Switch the selected Iris shader pack on or off, or choose a pack.",Category.VISUAL,false);instance=this;add(new ButtonSetting("packs","Shader pack selection","Choose shader pack",()->{var mc=Minecraft.getInstance();if(available())mc.gui.setScreen((Screen)IrisApi.getInstance().openMainIrisScreenObj(mc.gui.screen()));}));}
    public static boolean available(){return FabricLoader.getInstance().isModLoaded("iris");}
    public static void sync(){if(instance==null||!available())return;boolean on=IrisApi.getInstance().getConfig().areShadersEnabled() && net.irisshaders.iris.Iris.getIrisConfig().getShaderPackName().filter(s -> !s.isBlank()).isPresent();if(instance.isEnabled()!=on){instance.loadEnabled(on);ConfigManager.markDirty();}}
    @Override protected void onEnable(){apply(true);}
    @Override protected void onDisable(){apply(false);}
    private void apply(boolean on){
        if(!available()){loadEnabled(false);FeedbackHud.post("shaders","Shaders","Iris is not installed",false);return;}
        if(on&&net.irisshaders.iris.Iris.getIrisConfig().getShaderPackName().filter(s -> !s.isBlank()).isEmpty()){loadEnabled(false);
            var mc=Minecraft.getInstance();
            mc.gui.setScreen((Screen)IrisApi.getInstance().openMainIrisScreenObj(mc.gui.screen()));
            FeedbackHud.post("shaders","Shaders","Choose a shader pack first",false);return;}
        try{IrisApi.getInstance().getConfig().setShadersEnabledAndApply(on);sync();}
        catch(RuntimeException e){Goon.LOGGER.warn("Couldn't change shader state",e);sync();FeedbackHud.post("shaders","Shaders","Couldn't apply this pack. Check Iris settings.",false);}
    }
}
