package dev.goonclient.client.modules.combat;

import dev.goonclient.client.hud.HudPosition;
import dev.goonclient.client.gui.Ui;
import dev.goonclient.client.hud.HudModule;
import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.setting.BooleanSetting;
import dev.goonclient.client.module.setting.NumberSetting;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;

/** Flashing warnings above the hotbar when something is about to go wrong. */
public class DangerMeter extends HudModule {
	private static final EquipmentSlot[] GEAR = {EquipmentSlot.MAINHAND, EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

	private final NumberSetting healthThreshold = add(new NumberSetting("health", "Low health below", 35, 10, 80, 5, "%"));
	private final NumberSetting durabilityThreshold = add(new NumberSetting("durability", "Low durability below", 10, 2, 50, 1, "%"));
	private final BooleanSetting hunger = add(new BooleanSetting("hunger", "Warn when hungry", true));
	private final BooleanSetting sound = add(new BooleanSetting("sound", "Warning sound", true));

	private final Set<String> lastWarnings = new HashSet<>();

	public DangerMeter() {
		super("danger_meter", "Danger Meter", "Warns about low health, hunger, drowning, fire, poison and breaking gear", Category.COMBAT, true, HudPosition.bottomCenter(0, 62));
	}

	@Override
	public boolean isVisible(Minecraft mc) {
		return mc.player != null;
	}

	@Override
	protected boolean isTransient() {
		return true;
	}

	@Override
	protected void render(GuiGraphicsExtractor g, Minecraft mc, boolean editing) {
		List<String> warnings = mc.player != null ? warnings(mc.player) : new ArrayList<>();
		if (warnings.isEmpty() && editing) {
			warnings.add("LOW HEALTH");
			warnings.add("Diamond Pickaxe 6%");
		}
		if (mc.player != null && !editing) {
			playSoundForNew(mc, warnings);
		}
		if (warnings.isEmpty()) {
			setSize(1, 1);
			return;
		}
		Font font = mc.font;
		// A slow, gentle pulse on the red edge only, so it catches the eye without flashing the screen
		float pulse = 0.6f + 0.4f * (float) Math.sin(System.currentTimeMillis() / 220.0);
		int maxWidth = 0;
		for (String warning : warnings) {
			maxWidth = Math.max(maxWidth, Ui.boldWidth(font, warning) + 18);
		}
		int y = 0;
		for (String warning : warnings) {
			int w = Ui.boldWidth(font, warning) + 18;
			int x = (maxWidth - w) / 2;
			Ui.roundRect(g, x, y, x + w, y + 15, 4, 0xE0131416);
			Ui.roundRect(g, x + 4, y + 4, x + 6, y + 11, 1, Ui.withAlpha(Ui.BAD, pulse));
			Ui.bold(g, font, warning, x + 11, y + 4, Ui.BAD, true);
			y += 17;
		}
		setSize(maxWidth, y - 2);
	}

	private List<String> warnings(LocalPlayer player) {
		List<String> warnings = new ArrayList<>();
		if (player.isDeadOrDying() || player.isCreative() || player.isSpectator()) {
			return warnings;
		}
		if (player.getHealth() / player.getMaxHealth() * 100 <= healthThreshold.get()) {
			warnings.add(String.format("LOW HEALTH %.0f❤", player.getHealth()));
		}
		if (hunger.isOn() && player.getFoodData().getFoodLevel() <= 6) {
			warnings.add("HUNGRY - can't sprint");
		}
		if (player.isUnderWater() && player.getAirSupply() < player.getMaxAirSupply() / 3) {
			warnings.add("DROWNING");
		}
		if (player.isInLava()) {
			warnings.add("IN LAVA");
		} else if (player.isOnFire() && !player.hasEffect(MobEffects.FIRE_RESISTANCE)) {
			warnings.add("ON FIRE");
		}
		if (player.hasEffect(MobEffects.WITHER)) {
			warnings.add("WITHERING");
		} else if (player.hasEffect(MobEffects.POISON)) {
			warnings.add("POISONED");
		}
		for (EquipmentSlot slot : GEAR) {
			ItemStack stack = player.getItemBySlot(slot);
			if (stack.isDamageableItem()) {
				int percent = Math.round((stack.getMaxDamage() - stack.getDamageValue()) * 100f / stack.getMaxDamage());
				if (percent <= durabilityThreshold.get()) {
					warnings.add(stack.getHoverName().getString() + " " + percent + "%");
				}
			}
		}
		return warnings;
	}

	private void playSoundForNew(Minecraft mc, List<String> warnings) {
		Set<String> keys = new HashSet<>();
		for (String warning : warnings) {
			// Compare by the first word so a changing number doesn't re-trigger
			keys.add(warning.split(" ")[0]);
		}
		if (sound.isOn() && !lastWarnings.containsAll(keys)) {
			mc.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.NOTE_BLOCK_PLING, 0.6f));
		}
		lastWarnings.clear();
		lastWarnings.addAll(keys);
	}
}
