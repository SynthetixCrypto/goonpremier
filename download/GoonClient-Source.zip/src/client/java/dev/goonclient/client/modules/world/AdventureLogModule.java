package dev.goonclient.client.modules.world;

import dev.goonclient.client.GoonClient;
import dev.goonclient.client.gui.AdventureLogScreen;
import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.Module;
import dev.goonclient.client.module.setting.BooleanSetting;
import dev.goonclient.client.module.setting.ButtonSetting;
import dev.goonclient.client.tracker.AdventureLog;
import dev.goonclient.client.waypoint.WaypointManager;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.LivingEntity;

/** Keeps the Adventure Log: spots boss kills and dimension changes, and takes screenshots of big moments. */
public class AdventureLogModule extends Module {
	private static final Set<EntityType<?>> BOSSES = Set.of(EntityTypes.ENDER_DRAGON, EntityTypes.WITHER, EntityTypes.ELDER_GUARDIAN, EntityTypes.WARDEN);
	private static final int SCREENSHOT_DELAY_TICKS = 12;

	private final BooleanSetting travel = add(new BooleanSetting("travel", "Log trips between dimensions", true));
	private final BooleanSetting shotBosses = add(new BooleanSetting("shot_bosses", "Screenshot boss kills", true));
	private final BooleanSetting shotDrops = add(new BooleanSetting("shot_drops", "Screenshot rare finds", false));
	private final BooleanSetting shotAdvancements = add(new BooleanSetting("shot_advancements", "Screenshot advancements", false));

	private final Map<Integer, String> bosses = new HashMap<>();
	private final List<int[]> pendingShots = new ArrayList<>();
	private String lastWorld;
	private String lastDimension;

	public AdventureLogModule() {
		super("adventure_log", "Adventure Log", "Records deaths, bosses, rare finds, advancements and trips, with auto screenshots", Category.WORLD, true);
		add(new ButtonSetting("open", "See everything you've done here", "Open Log", () -> GoonClient.openNextTick(new AdventureLogScreen(null))));
		AdventureLog.setScreenshotHook(type -> {
			boolean wanted = switch (type) {
				case BOSS -> shotBosses.isOn();
				case DROP -> shotDrops.isOn();
				case ADVANCEMENT -> shotAdvancements.isOn();
				default -> false;
			};
			if (wanted && isEnabled()) {
				// Wait a moment so the toast or the scene is on screen
				pendingShots.add(new int[]{SCREENSHOT_DELAY_TICKS, type.ordinal()});
			}
		});
		AdventureLog.setEnabledCheck(this::isEnabled);
	}

	@Override
	public void onTick(Minecraft mc) {
		if (mc.player == null || mc.level == null) {
			return;
		}
		String world = WaypointManager.worldKey();
		String dimension = mc.level.dimension().identifier().toString();
		if (!Objects.equals(world, lastWorld)) {
			lastWorld = world;
			lastDimension = dimension;
			bosses.clear();
		}
		if (!dimension.equals(lastDimension)) {
			if (travel.isOn() && lastDimension != null) {
				AdventureLog.onTravel(dimension, mc.player.blockPosition());
			}
			lastDimension = dimension;
			bosses.clear();
		}
		trackBosses(mc, dimension);
		takeScreenshots(mc);
	}

	private void trackBosses(Minecraft mc, String dimension) {
		Map<Integer, String> seen = new HashMap<>();
		for (Entity entity : mc.level.getEntities(mc.player, mc.player.getBoundingBox().inflate(160), e -> BOSSES.contains(e.getType()))) {
			if (!(entity instanceof LivingEntity boss)) {
				continue;
			}
			if (boss.isDeadOrDying()) {
				String name = bosses.get(entity.getId());
				if (name != null) {
					AdventureLog.onBossKilled(name, entity.blockPosition(), dimension);
				}
			} else {
				seen.put(entity.getId(), entity.getType().getDescription().getString());
			}
		}
		bosses.clear();
		bosses.putAll(seen);
	}

	private void takeScreenshots(Minecraft mc) {
		Iterator<int[]> it = pendingShots.iterator();
		while (it.hasNext()) {
			int[] shot = it.next();
			if (--shot[0] <= 0) {
				it.remove();
				String type = AdventureLog.Type.values()[shot[1]].name().toLowerCase();
				String stamp = new SimpleDateFormat("yyyy-MM-dd_HH.mm.ss").format(new Date());
				Screenshot.grab(mc.gameDirectory, "goon-" + type + "-" + stamp + ".png", mc.gameRenderer.mainRenderTarget(), 1, message -> {
				});
			}
		}
	}
}
