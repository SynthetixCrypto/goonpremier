package dev.goonclient.client.mixin.ipn;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.Slice;

/** Hide only the continuous-crafting checkbox; sorting, moving and slot locking keep their upstream controls. */
@Mixin(targets="org.anti_ad.mc.ipnext.gui.inject.SortingButtonCollectionWidget$InitWidgets", remap=false)
public abstract class CraftingCheckboxMixin {
    @ModifyArg(method="<init>", index=0, remap=false,
        slice=@Slice(from=@At(value="INVOKE", remap=false,
            target="Lorg/anti_ad/mc/ipnext/config/GuiSettings;getSHOW_CONTINUOUS_CRAFTING_CHECKBOX()Lorg/anti_ad/mc/common/config/options/ConfigKeyToggleBoolean;")),
        at=@At(value="INVOKE", ordinal=0, remap=false,
            target="Lorg/anti_ad/mc/ipnext/gui/inject/base/SortButtonWidget;setVisible(Z)V"))
    private boolean goonclient$hideCraftingCheckbox(boolean visible) {
        return false;
    }
}
