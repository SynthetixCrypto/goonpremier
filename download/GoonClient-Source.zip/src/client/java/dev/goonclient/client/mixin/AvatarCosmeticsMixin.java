package dev.goonclient.client.mixin;

import dev.goonclient.client.cosmetics.Cosmetics;
import net.minecraft.client.renderer.entity.player.AvatarRenderer;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.world.entity.Avatar;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(AvatarRenderer.class)
public abstract class AvatarCosmeticsMixin {
	@Inject(method = "extractRenderState(Lnet/minecraft/world/entity/Avatar;Lnet/minecraft/client/renderer/entity/state/AvatarRenderState;F)V", at = @At("TAIL"))
	private void goon$cosmetics(Avatar entity, AvatarRenderState state, float partialTick, CallbackInfo ci) {
		if (entity instanceof Player player) state.nameTag = dev.goonclient.client.modules.visual.PlayerTags.decorate(player, state.nameTag);
        // Mannequins are avatars too; cosmetics belong only to players with a UUID.
		if (entity instanceof Player && !state.isSpectator && !state.isInvisible) state.skin = Cosmetics.skin(entity.getUUID(), state.skin);
	}
}
