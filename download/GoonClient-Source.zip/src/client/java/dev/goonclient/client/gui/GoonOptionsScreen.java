package dev.goonclient.client.gui;

import com.mojang.blaze3d.platform.InputConstants;
import dev.goonclient.client.compat.SodiumCompat;
import net.fabricmc.loader.api.FabricLoader;
import dev.goonclient.client.gui.render.GoonFont;
import dev.goonclient.client.gui.render.Shapes;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.CreditsAndAttributionScreen;
import net.minecraft.client.gui.screens.telemetry.TelemetryInfoScreen;
import net.minecraft.client.gui.screens.options.*;
import net.minecraft.client.gui.screens.options.controls.ControlsScreen;
import net.minecraft.client.gui.screens.packs.PackSelectionScreen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;

/** The Options landing page, shared by the title menu, pause menu and vanilla entry points. */
public final class GoonOptionsScreen extends Screen implements GoonScreen {
	private final Screen parent;
	private final List<Entry> entries = new ArrayList<>();
	private float scale;
	private int x, y;
	private int selected;
	private boolean draggingFov;

	public GoonOptionsScreen(Screen parent) {
		super(Component.literal("Goon Client Options"));
		this.parent = parent;
	}

	@Override
	protected void init() {
		scale = Ui.menuScale(width, height);
		x = (int) (width / scale - 580) / 2;
		y = (int) (height / scale - 366) / 2;
		entries.clear();
		var o = minecraft.options;
		add("Video", "Display, graphics & shaders", () -> minecraft.gui.setScreen(FabricLoader.getInstance().isModLoaded("sodium")
			? SodiumCompat.videoScreen(this) : new VideoSettingsScreen(this, minecraft, o)));
		add("Music & Sounds", "Volume, devices & subtitles", () -> minecraft.gui.setScreen(new SoundOptionsScreen(this, o)));
		add("Controls", "Key bindings & movement", () -> minecraft.gui.setScreen(new ControlsScreen(this, o)));
		add("Mouse", "Sensitivity & scrolling", () -> minecraft.gui.setScreen(new MouseSettingsScreen(this, o)));
		add("Chat", "Messages, scale & colours", () -> minecraft.gui.setScreen(new ChatOptionsScreen(this, o)));
		add("Accessibility", "Narrator, text & effects", () -> minecraft.gui.setScreen(new AccessibilityOptionsScreen(this, o)));
		add("Language", "Game language & fonts", () -> minecraft.gui.setScreen(new LanguageSelectScreen(this, o, minecraft.getLanguageManager())));
		add("Skin Customization", "Layers & main hand", () -> minecraft.gui.setScreen(new SkinCustomizationScreen(this, o)));
		add("Resource Packs", "Textures, models & sounds", () -> minecraft.gui.setScreen(new PackSelectionScreen(
			minecraft.getResourcePackRepository(), packs -> {
				o.updateResourcePacks(packs);
				minecraft.gui.setScreen(this);
			}, minecraft.getResourcePackDirectory(), Component.translatable("resourcePack.title"))));
		add("Online", "Server & social preferences", () -> minecraft.gui.setScreen(new OnlineOptionsScreen(this, o)));
		add("Goon Client", "Modules, interface & HUD", () -> minecraft.gui.setScreen(new ClickGuiScreen(this)));
		add("Low-resource preset", "Lighter settings with restore", () -> minecraft.gui.setScreen(new PerformanceScreen(this)));
		add("Telemetry", minecraft.allowsTelemetry() ? "Privacy & data collection" : "Unavailable for this account", () -> {
			if (minecraft.allowsTelemetry()) minecraft.gui.setScreen(new TelemetryInfoScreen(this, o));
		});
		add("Credits & Attribution", "The people behind Minecraft", () -> minecraft.gui.setScreen(new CreditsAndAttributionScreen(this)));
	}

	private void add(String title, String subtitle, Runnable action) {
		int i = entries.size();
		entries.add(new Entry(title, subtitle, x + 18 + (i % 3) * 184, y + 65 + (i / 3) * 48, action));
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor g, int mx, int my, float partialTick) {
		g.pose().pushMatrix();
		g.pose().scale(scale, scale);
		GlassUi.window(g, x, y, 580, 366, 1);
		Ui.logoMark(g, font, x + 18, y + 17, 24, 1);
		GoonFont.draw(g, "Options", x + 52, y + 16, 16, GoonFont.Weight.BOLD, Ui.TEXT, false);
		Ui.text(g, font, "Make the game yours.", x + 52, y + 38, Ui.MUTED);
		Ui.text(g, font, "GOON CLIENT", x + 470, y + 24, Ui.FAINT);
		for (int i = 0; i < entries.size(); i++) {
			Entry e = entries.get(i);
			boolean hover = Ui.inside(mx / scale, my / scale, e.x, e.y, e.x + 176, e.y + 44);
			float h = Ui.animate("options:card:" + e.title, hover ? 1 : 0, 0.5f);
			GlassUi.card(g, e.x, e.y, 176, 44, minecraft.getLastInputType().isKeyboard() && selected == i, h);
			Ui.bold(g, font, e.title, e.x + 11, e.y + 9, Ui.TEXT);
			Ui.text(g, font, e.subtitle, e.x + 11, e.y + 25, Ui.MUTED);
			if (minecraft.getLastInputType().isKeyboard() && selected == i) Ui.roundOutline(g, e.x, e.y, e.x + 176, e.y + 44, 6, Ui.accent(), 0);
		}
		int fx = x + 386, fy = y + 257;
		GlassUi.card(g, fx, fy, 176, 44, selected == 14 && minecraft.getLastInputType().isKeyboard(), 0);
		Ui.bold(g, font, "Field of view", fx + 11, fy + 9, Ui.TEXT);
		Ui.text(g, font, minecraft.options.fov().get() + "°", fx + 141, fy + 9, Ui.MUTED);
		Shapes.roundRect(g, fx + 11, fy + 29, fx + 165, fy + 32, 1.5f, Ui.CONTROL);
		float fraction = (minecraft.options.fov().get() - 30) / 80f;
		Shapes.roundRect(g, fx + 11, fy + 29, fx + 11 + fraction * 154, fy + 32, 1.5f, Ui.accent());
		Shapes.circle(g, fx + 11 + fraction * 154, fy + 30.5f, 3, Ui.TEXT);
		Ui.text(g, font, "Your changes save automatically.", x + 18, y + 336, Ui.FAINT);
		Menus.button(g, "Done", x + 416, y + 327, 146, (int) (mx / scale), (int) (my / scale), 1, Menus.Style.NORMAL);
		if (selected == 15 && minecraft.getLastInputType().isKeyboard()) Ui.roundOutline(g, x + 416, y + 327, x + 562, y + 351, 7, Ui.accent(), 0);
		g.pose().popMatrix();
	}

	@Override
	public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
		if (event.button() != 1) return super.mouseClicked(event, doubleClick);
		double mx = event.x() / scale, my = event.y() / scale;
		for (Entry e : entries) {
			if (Ui.inside(mx, my, e.x, e.y, e.x + 176, e.y + 44)) {
				minecraft.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, 1));
				e.action.run();
				return true;
			}
		}
		if (Ui.inside(mx, my, x + 386, y + 257, x + 562, y + 301)) {
			draggingFov = true;
			setFov(mx);
			return true;
		}
		if (Ui.inside(mx, my, x + 416, y + 327, x + 562, y + 351)) {
			onClose();
			return true;
		}
		return super.mouseClicked(event, doubleClick);
	}

	private void setFov(double mx) {
		minecraft.options.fov().set(30 + (int) Math.round(Math.clamp((mx - x - 397) / 154, 0, 1) * 80));
	}

	@Override
	public boolean mouseDragged(MouseButtonEvent event, double dx, double dy) {
		if (!draggingFov) return super.mouseDragged(event, dx, dy);
		setFov(event.x() / scale);
		return true;
	}

	@Override
	public boolean mouseReleased(MouseButtonEvent event) {
		if (draggingFov) {
			draggingFov = false;
			minecraft.options.save();
			return true;
		}
		return super.mouseReleased(event);
	}

	@Override
	public boolean keyPressed(KeyEvent event) {
		int key = event.key();
		if (selected == 14 && (key == InputConstants.KEY_LEFT || key == InputConstants.KEY_RIGHT)) {
			minecraft.options.fov().set(Math.clamp(minecraft.options.fov().get() + (key == InputConstants.KEY_RIGHT ? 1 : -1), 30, 110));
			return true;
		}
		int step = key == InputConstants.KEY_TAB ? (minecraft.hasShiftDown() ? -1 : 1) : key == InputConstants.KEY_RIGHT ? 1
			: key == InputConstants.KEY_LEFT ? -1 : key == InputConstants.KEY_DOWN ? 3 : key == InputConstants.KEY_UP ? -3 : 0;
		if (step != 0) {
			selected = Math.floorMod(selected + step, 16);
			return true;
		}
		if (key == InputConstants.KEY_RETURN || key == InputConstants.KEY_SPACE) {
			if (selected < entries.size()) entries.get(selected).action.run();
			else if (selected == 15) onClose();
			return true;
		}
		return super.keyPressed(event);
	}

	@Override
	public void removed() {
		minecraft.options.save();
	}

	@Override
	public void onClose() {
		minecraft.gui.setScreen(parent);
	}

	private record Entry(String title, String subtitle, int x, int y, Runnable action) {
	}
}
