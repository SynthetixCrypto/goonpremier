package dev.goonclient.client.modules.hud;

import dev.goonclient.client.compat.XaeroCompat;
import dev.goonclient.client.hud.HudModule;
import dev.goonclient.client.hud.HudPosition;
import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.setting.ButtonSetting;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/** Xaero's map participates in the same editor, scale controls and collision layout as every Goon HUD panel. */
public final class MinimapHud extends HudModule {
	private static MinimapHud instance;
	private int mapSize = 80;
	private static final int PAD = 3;

	public MinimapHud() {
		super("minimap", "Minimap", "Xaero's map, integrated with your HUD. Drag and resize in Edit HUD; other panels make room.",
			Category.HUD, true, HudPosition.topRight(4, 4));
		instance = this;
		add(new ButtonSetting("map_settings", "Map, radar and waypoints", "Settings", () -> {
			var mc = Minecraft.getInstance();
			mc.gui.setScreen(XaeroCompat.settings(mc.gui.screen()));
		}));
	}

	public static boolean integrated() { return instance != null; }
	public static boolean available() { return FabricLoader.getInstance().isModLoaded("xaerominimap"); }
	public static float mapScale() { return instance == null ? 1 : instance.scale.floatValue(); }
	public static void syncVisibility() {
		if (instance != null) XaeroCompat.syncVisibility(instance);
	}

	@Override protected boolean absoluteCoordinates() { return true; }
	@Override public boolean isLayoutObstacle() { return true; }
	@Override protected void measure(Minecraft mc, boolean editing) {
		mapSize = XaeroCompat.size(mc);
		// Native scaling is already reflected in the measured dimensions; don't scale the rectangle twice.
		setSize(Math.round((mapSize + PAD * 2) / scale.floatValue()), Math.round((mapSize + PAD * 2) / scale.floatValue()));
	}
	@Override public boolean isVisible(Minecraft mc) { return XaeroCompat.visible(mc); }
	@Override protected void render(GuiGraphicsExtractor g, Minecraft mc, boolean editing) {
		XaeroCompat.render(g, mc, screenX() + PAD, screenY() + PAD, mapSize);
	}
}
