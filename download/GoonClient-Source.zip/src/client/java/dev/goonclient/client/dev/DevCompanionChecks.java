package dev.goonclient.client.dev;

import com.google.gson.JsonObject;
import dev.goonclient.Goon;
import dev.goonclient.client.config.*;
import dev.goonclient.client.gui.*;
import dev.goonclient.client.modules.inventory.ContainerMemory;
import dev.goonclient.client.tracker.*;
import dev.goonclient.client.utility.WorldScope;
import java.nio.file.Files;
import java.util.List;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import net.minecraft.client.input.KeyEvent;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.core.*;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.*;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.phys.*;

/** Opt-in integrated-world regression tour. No real Microsoft identity/server or player's config is used. */
public final class DevCompanionChecks {
    private static int step;
    private static boolean begun;
    private static JsonObject before;
    private static WorldScope scope;
    private static BlockPos chest,unseen;
    private static FarmReports.Snapshot report,ended;
    private DevCompanionChecks(){}
    public static void init(){if(Boolean.getBoolean("goonclient.companionPreview")&&FabricLoader.getInstance().isDevelopmentEnvironment())ClientTickEvents.END_CLIENT_TICK.register(DevCompanionChecks::tick);}
    private static void require(boolean value,String message){if(!value)throw new IllegalStateException(message);}
    private static void run(Minecraft mc,String command){var server=mc.getSingleplayerServer();require(server!=null,"Integrated dev world required");server.execute(()->server.getCommands().performPrefixedCommand(server.createCommandSourceStack().withSuppressedOutput(),"execute as @p at @p run "+command));}
    private static String pos(BlockPos p){return p.getX()+" "+p.getY()+" "+p.getZ();}
    private static void shot(Minecraft mc,String name){Screenshot.grab(mc.gameDirectory,"goon-0180-"+name+".png",mc.gameRenderer.mainRenderTarget(),1,message->{});}
    private static void tick(Minecraft mc){
        if(!mc.isGameLoadFinished())return;
        if(!begun){if(mc.player==null||mc.level==null)return;begun=true;}
        mc.getFramerateLimitTracker().onInputReceived();step++;
        try{
            if(step==20){
                var baselineHud=dev.goonclient.client.module.ModuleManager.all().stream().filter(m->m instanceof dev.goonclient.client.hud.HudModule).map(m->(dev.goonclient.client.hud.HudModule)m).findFirst().orElseThrow();baselineHud.setPosition(baselineHud.defaultPosition());before=ConfigManager.capture();scope=WorldScope.current(mc);require(scope!=null,"No world namespace");
                require(WorldScope.of("mp:example.test:25565","A").key().equals(WorldScope.of("mp:example.test:25565","B").key()),"Display names changed server identity");
                require(!WorldScope.of("mp:example.test:25565","A").key().equals(WorldScope.of("mp:example.test:25566","A").key()),"Ports shared profile data");
                var minimal=ProfileStore.presets().stream().filter(p->p.id().equals("minimal")).findFirst().orElseThrow();
                require(ServerProfiles.bind(minimal).ok(),"Profile binding failed");ServerProfiles.onLeave();ServerProfiles.enter(scope);
                require(ProfileStore.lastApplied().equals("Minimal")&&Files.exists(ConfigManager.dir().resolve("server-profile-restore.json")),"Automatic setup not applied/journaled");
                ServerProfiles.onLeave();require(before.equals(ConfigManager.capture()),"Leave did not restore exact baseline");
                ServerProfiles.enter(scope);
                var hud=dev.goonclient.client.module.ModuleManager.all().stream().filter(m->m instanceof dev.goonclient.client.hud.HudModule).map(m->(dev.goonclient.client.hud.HudModule)m).findFirst().orElseThrow();
                var savedPosition=hud.position();
                hud.setPosition(new dev.goonclient.client.hud.HudPosition(0,0,137,91,0,0));
                ServerProfiles.init();require(before.equals(ConfigManager.capture()),"Crash recovery failed to restore HUD position");
                require(hud.position().equals(savedPosition),"Crash recovery retained stale server offsets");
                require(!Files.exists(ConfigManager.dir().resolve("server-profile-restore.json")),"Recovery journal not cleared");
                ServerProfiles.enter(scope);require(ServerProfiles.unbind().ok(),"Unlink failed");ServerProfiles.onLeave();require(before.equals(ConfigManager.capture()),"Unlink/leave changed baseline");
                ServerProfiles.enter(scope);
                var missing=new ProfileStore.Profile("missing-dev-profile","Removed setup","",true,before);
                require(ServerProfiles.bind(missing).ok(),"Missing binding setup failed");ServerProfiles.onLeave();ServerProfiles.enter(scope);require(before.equals(ConfigManager.capture()),"Missing setup changed settings");ServerProfiles.unbind();
                Goon.LOGGER.info("0.18.0 CHECK: local profile binding, join, exact leave restore, crash recovery, missing setup and unlink passed");
                ContainerMemory.setRecording(true);mc.gui.setScreen(null);
                chest=mc.player.blockPosition().offset(2,0,0);unseen=chest.offset(7,0,0);
                run(mc,"gamemode creative");run(mc,"setblock "+pos(chest.above())+" minecraft:air");run(mc,"setblock "+pos(chest.below())+" minecraft:stone");
                run(mc,"setblock "+pos(chest)+" minecraft:chest");run(mc,"item replace block "+pos(chest)+" container.0 with minecraft:diamond 7");run(mc,"item replace block "+pos(chest)+" container.1 with minecraft:bone 16");
                run(mc,"setblock "+pos(unseen)+" minecraft:barrel");run(mc,"item replace block "+pos(unseen)+" container.0 with minecraft:emerald 23");
                mc.options.guiScale().set(2);mc.resizeGui();
            }
            if(step==45){
                require(ContainerBookmarks.all().isEmpty(),"Unopened container was recorded");
                mc.player.setShiftKeyDown(false);
                mc.gameMode.useItemOn(mc.player,InteractionHand.MAIN_HAND,new BlockHitResult(Vec3.atCenterOf(chest),Direction.UP,chest,false));
            }
            if(step==70){
                var list=ContainerBookmarks.all();require(list.size()==1,"Actual chest open not recorded, or unseen chest recorded");
                var e=list.getFirst();require(e.x()==chest.getX()&&e.z()==chest.getZ(),"Wrong container location");
                require(e.items().stream().anyMatch(i->i.id().equals("minecraft:diamond")&&i.count()==7),"Chest diamond count wrong or player inventory included");
                require(e.items().stream().noneMatch(i->i.id().equals("minecraft:emerald")),"Unopened barrel contents leaked");
                run(mc,"item replace block "+pos(chest)+" container.0 with minecraft:diamond 9");
            }
            if(step==90){
                require(ContainerBookmarks.all().getFirst().items().stream().anyMatch(i->i.id().equals("minecraft:diamond")&&i.count()==9),"Server slot update not reflected");
                var cached=ContainerBookmarks.all();long revision=ContainerBookmarks.revision();
                for(int i=0;i<100;i++)ContainerBookmarks.slot(mc,mc.player.containerMenu.containerId,0);
                require(ContainerBookmarks.revision()==revision&&ContainerBookmarks.all()==cached,"Identical slot packets invalidated bookmarks");
                require(ContainerBookmarks.size()==cached.size(),"Bookmark size mismatch");
                Goon.LOGGER.info("0.18.2 CHECK: 100 duplicate slot updates retained revision and immutable snapshot");
                mc.player.closeContainer();ContainerBookmarks.onLeave();ContainerBookmarks.onJoin(mc);
                require(ContainerBookmarks.all().size()==1,"Saved container didn't reload");
                var screen=new ContainerBookmarksScreen(null);mc.gui.setScreen(screen);screen.search("diamond");require(screen.results().size()==1,"Item name search failed");screen.search("minecraft:bone");require(screen.results().size()==1,"Item ID search failed");screen.search("emerald");require(screen.results().isEmpty(),"Unknown item search found unopened inventory");screen.search("");
                Goon.LOGGER.info("0.18.0 CHECK: real block use/open/content/slot packets, inventory exclusion, unopened barrel, persistence and search passed");
            }
            if(step==100)shot(mc,"container-search-scale2");
            if(step==103){
                var screen=(ContainerBookmarksScreen)mc.gui.screen();require(mc.gui.hud.isHidden(),"Container browser did not hide HUD");
                require(!screen.mouseScrolled(0,0,0,-1),"Browser accepted scroll outside its window");
                screen.keyPressed(new KeyEvent(InputConstants.KEY_F,0,128));
                screen.keyPressed(new KeyEvent(InputConstants.KEY_TAB,0,0));
                screen.keyPressed(new KeyEvent(InputConstants.KEY_RETURN,0,0));require(!ContainerMemory.recording(),"Keyboard recording toggle failed");
                screen.keyPressed(new KeyEvent(InputConstants.KEY_RETURN,0,0));require(ContainerMemory.recording(),"Keyboard recording toggle restore failed");
            }
            if(step==118){mc.gui.screen().onClose();require(!mc.gui.hud.isHidden(),"Browser exit did not restore HUD");}
            if(step==105){mc.options.guiScale().set(4);mc.resizeGui();}
            if(step==115)shot(mc,"container-search-scale4");
            if(step==120){mc.options.guiScale().set(2);mc.resizeGui();mc.gui.setScreen(new ProfileScreen(null));}
            if(step==130)shot(mc,"profile-links-scale2");
            if(step==135){mc.options.guiScale().set(4);mc.resizeGui();}
            if(step==145)shot(mc,"profile-links-scale4");
            if(step==150){
                mc.gui.setScreen(null);LootTracker.reset();LootTracker.onPickup(new ItemStack(Items.BONE),64);LootTracker.onPickup(new ItemStack(Items.DIAMOND),7);
                run(mc,"experience add @p 120 points");
            }
            if(step==180){
                report=FarmReports.snapshot();require(report!=null&&report.total()==71,"Report item totals wrong");require(report.xp()>=120,"Observed XP missing");
                require(report.items().stream().anyMatch(i->i.id().equals("minecraft:bone")&&i.count()==64&&i.perHour()==3840),"Report rates don't match one-minute basis");
                var exported=FarmReports.export(report);require(Files.readString(exported.csv()).startsWith("\uFEFFkind,"),"CSV BOM/header missing");require(Files.readString(exported.summary()).contains("minecraft:bone"),"Summary missing items");
                var fixture=new FarmReports.Snapshot("=Test,world",report.startedAt(),report.capturedAt(),60_000,60_000,120,2,4,List.of(new FarmReports.ItemRow("minecraft:paper","=HYPERLINK(\"x\"),test",4,240)),false);
                var escaped=FarmReports.export(fixture);require(Files.readString(escaped.csv()).contains("'="),"Spreadsheet formula neutralization missing");
                Goon.LOGGER.info("0.18.0 CHECK: matching farm totals/rates/XP, paired CSV/Markdown export, quoting and formula-neutralization passed");
                mc.options.guiScale().set(2);mc.resizeGui();mc.gui.setScreen(new FarmReportScreen(null));
            }
            if(step==190)shot(mc,"farm-report-scale2");
            if(step==195){mc.options.guiScale().set(4);mc.resizeGui();}
            if(step==205)shot(mc,"farm-report-scale4");
            if(step==208){
                var screen=(FarmReportScreen)mc.gui.screen();require(mc.gui.hud.isHidden(),"Report did not hide HUD");
                require(!screen.mouseScrolled(0,0,0,-1),"Report accepted scroll outside its window");
                screen.keyPressed(new KeyEvent(InputConstants.KEY_TAB,0,0));screen.keyPressed(new KeyEvent(InputConstants.KEY_RETURN,0,0));
                require(mc.gui.screen()==null&&!mc.gui.hud.isHidden(),"Keyboard Done did not close report and restore HUD");
                Goon.LOGGER.info("0.18.0 CHECK: keyboard actions, outside-window scroll rejection and HUD restoration passed");
            }
            if(step==210){FarmReports.onLeave();ended=FarmReports.snapshot();require(ended.finished(),"Session not frozen on leave");}
            if(step==220){require(ended.equals(FarmReports.snapshot()),"Ended session kept counting time");
                ContainerMemory.setRecording(false);ContainerBookmarks.used(mc,new BlockHitResult(Vec3.atCenterOf(unseen),Direction.UP,unseen,false));require(ContainerBookmarks.all().size()==1,"Disabled recording added data");
                mc.gui.setScreen(null);run(mc,"setblock "+pos(chest)+" minecraft:air");run(mc,"setblock "+pos(unseen)+" minecraft:air");
                ConfigManager.apply(before,true,false);mc.disconnectFromWorld(net.minecraft.client.multiplayer.ClientLevel.DEFAULT_QUIT_MESSAGE);
            }
            if(step==235){mc.gui.setScreen(new ContainerBookmarksScreen(null));}
            if(step==245)shot(mc,"container-empty-no-world");
            if(step==250){mc.gui.setScreen(new FarmReportScreen(null));}
            if(step==260)shot(mc,"ended-report-no-world");
            if(step==270){require(mc.level==null&&mc.player==null,"No-world screens were not tested");require(ended.equals(FarmReports.snapshot()),"Disconnect changed ended snapshot");Goon.LOGGER.info("0.18.0 COMPANION CHECKS PASSED: profiles/recovery; observed containers/search/persistence; report exports/freeze; scale2/4 and no-world screens");mc.stop();}
        }catch(Exception e){throw new IllegalStateException("Companion regression failed at step "+step,e);}
    }
}
