package dev.goonclient.client.mixin.xaero;

import dev.goonclient.client.compat.NestedModFiles;
import java.nio.file.Path;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Xaero 1.46.4 only handles PATH origins; Fabric gives bundled mods a NESTED origin. */
@Pseudo
@Mixin(targets = "xaero.map.WorldMapFabric", remap = false)
public class XaeroWorldMapFileMixin {
	@Inject(method = "fetchModFile()Ljava/nio/file/Path;", at = @At("HEAD"), cancellable = true)
	private void goonclient$nestedModFile(CallbackInfoReturnable<Path> cir) {
		NestedModFiles.locate("xaeroworldmap").ifPresent(cir::setReturnValue);
	}
}
