package dev.goonclient.client.modules.combat;

import dev.goonclient.client.gui.Ui;
import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.Module;
import dev.goonclient.client.module.setting.BooleanSetting;
import dev.goonclient.client.module.setting.NumberSetting;
import dev.goonclient.client.render.WorldRender;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.gizmos.GizmoStyle;
import net.minecraft.gizmos.Gizmos;
import net.minecraft.gizmos.TextGizmo;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/** Bounded, tick-cached estimate of vanilla bow/throwable ballistics. No automatic aiming. */
public final class ProjectileGuide extends Module implements WorldRender.Renderable {
    private record Launch(double speed, double gravity, float pitchOffset, boolean arrow) {}
    private final BooleanSetting bow = add(new BooleanSetting("bow", "Bows (while drawing)", true));
    private final BooleanSetting throwables = add(new BooleanSetting("throwables", "Pearls, eggs, snowballs and bottles", true));
    private final BooleanSetting entityHits = add(new BooleanSetting("entity_hits", "Estimate hits on visible entities", true));
    private final BooleanSetting label = add(new BooleanSetting("label", "Estimated impact distance", true));
    private final NumberSetting ticks = add(new NumberSetting("ticks", "Simulation limit", 80, 20, 120, 10, " ticks"));
    private final NumberSetting width = add(new NumberSetting("width", "Line width", 2, 1, 4, .25));
    private final List<Vec3> path = new ArrayList<>();
    private ClientLevel level;
    private Vec3 impact, origin;
    private boolean mobImpact;
    public ProjectileGuide() {
        super("projectile_guide", "Projectile Guide", "Bow and throwable paths with estimated impact markers", Category.COMBAT, false);
    }
    @Override protected void onDisable() { clear(); }
    private void clear() { path.clear(); impact = null; origin = null; level = null; }
    private Launch launch(Minecraft mc, ItemStack stack) {
        if (bow.isOn() && stack.is(Items.BOW) && mc.player.isUsingItem() && mc.player.getUseItem().is(Items.BOW)) {
            float power = BowItem.getPowerForTime(stack.getUseDuration(mc.player) - mc.player.getUseItemRemainingTicks());
            return power >= .1 ? new Launch(power * 3, .05, 0, true) : null;
        }
        if (!throwables.isOn()) return null;
        if (stack.is(Items.ENDER_PEARL) || stack.is(Items.SNOWBALL) || stack.is(Items.EGG)) return new Launch(1.5, .03, 0, false);
        if (stack.is(Items.SPLASH_POTION) || stack.is(Items.LINGERING_POTION)) return new Launch(.5, .05, -20, false);
        if (stack.is(Items.EXPERIENCE_BOTTLE)) return new Launch(.7, .07, -20, false);
        return null;
    }
    @Override public void onTick(Minecraft mc) {
        clear();
        if (mc.level == null || mc.player == null || mc.gui.screen() != null || !mc.player.isAlive()) return;
        Launch model = mc.player.isUsingItem() ? launch(mc, mc.player.getUseItem()) : launch(mc, mc.player.getMainHandItem());
        if (model == null && !mc.player.isUsingItem()) model = launch(mc, mc.player.getOffhandItem());
        if (model == null) return;
        level = mc.level;
        origin = mc.player.getEyePosition().add(0, -.1, 0);
        Vec3 current = origin;
        double yaw = Math.toRadians(mc.player.getYRot()), pitch = Math.toRadians(mc.player.getXRot());
        Vec3 movement = new Vec3(-Math.sin(yaw) * Math.cos(pitch), -Math.sin(pitch + Math.toRadians(model.pitchOffset)), Math.cos(yaw) * Math.cos(pitch)).normalize().scale(model.speed);
        Vec3 inherited = mc.player.getKnownMovement();
        movement = movement.add(inherited.x, mc.player.onGround() ? 0 : inherited.y, inherited.z);
        List<Entity> nearby = new ArrayList<>();
        if (entityHits.isOn()) {
            int inspected = 0;
            for (Entity e : level.entitiesForRendering()) {
                if (++inspected > 2048) break;
                if (e != mc.player && e.isAlive() && e.isPickable() && !e.isInvisible() && !e.isSpectator() && !e.isPassengerOfSameVehicle(mc.player)
                    && e.distanceToSqr(mc.player) < 96 * 96) nearby.add(e);
            }
            nearby.sort(java.util.Comparator.comparingDouble(e -> e.distanceToSqr(mc.player)));
            if (nearby.size() > 64) nearby.subList(64, nearby.size()).clear();
            nearby.removeIf(e -> !mc.player.hasLineOfSight(e));
        }
        path.add(current);
        for (int step = 0; step < ticks.intValue(); step++) {
            BlockPos pos = BlockPos.containing(current);
            if (!level.hasChunkAt(pos) || current.y < level.getMinY() || current.distanceToSqr(origin) > 96 * 96) break;
            boolean water = level.getFluidState(pos).is(FluidTags.WATER);
            if (!model.arrow) movement = movement.add(0, -model.gravity, 0).scale(water ? .8 : .99);
            else if (water) movement = movement.scale(.6);
            Vec3 next = current.add(movement);
            // Every traversed chunk must already exist; clip never requests a missing chunk.
            boolean loaded = true;
            int fromChunkX = (int)Math.floor(Math.min(current.x, next.x)) >> 4, toChunkX = (int)Math.floor(Math.max(current.x, next.x)) >> 4;
            int fromChunkZ = (int)Math.floor(Math.min(current.z, next.z)) >> 4, toChunkZ = (int)Math.floor(Math.max(current.z, next.z)) >> 4;
            for (int x = fromChunkX; x <= toChunkX; x++) for (int z = fromChunkZ; z <= toChunkZ; z++)
                if (!level.hasChunkAt(new BlockPos(x << 4, pos.getY(), z << 4))) loaded = false;
            if (!loaded) break;
            var block = level.clipIncludingBorder(new ClipContext(current, next, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, mc.player));
            Vec3 end = block.getType() == HitResult.Type.MISS ? next : block.getLocation();
            boolean hit = block.getType() != HitResult.Type.MISS;
            double nearest = current.distanceToSqr(end);
            boolean entity = false;
            for (Entity e : nearby) {
                var contact = e.getBoundingBox().inflate(.3).clip(current, end);
                if (contact.isPresent() && current.distanceToSqr(contact.get()) < nearest) {
                    end = contact.get(); nearest = current.distanceToSqr(end); hit = true; entity = true;
                }
            }
            path.add(end);
            if (hit) { impact = end; mobImpact = entity; break; }
            current = next;
            if (model.arrow) movement = (water ? movement : movement.scale(.99)).add(0, -model.gravity, 0);
        }
    }
    @Override public void renderWorld(Minecraft mc, Camera camera, float partialTick) {
        if (level != mc.level || mc.player == null || mc.gui.screen() != null || origin == null || origin.distanceToSqr(mc.player.getEyePosition()) > 4) return;
        for (int i = 1; i < path.size(); i++) Gizmos.line(path.get(i - 1), path.get(i), Ui.withAlpha(Ui.accent(), .8f), width.floatValue());
        if (impact == null) return;
        int color = mobImpact ? Ui.WARN : Ui.accent();
        Gizmos.cuboid(new AABB(impact.x - .08, impact.y - .08, impact.z - .08, impact.x + .08, impact.y + .08, impact.z + .08), GizmoStyle.stroke(color, 2));
        if (label.isOn()) Gizmos.billboardText(String.format(Locale.ROOT, "Estimated  %.1f m", impact.distanceTo(origin)), impact.add(0, .25, 0), TextGizmo.Style.forColorAndCentered(color).withScale(.2f));
    }
}
