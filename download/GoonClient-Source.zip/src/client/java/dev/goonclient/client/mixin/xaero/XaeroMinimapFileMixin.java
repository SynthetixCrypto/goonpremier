package dev.goonclient.client.mixin.xaero;

import dev.goonclient.client.compat.NestedModFiles;
import java.nio.file.Path;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Xaero's Minimap 26.5.3 only handles PATH origins and returns null for the NESTED origin Fabric gives mods embedded
 * in the Goon jar, which crashed every packaged startup ("modFile is null" in HudMod.loadClient).
 */
@Pseudo
@Mixin(targets = "xaero.common.platform.services.FabricPlatformHelper", remap = false)
public class XaeroMinimapFileMixin {
	@Inject(method = "getModFile(Ljava/lang/String;)Ljava/nio/file/Path;", at = @At("HEAD"), cancellable = true)
	private void goonclient$nestedModFile(String modId, CallbackInfoReturnable<Path> cir) {
		NestedModFiles.locate(modId).ifPresent(cir::setReturnValue);
	}
}
