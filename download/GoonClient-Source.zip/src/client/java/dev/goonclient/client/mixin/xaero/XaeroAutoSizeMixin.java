package dev.goonclient.client.mixin.xaero;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import dev.goonclient.client.modules.hud.MinimapHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(targets = "xaero.hud.minimap.config.util.MinimapConfigClientUtils", remap = false)
public class XaeroAutoSizeMixin {
	/** Auto size chooses the unscaled map area; otherwise it cancels the user's Goon scale multiplier. */
	@ModifyExpressionValue(method = "getAutoMinimapSize", at = @At(value = "INVOKE",
		target = "Lxaero/hud/gui/util/GuiUtils;getMinimapScale(Lxaero/lib/client/config/ClientConfigManager;)F"))
	private static float goonclient$baseScale(float scale) {
		return scale / MinimapHud.mapScale();
	}
}
