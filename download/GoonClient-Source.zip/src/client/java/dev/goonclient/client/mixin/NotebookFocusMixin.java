package dev.goonclient.client.mixin;

import com.mojang.blaze3d.platform.Window;
import dev.goonclient.client.tracker.PerformanceNotebook;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Preserve focus-loss boundaries even when SDL delivers loss and regain in one poll. */
@Mixin(Window.class)
public class NotebookFocusMixin {
    @Inject(method="onFocus",at=@At("HEAD"))
    private void goonclient$notebookFocus(boolean focused,CallbackInfo ci){
        if(!focused)PerformanceNotebook.invalidateBoundary();
    }
}
