package dev.goonclient.client.modules.utility;

import dev.goonclient.client.gui.Ui;
import dev.goonclient.client.gui.render.Icons;
import dev.goonclient.client.hud.HudPosition;
import dev.goonclient.client.hud.TextHudModule;
import dev.goonclient.client.input.InputActivity;
import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.setting.BooleanSetting;
import dev.goonclient.client.module.setting.NumberSetting;
import dev.goonclient.client.tracker.IdleClock;
import dev.goonclient.client.tracker.SessionStats;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;

/** Farm-session inactivity readout. Never moves the player or bypasses a server's AFK rules. */
public final class AfkTimer extends TextHudModule {
    private final NumberSetting delay=add(new NumberSetting("delay","AFK after",60,15,600,15," seconds"));
    private final BooleanSetting showActive=add(new BooleanSetting("show_active","Show timer before AFK",true));
    private final IdleClock clock=new IdleClock();
    private ClientLevel world;
    public AfkTimer(){super("afk_timer","AFK Timer","Time since your last input; freezes in paused singleplayer. No automatic movement.",Category.UTILITY,false,HudPosition.leftColumn(120));}
    @Override protected Icons.Icon icon(){return Icons.Icon.TIMER;}
    @Override protected void onEnable(){clock.reset();world=null;}
    @Override public void loadEnabled(boolean enabled){super.loadEnabled(enabled);clock.reset();world=null;}
    @Override protected void onDisable(){clock.reset();world=null;}
    @Override public void onTick(Minecraft mc) {
        if(mc.player==null||mc.level==null){onDisable();return;}
        if(world!=mc.level){world=mc.level;clock.reset();}
        var o=mc.options;
        boolean held=mc.gui.screen()==null&&(o.keyUp.isDown()||o.keyDown.isDown()||o.keyLeft.isDown()||o.keyRight.isDown()||o.keyJump.isDown()||o.keyAttack.isDown()||o.keyUse.isDown());
        clock.update(System.nanoTime(),InputActivity.sequence(),held,mc.isPaused());
    }
    @Override protected void collect(Minecraft mc,List<Line> lines,boolean editing) {
        long idle=editing&&mc.player==null?150_000:clock.idleMillis();
        boolean afk=idle>=delay.intValue()*1000L;
        if(editing||afk||showActive.isOn())lines.add(new Line(afk?"AFK":"Idle",SessionStats.formatDuration(idle),afk?Ui.WARN:Ui.TEXT));
    }
}
