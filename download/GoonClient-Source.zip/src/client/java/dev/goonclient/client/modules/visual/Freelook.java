package dev.goonclient.client.modules.visual;

import dev.goonclient.client.GoonKeys;
import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.Module;
import dev.goonclient.client.module.setting.BooleanSetting;
import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;

/** Hold the freelook key to look around your character without turning. */
public class Freelook extends Module {
	private static Freelook instance;

	private final BooleanSetting thirdPerson = add(new BooleanSetting("third_person", "Switch to third person", true));
	private final BooleanSetting toggleMode = add(new BooleanSetting("toggle", "Toggle instead of hold", false));

	private boolean active;
	private boolean keyWasDown;
	private float yaw;
	private float pitch;
	private CameraType previousCamera;

	public Freelook() {
		super("freelook", "Freelook", "Hold Left Alt to orbit the camera around you", Category.VISUAL, true);
		instance = this;
	}

	@Override
	public void onTick(Minecraft mc) {
		if (mc.player == null) {
			return;
		}
		boolean down = GoonKeys.FREELOOK.isDown() && mc.gui.screen() == null;
		if (toggleMode.isOn()) {
			if (down && !keyWasDown) {
				if (active) {
					stop(mc);
				} else {
					start(mc);
				}
			}
		} else if (down && !active) {
			start(mc);
		} else if (!down && active) {
			stop(mc);
		}
		keyWasDown = down;
	}

	@Override
	protected void onDisable() {
		if (active) {
			stop(Minecraft.getInstance());
		}
	}

	private void start(Minecraft mc) {
		yaw = mc.player.getYRot();
		pitch = mc.player.getXRot();
		previousCamera = mc.options.getCameraType();
		if (thirdPerson.isOn() && previousCamera.isFirstPerson()) {
			mc.options.setCameraType(CameraType.THIRD_PERSON_BACK);
		}
		active = true;
	}

	private void stop(Minecraft mc) {
		active = false;
		if (previousCamera != null) {
			mc.options.setCameraType(previousCamera);
		}
	}

	public static boolean isActive() {
		return instance != null && instance.active;
	}

	public static float yaw() {
		return instance.yaw;
	}

	public static float pitch() {
		return instance.pitch;
	}

	/** Same maths as Entity#turn, applied to the freelook camera instead of the player. */
	public static void turn(double dx, double dy) {
		instance.yaw += (float) dx * 0.15f;
		instance.pitch = Mth.clamp(instance.pitch + (float) dy * 0.15f, -90f, 90f);
	}
}
