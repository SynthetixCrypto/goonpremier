package dev.goonclient.client.tracker;

import dev.goonclient.client.utility.LocalFiles;
import dev.goonclient.client.utility.WorldScope;
import java.io.IOException;
import java.nio.file.*;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;
import net.minecraft.client.Minecraft;
import net.minecraft.core.registries.BuiltInRegistries;

/** Explicit local exports: immutable snapshots, paired UTF-8 CSV/Markdown, no network upload. */
public final class FarmReports {
    public record ItemRow(String id,String name,long count,long perHour){}
    public record Snapshot(String world,long startedAt,long capturedAt,long elapsedMs,long rateBasisMs,int xp,int kills,long total,List<ItemRow> items,boolean finished){}
    public record Export(Path csv,Path summary){}
    private static boolean active;
    private static String world="World";
    private static Snapshot last;
    private FarmReports(){}
    public static void onJoin(Minecraft mc){active=true;var scope=WorldScope.current(mc);world=scope==null?"World":scope.name();}
    public static void onLeave(){if(active){last=current(true);active=false;}}
    public static Snapshot snapshot(){return active?current(false):last;}
    private static Snapshot current(boolean finished){
        long elapsed=LootTracker.elapsedMs(),basis=Math.max(60_000,elapsed);var rows=new ArrayList<ItemRow>();long total=0;
        for(var row:LootTracker.rows(false)){
            total+=row.count();rows.add(new ItemRow(BuiltInRegistries.ITEM.getKey(row.icon().getItem()).toString(),WorldScope.clean(row.icon().getHoverName().getString(),96),row.count(),rate(row.count(),basis)));
        }
        return new Snapshot(world,LootTracker.startedEpochMs(),System.currentTimeMillis(),elapsed,basis,LootTracker.xpGained(),LootTracker.kills(),total,List.copyOf(rows),finished);
    }
    public static long rate(long count,long basisMs){return Math.round(Math.max(0,count)*3_600_000d/Math.max(60_000,basisMs));}
    public static Path folder(){return Minecraft.getInstance().gameDirectory.toPath().resolve("goonclient").resolve("reports");}
    public static Export export(Snapshot s)throws IOException{
        if(s==null)throw new IOException("Join a world to start a session first.");
        String stamp=Instant.ofEpochMilli(s.capturedAt()).atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss"));
        String base="farm-"+stamp+"-"+UUID.randomUUID().toString().substring(0,8);
        Path csv=folder().resolve(base+".csv"),md=folder().resolve(base+".md");
        try{LocalFiles.write(csv,"\uFEFF"+csv(s));LocalFiles.write(md,markdown(s));return new Export(csv,md);}
        catch(IOException e){Files.deleteIfExists(csv);Files.deleteIfExists(md);throw e;}
    }
    private static String cell(String text){
        String s=text.replace('\r',' ').replace('\n',' ');
        String stripped=s.stripLeading();if(!stripped.isEmpty()&&"=+-@".indexOf(stripped.charAt(0))>=0)s="'"+s;
        return "\""+s.replace("\"","\"\"")+"\"";
    }
    public static String csv(Snapshot s){
        StringBuilder out=new StringBuilder("kind,id,name,count,per_hour,elapsed_seconds,rate_basis_seconds,world,started_utc,captured_utc\r\n");
        for(var i:s.items())csvRow(out,s,"item",i.id(),i.name(),i.count(),i.perHour());
        csvRow(out,s,"summary","xp","Observed XP gained",s.xp(),rate(s.xp(),s.rateBasisMs()));
        csvRow(out,s,"summary","kills","Locally credited kills",s.kills(),rate(s.kills(),s.rateBasisMs()));
        csvRow(out,s,"summary","total_items","Items picked up",s.total(),rate(s.total(),s.rateBasisMs()));return out.toString();
    }
    private static void csvRow(StringBuilder out,Snapshot s,String kind,String id,String name,long count,long rate){
        out.append(cell(kind)).append(',').append(cell(id)).append(',').append(cell(name)).append(',').append(count).append(',').append(rate).append(',').append(s.elapsedMs()/1000d).append(',').append(s.rateBasisMs()/1000d).append(',').append(cell(s.world())).append(',').append(cell(Instant.ofEpochMilli(s.startedAt()).toString())).append(',').append(cell(Instant.ofEpochMilli(s.capturedAt()).toString())).append("\r\n");
    }
    private static String md(String text){return text.replace("\\","\\\\").replace("*","\\*").replace("_","\\_").replace("[","\\[").replace("]","\\]").replace("`","\\`").replace('|','/').replace('\n',' ').replace('\r',' ');}
    public static String markdown(Snapshot s){
        StringBuilder out=new StringBuilder("# Goon Client farm report\n\n");
        out.append("World: ").append(md(s.world())).append("\n\nSession: ").append(SessionStats.formatDuration(s.elapsedMs())).append(s.finished()?" (ended)":" (snapshot)").append("\n\n");
        out.append("Captured: ").append(Instant.ofEpochMilli(s.capturedAt())).append("\n\n");
        out.append("Items picked up: ").append(s.total()).append("\n\nObserved XP gained: ").append(s.xp()).append(" · ").append(rate(s.xp(),s.rateBasisMs())).append(" XP/hour\n\nLocally credited kills: ").append(s.kills()).append(" · ").append(rate(s.kills(),s.rateBasisMs())).append(" /hour\n\n");
        out.append("| Item | Item ID | Picked up | Per hour |\n| --- | --- | ---: | ---: |\n");
        for(var i:s.items())out.append("| ").append(md(i.name())).append(" | ").append(md(i.id())).append(" | ").append(i.count()).append(" | ").append(i.perHour()).append(" |\n");
        out.append("\nRates use at least 60 seconds, matching the Loot Tracker. Session time includes menus/pauses. Counts are local pickups, not items left on the ground. XP is observed positive XP changes; kills use local hit/death credit, not server-wide totals.\n");return out.toString();
    }
    public static String share(Snapshot s){
        if(s==null)return "No farm session yet.";
        StringBuilder out=new StringBuilder("Goon Client farm session · "+md(s.world())+"\n"+SessionStats.formatDuration(s.elapsedMs())+" · "+s.total()+" items picked up · "+s.xp()+" XP\n"+rate(s.xp(),s.rateBasisMs())+" XP/hour · "+s.kills()+" credited kills\n");
        for(var i:s.items().stream().limit(10).toList()){
            String line="• "+md(i.name())+": "+i.count()+" ("+i.perHour()+"/hour)\n";
            if(out.length()+line.length()>1850){out.append("More items in the exported report.\n");break;}out.append(line);
        }
        out.append("Local pickups; rates use at least 60 seconds.");return out.toString();
    }
}
