package dev.goonclient.client.mixin.xaero;

import dev.goonclient.client.modules.hud.MinimapHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import xaero.hud.minimap.BuiltInHudModules;
import xaero.hud.module.HudModule;
import xaero.hud.render.HudRenderer;

@Mixin(value = HudRenderer.class, remap = false)
public class XaeroHudMixin {
	/** Goon draws this module once in its own layout, including in the HUD editor. */
	@Inject(method = "renderModule", at = @At("HEAD"), cancellable = true)
	private void goonclient$ownMinimap(HudModule<?> module, xaero.hud.Hud hud,
		xaero.hud.render.module.ModuleRenderContext context, net.minecraft.client.gui.GuiGraphicsExtractor g,
		float partialTick, CallbackInfo ci) {
		if (MinimapHud.integrated() && module == BuiltInHudModules.MINIMAP) ci.cancel();
	}
}
