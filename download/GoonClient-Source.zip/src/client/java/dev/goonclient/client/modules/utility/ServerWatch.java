package dev.goonclient.client.modules.utility;

import dev.goonclient.client.GoonChat;
import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.Module;
import dev.goonclient.client.module.setting.BooleanSetting;
import dev.goonclient.client.module.setting.NumberSetting;
import dev.goonclient.client.modules.hud.FeedbackHud;
import java.util.Locale;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;

/** Observes world-clock packets only. A delayed packet is not a measurement of server TPS or an outage verdict. */
public final class ServerWatch extends Module {
    private static ServerWatch instance;
    private final NumberSetting threshold = add(new NumberSetting("threshold", "Warn after no clock updates", 5, 3, 30, 1, "s"));
    private final BooleanSetting recovery = add(new BooleanSetting("recovery", "Notify when clock updates resume", true));
    private final BooleanSetting chat = add(new BooleanSetting("chat", "Local chat warnings", true));
    private final BooleanSetting notifications = add(new BooleanSetting("notifications", "Use existing Notifications HUD", false));
    private ClientLevel level;
    private long joined, lastClock;
    private int samples;
    private double usualInterval;
    private boolean warned;

    public ServerWatch() {
        super("server_watch", "Server Watch", "Warns about delayed multiplayer world-clock updates; no automatic reconnect", Category.UTILITY, false);
        instance = this;
    }

    public static void clockUpdate() {
        var self = instance;
        var mc = Minecraft.getInstance();
        if (self == null || !self.isEnabled() || mc.level == null || mc.player == null || mc.hasSingleplayerServer()) return;
        long now = System.nanoTime();
        self.bind(mc.level, now);
        if (self.warned) {
            self.warned = false;
            if (self.recovery.isOn()) self.notice("World-clock updates resumed.", true);
            // A stalled interval must not become the new normal interval.
        } else if (self.lastClock != 0) {
            double interval = (now - self.lastClock) / 1_000_000_000d;
            if (interval > 0 && interval < 30) self.usualInterval = self.usualInterval == 0 ? interval : self.usualInterval * .8 + interval * .2;
        }
        self.lastClock = now;
        self.samples = Math.min(100, self.samples + 1);
    }

    @Override public void onTick(Minecraft mc) {
        if (mc.level == null || mc.player == null || mc.hasSingleplayerServer()) { clear(); return; }
        long now = System.nanoTime();
        bind(mc.level, now);
        if (mc.level.tickRateManager().isFrozen()) {
            lastClock = 0; samples = 0; warned = false; usualInterval = 0; joined = now;
            return;
        }
        if (samples < 2 || now - joined < 10_000_000_000L || warned) return;
        double elapsed = (now - lastClock) / 1_000_000_000d;
        double limit = Math.max(threshold.get(), usualInterval * 3);
        if (elapsed >= limit) {
            warned = true;
            notice(String.format(Locale.ROOT, "No world-clock updates for %.1fs. The server or connection may be slow.", elapsed), false);
        }
    }

    private void bind(ClientLevel current, long now) {
        if (level == current) return;
        clear(); level = current; joined = now;
    }

    private void notice(String text, boolean positive) {
        if (chat.isOn()) GoonChat.info("Server Watch: " + text);
        if (notifications.isOn()) FeedbackHud.post("server-watch", "Server Watch", text, positive);
    }

    private void clear() { level = null; joined = 0; lastClock = 0; samples = 0; usualInterval = 0; warned = false; }
    public static void reset() { if (instance != null) instance.clear(); }
    @Override protected void onEnable() { clear(); }
    @Override protected void onDisable() { clear(); }
}
