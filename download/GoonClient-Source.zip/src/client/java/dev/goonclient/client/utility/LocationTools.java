package dev.goonclient.client.utility;

import dev.goonclient.client.GoonChat;
import dev.goonclient.client.modules.world.WorldHuds;
import dev.goonclient.client.waypoint.WaypointManager;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Player;

/** Explicit local coordinate/waypoint commands; never sends a chat message to a server. */
public final class LocationTools {
    private LocationTools() { }

    public static int coordinates(Player player, boolean copy) {
        var pos = player.blockPosition();
        String dimension = player.level().dimension().identifier().toString();
        String text = WorldHuds.dimensionName(dimension) + " [" + dimension + "]: "
                + pos.getX() + " " + pos.getY() + " " + pos.getZ();
        output(text, copy);
        return 1;
    }

    public static int portal(Player player, boolean copy) {
        var pos = player.blockPosition();
        String dimension = player.level().dimension().identifier().toString();
        String destination;
        int x, z;
        if (dimension.equals("minecraft:overworld")) {
            destination = "Nether";
            // Integer floor matches block coordinates for negative positions too.
            x = Math.floorDiv(pos.getX(), 8); z = Math.floorDiv(pos.getZ(), 8);
        } else if (dimension.equals("minecraft:the_nether")) {
            destination = "Overworld";
            x = pos.getX() * 8; z = pos.getZ() * 8;
        } else {
            GoonChat.error("Portal conversion is only defined for the Overworld and Nether.");
            return 0;
        }
        output(destination + " portal estimate: X " + x + ", Z " + z + " (vanilla 8:1; height and portal placement may differ)", copy);
        return 1;
    }

    public static int waypoint(String name) {
        var waypoint = WaypointManager.byName(name);
        if (waypoint.isEmpty()) {
            GoonChat.error("No waypoint called '" + name + "'");
            return 0;
        }
        var w = waypoint.get();
        String plainName = w.name().replaceAll("[\\p{Cntrl}\\s]+", " ").strip();
        output(plainName + " — " + WorldHuds.dimensionName(w.dimension()) + " [" + w.dimension() + "]: "
                + w.x() + " " + w.y() + " " + w.z(), true);
        return 1;
    }

    private static void output(String text, boolean copy) {
        if (copy) Minecraft.getInstance().keyboardHandler.setClipboard(text);
        GoonChat.info((copy ? "Copied: " : "") + text);
    }
}
