package dev.goonclient.client.dev;

import dev.goonclient.Goon;
import dev.goonclient.client.module.ModuleManager;
import dev.goonclient.client.module.Module;
import dev.goonclient.client.tracker.AdventureLog;
import dev.goonclient.client.tracker.IdleClock;
import dev.goonclient.client.tracker.LootTracker;
import dev.goonclient.client.input.InputActivity;
import dev.goonclient.client.modules.inventory.LootTrackerHud;
import dev.goonclient.client.gui.HudEditorScreen;
import dev.goonclient.client.config.ProfileStore;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.NaturalSpawner;
import net.minecraft.world.level.LightLayer;
import java.util.HashSet;
import java.util.Map;
import java.util.List;
import java.lang.reflect.Field;

/** Opt-in checks run only by the backed-up dev tour. Never enabled for normal players. */
public final class DevFeatureChecks {
    private static int maxCells,completedAt=-1,finishAt=-1,bossBefore;
    private static long discoveriesBefore;
    private DevFeatureChecks() {}
    private static Module module(String id){return ModuleManager.all().stream().filter(m->m.id().equals(id)).findFirst().orElseThrow();}
    private static Object field(Object obj,String name){try{Field f=obj.getClass().getDeclaredField(name);f.setAccessible(true);return f.get(obj);}catch(Exception e){throw new IllegalStateException(e);}}
    private static void setting(Module m,String id,com.google.gson.JsonElement value){m.settings().stream().filter(s->s.id().equals(id)).findFirst().orElseThrow().fromJson(value);}
    private static void require(boolean b,String message){if(!b)throw new IllegalStateException(message);}
    private static void run(Minecraft mc,String command){var server=mc.getSingleplayerServer();require(server!=null,"Integrated dev world required");server.execute(()->server.getCommands().performPrefixedCommand(server.createCommandSourceStack().withSuppressedOutput(),"execute as @p at @p run "+command));}
    private static int bossCount(){return (int)AdventureLog.entries().stream().filter(e->e.type()==AdventureLog.Type.BOSS).count();}
    private static void shot(Minecraft mc,String name){Screenshot.grab(mc.gameDirectory,"goon-0178-"+name+".png",mc.gameRenderer.mainRenderTarget(),1,message->{});}
    public static void tick(Minecraft mc,int step,Runnable done) {
        var spawn=module("spawn_overlay");var nearby=module("nearby_entities");var afk=module("afk_timer");var loot=module("loot_tracker");var log=module("adventure_log");
        if(step==0) {
            require(net.fabricmc.loader.api.FabricLoader.getInstance().isDevelopmentEnvironment(),"Development environment required");
            mc.gui.setScreen(null);mc.options.guiScale().set(2);mc.resizeGui();
            run(mc,"gamemode creative");run(mc,"time set 18000");run(mc,"weather clear");
            run(mc,"kill @e[tag=goon178_test]");run(mc,"summon minecraft:warden ~3 ~ ~ {Tags:[\"goon178_test\"],NoAI:1b,Silent:1b}");
            for(var hud:ModuleManager.hudModules())hud.loadEnabled(java.util.Set.of("fps","memory","coordinates","nearby_entities","loot_tracker","afk_timer","minimap").contains(hud.id()));
            log.loadEnabled(true);setting(log,"shot_bosses",new com.google.gson.JsonPrimitive(false));
            discoveriesBefore=((Number)field(log,"discoveryScans")).longValue();bossBefore=bossCount();
            LootTracker.reset();LootTracker.onPickup(new ItemStack(Items.BONE),64);LootTracker.onPickup(new ItemStack(Items.ROTTEN_FLESH),32);
            mc.player.setItemSlot(EquipmentSlot.MAINHAND,new ItemStack(Items.BONE));setting(loot,"held_item_only",new com.google.gson.JsonPrimitive(true));
        }
        if(step==10){setting(spawn,"radius",new com.google.gson.JsonPrimitive(32));spawn.setEnabled(true);}
        if(step>10) {int n=((Number)field(spawn,"lastTickCells")).intValue();require(n<=4096,"Spawn scan exceeded cell budget");maxCells=Math.max(maxCells,n);}
        if(step==20) {
            long before=((Number)field(nearby,"scans")).longValue();for(int i=0;i<1000;i++)nearby.onTick(mc);
            require(((Number)field(nearby,"scans")).longValue()-before<=1,"Entity recount ran repeatedly within one frame");
            setting(nearby,"radius",new com.google.gson.JsonPrimitive(16));nearby.onTick(mc);
            require(((Number)field(nearby,"scans")).longValue()>before,"Entity setting did not invalidate cache");
            var first=LootTracker.rows(false);for(int i=0;i<100;i++)require(LootTracker.rows(false)==first,"Loot cache re-sorted within one frame");
            LootTracker.onPickup(new ItemStack(Items.BONE),10);require(LootTracker.rows(false).getFirst().count()==74,"Pickup did not invalidate loot cache");
            LootTracker.onPickup(new ItemStack(Items.BONE),-3);require(LootTracker.rows(false).getFirst().count()==74,"Invalid pickup reduced counts");
            var clock=(IdleClock)field(afk,"clock");clock.reset();long now=System.nanoTime();clock.update(now-125_000_000_000L,InputActivity.sequence(),false,false);clock.update(now,InputActivity.sequence(),false,false);
            Goon.LOGGER.info("0.17.8 CHECK: 1000 entity reads reused cache; settings refreshed; loot cache/pickup validation passed");
        }
        if(step==30) {
            var prepared=(List<?>)field(loot,"prepared");require(prepared.size()==1,"Held item focus did not filter rows");
            require(((LootTracker.Row)prepared.getFirst()).icon().getItem()==Items.BONE,"Wrong held-item row");shot(mc,"farm-focus");
        }
        if(step==35)mc.player.setItemSlot(EquipmentSlot.MAINHAND,ItemStack.EMPTY);
        if(step==40){require(((List<?>)field(loot,"prepared")).isEmpty(),"Empty-hand focus showed unrelated loot");shot(mc,"empty-hand-focus");}
        if(step==45)mc.player.setItemSlot(EquipmentSlot.MAINHAND,new ItemStack(Items.BONE));
        if(step==50){require(!((Map<?,?>)field(log,"bosses")).isEmpty(),"Boss discovery missed test boss");run(mc,"kill @e[tag=goon178_test]");}
        if(step==70) {
            require(bossCount()==bossBefore+1,"Boss death was missed or logged repeatedly");
            long sequence=InputActivity.sequence();mc.keyboardHandler.charTyped(mc.getWindow().handle()+1,new CharacterEvent('x'));require(InputActivity.sequence()==sequence,"Wrong-window input counted");
            mc.keyboardHandler.charTyped(mc.getWindow().handle(),new CharacterEvent('x'));
            require(InputActivity.sequence()==sequence+(mc.isWindowActive()?1:0),"Typing activity hook/focus guard failed");
            afk.onTick(mc);if(mc.isWindowActive())require(((IdleClock)field(afk,"clock")).idleMillis()<1000,"Typing did not reset AFK");
            Goon.LOGGER.info("0.17.8 CHECK: held/empty focus, raw typing activity/window guard, and exactly one tracked boss death passed");
        }
        if(step>=90&&completedAt<0&&((Number)field(spawn,"completedScans")).intValue()>0) {
            compareSpawn(mc,spawn);completedAt=step;shot(mc,"bounded-spawn-overlay");
            long discoveries=((Number)field(log,"discoveryScans")).longValue()-discoveriesBefore;
            require(discoveries<=step/10+3,"Boss discovery was not throttled");
            Goon.LOGGER.info("0.17.8 CHECK: spawn radius 32 completed with at most {} cells per tick; {} boss discoveries across {} ticks",maxCells,discoveries,step);
        }
        if(completedAt>0&&step==completedAt+5) {
            setting(spawn,"radius",new com.google.gson.JsonPrimitive(4));spawn.onTick(mc);require(((Number)field(spawn,"scanRadius")).intValue()==4,"Radius change did not restart scan");
            var origin=(BlockPos)field(spawn,"scanCentre");
            for(Object spot:(List<?>)field(spawn,"spots")) {
                try {var type=spot.getClass();var x=type.getDeclaredMethod("x");var z=type.getDeclaredMethod("z");x.setAccessible(true);z.setAccessible(true);
                    require(Math.abs(((Number)x.invoke(spot)).intValue()-origin.getX())<=4&&Math.abs(((Number)z.invoke(spot)).intValue()-origin.getZ())<=4,"Radius change retained out-of-range marker");
                }catch(Exception ex){throw new IllegalStateException(ex);}
            }spawn.loadEnabled(false);require(((List<?>)field(spawn,"spots")).isEmpty()&&field(spawn,"cursor")==null,"Preset disable retained spawn scan");
            ProfileStore.load(ProfileStore.presets().stream().filter(p->p.id().equals("all_hud")).findFirst().orElseThrow());
            mc.gui.setScreen(new HudEditorScreen(null));mc.options.guiScale().set(3);mc.resizeGui();finishAt=step+15;
        }
        if(finishAt>0&&step==finishAt){DevMenuPreview.verifyLayout(mc);shot(mc,"all-hud-37");}
        if(finishAt>0&&step==finishAt+5){run(mc,"kill @e[tag=goon178_test]");Goon.LOGGER.info("0.17.8 FEATURE CHECKS PASSED: AFK, loot focus/cache, nearby cache, incremental spawn, boss tracking and 37-HUD layout");done.run();}
        if(step>450&&completedAt<0)throw new IllegalStateException("Budgeted scan failed to complete in dev tour");
    }
    private static void compareSpawn(Minecraft mc,Module module) {
        var centre=(BlockPos)field(module,"scanCentre");var expected=new HashSet<String>();int r=32,v=16;
        var pos=new BlockPos.MutableBlockPos();int light=mc.level.dimensionType().monsterSpawnBlockLightLimit();
        for(int x=-r;x<=r;x++)for(int z=-r;z<=r;z++)for(int y=-v;y<=v;y++) {
            pos.set(centre.getX()+x,centre.getY()+y,centre.getZ()+z);
            if(pos.getY()<=mc.level.getMinY()||pos.getY()>=mc.level.getMaxY()||!mc.level.hasChunkAt(pos))continue;
            var state=mc.level.getBlockState(pos);
            if(!NaturalSpawner.isValidEmptySpawnBlock(mc.level,pos,state,state.getFluidState(),EntityTypes.ZOMBIE))continue;
            var below=pos.below();if(!mc.level.getBlockState(below).isValidSpawn(mc.level,below,EntityTypes.ZOMBIE))continue;
            var above=pos.above();var top=mc.level.getBlockState(above);
            if(!NaturalSpawner.isValidEmptySpawnBlock(mc.level,above,top,top.getFluidState(),EntityTypes.ZOMBIE)||mc.level.getBrightness(LightLayer.BLOCK,pos)>light)continue;
            expected.add(pos.getX()+","+pos.getY()+","+pos.getZ());
        }
        var actual=new HashSet<String>();
        for(Object spot:(List<?>)field(module,"spots")) {
            try {var type=spot.getClass();var x=type.getDeclaredMethod("x");var y=type.getDeclaredMethod("y");var z=type.getDeclaredMethod("z");x.setAccessible(true);y.setAccessible(true);z.setAccessible(true);
                actual.add(x.invoke(spot)+","+(int)Math.floor(((Number)y.invoke(spot)).doubleValue())+","+z.invoke(spot));
            }catch(Exception ex){throw new IllegalStateException(ex);}
        }
        require(!actual.isEmpty(),"Spawn test had no markers");require(actual.equals(expected),"Incremental spawn markers differ: "+actual.size()+" vs "+expected.size());
        Goon.LOGGER.info("0.17.8 CHECK: {} radius-32 markers match the full reference scan",actual.size());
    }
}
