package dev.goonclient.client.gui;

import com.mojang.blaze3d.Blaze3D;
import com.mojang.blaze3d.platform.InputConstants;
import dev.goonclient.client.gui.render.GoonFont;
import dev.goonclient.client.gui.render.Shapes;
import dev.goonclient.client.tracker.PerformanceNotebook;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

/** Farm Report's glass controls, with explicit capture/export actions and no world-dependent rendering. */
public final class PerformanceNotebookScreen extends Screen implements GoonScreen {
    private enum Action { DONE, START, CANCEL, EXPORT, OPEN_FOLDER }
    private record Hit(Action action, float x1, float y1, float x2, float y2, Runnable run) {}
    private final Screen parent;
    private final List<Hit> hits = new ArrayList<>();
    private PerformanceNotebook.Snapshot report;
    private final String[] values = new String[8];
    private static final String[] LABELS = {"Active measured duration", "Samples", "Mean FPS", "P95 frame time", "P99 frame time", "Max frame time", "Frames >33 ms / >50 ms", "Heap / process resident RAM at review"};
    private Action focus;
    private float s, x, y, w, h;
    private long refreshedAt;
    private String heading = "Ready for a local 60-second capture.";
    private volatile String status = "Start replaces the previous capture and returns you to gameplay.";
    private volatile boolean working, error;
    public PerformanceNotebookScreen(Screen parent) { super(Component.literal("Performance Notebook")); this.parent = parent; }
    @Override protected void init() {
        GlassUi.hideHud(minecraft);
        s = Math.max(.01f, Math.min(Ui.menuScale(width, height), Math.min(width / 650f, height / 450f)));
        float vw = width / s, vh = height / s; w = Math.min(630, vw - 28); h = Math.min(420, vh - 28);
        x = (vw - w) / 2; y = (vh - h) / 2; refresh();
    }
    @Override public void tick() { super.tick(); if (System.nanoTime() - refreshedAt > 250_000_000L) refresh(); }
    private void refresh() {
        refreshedAt = System.nanoTime();
        if (PerformanceNotebook.running()) {
            report = null;
            heading = "Capturing: " + PerformanceNotebook.number(PerformanceNotebook.elapsedSeconds()) + " / 60 s wall time. Close this menu to measure gameplay.";
            values[0] = PerformanceNotebook.number(PerformanceNotebook.activeSeconds()) + " s";
            values[1] = Integer.toString(PerformanceNotebook.samples());
            for (int i = 2; i < values.length; i++) values[i] = "Available when capture ends";
            return;
        }
        report = PerformanceNotebook.snapshot();
        if (report == null) {
            heading = minecraft.level == null ? "Join a world to start. Finished results remain available after disconnect." : "Ready for a local 60-second capture.";
            java.util.Arrays.fill(values, "—"); return;
        }
        var r = report.result();
        heading = PerformanceNotebook.stopLabel(r) + " · " + PerformanceNotebook.number(r.elapsedSeconds()) + " s elapsed";
        values[0] = PerformanceNotebook.number(r.activeSeconds()) + " s"; values[1] = Integer.toString(r.samples());
        values[2] = r.samples() == 0 ? "Unavailable: no eligible intervals" : PerformanceNotebook.number(r.meanFps());
        values[3] = r.samples() == 0 ? "—" : PerformanceNotebook.number(r.p95Ms()) + " ms";
        values[4] = r.samples() == 0 ? "—" : PerformanceNotebook.number(r.p99Ms()) + " ms";
        values[5] = r.samples() == 0 ? "—" : PerformanceNotebook.number(r.maxMs()) + " ms";
        values[6] = r.over33() + " / " + r.over50();
        values[7] = PerformanceNotebook.memory(report.reviewMemory().heapUsed()) + " / " + PerformanceNotebook.memory(report.reviewMemory().processBytes());
    }
    private static void text(GuiGraphicsExtractor g, String value, float x, float y, float size, boolean bold, int color) {
        GoonFont.draw(g, value, x, y, size, bold ? GoonFont.Weight.BOLD : GoonFont.Weight.REGULAR, color == Ui.MUTED ? GlassUi.LABEL : color, false);
    }
    private static String shorten(String value, float width, float size) { return Ui.ellipsize(value, width, size, GoonFont.Weight.REGULAR); }
    @Override public void extractRenderState(GuiGraphicsExtractor g, int realX, int realY, float dt) {
        hits.clear(); int mx = (int)(realX / s), my = (int)(realY / s);
        g.pose().pushMatrix(); g.pose().scale(s, s); GlassUi.panel(g, x, y, w, h, 1);
        text(g, "Performance Notebook", x + 18, y + 17, 15, true, Ui.TEXT);
        button(g, Action.DONE, "Done", x + w - 70, y + 15, 52, mx, my, this::onClose);
        text(g, shorten(heading, w - 36, 8.2f), x + 18, y + 51, 8.2f, false, report != null && report.result().early() ? Ui.WARN : Ui.MUTED);
        text(g, "Menus, loading, focus loss and pauses are excluded. Excluded intervals never join up.", x + 18, y + 72, 7.6f, false, Ui.MUTED);
        if (report != null && report.result().provisional())
            text(g, PerformanceNotebook.INSUFFICIENT, x + 18, y + 84, 7.4f, true, Ui.WARN);
        Shapes.rect(g, x + 18, y + 94, x + w - 18, y + 94.5f, Ui.BORDER);
        for (int i = 0; i < LABELS.length; i++) {
            float yy = y + 106 + i * 22;
            text(g, LABELS[i], x + 18, yy, 8.2f, false, Ui.MUTED);
            text(g, shorten(values[i] == null ? "—" : values[i], w - 310, 8.2f), x + 295, yy, 8.2f, true, Ui.TEXT);
        }
        text(g, "P95/P99 are frame-time percentiles, not 1% low FPS. No GPU instrumentation.", x + 18, y + h - 113, 7.4f, false, Ui.MUTED);
        text(g, "Start settings and cached start/review memory are included in the summary.", x + 18, y + h - 99, 7.4f, false, Ui.MUTED);
        text(g, "Exports stay local and contain no account, server, path, coordinate or log data.", x + 18, y + h - 85, 7.4f, false, Ui.MUTED);
        float bw = (w - 51) / 4, by = y + h - 65;
        button(g, Action.START, "Start 60 s", x + 18, by, bw, mx, my, this::start);
        button(g, Action.CANCEL, "Cancel capture", x + 23 + bw, by, bw, mx, my, () -> { PerformanceNotebook.cancel(); status = "Stopped early. Partial results can be exported."; refresh(); });
        button(g, Action.EXPORT, working ? "Working…" : "Export CSV + summary", x + 28 + 2 * bw, by, bw, mx, my, this::export);
        button(g, Action.OPEN_FOLDER, "Open folder", x + 33 + 3 * bw, by, bw, mx, my, this::openFolder);
        text(g, shorten(status, w - 36, 7.6f), x + 18, y + h - 29, 7.6f, false, error ? Ui.WARN : Ui.MUTED);
        for (var f : hits) if (f.action() == focus && enabled(f.action())) Shapes.outline(g, f.x1() - 1, f.y1() - 1, f.x2() + 1, f.y2() + 1, 5, Ui.accent());
        g.pose().popMatrix(); super.extractRenderState(g, realX, realY, dt);
    }
    private void start() {
        if (PerformanceNotebook.start(minecraft)) minecraft.gui.setScreen(null);
        else { status = "Join a world before starting a capture."; error = true; }
    }
    private void export() {
        if (working || PerformanceNotebook.running()) return;
        var snapshot = PerformanceNotebook.snapshot(); if (snapshot == null) return;
        var folder = PerformanceNotebook.folder(); working = true; error = false; status = "Saving CSV and summary…";
        var worker = new Thread(() -> {
            try { PerformanceNotebook.export(snapshot, folder); status = "Saved CSV and summary in the reports folder. Nothing uploaded."; }
            catch (Exception e) { error = true; status = "Couldn't save the report. Check the game folder is writable."; }
            finally { working = false; }
        }, "Goon notebook export"); worker.setDaemon(true); worker.start();
    }
    private void openFolder() {
        if (working) return; var folder = PerformanceNotebook.folder(); working = true; error = false;
        var worker = new Thread(() -> {
            try { Files.createDirectories(folder); Blaze3D.openPath(folder); status = "Reports folder opened."; }
            catch (Exception e) { error = true; status = "Couldn't open the reports folder."; }
            finally { working = false; }
        }, "Goon notebook folder"); worker.setDaemon(true); worker.start();
    }
    private boolean enabled(Action action) {
        return switch (action) {
            case DONE -> true;
            case START -> !working && PerformanceNotebook.canStart(minecraft);
            case CANCEL -> PerformanceNotebook.running();
            case EXPORT -> !working && !PerformanceNotebook.running() && report != null;
            case OPEN_FOLDER -> !working;
        };
    }
    private void button(GuiGraphicsExtractor g, Action action, String label, float bx, float by, float bw, int mx, int my, Runnable run) {
        boolean enabled = enabled(action);
        boolean hover = enabled && Ui.inside(mx, my, bx, by, bx + bw, by + 24);
        Shapes.panel(g, bx, by, bx + bw, by + 24, 5, hover ? Ui.RAISED_HOVER : Ui.RAISED, Ui.BORDER);
        String shown = shorten(label, bw - 10, 7.3f);
        text(g, shown, bx + (bw - GoonFont.width(shown, 7.3f, GoonFont.Weight.BOLD)) / 2, by + 8, 7.3f, true, enabled ? Ui.TEXT : Ui.FAINT);
        if (enabled) hits.add(new Hit(action, bx, by, bx + bw, by + 24, run));
    }
    @Override public boolean mouseClicked(MouseButtonEvent e, boolean twice) {
        if (e.button() != InputConstants.MOUSE_BUTTON_LEFT) return true;
        for (var hit : hits) if (enabled(hit.action()) && Ui.inside(e.x() / s, e.y() / s, hit.x1(), hit.y1(), hit.x2(), hit.y2())) { focus = hit.action(); hit.run().run(); return true; }
        return true;
    }
    @Override public boolean keyPressed(KeyEvent e) {
        if (e.key() == InputConstants.KEY_ESCAPE) { onClose(); return true; }
        if (e.key() == InputConstants.KEY_TAB && !hits.isEmpty()) {
            int index = -1; for (int i = 0; i < hits.size(); i++) if (hits.get(i).action() == focus) index = i;
            int selected = index < 0 ? (e.hasShiftDown() ? hits.size() - 1 : 0) : Math.floorMod(index + (e.hasShiftDown() ? -1 : 1), hits.size());
            focus = hits.get(selected).action(); return true;
        }
        if (e.key() == InputConstants.KEY_RETURN || e.key() == InputConstants.KEY_SPACE) {
            for (var hit : hits) if (hit.action() == focus && enabled(hit.action())) { hit.run().run(); return true; }
        }
        return super.keyPressed(e);
    }
    @Override public void removed() { GlassUi.restoreHud(minecraft); }
    @Override public void onClose() { minecraft.gui.setScreen(parent); }
    @Override public boolean isPauseScreen() { return false; }
}
