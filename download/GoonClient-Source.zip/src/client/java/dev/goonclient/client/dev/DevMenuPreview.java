package dev.goonclient.client.dev;

import dev.goonclient.Goon;
import dev.goonclient.client.gui.ClickGuiScreen;
import dev.goonclient.client.gui.StudioScreen;
import dev.goonclient.client.module.ModuleManager;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;

/**
 * {@code ./gradlew runClient -PmenuPreview}: joins "New World", opens the ClickGUI and every Settings page and saves
 * a screenshot of each (run/screenshots/goon-menu-*.png), then quits. Visual only; no assertions.
 */
public final class DevMenuPreview {
	private static int ticks;
	private static com.google.gson.JsonObject savedSettings;
	private static final java.util.Map<dev.goonclient.client.module.Module, Boolean> restore = new java.util.HashMap<>();

	private DevMenuPreview() {
	}

	public static void init() {
		if (!Boolean.getBoolean("goonclient.menuPreview")) {
			return;
		}
		Goon.LOGGER.info("Menu preview mode enabled");
		ClientTickEvents.END_CLIENT_TICK.register(DevMenuPreview::tick);
	}

	private static void tick(Minecraft mc) {
		if (mc.player == null || mc.level == null) {
			return;
		}
		ticks++;
        if (ticks >= 260 && Boolean.getBoolean("goonclient.brandPreview")) {
            int cycle = (ticks - 260) / 32;
            int step = (ticks - 260) % 32;
            var themes = dev.goonclient.client.gui.Themes.ALL;
            if (cycle >= themes.size()) {
                if (savedSettings != null) {
                    dev.goonclient.client.config.ConfigManager.apply(savedSettings, true, false);
                    dev.goonclient.client.config.ConfigManager.save();
                }
                Goon.LOGGER.info("Brand preview: all {} themes captured", themes.size());
                mc.stop();
                return;
            }
            String theme = themes.get(cycle).name();
            if (step == 0) {
                ModuleManager.all().stream().filter(m -> m.id().equals("interface")).findFirst().ifPresent(m -> {
                    m.loadEnabled(true);
                    m.settings().stream().filter(s -> s.id().equals("theme")).findFirst().ifPresent(s -> ((dev.goonclient.client.module.setting.ModeSetting)s).set(theme));
                });
                mc.gui.setScreen(new ClickGuiScreen(null));
            } else if (step == 6) shot(mc, "brand-" + theme.toLowerCase(java.util.Locale.ROOT) + "-menu");
            else if (step == 8) mc.gui.setScreen(new StudioScreen(null, StudioScreen.Page.HUD));
            else if (step == 14) shot(mc, "brand-" + theme.toLowerCase(java.util.Locale.ROOT) + "-settings");
            else if (step == 16) mc.gui.setScreen(new StudioScreen(null, StudioScreen.Page.THEMES));
            else if (step == 22) shot(mc, "brand-" + theme.toLowerCase(java.util.Locale.ROOT) + "-themes");
            else if (step == 24) mc.gui.setScreen(null);
            else if (step == 28) shot(mc, "brand-" + theme.toLowerCase(java.util.Locale.ROOT) + "-hud");
            return;
        }
		if (ticks == 1) savedSettings = dev.goonclient.client.config.ConfigManager.capture();
		switch (ticks) {
			case 30 -> ModuleManager.all().stream().filter(m -> m.id().equals("interface")).findFirst().ifPresent(m -> {
				m.loadEnabled(true);
				m.settings().stream().filter(setting -> setting.id().equals("theme")).findFirst()
					.ifPresent(setting -> ((dev.goonclient.client.module.setting.ModeSetting) setting).set(System.getProperty("goonclient.devAccent", "Noir")));
			});
			case 40 -> {
				mc.player.setYRot(200f);
				mc.player.setXRot(-12f);
				mc.gui.setScreen(new ClickGuiScreen(null));
			}
			case 70 -> shot(mc, "modules");
			case 72 -> mc.gui.setScreen(new StudioScreen(null, StudioScreen.Page.THEMES));
			case 95 -> shot(mc, "themes");
			case 97 -> mc.gui.setScreen(new StudioScreen(null, StudioScreen.Page.HUD));
			case 120 -> shot(mc, "hud");
			case 122 -> mc.gui.setScreen(new StudioScreen(null, StudioScreen.Page.INTERFACE));
			case 145 -> shot(mc, "interface");
			case 147 -> mc.gui.setScreen(new StudioScreen(null, StudioScreen.Page.MAIN));
			case 160 -> shot(mc, "main");
			case 162 -> mc.gui.setScreen(new StudioScreen(null, StudioScreen.Page.CONFIGS));
			case 170 -> shot(mc, "configs");
			case 172 -> {
				ClickGuiScreen menu = new ClickGuiScreen(null);
				menu.openSettingsFor(ModuleManager.all().stream().filter(m -> m.id().equals("crosshair")).findFirst().orElse(ModuleManager.all().getFirst()));
				mc.gui.setScreen(menu);
			}
			case 200 -> shot(mc, "module-settings");
			case 202 -> {
				mc.gui.setScreen(null);
				// Reset layout through the public preset, including old saved HUD positions.
				dev.goonclient.client.config.ProfileStore.load(dev.goonclient.client.config.ProfileStore.presets().stream().filter(p -> p.id().equals("combatant")).findFirst().orElseThrow());
				// Pills, titled panels, a target and a notification
				for (var module : ModuleManager.hudModules()) {
					boolean on = java.util.Set.of("fps", "memory", "speed", "coordinates", "clock", "potions", "active_modules", "cooldowns", "inventory_hud", "target", "notifications", "armor", "minimap").contains(module.id());
					restore.putIfAbsent(module, module.isEnabled());
					module.loadEnabled(on);
				}
				run(mc, "effect give @s speed 90 1 true");
				run(mc, "effect give @s regeneration 40 0 true");
				run(mc, "summon husk ^ ^ ^3 {NoAI:1b,PersistenceRequired:1b}");
				run(mc, "time set 12500");
				run(mc, "gamemode creative");
				// A bound, enabled module for the Keybinds panel and a running cooldown for the Cooldowns panel
				ModuleManager.all().stream().filter(m -> m.id().equals("zoom")).findFirst().ifPresent(m -> {
					m.loadEnabled(true);
					for (int key : new int[]{com.mojang.blaze3d.platform.InputConstants.KEY_F8, com.mojang.blaze3d.platform.InputConstants.KEY_F9, com.mojang.blaze3d.platform.InputConstants.KEY_Y, com.mojang.blaze3d.platform.InputConstants.KEY_O,
						com.mojang.blaze3d.platform.InputConstants.KEY_K, com.mojang.blaze3d.platform.InputConstants.KEY_I, com.mojang.blaze3d.platform.InputConstants.KEY_P}) {
						var result = dev.goonclient.client.input.ModuleBindings.assign(mc, m, key);
						Goon.LOGGER.info("Menu preview bind: {}", result.message());
						if (result.ok()) break;
					}
				});
				mc.player.getCooldowns().addCooldown(new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.ENDER_PEARL), 600);
			}
			case 208 -> { mc.player.setXRot(8f); mc.gui.hud.getChat().clearMessages(false); }
			case 215 -> ModuleManager.all().stream().filter(m -> m.id().equals("fullbright")).findFirst().ifPresent(m -> {
				dev.goonclient.client.input.ModuleBindings.toggle(m);
				dev.goonclient.client.input.ModuleBindings.toggle(m);
			});
			case 225 -> shot(mc, "ingame");
			case 226 -> mc.gui.setScreen(new net.minecraft.client.gui.screens.ChatScreen("", false));
			case 232 -> shot(mc, "chat");
			case 233 -> {
				var editor = new dev.goonclient.client.gui.HudEditorScreen(null);
				editor.inspect(ModuleManager.hudModules().stream().filter(m -> m.id().equals("potions")).findFirst().orElseThrow());
				mc.gui.setScreen(editor);
			}
			case 245 -> shot(mc, "editor");
			case 246 -> {
				// Drag the FPS pill over the crosshair and hotbar area with Alt held (no snapping): places that used to
				// push a dragged panel away. It must land exactly where it was dropped.
				var editor = (dev.goonclient.client.gui.HudEditorScreen) mc.gui.screen();
				dragged = ModuleManager.hudModules().stream().filter(m -> m.id().equals("fps")).findFirst().orElseThrow();
				var info = new net.minecraft.client.input.MouseButtonInfo(com.mojang.blaze3d.platform.InputConstants.MOUSE_BUTTON_LEFT, 256);
				double sx = dragged.screenX() + 4, sy = dragged.screenY() + 4;
				editor.mouseClicked(new net.minecraft.client.input.MouseButtonEvent(sx, sy, info), false);
				double dx = mc.getWindow().getGuiScaledWidth() / 2.0 - 20, dy = mc.getWindow().getGuiScaledHeight() / 2.0 + 6;
				var drop = new net.minecraft.client.input.MouseButtonEvent(dx, dy, info);
				editor.mouseDragged(drop, 0, 0);
				editor.mouseReleased(drop);
				expectX = (int) Math.round(dx - 4);
				expectY = (int) Math.round(dy - 4);
			}
			case 250 -> {
				boolean exact = dragged != null && dragged.screenX() == expectX && dragged.screenY() == expectY;
				Goon.LOGGER.info("Editor drag exactness: {} (wanted {},{} got {},{})", exact ? "OK" : "OFF", expectX, expectY,
					dragged == null ? -1 : dragged.screenX(), dragged == null ? -1 : dragged.screenY());
				shot(mc, "editor-drag");
			}
			case 251 -> {
				mc.gui.setScreen(null);
				run(mc, "gamemode survival");
				if (savedSettings != null) {
					dev.goonclient.client.config.ConfigManager.apply(savedSettings, true, false);
					dev.goonclient.client.config.ConfigManager.save();
				}
				run(mc, "kill @e[type=husk]");
			}
			case 259 -> {
                if (Boolean.getBoolean("goonclient.brandPreview")) {
                    dev.goonclient.client.config.ProfileStore.load(dev.goonclient.client.config.ProfileStore.presets().stream().filter(p -> p.id().equals("combatant")).findFirst().orElseThrow());
                } else mc.stop();
            }
			default -> {
			}
		}
	}

	private static dev.goonclient.client.hud.HudModule dragged;
	private static int expectX, expectY;

	private static void run(Minecraft mc, String command) {
		var server = mc.getSingleplayerServer();
		if (server != null) {
			server.execute(() -> server.getCommands().performPrefixedCommand(
				server.createCommandSourceStack().withSuppressedOutput(), "execute as @p at @p run " + command));
		}
	}

	private static void shot(Minecraft mc, String name) {
		Goon.LOGGER.info("Menu preview: {}", name);
		Screenshot.grab(mc.gameDirectory, "goon-menu-" + name + ".png", mc.gameRenderer.mainRenderTarget(), 1, message -> {
		});
	}
}
