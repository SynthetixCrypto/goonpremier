package dev.goonclient.client.hud;

import dev.goonclient.client.gui.Ui;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/** Registry-free layout samples: item components are unavailable before joining the first world in 26.3. */
final class HudPreview {
    private HudPreview() { }

    private static String[] rows(HudModule module) {
        return switch (module.id()) {
            case "active_modules" -> new String[]{"Fullbright   F8", "Spawn Overlay   F9"};
            case "block_info" -> new String[]{"Stone", "XYZ   128 64 -256", "Tool   Suitable for drops", "Break time   ~0.30 s"};
            case "tool_info" -> new String[]{"Diamond Pickaxe", "Durability   1234 / 1561", "Efficiency V"};
            case "coordinates" -> new String[]{"XYZ   128 64 -256", "Facing   North", "Biome   Plains"};
            case "cps" -> new String[]{"CPS   6 L / 2 R"};
            case "hit_distance" -> new String[]{"Hit distance   2.45 m", "Zombie"};
            case "fps" -> new String[]{"FPS   120"};
            case "ping" -> new String[]{"Ping   42 ms"};
            case "memory" -> new String[]{"RAM   42% (1720/4096 MB)"};
            case "hardware_usage" -> new String[]{"CPU   24%", "GPU   38%"};
            case "clock" -> new String[]{"12:30"};
            case "world_time" -> new String[]{"Day 1   12:00"};
            case "speed" -> new String[]{"Speed   4.32 b/s"};
            case "armor" -> new String[]{"Helmet   100%", "Chestplate   85%", "Leggings   50%", "Boots   10%"};
            case "potions" -> new String[]{"Speed II   1:30", "Strength   3:00"};
            case "item_counter" -> new String[]{"Arrows   64", "Totems   2", "Food   32"};
            case "target" -> new String[]{"Zombie   Hostile", "14 / 20 HP", "6.2 m   2 armour"};
            case "shield_status" -> new String[]{"Shield   Ready", "Durability   85%"};
            case "attack_indicator" -> new String[]{"Attack   60%"};
            case "danger_meter" -> new String[]{"LOW HEALTH", "Diamond Pickaxe   6%"};
            case "boss_prep" -> new String[]{"Boss preparation   4 / 6", "Food   32 / 16", "Arrows   64 / 64", "Totems   2 / 1"};
            case "loot_tracker" -> new String[]{"Loot   7:30", "Rotten Flesh   64   512/h", "Bone   37   296/h", "3400 XP/h   120 kills/h"};
            case "pickup_notifier" -> new String[]{"+3 Diamonds", "+12 Iron"};
            case "light_level" -> new String[]{"Light   7 (sky 15)", "Too bright for mobs"};
            case "nearby_entities" -> new String[]{"Hostile   3", "Zombie   x3", "Animals   2", "Items   4"};
            case "mining" -> new String[]{"Mined   128", "Rate   24 /min", "Iron   x12", "Tool   820 uses left"};
            case "waypoint_list" -> new String[]{"Base   120m", "Village   340m"};
            case "session_stats" -> new String[]{"Session   25:00", "Mined   128", "Mobs   12", "XP   340"};
            case "compass" -> new String[]{"W           N           E"};
            case "frame_graph" -> new String[]{"FPS   120", "Frame time   8.3 ms"};
            default -> new String[]{module.name(), "Sample data"};
        };
    }

    static void measure(HudModule module, Minecraft mc) {
        if (module.id().equals("minimap")) { module.setSize(86, 86); return; }
        int width = 40;
        for (String row : rows(module)) width = Math.max(width, Ui.width(mc.font, row) + 12);
        boolean header=module instanceof TextHudModule && rows(module).length>1;
        if(header)width=Math.max(width,Ui.width(mc.font,module.name())+22);
        module.setSize(width, rows(module).length * 12 + 8+(header?18:0));
    }

    static void render(HudModule module, GuiGraphicsExtractor g, Minecraft mc, int width, int height) {
        dev.goonclient.client.gui.GlassUi.hud(g,width,height);
        if (module.id().equals("minimap")) {
            // Deliberately schematic, not world/seed information or a call into Xaero's world renderer.
            g.enableScissor(3, 3, width - 3, height - 3);
            g.fill(3, 3, width - 3, height - 3, 0xFF202A25);
            for (int x=4; x<width-3; x+=10) g.fill(x, 3, x+1, height-3, 0xFF2B3830);
            for (int y=4; y<height-3; y+=10) g.fill(3, y, width-3, y+1, 0xFF2B3830);
            g.fill(width/2-6, 3, width/2+4, height-3, 0xFF263D4A);
            Ui.roundRect(g, width/2f-2, height/2f-2, width/2f+2, height/2f+2, 2, Ui.accent());
            Ui.text(g, mc.font, "N", width/2-2, 7, Ui.TEXT, false);
            Ui.text(g, mc.font, "Map preview", 12, height-16, Ui.MUTED, false);
            g.disableScissor();
            return;
        }
        boolean header=module instanceof TextHudModule && rows(module).length>1;
        if(header){
            dev.goonclient.client.gui.render.Shapes.circle(g,7,8,1.5f,Ui.accent());
            dev.goonclient.client.gui.GlassUi.text(g,module.name(),13,4,7.4f,Ui.TEXT,true);
            dev.goonclient.client.gui.GlassUi.line(g,5,16,width-10);
        }
        int y=header?22:4;
        for (String row : rows(module)) {
            Ui.text(g, mc.font, row, 6, y, module.id().equals("danger_meter") ? Ui.WARN : Ui.TEXT, true);
            y+=12;
        }
    }
}
