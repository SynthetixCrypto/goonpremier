package dev.goonclient.client.mixin;

import dev.goonclient.client.tracker.AdventureLog;
import net.minecraft.advancements.AdvancementHolder;
import net.minecraft.client.gui.components.toasts.AdvancementToast;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(AdvancementToast.class)
public class AdvancementToastMixin {
	/** The game makes this toast exactly when you earn an advancement (not when progress syncs on join). */
	@Inject(method = "<init>", at = @At("RETURN"))
	private void goonclient$logAdvancement(AdvancementHolder advancement, CallbackInfo ci) {
		AdventureLog.onAdvancement(advancement);
	}
}
