package dev.goonclient.client.config;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.goonclient.Goon;
import dev.goonclient.client.GoonChat;
import dev.goonclient.client.utility.LocalFiles;
import dev.goonclient.client.utility.WorldScope;
import java.nio.file.*;
import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.client.Minecraft;

/** Explicit local bindings. Joining applies a saved setup; leaving restores the pre-join setup, even after a crash. */
public final class ServerProfiles {
    private record Binding(String profile,String name){}
    private static final Map<String,Binding> bindings=new LinkedHashMap<>();
    private static WorldScope current;
    private static JsonObject before;
    private static boolean ready;
    private ServerProfiles(){}
    private static Path file(){return ConfigManager.dir().resolve("server-profiles.json");}
    private static Path journal(){return ConfigManager.dir().resolve("server-profile-restore.json");}
    public static void init(){
        bindings.clear();current=null;before=null;ready=true;
        try{
            if(Files.exists(journal())){
                JsonObject old=JsonParser.parseString(LocalFiles.read(journal(),256*1024)).getAsJsonObject();
                ProfileStore.validate(old);
                // Capture omits default positions. Clear stale server offsets before startup recovery.
                var modules=old.getAsJsonObject("modules");
                for(var module:dev.goonclient.client.module.ModuleManager.all())
                    if(module instanceof dev.goonclient.client.hud.HudModule hud && modules.has(module.id()))
                        hud.setPosition(hud.defaultPosition());
                ConfigManager.apply(old,false,false);LocalFiles.write(ConfigManager.dir().resolve("modules.json"),ConfigManager.GSON.toJson(ConfigManager.capture()));ConfigManager.markDirty();ConfigManager.save();Files.delete(journal());
            }
            if(Files.exists(file())){
                JsonObject data=JsonParser.parseString(LocalFiles.read(file(),64*1024)).getAsJsonObject();
                if(data.get("version").getAsInt()!=1)throw new IllegalArgumentException();
                for(var entry:data.getAsJsonObject("bindings").entrySet()){
                    if(bindings.size()==128)break;
                    if(!entry.getKey().matches("[a-f0-9]{64}"))continue;
                    var value=entry.getValue().getAsJsonObject();
                    bindings.put(entry.getKey(),new Binding(value.get("profile").getAsString(),WorldScope.clean(value.get("name").getAsString(),96)));
                }
            }
        }catch(Exception e){ready=false;Goon.LOGGER.warn("Automatic setups unavailable: check the local profile files. Existing files retained.");}
    }
    private static void save()throws java.io.IOException{
        JsonObject values=new JsonObject();bindings.forEach((key,b)->{JsonObject v=new JsonObject();v.addProperty("profile",b.profile());v.addProperty("name",b.name());values.add(key,v);});
        JsonObject data=new JsonObject();data.addProperty("version",1);data.add("bindings",values);LocalFiles.write(file(),ConfigManager.GSON.toJson(data));
    }
    public static boolean canLink(){return ready&&current!=null;}
    public static String linkLabel(){
        if(!ready)return "Automatic setups unavailable: check local profile files.";
        if(current==null)return "Join a world or server to link a setup.";
        Binding b=bindings.get(current.key());return b==null?"No automatic setup for "+current.name():"On join: "+b.name();
    }
    public static boolean linked(){return current!=null&&bindings.containsKey(current.key());}
    public static ProfileStore.Result bind(ProfileStore.Profile profile){
        if(!canLink())return new ProfileStore.Result(false,"Join a world or server first.");
        if(bindings.size()>=128&&!linked())return new ProfileStore.Result(false,"128 worlds are linked. Unlink one before adding another.");
        Binding previous=bindings.put(current.key(),new Binding(profile.id(),profile.name()));
        try{save();return new ProfileStore.Result(true,"“"+profile.name()+"” will load next time you join this world/server.");}
        catch(Exception e){if(previous==null)bindings.remove(current.key());else bindings.put(current.key(),previous);return new ProfileStore.Result(false,"Couldn't save the link. Check the config folder.");}
    }
    public static ProfileStore.Result unbind(){
        if(!canLink())return new ProfileStore.Result(false,"Join the linked world/server first.");
        Binding previous=bindings.remove(current.key());
        try{save();return new ProfileStore.Result(true,"Automatic setup removed. Current settings are unchanged.");}
        catch(Exception e){if(previous!=null)bindings.put(current.key(),previous);return new ProfileStore.Result(false,"Couldn't remove the link. Check the config folder.");}
    }
    public static void onJoin(Minecraft mc){enter(WorldScope.current(mc));}
    public static void enter(WorldScope scope){
        if(current!=null)onLeave();current=scope;
        if(!ready||scope==null)return;
        Binding binding=bindings.get(scope.key());if(binding==null)return;
        try{
            var profile=ProfileStore.list().stream().filter(p->p.id().equals(binding.profile())).findFirst().orElse(null);
            if(profile==null){GoonChat.error("Linked setup is missing. Open Configs to choose another.");return;}
            JsonObject snapshot=ConfigManager.capture();LocalFiles.write(journal(),ConfigManager.GSON.toJson(snapshot));
            var result=ProfileStore.load(profile);
            if(result.ok()){before=snapshot;GoonChat.info("Automatic setup: "+profile.name()+". Your previous setup returns when you leave.");}
            else{Files.deleteIfExists(journal());GoonChat.error(result.message());}
        }catch(Exception e){GoonChat.error("Couldn't apply the automatic setup. Check local profile files.");}
    }
    public static void onLeave(){
        if(before!=null){
            JsonObject restore=before;before=null;
            try{ConfigManager.apply(restore,true,false);LocalFiles.write(ConfigManager.dir().resolve("modules.json"),ConfigManager.GSON.toJson(ConfigManager.capture()));ConfigManager.markDirty();ConfigManager.save();Files.deleteIfExists(journal());}
            catch(Exception e){ready=false;Goon.LOGGER.warn("Automatic setup restore needs recovery on next startup.");}
        }
        current=null;
    }
}
