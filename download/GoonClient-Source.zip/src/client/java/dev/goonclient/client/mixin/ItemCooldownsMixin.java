package dev.goonclient.client.mixin;

import dev.goonclient.client.tracker.CooldownTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.ItemCooldowns;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Records the local player's item cooldowns as they start and end (the integrated server's copy is ignored). */
@Mixin(ItemCooldowns.class)
public abstract class ItemCooldownsMixin {
	@Inject(method = "addCooldown(Lnet/minecraft/resources/Identifier;I)V", at = @At("HEAD"))
	private void goonclient$started(Identifier group, int ticks, CallbackInfo ci) {
		if (isLocal()) CooldownTracker.started(group, ticks);
	}

	@Inject(method = "removeCooldown", at = @At("HEAD"))
	private void goonclient$removed(Identifier group, CallbackInfo ci) {
		if (isLocal()) CooldownTracker.removed(group);
	}

	private boolean isLocal() {
		Minecraft mc = Minecraft.getInstance();
		return mc != null && mc.player != null && (Object) this == mc.player.getCooldowns();
	}
}
