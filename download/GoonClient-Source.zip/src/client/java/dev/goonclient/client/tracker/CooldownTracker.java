package dev.goonclient.client.tracker;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.resources.Identifier;

/** Item cooldowns the server gave the local player, with their full length, so the HUD can show time left. */
public final class CooldownTracker {
	public record Entry(Identifier group, long startedAt, int ticks) {
		public long remainingMs(long now) {
			return Math.max(0, startedAt + ticks * 50L - now);
		}
	}

	private static final Map<Identifier, Entry> ACTIVE = new LinkedHashMap<>();

	private CooldownTracker() {
	}

	public static void started(Identifier group, int ticks) {
		if (ticks > 0) ACTIVE.put(group, new Entry(group, System.currentTimeMillis(), ticks));
	}

	public static void removed(Identifier group) {
		ACTIVE.remove(group);
	}

	public static void clear() {
		ACTIVE.clear();
	}

	public static List<Entry> active() {
		long now = System.currentTimeMillis();
		ACTIVE.values().removeIf(entry -> entry.remainingMs(now) <= 0);
		return new ArrayList<>(ACTIVE.values());
	}
}
