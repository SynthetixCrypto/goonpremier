package dev.goonclient.client.render;

import dev.goonclient.Goon;
import dev.goonclient.client.module.Module;
import dev.goonclient.client.module.ModuleManager;
import java.util.HashSet;
import java.util.Set;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderEvents;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.gizmos.Gizmos;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3fc;

/**
 * Drawing in the 3D world. 26.3 has a built-in "gizmo" layer (boxes, lines, quads, floating text) that the game
 * collects every frame; modules add theirs right before it's finalised, so it all renders with correct depth.
 */
public final class WorldRender {
	private static final Set<String> FAILED = new HashSet<>();

	private WorldRender() {
	}

	/** A module that draws in the world. Called once per frame while the module is enabled. */
	public interface Renderable {
		void renderWorld(Minecraft mc, Camera camera, float partialTick);
	}

	public static void register() {
		LevelRenderEvents.BEFORE_GIZMOS.register(context -> {
			Minecraft mc = Minecraft.getInstance();
			if (mc.player == null || mc.level == null) {
				return;
			}
			Camera camera = mc.gameRenderer.mainCamera();
			float partialTick = mc.getDeltaTracker().getGameTimeDeltaPartialTick(false);
			try (Gizmos.TemporaryCollection ignored = context.levelRenderer().collectPerFrameRenderThreadGizmos()) {
				for (Module module : ModuleManager.all()) {
					if (module.isEnabled() && module instanceof Renderable renderable) {
						try {
							renderable.renderWorld(mc, camera, partialTick);
						} catch (RuntimeException e) {
							// Log once per module instead of every frame
							if (FAILED.add(module.id())) {
								Goon.LOGGER.error("{} failed to draw in the world", module.name(), e);
							}
						}
					}
				}
			}
		});
	}

	/**
	 * The four corners of a rectangle that always faces the camera, centred on {@code centre}.
	 * {@code fromX}/{@code toX} are offsets along the screen's horizontal axis (negative = left).
	 */
	public static Vec3[] billboard(Camera camera, Vec3 centre, double fromX, double toX, double fromY, double toY, double towardCamera) {
		Vector3fc left = camera.leftVector();
		Vector3fc up = camera.upVector();
		Vector3fc forward = camera.forwardVector();
		Vec3 right = new Vec3(-left.x(), -left.y(), -left.z());
		Vec3 upVec = new Vec3(up.x(), up.y(), up.z());
		Vec3 base = centre.subtract(forward.x() * towardCamera, forward.y() * towardCamera, forward.z() * towardCamera);
		return new Vec3[]{
			base.add(right.scale(fromX)).add(upVec.scale(fromY)),
			base.add(right.scale(toX)).add(upVec.scale(fromY)),
			base.add(right.scale(toX)).add(upVec.scale(toY)),
			base.add(right.scale(fromX)).add(upVec.scale(toY))
		};
	}
}
