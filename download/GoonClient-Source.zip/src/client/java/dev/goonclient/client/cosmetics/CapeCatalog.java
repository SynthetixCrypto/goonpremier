package dev.goonclient.client.cosmetics;

import java.util.List;

/** Stable IDs are shared by the wardrobe and the optional friends service. */
public final class CapeCatalog {
    public record Cape(String id, String name, String description, int color, int motif) {}
    public static final List<Cape> CAPES = List.of(
        new Cape("none", "Original cape", "Keep your Minecraft cape.", 0xFF7D8490, 0),
        new Cape("nation_noir", "Nation Noir", "The crew's signature. Noir pink on charcoal glass.", 0xFFE16B78, 10),
        new Cape("nation_mint", "Nation Mint", "The original crew colour, in mint.", 0xFF43E0B2, 1),
        new Cape("after_hours", "After Hours", "Violet orbits on midnight cloth.", 0xFF9B6BFF, 2),
        new Cape("nation_gold", "Nation Gold", "Gold insignia and tailored chevrons.", 0xFFF2B84B, 3),
        new Cape("glacier", "Glacier", "Ice-blue ridges. Cold and clean.", 0xFF5CC8E7, 4),
        new Cape("redline", "Redline", "Crimson cuts across charcoal.", 0xFFFF5265, 5),
        new Cape("deep_blue", "Deep Blue", "Cobalt contour lines and silver seams.", 0xFF5DA7FF, 6),
        new Cape("rose_signal", "Rose Signal", "A rose crest with radiating petals.", 0xFFFF91BD, 7),
        new Cape("ghost", "Ghost", "Silver mesh. Quiet Nation branding.", 0xFFDCE1EA, 8),
        new Cape("ember", "Ember", "Copper sunset over black fabric.", 0xFFFF7A45, 9)
    );
    private CapeCatalog() {}
    public static Cape find(String id) { return CAPES.stream().filter(c -> c.id().equals(id)).findFirst().orElse(CAPES.getFirst()); }
    public static boolean valid(String id) { return CAPES.stream().anyMatch(c -> c.id().equals(id)); }
}
