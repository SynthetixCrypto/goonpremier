package dev.goonclient.client.dev;

import dev.goonclient.Goon;
import dev.goonclient.client.gui.AdventureLogScreen;
import dev.goonclient.client.gui.ClickGuiScreen;
import dev.goonclient.client.gui.HudEditorScreen;
import dev.goonclient.client.module.Module;
import dev.goonclient.client.module.ModuleManager;
import dev.goonclient.client.modules.visual.CustomCrosshair;
import dev.goonclient.client.tracker.AdventureLog;
import dev.goonclient.client.waypoint.Waypoint;
import dev.goonclient.client.waypoint.WaypointManager;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.server.IntegratedServer;
import net.minecraft.client.tutorial.TutorialSteps;
import net.minecraft.network.chat.Component;
import net.minecraft.core.BlockPos;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Development only: with -Dgoonclient.devSnapshots=true, walks through the HUD, menu, a settings page and the
 * HUD editor, taking a screenshot of each, then quits. Lets the UI be checked without clicking through it.
 */
public final class DevSnapshots {
	private static int ticksInWorld;
	private static int ticksOnTitle = -1;
	private static ClickGuiScreen menu;
	private static dev.goonclient.client.gui.PerformanceScreen performance;
	private static String performanceBefore;
	private static String interfaceBefore;
	private static dev.goonclient.client.gui.ScreenshotScreen screenshots;
	private static java.nio.file.Path galleryFixture;
	private static int startupTicks;
	private static dev.goonclient.client.hud.HudModule startupMap;
	private static dev.goonclient.client.hud.HudPosition startupMapPosition;
	private static double startupMapScale;
	private static int startupMapWidth;
	private static volatile boolean screenshotPending;
	private static boolean originalFocusPause;
	private static dev.goonclient.client.hud.HudModule minimap;
	private static dev.goonclient.client.hud.HudPosition minimapPosition;
	private static double minimapScale;
	private static int minimapWidth;
	private static double minimapResizedScale;
	private static boolean minimapEnabled;
	private static int originalGuiScale;
	private static HudEditorScreen mapEditor;
	/** HUD modules switched on for the showcase shot, with the state to put back afterwards. */
	private static final List<String> SHOWCASE = List.of("coordinates", "compass", "fps", "ping", "armor", "potions",
		"item_counter", "target", "danger_meter", "pickup_notifier", "health_bars", "damage_numbers", "crosshair",
		"shield_status", "loot_tracker", "attack_indicator", "adventure_log", "hardware_usage");
	/** World overlays get their own night-time shot. */
	private static final List<String> OVERLAYS = List.of("spawn_overlay", "chunk_borders", "spawn_range");
	private static final Map<Module, Boolean> restore = new HashMap<>();

	private DevSnapshots() {
	}

	public static void init() {
		if (Boolean.getBoolean("goonclient.devStartupSnapshots")) {
			ClientTickEvents.END_CLIENT_TICK.register(DevSnapshots::startupTick);
			return;
		}
		if (!Boolean.getBoolean("goonclient.devSnapshots")) {
			return;
		}
		Goon.LOGGER.info("Dev snapshot mode enabled");
		ClientTickEvents.END_CLIENT_TICK.register(DevSnapshots::tick);
	}

	/** Real-launcher clean-install smoke test, using the packaged jar and Mojang runtime. */
	private static void startupTick(Minecraft mc) {
		if (!mc.isGameLoadFinished()) return;
		mc.getFramerateLimitTracker().onInputReceived();
		if (screenshotPending) return;
		startupTicks++;
		if (startupTicks == 60) {
			if (mc.options.onboardAccessibility || !(mc.gui.screen() instanceof dev.goonclient.client.gui.GoonTitleScreen)) {
				throw new IllegalStateException("Clean launch did not reach the Goon title screen directly");
			}
			Goon.LOGGER.info("Dev clean launch: Goon title reached directly, narrator onboarding skipped");
			shot(mc, "startup-title");
		} else if (startupTicks == 65) {
			mc.gui.setScreen(new net.minecraft.client.gui.screens.options.OptionsScreen(mc.gui.screen(), mc.options));
		} else if (startupTicks == 95) {
			if (!(mc.gui.screen() instanceof dev.goonclient.client.gui.GoonOptionsScreen)) throw new IllegalStateException("Options replacement failed");
			shot(mc, "startup-options");
		} else if (startupTicks == 100) {
			mc.gui.screen().keyPressed(new net.minecraft.client.input.KeyEvent(com.mojang.blaze3d.platform.InputConstants.KEY_RETURN, 0, 0));
		} else if (startupTicks == 125) {
			if (mc.gui.screen() instanceof dev.goonclient.client.gui.GoonOptionsScreen
				|| mc.gui.screen() instanceof net.minecraft.client.gui.screens.options.VideoSettingsScreen) {
				throw new IllegalStateException("Pack Video button did not open Sodium settings");
			}
			Goon.LOGGER.info("Dev Options Video button opened {}", mc.gui.screen().getClass().getName());
			shot(mc, "startup-video");
		} else if (startupTicks == 130) {
			mc.gui.screen().onClose();
		} else if (startupTicks == 140) {
			if (!(mc.gui.screen() instanceof dev.goonclient.client.gui.GoonOptionsScreen)) throw new IllegalStateException("Video settings didn't return to Goon Options");
			if (mc.player != null || mc.level != null) throw new IllegalStateException("Startup HUD check requires no world");
			for (var hud : ModuleManager.hudModules()) { restore.put(hud, hud.isEnabled()); hud.loadEnabled(true); }
			menu = new ClickGuiScreen(new TitleScreen());
			mc.gui.setScreen(menu);
		} else if (startupTicks == 155) {
			mc.gui.setScreen(new HudEditorScreen(menu));
		} else if (startupTicks == 180) {
			for (var hud : ModuleManager.hudModules()) {
				if (hud.screenWidth() < 3 || hud.screenHeight() < 3) throw new IllegalStateException("Missing menu preview: " + hud.id());
			}
			Goon.LOGGER.info("Dev main-menu HUD: all {} modules rendered without a player or level", ModuleManager.hudModules().size());
			startupMap = ModuleManager.hudModules().stream().filter(m -> m.id().equals("minimap")).findFirst().orElse(null);
			if (startupMap != null) {
				startupMapPosition = startupMap.position(); startupMapScale = startupMap.scale.get(); startupMapWidth = startupMap.screenWidth();
				var editor = (HudEditorScreen) mc.gui.screen();
				double x=startupMap.screenX()+8, y=startupMap.screenY()+8;
				var press=new net.minecraft.client.input.MouseButtonEvent(x,y,new net.minecraft.client.input.MouseButtonInfo(com.mojang.blaze3d.platform.InputConstants.MOUSE_BUTTON_LEFT,0));
				if (!editor.mouseClicked(press,false)) throw new IllegalStateException("Preview cannot be selected");
				var drag=new net.minecraft.client.input.MouseButtonEvent(x+12,y+16,press.buttonInfo());
				editor.mouseDragged(drag,12,16); editor.mouseReleased(drag);
				if (startupMap.position().equals(startupMapPosition)) throw new IllegalStateException("Preview drag did not move the minimap");
				editor.mouseScrolled(x+12,y+16,0,startupMapScale >= 2 ? -1 : 1);
				if (startupMap.scale.get()==startupMapScale) throw new IllegalStateException("Preview wheel did not resize the minimap");
			}
		} else if (startupTicks == 185) {
			if (startupMap != null) {
				if (startupMap.screenWidth()==startupMapWidth) throw new IllegalStateException("Preview size did not follow the scale");
				startupMap.setPosition(startupMapPosition); startupMap.scale.set(startupMapScale);
			}
			for (var entry : restore.entrySet()) entry.getKey().loadEnabled(entry.getValue());
			restore.clear();
			Goon.LOGGER.info("Dev main-menu HUD: preview drag and resize passed; positions, scales and module states restored");
		} else if (startupTicks == 190) {
			shot(mc, "startup-hud-editor");
		} else if (startupTicks == 195) {
			((HudEditorScreen) mc.gui.screen()).showElements();
		} else if (startupTicks == 205) {
			shot(mc, "startup-hud-elements");
		} else if (startupTicks == 210) {
			for (var entry : restore.entrySet()) entry.getKey().loadEnabled(entry.getValue());
			restore.clear();
			mc.gui.screen().onClose();
			if (mc.gui.screen() != menu) throw new IllegalStateException("HUD editor did not return to its menu");
			Goon.LOGGER.info("Dev main-menu HUD: drawer and return navigation passed; module states restored");
			mc.stop();
		}
	}

	private static void tick(Minecraft mc) {
		mc.getFramerateLimitTracker().onInputReceived();
		if (screenshotPending) return;
		if (ticksOnTitle >= 0) {
			ticksOnTitle++;
			if (ticksOnTitle == 60) {
				shot(mc, "title");
			} else if (ticksOnTitle == 62) {
				// The same menu with a picture from config/goonclient/backgrounds (if there is one)
				setMenuBackground("Custom image");
			} else if (ticksOnTitle == 90) {
				shot(mc, "title-custom");
			} else if (ticksOnTitle == 92) {
				setMenuBackground("Goon");
				// A clean background with no UI, used as the launcher background
				mc.gui.setScreen(new PanoramaOnly());
			} else if (ticksOnTitle == 115) {
				shot(mc, "panorama");
			} else if (ticksOnTitle == 118) {
				try {
					galleryFixture = java.nio.file.Files.createTempFile(mc.gameDirectory.toPath().resolve("screenshots"), "dev-gallery-", ".png");
					java.nio.file.Files.copy(mc.gameDirectory.toPath().resolve("screenshots/goon-hud.png"), galleryFixture, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
				} catch (java.io.IOException e) {
					throw new IllegalStateException("Couldn't create gallery fixture", e);
				}
				screenshots = new dev.goonclient.client.gui.ScreenshotScreen(new TitleScreen());
				mc.gui.setScreen(screenshots);
			} else if (ticksOnTitle == 155) {
				shot(mc, "screenshots");
			} else if (ticksOnTitle == 158) {
				if (!screenshots.previewFile(galleryFixture)) throw new IllegalStateException("Screenshot library didn't load");
			} else if (ticksOnTitle == 185) {
				shot(mc, "screenshot-preview");
			} else if (ticksOnTitle == 190) {
				screenshots.removeSelected();
				if (java.nio.file.Files.exists(galleryFixture)) throw new IllegalStateException("Gallery remove failed");
			} else if (ticksOnTitle == 210) {
				screenshots.undoRemove();
				try {
					if (java.nio.file.Files.mismatch(galleryFixture, mc.gameDirectory.toPath().resolve("screenshots/goon-hud.png")) != -1) throw new IllegalStateException("Gallery restore changed image");
					java.nio.file.Files.delete(galleryFixture);
					Goon.LOGGER.info("Dev screenshot manager: preview, remove and byte-identical undo passed");
				} catch (java.io.IOException e) {
					throw new IllegalStateException("Gallery undo failed", e);
				}
			} else if (ticksOnTitle == 215) {
				if (mc.player != null || mc.level != null) throw new IllegalStateException("Disconnect did not unload the world");
				mc.gui.setScreen(new HudEditorScreen(new TitleScreen()));
			} else if (ticksOnTitle == 240) {
				Goon.LOGGER.info("Dev HUD editor after disconnect: world-free preview rendered safely");
				shot(mc, "hud-editor-after-disconnect");
			} else if (ticksOnTitle == 245) {
				mc.gui.screen().onClose();
				mc.stop();
			}
			return;
		}
		if (mc.player == null || mc.level == null) {
			return;
		}
		ticksInWorld++;
		switch (ticksInWorld) {
			case 10 -> {
				originalFocusPause = mc.options.pauseOnLostFocus;
				mc.options.pauseOnLostFocus = false;
				if (mc.options.onboardAccessibility) throw new IllegalStateException("Narrator onboarding was not skipped");
				// -PdevAccent: the whole tour in that accent colour
				setInterface("theme", System.getProperty("goonclient.devAccent", "Mint"));
				// No tutorial toasts in the shots
				mc.getTutorial().setStep(TutorialSteps.NONE);
				mc.options.tutorialStep = TutorialSteps.NONE;
				for (Module module : ModuleManager.all()) {
					if (SHOWCASE.contains(module.id())) {
						restore.put(module, module.isEnabled());
						module.loadEnabled(true);
					}
				}
				// Gear, effects and items so every panel has something to show
				for (String command : List.of("time set 1000", "weather clear", "kill @e[type=!player,distance=..30]", "clear @s",
					"item replace entity @s armor.head with diamond_helmet",
					"item replace entity @s armor.chest with diamond_chestplate",
					"item replace entity @s armor.legs with iron_leggings[damage=110]",
					"item replace entity @s armor.feet with iron_boots[damage=170]",
					"item replace entity @s weapon.mainhand with diamond_pickaxe[damage=1460]",
					"item replace entity @s weapon.offhand with shield",
					"give @s arrow 64", "give @s cooked_beef 9", "give @s diamond_sword[damage=400]", "give @s bow", "give @s totem_of_undying 2", "give @s ender_pearl 16", "give @s golden_apple 12",
					"effect give @s speed 90 1 true", "effect give @s haste 200 1 true",
					"effect give @s fire_resistance 465 0 true")) {
					run(mc, command);
				}
			}
			case 20 -> {
				BlockPos pos = mc.player.blockPosition();
				String dimension = mc.level.dimension().identifier().toString();
				WaypointManager.add(new Waypoint("DevBase", pos.getX() + 40, pos.getY(), pos.getZ() - 60, dimension, 0xFF5BE37D, false, 0));
				WaypointManager.add(new Waypoint("DevDeath", pos.getX() - 30, pos.getY(), pos.getZ() - 80, dimension, WaypointManager.DEATH_COLOR, true, 0));
				mc.player.setYRot(180f);
				mc.player.setXRot(10f);
			}
			// A mob to look at for Mob Info (a husk, so it doesn't burn in daylight)
			case 30 -> {
				run(mc, "summon husk ^ ^ ^4 {NoAI:1b,PersistenceRequired:1b}");
				// A second one off to the side, where its health bar and damage numbers aren't behind Mob Info
				run(mc, "summon husk ^4 ^ ^8 {NoAI:1b,PersistenceRequired:1b}");
			}
			case 45 -> {
				run(mc, "damage @e[type=husk,limit=1,sort=nearest] 7");
				run(mc, "damage @e[type=husk,limit=1,sort=furthest] 9");
			}
			case 105 -> {
				// Real pickups (the notifier listens for them), late enough that the popups are still up in the shot
				run(mc, "summon item ~ ~ ~ {Item:{id:\"minecraft:cobblestone\",count:37}}");
				run(mc, "summon item ~ ~ ~ {Item:{id:\"minecraft:diamond\",count:3}}");
			}
			case 130 -> {
				mc.gui.hud.getChat().clearMessages(false);
				mc.gui.toastManager().clear();
			}
			// A fresh hit just before the shot, so a damage number is floating
			case 134 -> {
				run(mc, "damage @e[type=husk,limit=1,sort=nearest] 2");
				run(mc, "damage @e[type=husk,limit=1,sort=furthest] 3");
			}
			case 140 -> {
				Goon.LOGGER.info("Dev fps in game with the HUD showcase: {}", mc.getFps());
				shot(mc, "hud");
			}
			// The heavier panels get a shot of their own, so the showcase stays readable
			case 142 -> {
				setEnabled(List.of("boss_prep", "frame_graph", "hardware_usage"), true);
				setEnabled(List.of("potions", "pickup_notifier", "loot_tracker"), false);
			}
			case 152 -> {
				Goon.LOGGER.info("Dev GPU frame utilization with HUD timing enabled: {}%", mc.getGpuUtilization());
				for (var hud : ModuleManager.hudModules()) {
					if (hud.isEnabled()) {
						Goon.LOGGER.info("Dev rect {} x={} y={} w={} h={} moved={}", hud.id(), hud.screenX(), hud.screenY(), hud.screenWidth(), hud.screenHeight(), hud.isMoved());
					}
				}
				shot(mc, "tools");
			}
			case 154 -> {
				setEnabled(List.of("boss_prep", "frame_graph", "hardware_usage"), false);
				setEnabled(List.of("potions", "pickup_notifier", "loot_tracker"), true);
				// Better Chat: repeats should fold into one line with a counter
				var chat = mc.gui.hud.getChat();
				chat.addClientSystemMessage(Component.literal("Server restarting in 5 minutes"));
				chat.addClientSystemMessage(Component.literal("Server restarting in 5 minutes"));
				chat.addClientSystemMessage(Component.literal("Server restarting in 5 minutes"));
				chat.addClientSystemMessage(Component.literal("Welcome back!"));
				chat.addClientSystemMessage(Component.literal("Welcome back!"));
			}
			case 157 -> shot(mc, "chat");
			case 160 -> {
				menu = new ClickGuiScreen(null);
				mc.gui.setScreen(menu);
			}
			// Toggle check: switch a module on and make sure its card animation fully lands
			case 182 -> ModuleManager.all().stream().filter(m -> m.id().equals("memory")).findFirst().ifPresent(Module::toggle);
			case 187 -> Goon.LOGGER.info("Dev toggle animation after 250 ms: {} (1.0 = finished)",
				dev.goonclient.client.gui.Ui.animate("cg:card:on:memory", 1f, 0.42f));
			case 190 -> {
				Goon.LOGGER.info("Dev fps with the menu open: {}", mc.getFps());
				shot(mc, "menu");
			}
			case 195 -> ModuleManager.all().stream().filter(m -> m.id().equals("memory")).findFirst().ifPresent(Module::toggle);
			case 196 -> ClickGuiChecks.all(menu);
			case 198 -> ClickGuiChecks.cardOptions(menu);
			case 199 -> ClickGuiChecks.cardToggle(menu);
			case 200 -> ClickGuiChecks.bottom(menu);
			case 207 -> { ClickGuiChecks.verify(menu); shot(mc, "menu-scroll-bottom"); }
			case 208 -> ClickGuiChecks.middle(menu);
			case 215 -> { ClickGuiChecks.verify(menu); shot(mc, "menu-scroll-middle"); }
			case 216 -> ClickGuiChecks.dragTop(menu);
			case 220 -> menu.openSettingsFor(ModuleManager.all().stream().filter(m -> m instanceof CustomCrosshair).findFirst().orElseThrow());
			case 245 -> shot(mc, "settings");
			case 250 -> {
				if (dev.goonclient.client.config.PerformancePreset.canRestore()) throw new IllegalStateException("Restore the existing dev performance backup before running the tour");
				performanceBefore = mc.options.dumpOptionsForReport();
				interfaceBefore = interfaceValues();
				performance = new dev.goonclient.client.gui.PerformanceScreen(menu);
				mc.gui.setScreen(performance);
				performance.applyPreset();
				if (!dev.goonclient.client.config.PerformancePreset.canRestore() || mc.options.renderDistance().get() > 8
					|| mc.options.simulationDistance().get() > 5 || mc.options.framerateLimit().get() > 90
					|| mc.options.cloudStatus().get() != net.minecraft.client.CloudStatus.OFF) throw new IllegalStateException("Performance preset wasn't applied");
			}
			case 265 -> shot(mc, "performance");
			case 270 -> {
				performance = new dev.goonclient.client.gui.PerformanceScreen(menu);
				mc.gui.setScreen(performance);
				performance.restorePreset();
				if (!performanceBefore.equals(mc.options.dumpOptionsForReport()) || !interfaceBefore.equals(interfaceValues())
					|| dev.goonclient.client.config.PerformancePreset.canRestore()) throw new IllegalStateException("Performance preset did not restore options");
				Goon.LOGGER.info("Dev performance preset: applied and restored all video options");
			}
			case 280 -> {
				HudEditorScreen editor = new HudEditorScreen(null);
				mc.gui.setScreen(editor);
				editor.showElements();
			}
			case 305 -> shot(mc, "editor");
			case 315 -> {
				mc.gui.setScreen(null);
				run(mc, "time set 18000");
				setEnabled(OVERLAYS, true);
			}
			case 345 -> shot(mc, "overlays");
			case 350 -> {
				setEnabled(OVERLAYS, false);
				run(mc, "time set 1000");
				// A few typical entries, so the log screen shows every kind of event
				BlockPos pos = mc.player.blockPosition();
				String overworld = "minecraft:overworld";
				AdventureLog.clear();
				AdventureLog.add(AdventureLog.Type.TRAVEL, "Entered The Nether", "", "minecraft:the_nether", pos.offset(-12, 0, 40));
				AdventureLog.add(AdventureLog.Type.DEATH, "Died", mc.player.getName().getString() + " was blown up by Creeper", overworld, pos.offset(210, -40, -95));
				AdventureLog.add(AdventureLog.Type.DROP, "Found Diamond ×5", "Diamond", overworld, pos.offset(180, -52, -120));
				AdventureLog.add(AdventureLog.Type.ADVANCEMENT, "Diamonds!", "Advancement made: Acquire diamonds", overworld, pos.offset(180, -52, -120));
				AdventureLog.add(AdventureLog.Type.BOSS, "Defeated Elder Guardian", "Boss fight", overworld, pos.offset(-640, -20, 812));
				AdventureLog.add(AdventureLog.Type.DROP, "Found Totem of Undying ×2", "Totem of Undying", overworld, pos.offset(-30, 4, 66));
				mc.gui.setScreen(new AdventureLogScreen(null));
			}
			case 375 -> shot(mc, "log");
			// Through the vanilla pause screen, to check the Goon pause menu replaces it
			case 380 -> mc.gui.setScreen(new PauseScreen(true));
			case 405 -> shot(mc, "pause");
			case 406 -> {
				mc.gui.setScreen(new net.minecraft.client.gui.screens.options.OptionsScreen(mc.gui.screen(), mc.options));
				if (!(mc.gui.screen() instanceof dev.goonclient.client.gui.GoonOptionsScreen)) throw new IllegalStateException("Vanilla Options wasn't replaced");
			}
			case 409 -> shot(mc, "options");
			case 410 -> {
				mc.gui.setScreen(null);
				WaypointManager.remove("DevBase");
				WaypointManager.remove("DevDeath");
				restore.forEach(Module::loadEnabled);
			}
			case 420 -> {
				setEnabled(List.of("item_physics"), true);
				mc.player.setXRot(40);
				run(mc, "summon item ~-1 ~ ~-2 {Item:{id:\"minecraft:diamond_sword\",count:1},PickupDelay:32767}");
				run(mc, "summon item ~ ~ ~-2 {Item:{id:\"minecraft:diamond\",count:1},PickupDelay:32767}");
				run(mc, "summon item ~1 ~ ~-2 {Item:{id:\"minecraft:cobblestone\",count:1},PickupDelay:32767}");
			}
			case 455 -> shot(mc, "item-physics");
			case 460 -> {
				restore.forEach(Module::loadEnabled);
				mc.player.setXRot(10);
				run(mc, "kill @e[type=item,distance=..5]");
			}
			case 465 -> {
				setEnabled(List.of("time_changer"), true);
				Module module = ModuleManager.all().stream().filter(m -> m.id().equals("time_changer")).findFirst().orElseThrow();
				module.settings().stream().filter(s -> s.id().equals("time")).findFirst().ifPresent(s ->
					((dev.goonclient.client.module.setting.ModeSetting) s).set("Night"));
			}
			case 495 -> {
				long realTime = Math.floorMod(mc.level.getDefaultClockTime(), 24000);
				if (realTime > 6000) throw new IllegalStateException("Visual time changed the real client clock");
				Goon.LOGGER.info("Dev time changer: visual night, real client clock still {}", realTime);
				shot(mc, "time-changer");
			}
			case 500 -> {
				setEnabled(List.of("time_changer"), false);
				restore.forEach(Module::loadEnabled);
			}
			case 525 -> shot(mc, "time-restored");
			case 530 -> {
				minimap = ModuleManager.hudModules().stream().filter(m -> m.id().equals("minimap")).findFirst().orElse(null);
				if (minimap == null) break;
				minimapPosition = minimap.position();
				minimapScale = minimap.scale.get();
				minimapEnabled = minimap.isEnabled();
				minimap.setEnabled(true);
				originalGuiScale = mc.options.guiScale().get();
				mapEditor = new HudEditorScreen(null);
				mc.gui.setScreen(mapEditor);
			}
			case 540 -> {
				if (minimap == null) break;
				minimapWidth = minimap.screenWidth();
				// Exercise the real editor's pointer handlers, not only the model setter.
				var press = new net.minecraft.client.input.MouseButtonEvent(minimap.screenX() + 8, minimap.screenY() + 8,
					new net.minecraft.client.input.MouseButtonInfo(com.mojang.blaze3d.platform.InputConstants.MOUSE_BUTTON_LEFT, 0));
				mapEditor.mouseClicked(press, false);
				var drag = new net.minecraft.client.input.MouseButtonEvent(mc.getWindow().getGuiScaledWidth() - minimap.screenWidth() - 8,
					8, press.buttonInfo());
				mapEditor.mouseDragged(drag, 100, 0);
				mapEditor.mouseReleased(drag);
			}
			case 550 -> {
				if (minimap == null) break;
				if (minimap.position().equals(minimapPosition)) throw new IllegalStateException("Minimap drag didn't move it");
				mapEditor.mouseScrolled(minimap.screenX() + 8, minimap.screenY() + 8, 0, 8);
				minimapResizedScale = minimap.scale.get();
			}
			case 565 -> {
				if (minimap == null) break;
				if (minimap.scale.get() <= minimapScale) throw new IllegalStateException("Minimap editor resize failed");
				assertMapResize(minimapWidth, minimapScale);
				assertMapClear(mc, true);
				shot(mc, "minimap-editor");
			}
			case 570 -> { if (minimap != null) mc.gui.setScreen(null); }
			case 573 -> { if (minimap != null) minimap.scale.set(0.5); }
			case 578 -> {
				if (minimap == null) break;
				assertMapResize(minimapWidth, minimapScale);
				assertMapClear(mc, false);
				minimap.scale.set(minimapResizedScale);
			}
			case 585 -> {
				if (minimap == null) break;
				assertMapClear(mc, false);
				var moved = minimap.position();
				double resized = minimap.scale.get();
				dev.goonclient.client.config.ConfigManager.save();
				minimap.resetPosition();
				dev.goonclient.client.config.ConfigManager.load();
				if (!minimap.position().equals(moved) || minimap.scale.get() != resized) throw new IllegalStateException("Minimap layout didn't survive config reload");
				shot(mc, "minimap-moved");
			}
			case 590 -> {
				if (minimap == null) break;
				minimap.setEnabled(false);
			}
			case 600 -> { if (minimap != null) shot(mc, "minimap-hidden"); }
			case 605 -> {
				if (minimap == null) break;
				minimap.setEnabled(true);
				minimap.resetPosition();
				mc.options.guiScale().set(2);
				mc.resizeGui();
			}
			case 625 -> {
				if (minimap == null) break;
				assertMapClear(mc, false);
				shot(mc, "minimap-scale2");
			}
			case 610 -> {
				if (minimap == null) break;
				minimapWidth = minimap.screenWidth();
				minimap.scale.set(2.0);
			}
			case 618 -> {
				if (minimap == null) break;
				assertMapResize(minimapWidth, 1.0);
				assertMapClear(mc, false);
				minimap.scale.set(1.0);
			}
			case 630 -> {
				if (minimap == null) break;
				mc.options.guiScale().set(4);
				mc.resizeGui();
				dev.goonclient.client.compat.XaeroCompat.enlarged(true);
			}
			case 650 -> {
				if (minimap == null) break;
				assertMapClear(mc, false);
				shot(mc, "minimap-enlarged");
			}
			case 655 -> {
				if (minimap == null) break;
				dev.goonclient.client.compat.XaeroCompat.enlarged(false);
				mc.options.guiScale().set(originalGuiScale);
				mc.resizeGui();
				minimap.setPosition(minimapPosition);
				minimap.scale.set(minimapScale);
				menu = new ClickGuiScreen(null);
				mc.gui.setScreen(menu);
				menu.openSettingsFor(minimap);
			}
			case 680 -> { if (minimap != null) shot(mc, "minimap-settings"); }
			case 685 -> {
				if (minimap != null) {
					((dev.goonclient.client.module.setting.ButtonSetting) minimap.settings().stream()
						.filter(s -> s.id().equals("map_settings")).findFirst().orElseThrow()).press();
				}
			}
			case 700 -> {
				if (minimap == null) break;
				if (!mc.gui.screen().getClass().getName().startsWith("xaero.")) throw new IllegalStateException("Native minimap settings didn't open");
				shot(mc, "minimap-native-settings");
			}
			case 695 -> {
				if (minimap == null) break;
				var button = mc.gui.screen().children().stream()
					.filter(w -> w instanceof net.minecraft.client.gui.components.Button b && b.getMessage().getString().equals("Change Position"))
					.map(w -> (net.minecraft.client.gui.components.Button) w).findFirst().orElseThrow();
				mc.gui.screen().mouseClicked(new net.minecraft.client.input.MouseButtonEvent(button.getX() + 3, button.getY() + 3,
					new net.minecraft.client.input.MouseButtonInfo(com.mojang.blaze3d.platform.InputConstants.MOUSE_BUTTON_LEFT, 0)), false);
				if (!(mc.gui.screen() instanceof HudEditorScreen)) throw new IllegalStateException("Xaero Change Position didn't open Goon HUD editor");
			}
			case 697 -> { if (minimap != null) mc.gui.screen().onClose(); }
			case 702 -> {
				if (minimap == null) break;
				mc.gui.screen().onClose();
				if (mc.gui.screen() != menu) throw new IllegalStateException("Minimap settings didn't return to ClickGUI");
			}
			case 704 -> {
				if (minimap != null) {
					minimap.setEnabled(minimapEnabled);
					dev.goonclient.client.config.ConfigManager.save();
				}
			}
			case 705 -> {
				menu = new ClickGuiScreen(null); mc.gui.setScreen(menu);
				ClickGuiChecks.all(menu);
				mc.options.guiScale().set(2); mc.resizeGui();
			}
			case 712 -> ClickGuiChecks.bottom(menu);
			case 720 -> { ClickGuiChecks.verify(menu); shot(mc, "menu-scroll-scale2"); }
			case 722 -> { mc.options.guiScale().set(3); mc.resizeGui(); }
			case 730 -> { ClickGuiChecks.verify(menu); shot(mc, "menu-scroll-scale3"); }
			case 732 -> { menu.openSettingsFor(ModuleManager.all().stream().filter(m -> m.id().equals("interface")).findFirst().orElseThrow()); }
			case 740 -> ClickGuiChecks.bottom(menu);
			case 748 -> { ClickGuiChecks.verify(menu); shot(mc, "settings-scroll"); }
			case 750 -> { mc.options.guiScale().set(originalGuiScale); mc.resizeGui(); }
			case 752 -> {
				dev.goonclient.client.cosmetics.Cosmetics.equip("nation_noir");
				mc.gui.setScreen(new dev.goonclient.client.gui.CosmeticsScreen(menu));
			}
			case 760 -> shot(mc, "wardrobe");
			case 762 -> {
				mc.gui.setScreen(null);
				mc.options.setCameraType(net.minecraft.client.CameraType.THIRD_PERSON_BACK);
				run(mc, "item replace entity @s armor.chest with air");
			}
			case 775 -> shot(mc, "cape-third-person");
			case 776 -> { mc.options.setCameraType(net.minecraft.client.CameraType.FIRST_PERSON); dev.goonclient.client.cosmetics.Cosmetics.equip("none"); }
			case 780 -> {
				if (minimap != null) {
					minimap.setEnabled(minimapEnabled);
					dev.goonclient.client.config.ConfigManager.save();
					Goon.LOGGER.info("Dev minimap: drag/resize, config reload, hidden state, GUI scale changes, enlarged map, native navigation and collision checks passed");
				}
				mc.options.pauseOnLostFocus = originalFocusPause;
				// Leave the world to see the main menu
				ticksOnTitle = 0;
				mc.disconnect(new TitleScreen(), false);
			}
			default -> {
			}
		}
	}

	private static final class PanoramaOnly extends Screen {
		private PanoramaOnly() {
			super(Component.empty());
		}

		@Override
		public void extractBackground(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
			extractPanorama(g, partialTick);
		}
	}

	private static void setMenuBackground(String mode) {
		setInterface("menu_background", mode);
	}

	private static void assertMapClear(Minecraft mc, boolean editing) {
		var map = new dev.goonclient.client.hud.HudLayout.Rect(minimap.screenX(), minimap.screenY(), minimap.screenWidth(), minimap.screenHeight());
		for (var hud : ModuleManager.hudModules()) {
			if (hud == minimap || !hud.isEnabled() || (!editing && !hud.isVisible(mc))) continue;
			if (hud.screenWidth() <= 2 || hud.screenHeight() <= 2) continue;
			var rect = new dev.goonclient.client.hud.HudLayout.Rect(hud.screenX(), hud.screenY(), hud.screenWidth(), hud.screenHeight());
			if (map.overlaps(rect)) throw new IllegalStateException("Minimap overlaps " + hud.id() + ": " + map + " vs " + rect);
		}
		Goon.LOGGER.info("Dev minimap bounds: {} native PIP {} GUI scale {}", map, dev.goonclient.client.compat.XaeroCompat.drawnBounds(), mc.getWindow().getGuiScale());
	}

	private static void assertMapResize(int width, double scale) {
		double expectedRatio = minimap.scale.get() / scale;
		double actualRatio = (minimap.screenWidth() - 6.0) / (width - 6.0);
		if (Math.abs(actualRatio - expectedRatio) > 0.04) throw new IllegalStateException("Native auto size cancelled Goon resize: expected " + expectedRatio + " got " + actualRatio);
		Goon.LOGGER.info("Dev minimap resize: {} -> {} GUI units, scale {} -> {}", width, minimap.screenWidth(), scale, minimap.scale.get());
	}

	private static String interfaceValues() {
		return ModuleManager.all().stream().filter(m -> m.id().equals("interface")).findFirst().orElseThrow().settings().stream()
			.filter(s -> s.id().equals("menu_blur") || s.id().equals("menu_background"))
			.map(s -> s.id() + "=" + s.toJson()).collect(java.util.stream.Collectors.joining(","));
	}

	private static void setInterface(String id, String value) {
		for (Module module : ModuleManager.all()) {
			if (module.id().equals("interface")) {
				module.settings().stream().filter(setting -> setting.id().equals(id)).findFirst()
					.ifPresent(setting -> ((dev.goonclient.client.module.setting.ModeSetting) setting).set(value));
			}
		}
	}

	private static void setEnabled(List<String> ids, boolean on) {
		for (Module module : ModuleManager.all()) {
			if (ids.contains(module.id())) {
				restore.putIfAbsent(module, module.isEnabled());
				module.loadEnabled(on);
			}
		}
	}

	/** Runs a command as the player on the singleplayer server, so it works even with cheats off. */
	private static void run(Minecraft mc, String command) {
		IntegratedServer server = mc.getSingleplayerServer();
		if (server != null) {
			server.execute(() -> server.getCommands().performPrefixedCommand(
				server.createCommandSourceStack().withSuppressedOutput(), "execute as @p at @p run " + command));
		}
	}

	private static void shot(Minecraft mc, String name) {
		Goon.LOGGER.info("Dev snapshot: {}", name);
		screenshotPending = true;
		// Named files and no "Saved screenshot" chat line
		Screenshot.grab(mc.gameDirectory, "goon-" + name + ".png", mc.gameRenderer.mainRenderTarget(), 1, message -> {
			screenshotPending = false;
		});
	}
}
