package dev.goonclient.client.modules.hud;

import dev.goonclient.client.gui.Ui;
import dev.goonclient.client.gui.render.Px;
import dev.goonclient.client.gui.render.Shapes;
import dev.goonclient.client.hud.HudModule;
import dev.goonclient.client.hud.HudPosition;
import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.setting.BooleanSetting;
import dev.goonclient.client.module.setting.NumberSetting;
import java.util.Arrays;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/** Frame-time graph: one bar per frame, with average, 1% low and the worst frame, so stutters show up at a glance. */
public class FrameGraph extends HudModule {
	private static final int SAMPLES = 120;
	private static final int PAD = 5;
	private static final float TARGET_MS = 1000f / 60f;

	private final NumberSetting graphHeight = add(new NumberSetting("graph_height", "Graph height", 20, 14, 48, 1));
	private final BooleanSetting stats = add(new BooleanSetting("stats", "Average, 1% low and worst frame", true));

	private final float[] frames = new float[SAMPLES];
	private final float[] sorted = new float[SAMPLES];
	private final float[] boxes = new float[SAMPLES * 4];
	private int next;
	private int filled;
	private long last;

	public FrameGraph() {
		super("frame_graph", "FPS Graph", "Frame times as a live graph with average, 1% low and the worst frame", Category.HUD, false, HudPosition.topRight(2, 2));
        add(new dev.goonclient.client.module.setting.ButtonSetting("notebook", "Performance Notebook", "Open", () -> {var mc=net.minecraft.client.Minecraft.getInstance(); dev.goonclient.client.GoonClient.openNextTick(new dev.goonclient.client.gui.PerformanceNotebookScreen(mc.gui.screen()));}));
	}

	@Override protected void measure(Minecraft mc, boolean editing) {

		Font font = mc.font;
		int graphW = SAMPLES;
		int graphH = graphHeight.intValue();
		int width = graphW + PAD * 2;
		int headerH = 11;
		int footerH = stats.isOn() ? 11 : 0;
		int height = PAD + headerH + graphH + footerH + PAD - (stats.isOn() ? 0 : 1);

		setSize(width, height);
	}

	@Override
	protected void render(GuiGraphicsExtractor g, Minecraft mc, boolean editing) {
		sample();
		Font font = mc.font;
		int graphW = SAMPLES;
		int graphH = graphHeight.intValue();
		int width = graphW + PAD * 2;
		int headerH = 11;
		int footerH = stats.isOn() ? 11 : 0;
		int height = PAD + headerH + graphH + footerH + PAD - (stats.isOn() ? 0 : 1);

		Ui.roundRect(g, 0, 0, width, height, 4, Ui.HUD_BACKGROUND);

		// Header: current FPS, and the frame time it works out to
		int fps = mc.getFps();
		String fpsText = Integer.toString(fps);
		Ui.bold(g, font, fpsText, PAD, PAD, fps < 30 ? Ui.BAD : fps < 60 ? Ui.WARN : Ui.TEXT, true);
		Ui.text(g, font, "FPS", PAD + Ui.boldWidth(font, fpsText) + 3, PAD, Ui.MUTED, true);
		float average = average();
		String ms = filled == 0 ? "-" : String.format("%.1f ms", average);
		Ui.text(g, font, ms, width - PAD - Ui.width(font, ms), PAD, Ui.FAINT, true);

		// Graph: the 60 FPS line sits two thirds of the way up until a slower frame needs the room. The scale eases
		// to its new value so one spike doesn't make the whole graph jump.
		int gx = PAD;
		int gy = PAD + headerH;
		Shapes.rect(g, gx, gy, gx + graphW, gy + graphH, 0x40000000);
		float worst = worst();
		float scale = Ui.animate("frame_graph:scale", Math.max(TARGET_MS * 1.5f, worst * 1.15f), 0.3f);
		float guideY = gy + graphH - graphH * (TARGET_MS / scale);
		// A hairline at 60 FPS
		Shapes.rect(g, gx, guideY, gx + graphW, guideY + 1f / Px.length(g, 1f), 0x30FFFFFF);
		float spike = Math.max(TARGET_MS * 2f, average * 2.5f);
		drawBars(g, gx, gy, graphH, scale, 0, spike, Ui.withAlpha(Ui.MUTED, 0.85f));
		drawBars(g, gx, gy, graphH, scale, spike, 50f, Ui.WARN);
		drawBars(g, gx, gy, graphH, scale, 50f, Float.MAX_VALUE, Ui.BAD);

		if (stats.isOn()) {
			int fy = gy + graphH + 3;
			String avg = "avg " + (filled == 0 ? "-" : Math.round(1000f / Math.max(0.01f, average)));
			String low = "1% " + (filled == 0 ? "-" : Math.round(1000f / Math.max(0.01f, percentile(0.99f))));
			String max = "max " + (filled == 0 ? "-" : String.format("%.0f ms", worst));
			Ui.text(g, font, avg, PAD, fy, Ui.MUTED, true);
			Ui.text(g, font, low, PAD + graphW / 2 - Ui.width(font, low) / 2, fy, Ui.MUTED, true);
			Ui.text(g, font, max, width - PAD - Ui.width(font, max), fy, Ui.MUTED, true);
		}
		setSize(width, height);
	}

	/** Frame-to-frame time. The HUD draws once per frame, so this is the real frame time while the HUD is visible. */
	private void sample() {
		long now = System.nanoTime();
		if (last != 0) {
			float ms = (now - last) / 1_000_000f;
			// Ignore pauses (alt-tab, loading screens) so one huge bar doesn't flatten the graph for two seconds
			if (ms < 1000f) {
				frames[next] = ms;
				next = (next + 1) % SAMPLES;
				filled = Math.min(SAMPLES, filled + 1);
			}
		}
		last = now;
	}

	/** Bars whose frame time is in [from, to), oldest on the left, as one batched draw. */
	private void drawBars(GuiGraphicsExtractor g, int gx, int gy, int graphH, float scale, float from, float to, int color) {
		int count = 0;
		for (int i = 0; i < filled; i++) {
			// Newest frame on the right edge
			float ms = frames[Math.floorMod(next - filled + i, SAMPLES)];
			if (ms < from || ms >= to) {
				continue;
			}
			float x = gx + SAMPLES - filled + i;
			float h = Math.max(1f, Math.min(graphH, graphH * ms / scale));
			boxes[count * 4] = x;
			boxes[count * 4 + 1] = gy + graphH - h;
			boxes[count * 4 + 2] = x + 1;
			boxes[count * 4 + 3] = gy + graphH;
			count++;
		}
		Shapes.rects(g, boxes, count, color);
	}

	private float average() {
		if (filled == 0) {
			return 0;
		}
		float sum = 0;
		for (int i = 0; i < filled; i++) {
			sum += frames[i];
		}
		return sum / filled;
	}

	private float worst() {
		float worst = 0;
		for (int i = 0; i < filled; i++) {
			worst = Math.max(worst, frames[i]);
		}
		return worst;
	}

	private float percentile(float p) {
		System.arraycopy(frames, 0, sorted, 0, filled);
		Arrays.sort(sorted, 0, filled);
		return sorted[Math.min(filled - 1, (int) (filled * p))];
	}
}
