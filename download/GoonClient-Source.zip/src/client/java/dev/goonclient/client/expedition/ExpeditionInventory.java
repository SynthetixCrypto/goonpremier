package dev.goonclient.client.expedition;

import java.util.*;
import net.minecraft.client.Minecraft;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;

/** Reads carried player slots only. Never reads menus, cursor stacks, containers or nested item components. */
public final class ExpeditionInventory {
    private ExpeditionInventory() {}
    public record Snapshot(boolean available, Map<String, Integer> counts) {
        public Snapshot { counts = Map.copyOf(counts); }
        public int count(String item) { return counts.getOrDefault(item, 0); }
    }
    private static final EquipmentSlot[] EQUIPMENT = {
            EquipmentSlot.OFFHAND, EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET
    };

    public static Snapshot capture(Minecraft mc) {
        if (mc == null || mc.player == null || mc.level == null) return new Snapshot(false, Map.of());
        Map<String, Integer> counts = new HashMap<>();
        // getNonEquipmentItems includes hotbar/main inventory. MAINHAND would count the selected stack twice.
        for (ItemStack stack : mc.player.getInventory().getNonEquipmentItems()) add(counts, stack);
        for (EquipmentSlot slot : EQUIPMENT) add(counts, mc.player.getItemBySlot(slot));
        return new Snapshot(true, counts);
    }

    private static void add(Map<String, Integer> counts, ItemStack stack) {
        if (!stack.isEmpty()) counts.merge(BuiltInRegistries.ITEM.getKey(stack.getItem()).toString(), stack.getCount(), Integer::sum);
    }
}
