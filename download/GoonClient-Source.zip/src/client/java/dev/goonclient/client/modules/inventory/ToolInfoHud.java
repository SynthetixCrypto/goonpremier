package dev.goonclient.client.modules.inventory;

import dev.goonclient.client.gui.render.Icons;
import dev.goonclient.client.gui.Ui;
import dev.goonclient.client.hud.HudPosition;
import dev.goonclient.client.hud.TextHudModule;
import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.setting.BooleanSetting;
import dev.goonclient.client.module.setting.NumberSetting;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.item.enchantment.Enchantment;

/** Only the local held stack is inspected. */
public final class ToolInfoHud extends TextHudModule {
    private final BooleanSetting enchantments = add(new BooleanSetting("enchantments", "Show enchantments", true));
    private final NumberSetting maximum = add(new NumberSetting("maximum", "Maximum enchantments", 4, 1, 8, 1));
    public ToolInfoHud() {
        super("tool_info", "Tool Info", "Held-item name, remaining durability and readable enchantment levels", Category.INVENTORY, false, HudPosition.bottomRight(2, 90));
    }

    @Override
    protected Icons.Icon icon() {
    	return Icons.Icon.COG;
    }
    @Override public boolean isVisible(Minecraft mc) { return mc.player != null && !mc.player.getMainHandItem().isEmpty(); }
    @Override protected void collect(Minecraft mc, List<Line> lines, boolean editing) {
        if (mc.player == null || mc.player.getMainHandItem().isEmpty()) {
            if (editing) { lines.add(new Line("", "Diamond Pickaxe", Ui.TEXT)); lines.add(new Line("Durability", "1234 / 1561")); lines.add(new Line("", "Efficiency V", Ui.MUTED)); }
            return;
        }
        var stack = mc.player.getMainHandItem();
        lines.add(new Line("", Ui.ellipsize(mc.font, stack.getHoverName().getString(), 190, true), Ui.TEXT));
        if (stack.isDamageableItem()) {
            int left = Math.max(0, Math.min(stack.getMaxDamage(), stack.getMaxDamage() - stack.getDamageValue()));
            lines.add(new Line("Durability", left + " / " + stack.getMaxDamage(), left <= stack.getMaxDamage() * .1 ? Ui.WARN : Ui.TEXT));
        } else if (stack.getMaxStackSize() > 1) lines.add(new Line("Stack", stack.getCount() + " / " + stack.getMaxStackSize()));
        var stored = stack.get(DataComponents.ENCHANTMENTS);
        if (stored == null || stored.isEmpty()) stored = stack.get(DataComponents.STORED_ENCHANTMENTS);
        if (enchantments.isOn() && stored != null) {
            var names = new ArrayList<String>();
            for (var entry : stored.entrySet()) names.add(Enchantment.getFullname(entry.getKey(), entry.getIntValue()).getString());
            names.sort(Comparator.naturalOrder());
            for (int i = 0; i < Math.min(names.size(), maximum.intValue()); i++) lines.add(new Line("", Ui.ellipsize(mc.font, names.get(i), 190, false), Ui.MUTED));
            if (names.size() > maximum.intValue()) lines.add(new Line("", "+" + (names.size() - maximum.intValue()) + " enchantments", Ui.MUTED));
        }
    }
}
