package dev.goonclient.client.mixin.ipn;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Goon excludes IPN's continuous crafting for both grids and stonecutters, even with old saved settings. */
@Mixin(targets={"org.anti_ad.mc.ipnext.event.ContinuousCraftingHandler",
        "org.anti_ad.mc.ipnext.event.CutterCraftingHandlerBase"}, remap=false)
public abstract class AutoCraftingMixin {
    @Inject(method="getEnabled()Z", at=@At("HEAD"), cancellable=true, remap=false)
    private void goonclient$noAutoCrafting(CallbackInfoReturnable<Boolean> cir) {
        cir.setReturnValue(false);
    }
}
