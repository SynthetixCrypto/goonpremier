package dev.goonclient.client.gui;

import com.mojang.blaze3d.platform.InputConstants;
import dev.goonclient.client.config.ConfigManager;
import dev.goonclient.client.gui.render.GoonFont;
import dev.goonclient.client.gui.render.Icons;
import dev.goonclient.client.gui.render.Shapes;
import dev.goonclient.client.hud.HudModule;
import dev.goonclient.client.module.ModuleManager;
import dev.goonclient.client.module.setting.BooleanSetting;
import dev.goonclient.client.module.setting.ButtonSetting;
import dev.goonclient.client.module.setting.ModeSetting;
import dev.goonclient.client.module.setting.NumberSetting;
import dev.goonclient.client.module.setting.Setting;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;

/**
 * Move, resize and hide HUD panels over the live game. A faint grid and snap guides help line things up, the
 * Elements drawer turns panels on and off, and everything animates in.
 */
public class HudEditorScreen extends Screen {
	/** GUI units a drag must move before it counts as a drag (a plain click only selects), and the snap reach. */
	private static final double DRAG_THRESHOLD = 2.5, SNAP = 3.5;
	private static final float GRID = 16;
	private static final float DRAWER = 170;
	private static final float SIZE = 8.2f;
	private static final float SMALL = 7.4f;

	private final Screen parent;
	private final List<Hit> hits = new ArrayList<>();
	private HudModule dragging;
    private HudModule inspected;
    private boolean onlySelected;
    private float inspectorX, inspectorY;

    /** Also used by the visual-only menu capture; no world access is required. */
    public void inspect(HudModule module) { inspected=module; drawerOpen=false; }

	private double grabX, grabY, pressX, pressY;
	private boolean dragActive;
	private float guideX = -1, guideY = -1;
	/** Which side the inspector sits on: opposite the selected panel, so it never covers what you're moving. */
	private boolean inspectorOnLeft;
	private boolean drawerOpen;
	private float drawerScroll;
	private float drawerX1;
	private float drawerY1;
	private float drawerY2;
	private float drawerContent;
	private long openedAt;

	public HudEditorScreen(Screen parent) {
		super(Component.literal("Edit HUD"));
		this.parent = parent;
	}

	@Override
	protected void init() {
        hits.clear(); dragging=null; numberDragging=null;
        inspectorX=Math.max(4,width-174); inspectorY=Math.max(4,Math.min(70,height-216));
		if (openedAt == 0) {
			openedAt = System.currentTimeMillis();
		}
	}

	@Override
	public void extractBackground(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
		// Use a menu backdrop when there is no world behind the editor.
		if (minecraft.level == null) extractPanorama(g, partialTick);
		// Keep a loaded world visible so placement uses the live HUD.
		float open = Ui.easeOutCubic((System.currentTimeMillis() - openedAt) / 300f);
		g.fill(0, 0, width, height, Ui.withAlpha(0x18000000, open));
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
		Ui.beginFrame();
		hits.clear();
		float open = Ui.easeOutCubic((System.currentTimeMillis() - openedAt) / 320f);

		drawGrid(g, open * Ui.animate("hudedit:grid", dragging != null ? 1f : 0f, .6f));
        if(minecraft.level==null && dev.goonclient.client.modules.utility.Interface.glassHotbar()) {
            HotbarStyle.background(g,width/2-91,height-22,182,22);
            HotbarStyle.selected(g,width/2-92,height-23,24,23);
        }

		HudModule hovered = dragging != null ? dragging : moduleAt(mouseX, mouseY);
		HudModule.beginLayout(width, height);
		reserveControls();
		for (HudModule module : HudModule.layoutOrder(ModuleManager.hudModules())) {
			if (!module.isEnabled() || (onlySelected && inspected != null && module != inspected)) {
				continue;
			}
			boolean active = module == hovered || module == inspected;
			float h = Ui.animate("hudedit:" + module.id(), active ? 1f : 0f, 0.6f);
			float l = Ui.animate("hudedit:lift:" + module.id(), module == dragging ? 1f : 0f, 0.6f);
			module.renderAt(g, minecraft, width, height, true);
			float x1 = module.screenX() - 2;
			float y1 = module.screenY() - 2;
			float x2 = module.screenX() + module.screenWidth() + 2;
			float y2 = module.screenY() + module.screenHeight() + 2;
			if (l > 0.01f) {
				Shapes.shadow(g, x1, y1, x2, y2, 5, 10, 3, 0.5f * l);
			}
			Shapes.roundRect(g, x1, y1, x2, y2, 5, Ui.withAlpha(Ui.accent(), 0.08f * h * open));
			Shapes.outline(g, x1, y1, x2, y2, 5, Ui.withAlpha(Ui.lerp(h, 0x40FFFFFF, Ui.accent()), open));
		}

		// Snap guides fade in while dragging
		float guides = Ui.animate("hudedit:guides", dragging != null ? 1f : 0f, 0.6f);
		if (guides > 0.01f) {
			if (guideX >= 0) {
				Shapes.rect(g, guideX, 0, guideX + 0.5f, height, Ui.withAlpha(Ui.accent(), 0.8f * guides));
			}
			if (guideY >= 0) {
				Shapes.rect(g, 0, guideY, width, guideY + 0.5f, Ui.withAlpha(Ui.accent(), 0.8f * guides));
			}
		}

		if (hovered != null) {
			drawLabel(g, hovered);
		}
		drawDrawer(g, mouseX, mouseY, open);
		drawChrome(g, mouseX, mouseY, open);
		super.extractRenderState(g, mouseX, mouseY, partialTick);
	}

	/** Opens with the Elements drawer showing. */
	public void showElements() {
		drawerOpen = true;
	}

	private void drawGrid(GuiGraphicsExtractor g, float open) {
		int line = Ui.withAlpha(0x0FFFFFFF, open);
		for (float x = GRID; x < width; x += GRID) {
			Shapes.rect(g, x, 0, x + 0.34f, height, line);
		}
		for (float y = GRID; y < height; y += GRID) {
			Shapes.rect(g, 0, y, width, y + 0.34f, line);
		}
		// Centre lines a little stronger
		int centre = Ui.withAlpha(0x26FFFFFF, open);
		Shapes.rect(g, width / 2f, 0, width / 2f + 0.34f, height, centre);
		Shapes.rect(g, 0, height / 2f, width, height / 2f + 0.34f, centre);
	}

	private void drawLabel(GuiGraphicsExtractor g, HudModule module) {
		String name = module.name();
		String size = Math.round(module.scale.get() * 100) + "%";
		float nw = GoonFont.width(name, SMALL, GoonFont.Weight.BOLD);
		float sw = GoonFont.width(size, SMALL, GoonFont.Weight.REGULAR);
		float w = nw + sw + 18;
		float lx = Math.max(2, Math.min(module.screenX() - 2, width - w - 2));
		float ly = module.screenY() > 18 ? module.screenY() - 17 : module.screenY() + module.screenHeight() + 5;
		Shapes.panel(g, lx, ly, lx + w, ly + 13, 6.5f, 0xF0131416, Ui.BORDER_STRONG);
		GoonFont.draw(g, name, lx + 7, ly + 3, SMALL, GoonFont.Weight.BOLD, Ui.TEXT, false);
		GoonFont.draw(g, size, lx + 11 + nw, ly + 3, SMALL, GoonFont.Weight.REGULAR, Ui.MUTED, false);
	}

	private String hintText() {
		return (minecraft.player == null || minecraft.level == null ? "Preview • " : "")
			+ "Drag to move   Scroll to resize   Right-click to hide   Esc when you're done";
	}

	/**
	 * The editor shows panels exactly where they are. Its own controls (inspector, drawer, hints, switch) float on top
	 * and reserve nothing, so opening or closing them never makes a panel jump.
	 */
	private void reserveControls() {
	}

	/** A panel on the left listing every HUD element with a switch, so hidden ones can be brought back. Scrolls if needed. */
	private void drawDrawer(GuiGraphicsExtractor g, int mouseX, int mouseY, float open) {
		float slide = Ui.animate("hudedit:drawer", drawerOpen ? 1f : 0f, 0.5f);
		if (slide < 0.01f) {
			drawerY2 = 0;
			return;
		}
		List<HudModule> modules = ModuleManager.hudModules();
		float rowHeight = 20;
		drawerContent = modules.size() * rowHeight;
		// Sits below the toolbar and stops above the hint
		float y1 = 70;
		float h = Math.min(34 + drawerContent + 8, height - y1 - 30);
		float x1 = 8 - (1 - slide) * (DRAWER + 16);
		drawerX1 = x1;
		drawerY1 = y1;
		drawerY2 = y1 + h;
		float alpha = slide * open;
		Shapes.shadow(g, x1, y1, x1 + DRAWER, y1 + h, 10, 14, 4, 0.5f * alpha);
		GlassUi.panel(g,x1,y1,DRAWER,h,alpha);
		GoonFont.draw(g, "Elements", x1 + 12, y1 + 11, 9.4f, GoonFont.Weight.BOLD, Ui.withAlpha(Ui.TEXT, alpha), false);
		long on = modules.stream().filter(HudModule::isEnabled).count();
		String count = on + " of " + modules.size() + " on";
		float cw = GoonFont.width(count, SMALL, GoonFont.Weight.REGULAR);
		GoonFont.draw(g, count, x1 + DRAWER - 12 - cw, y1 + 12, SMALL, GoonFont.Weight.REGULAR, Ui.withAlpha(Ui.MUTED, alpha), false);

		float listTop = y1 + 32;
		float listBottom = y1 + h - 6;
		drawerScroll = Math.max(0, Math.min(drawerScroll, Math.max(0, drawerContent - (listBottom - listTop))));
		float scroll = Ui.animate("hudedit:drawerScroll", drawerScroll, 0.55f);
		g.enableScissor((int) x1 + 1, (int) listTop, (int) (x1 + DRAWER) - 1, (int) listBottom);
		float y = listTop - scroll;
		for (HudModule module : modules) {
			if (y + rowHeight > listTop && y < listBottom) {
				boolean hover = Ui.inside(mouseX, mouseY, x1 + 4, Math.max(y, listTop), x1 + DRAWER - 4, Math.min(y + rowHeight, listBottom));
				float hv = Ui.animate("hudedit:row:" + module.id(), hover ? 1f : 0f, 0.6f);
				if (hv > 0.01f) {
					Shapes.roundRect(g, x1 + 4, y, x1 + DRAWER - 4, y + rowHeight, 6, Ui.withAlpha(0x0FFFFFFF, hv * alpha));
				}
				GoonFont.draw(g, Ui.ellipsize(module.name(), DRAWER - 60, SIZE, GoonFont.Weight.REGULAR), x1 + 12, y + 6, SIZE, GoonFont.Weight.REGULAR,
					Ui.withAlpha(module.isEnabled() ? Ui.TEXT : Ui.MUTED, alpha), false);
				Ui.toggleSwitch(g, x1 + DRAWER - 32, y + 5, Ui.animate("hudedit:on:" + module.id(), module.isEnabled() ? 1f : 0f, 0.42f), alpha);
				hits.add(new Hit(x1 + 4, Math.max(y, listTop), x1 + DRAWER - 4, Math.min(y + rowHeight, listBottom), module::toggle));
			}
			y += rowHeight;
		}
		g.disableScissor();
	}


	/**
	 * The panel under the pointer, with a little slack so small ones are easy to grab. Where panels overlap, the
	 * selected one wins, then the smallest (the one on top).
	 */
	private HudModule moduleAt(double mouseX, double mouseY) {
		HudModule best = null;
		long bestArea = Long.MAX_VALUE;
		for (HudModule module : ModuleManager.hudModules()) {
			if (!module.isEnabled() || (onlySelected && inspected != null && module != inspected) || module.screenWidth() < 3) continue;
			if (mouseX < module.screenX() - 2 || mouseX >= module.screenX() + module.screenWidth() + 2
				|| mouseY < module.screenY() - 2 || mouseY >= module.screenY() + module.screenHeight() + 2) continue;
			if (module == inspected && module.contains(mouseX, mouseY)) return module;
			long area = (long) module.screenWidth() * module.screenHeight();
			if (area < bestArea) {
				best = module;
				bestArea = area;
			}
		}
		return best;
	}

	@Override
	public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
		clickX = event.x();
		clickY = event.y();
        if(event.button()!=InputConstants.MOUSE_BUTTON_LEFT && event.button()!=InputConstants.MOUSE_BUTTON_RIGHT)return true;
		for (int i = hits.size() - 1; i >= 0; i--) {
			Hit hit = hits.get(i);
			if (Ui.inside(event.x(), event.y(), hit.x1, hit.y1, hit.x2, hit.y2)) {
				minecraft.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, 1.0f));
				if(event.button()==InputConstants.MOUSE_BUTTON_LEFT){hit.action.run();updateSlider(event.x());}
				return true;
			}
		}
		if(inspected!=null && Ui.inside(event.x(),event.y(),inspX1,inspY1,inspX2,inspY2))return true;
        // Clicks on the drawer itself never fall through to the panels behind it
		if (drawerOpen && Ui.inside(event.x(), event.y(), drawerX1, drawerY1, drawerX1 + DRAWER, drawerY2)) {
			return true;
		}
		HudModule module = moduleAt(event.x(), event.y());
		if (module != null) {
			if (event.button() == InputConstants.MOUSE_BUTTON_RIGHT) {
				module.setEnabled(false);
				if (module == inspected) inspected = null;
			} else {
				if (module != inspected) {
					inspected = module;
					inspectorScroll = 0;
				}
				inspectorOnLeft = module.screenX() + module.screenWidth() / 2.0 > width / 2.0;
				dragging = module;
				dragActive = false;
				pressX = event.x();
				pressY = event.y();
				grabX = event.x() - module.screenX();
				grabY = event.y() - module.screenY();
			}
			return true;
		}
		// Clicking empty space lets go of the selection and closes its inspector
		if (event.button() == InputConstants.MOUSE_BUTTON_LEFT && inspected != null) {
			inspected = null;
			onlySelected = false;
			return true;
		}
		return super.mouseClicked(event, doubleClick);
	}

	@Override
	public boolean mouseDragged(MouseButtonEvent event, double dragX, double dragY) {
		if (numberDragging != null) {
			updateSlider(event.x());
			return true;
		}
		if (inspDragging) {
			inspUserX = (float) (event.x() / cs) - inspGrabX;
			inspUserY = (float) (event.y() / cs) - inspGrabY;
			return true;
		}
		if (dragging == null) {
			return super.mouseDragged(event, dragX, dragY);
		}
		// A click only selects; the panel starts following once the pointer has really moved
		if (!dragActive) {
			if (Math.hypot(event.x() - pressX, event.y() - pressY) < DRAG_THRESHOLD) return true;
			dragActive = true;
		}
		double w = dragging.screenWidth(), h = dragging.screenHeight();
		double left = event.x() - grabX, top = event.y() - grabY;
		guideX = guideY = -1;
		if (!event.hasAltDown()) {
			double[] sx = snap(left, w, true), sy = snap(top, h, false);
			left = sx[0];
			guideX = (float) sx[1];
			top = sy[0];
			guideY = (float) sy[1];
		}
		int x = (int) Math.round(Math.max(0, Math.min(width - w, left)));
		int y = (int) Math.round(Math.max(0, Math.min(height - h, top)));
		dragging.moveTo(x, y, width, height);
		return true;
	}

	/**
	 * Snaps one axis: the dragged panel's start, middle and end against the screen's edges and centre and against every
	 * other panel's. Returns {snapped start, guide line position or -1}. Holding Alt skips this.
	 */
	private double[] snap(double start, double size, boolean horizontal) {
		double limit = horizontal ? width : height;
		List<Double> targets = new ArrayList<>(List.of(0.0, limit / 2, limit));
		for (HudModule other : ModuleManager.hudModules()) {
			if (other == dragging || !other.isEnabled() || other.screenWidth() < 3 || other.screenHeight() < 3) continue;
			double a = horizontal ? other.screenX() : other.screenY();
			double length = horizontal ? other.screenWidth() : other.screenHeight();
			targets.add(a);
			targets.add(a + length / 2);
			targets.add(a + length);
		}
		double best = SNAP, position = start, guide = -1;
		for (double target : targets) {
			for (double offset : new double[]{0, size / 2, size}) {
				double delta = target - (start + offset);
				if (Math.abs(delta) < best) {
					best = Math.abs(delta);
					position = start + delta;
					guide = target;
				}
			}
		}
		return new double[]{position, guide};
	}

	@Override
	public boolean mouseReleased(MouseButtonEvent event) {
        numberDragging=null;
		inspDragging = false;
		if (dragging != null && dragActive) inspectorOnLeft = dragging.screenX() + dragging.screenWidth() / 2.0 > width / 2.0;
		dragging = null;
		dragActive = false;
		guideX = -1;
		guideY = -1;
		return super.mouseReleased(event);
	}

	@Override
	public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        if(inspected!=null && Ui.inside(mouseX,mouseY,inspX1,inspY1,inspX2,inspY2)){inspectorScroll-=(float)scrollY*24f;return true;}
		if (drawerOpen && Ui.inside(mouseX, mouseY, drawerX1, drawerY1, drawerX1 + DRAWER, drawerY2)) {
			drawerScroll -= (float) scrollY * 30f;
			return true;
		}
		HudModule module = moduleAt(mouseX, mouseY);
		if (module != null) {
			module.scale.set(module.scale.get() + scrollY * 0.05);
			ConfigManager.markDirty();
			return true;
		}
		return true;
	}

	@Override
	public boolean keyPressed(KeyEvent event) {
		// Arrow keys nudge the selected panel by a unit (five with Shift) for exact placement
		if (inspected != null && inspected.isEnabled() && !event.hasControlDown()) {
			int dx = event.key() == InputConstants.KEY_LEFT ? -1 : event.key() == InputConstants.KEY_RIGHT ? 1 : 0;
			int dy = event.key() == InputConstants.KEY_UP ? -1 : event.key() == InputConstants.KEY_DOWN ? 1 : 0;
			if (dx != 0 || dy != 0) {
				int step = event.hasShiftDown() ? 5 : 1;
				int x = Math.max(0, Math.min(width - inspected.screenWidth(), inspected.screenX() + dx * step));
				int y = Math.max(0, Math.min(height - inspected.screenHeight(), inspected.screenY() + dy * step));
				inspected.moveTo(x, y, width, height);
				return true;
			}
		}
		if (event.key() == InputConstants.KEY_ESCAPE && drawerOpen) {
			drawerOpen = false;
			return true;
		}
		if (event.key() == InputConstants.KEY_E && !event.hasControlDown()) {
			drawerOpen = !drawerOpen;
			return true;
		}
		if (event.key() == InputConstants.KEY_R && event.hasControlDown()) {
			ModuleManager.hudModules().forEach(HudModule::resetPosition);
			ConfigManager.markDirty();
			return true;
		}
		if (event.key() == InputConstants.KEY_H && event.hasAltDown()) {
			dev.goonclient.client.modules.utility.Interface.toggleHints();
			return true;
		}
		return super.keyPressed(event);
	}

    @Override public void removed(){hits.clear();dragging=null;numberDragging=null;ConfigManager.save();}

    private void updateSlider(double mouseX) {
        if(numberDragging==null)return;
        numberDragging.setFraction(Math.max(0,Math.min(1,(mouseX-numberX1)/Math.max(1,numberW))));
        ConfigManager.markDirty();
    }

	// ---- Chrome (drawn on the shared menu canvas so it matches the ClickGUI) ----------------------------

	/** Canvas scale and the inspector / slider rectangles in GUI units, refreshed every frame for input. */
	private float cs = 1;
	private float inspX1, inspY1, inspX2, inspY2;
	private static final float INSPECTOR_W = 120;

	private void canvasHit(float x1, float y1, float x2, float y2, Runnable action) {
		hits.add(new Hit(x1 * cs, y1 * cs, x2 * cs, y2 * cs, action));
	}

	private void drawChrome(GuiGraphicsExtractor g, int mouseX, int mouseY, float open) {
		cs = GlassUi.canvasScale(width, height);
		float cw = width / cs, ch = height / cs;
		float mx = mouseX / cs, my = mouseY / cs;
		g.pose().pushMatrix();
		g.pose().scale(cs, cs);
		int navHover = GlassUi.navigationHit(cw, mx, my);
		GlassUi.navigation(g, cw, 1, Ui.animate("hudedit:nav0", navHover == 0 ? 1 : 0, .6f), Ui.animate("hudedit:nav1", navHover == 1 ? 1 : 0, .6f), open);
		float nx = cw / 2 - GlassUi.NAV_W / 2;
		canvasHit(nx, GlassUi.NAV_Y, nx + GlassUi.NAV_W / 2, GlassUi.NAV_Y + GlassUi.NAV_H, () -> minecraft.gui.setScreen(new ClickGuiScreen(this)));
		canvasHit(nx + GlassUi.NAV_W / 2, GlassUi.NAV_Y, nx + GlassUi.NAV_W, GlassUi.NAV_Y + GlassUi.NAV_H,
			() -> minecraft.gui.setScreen(new StudioScreen(this, StudioScreen.Page.HUD)));
		drawInspector(g, mx, my, cw);
		GlassUi.hintsRow(g, List.of("Drag - move", "Alt - no snap", "Arrows - nudge", "Scroll - resize", "RMB - hide", "Click empty - deselect", "E - elements",
			"Ctrl+R - reset", "Esc - close", "Alt+H - hide hints"), cw / 2, GlassUi.NAV_Y + GlassUi.NAV_H + 5, open);
		g.pose().popMatrix();
	}

	/**
	 * The selected element's panel, laid out like Combatant's HUD element editor: title and close, Enabled / Only
	 * this, then every setting inline (scale, switches, sliders, inline option lists, buttons), scrolling when long.
	 */
	private void drawInspector(GuiGraphicsExtractor g, float mx, float my, float cw) {
		if (inspected == null) {
			inspX2 = inspX1 = 0;
			return;
		}
		float w = INSPECTOR_W, x = inspectorLeft(cw), y = inspectorTop();
		float content = inspectorContentHeight();
		float h = inspectorHeight(content);
		inspX1 = x * cs; inspY1 = y * cs; inspX2 = (x + w) * cs; inspY2 = (y + h) * cs;
		GlassUi.window(g, x, y, w, h, 1);
		GlassUi.text(g, Ui.ellipsize(inspected.name(), w - 32, 7, GoonFont.Weight.REGULAR), x + 8, y + 7.3f, 7, 0xFFFFFFFF, false);
		// Grab the title bar to move the inspector out of the way
		canvasHit(x, y, x + w - 20, y + 20, () -> {
			inspDragging = true;
			inspGrabX = (float) (clickX / cs) - x;
			inspGrabY = (float) (clickY / cs) - y;
		});
		float cx = x + w - 11, cy = y + 11;
		Shapes.circle(g, cx, cy, 5.2f, Ui.inside(mx, my, cx - 5.2f, cy - 5.2f, cx + 5.2f, cy + 5.2f) ? 0xFF3A3540 : 0xFF2A262E);
		Icons.draw(g, Icons.Icon.CLOSE, cx - 2.5f, cy - 2.5f, 5, 0xFFE8E5ED);
		canvasHit(cx - 5.2f, cy - 5.2f, cx + 5.2f, cy + 5.2f, () -> { inspected = null; onlySelected = false; });

		// Enabled / Only this
		float sx = x + 6, sw = w - 12, sy = y + 21, sh = 11, half = (sw - 2.4f) / 2;
		Shapes.panel(g, sx, sy, sx + sw, sy + sh, 3, 0xC81D1A20, 0x1AFFFFFF);
		String[] labels = {"Enabled", "Only this"};
		boolean[] lit = {inspected.isEnabled(), onlySelected};
		for (int i = 0; i < 2; i++) {
			float bx = sx + 1.2f + half * i;
			float on = Ui.animate("hudedit:seg" + i, lit[i] ? 1 : 0, .5f);
			if (on > .01f) Shapes.roundRect(g, bx, sy + 1.2f, bx + half, sy + sh - 1.2f, 2.4f, Ui.withAlpha(Ui.lerp(.45f, 0xFF2A2026, Ui.accent()), on));
			float tw = GoonFont.width(labels[i], 5.2f, GoonFont.Weight.REGULAR);
			GoonFont.draw(g, labels[i], bx + (half - tw) / 2, sy + 3.1f, 5.2f, GoonFont.Weight.REGULAR, Ui.lerp(on, 0xFFA8A3AE, 0xFFFFFFFF), false);
			final int index = i;
			canvasHit(bx, sy, bx + half, sy + sh, () -> {
				if (index == 0) { inspected.toggle(); ConfigManager.markDirty(); }
				else onlySelected = !onlySelected;
			});
		}

		// Settings, clipped to the panel and scrolled
		float left = x + 7, right = x + w - 9;
		clipTop = y + 37;
		clipBottom = y + h - 5;
		float maxScroll = Math.max(0, content - (clipBottom - clipTop));
		inspectorScroll = Math.max(0, Math.min(maxScroll, inspectorScroll));
		float shown = Ui.animate("hudedit:scroll", inspectorScroll, .5f);
		g.enableScissor((int) Math.floor(x + 1), (int) Math.ceil(clipTop), (int) Math.ceil(x + w - 1), (int) Math.floor(clipBottom));
		float ry = clipTop + 2 - shown;
		ry = sliderRow(g, inspected.scale, "hudedit:scale", left, ry, right, mx, my);
		for (Setting<?> setting : inspected.settings()) {
			if (setting == inspected.scale) continue;
			String key = "hudedit:set:" + inspected.id() + ":" + setting.id();
			if (setting instanceof BooleanSetting bool) ry = toggleRow(g, bool, key, left, ry, right);
			else if (setting instanceof NumberSetting number) ry = sliderRow(g, number, key, left, ry, right, mx, my);
			else if (setting instanceof ModeSetting mode) ry = modeRow(g, mode, left, ry, right, mx, my);
			else if (setting instanceof ButtonSetting button) ry = buttonRow(g, button.name(), button.buttonLabel(), left, ry, right, mx, my, button::press);
		}
		buttonRow(g, "Position", "Reset", left, ry, right, mx, my, () -> { inspected.resetPosition(); ConfigManager.markDirty(); });
		g.disableScissor();
		if (maxScroll > 0) {
			float track = clipBottom - clipTop, thumb = Math.max(14, track * track / content);
			float ty = clipTop + (track - thumb) * (shown / maxScroll);
			Shapes.roundRect(g, x + w - 4.6f, ty, x + w - 3.2f, ty + thumb, .7f, 0x66FFFFFF);
		}
	}

	private static final float INSPECTOR_Y = 113, INSPECTOR_MAX_H = 252;
	private float clipTop, clipBottom, inspectorScroll;
	private NumberSetting numberDragging;
	private float numberX1, numberW;

	/** Where the player dragged the inspector to (canvas units), or NaN to let it sit opposite the selected panel. */
	private float inspUserX = Float.NaN, inspUserY = Float.NaN, inspGrabX, inspGrabY;
	private boolean inspDragging;
	private double clickX, clickY;

	private float inspectorLeft(float canvasW) {
		if (!Float.isNaN(inspUserX)) return Math.max(2, Math.min(canvasW - INSPECTOR_W - 2, inspUserX));
		// Opposite the selected panel (and clear of the elements drawer), sliding there when it changes
		boolean left = inspectorOnLeft && !drawerOpen;
		return Ui.animate("hudedit:inspx", left ? 24 : canvasW - INSPECTOR_W - 51, .55f);
	}

	private float inspectorTop() {
		if (Float.isNaN(inspUserY)) return INSPECTOR_Y;
		float canvasH = height / GlassUi.canvasScale(width, height);
		return Math.max(2, Math.min(canvasH - 40, inspUserY));
	}

	private float inspectorHeight(float content) {
		float canvasH = height / GlassUi.canvasScale(width, height);
		return Math.min(Math.min(INSPECTOR_MAX_H, canvasH - INSPECTOR_Y - 34), 37 + content + 7);
	}

	/** Height of the settings list (scale, each setting, the position row), matching what drawInspector draws. */
	private float inspectorContentHeight() {
		if (inspected == null) return 0;
		float total = 2 + 21;
		for (Setting<?> setting : inspected.settings()) {
			if (setting == inspected.scale) continue;
			if (setting instanceof BooleanSetting || setting instanceof NumberSetting || setting instanceof ButtonSetting) total += 21;
			else if (setting instanceof ModeSetting mode) total += 21 + (optionLines(mode, INSPECTOR_W - 18) - 1) * 8.5f;
		}
		return total + 21;
	}

	/** A click target inside the scrolled list: only the part showing between the clip edges counts. */
	private void listHit(float x1, float y1, float x2, float y2, Runnable action) {
		float top = Math.max(y1, clipTop), bottom = Math.min(y2, clipBottom);
		if (bottom > top) canvasHit(x1, top, x2, bottom, action);
	}

	private float toggleRow(GuiGraphicsExtractor g, BooleanSetting setting, String key, float left, float y, float right) {
		float on = Ui.animate(key, setting.isOn() ? 1f : 0f, .42f);
		Shapes.panel(g, left, y, right, y + 17, 3, 0x59141217, Ui.withAlpha(Ui.lerp(on, 0x50FFFFFF, Ui.accent()), .55f + .25f * on));
		float sx = left + 4, sy = y + 4.5f;
		Shapes.roundRect(g, sx, sy, sx + 15, sy + 8, 4, Ui.lerp(on, 0xFF4A4650, Ui.accent()));
		Shapes.circle(g, sx + 4 + on * 7, sy + 4, 2.9f, 0xFFFFFFFF);
		GlassUi.text(g, Ui.ellipsize(setting.name(), right - left - 28, 5.8f, GoonFont.Weight.REGULAR), left + 23, y + 5.6f, 5.8f, 0xFFF4F2F7, false);
		listHit(left, y, right, y + 17, () -> { setting.toggle(); ConfigManager.markDirty(); });
		return y + 21;
	}

	private float sliderRow(GuiGraphicsExtractor g, NumberSetting setting, String key, float left, float y, float right, float mx, float my) {
		GlassUi.text(g, Ui.ellipsize(setting.name(), right - left - 24, 5.6f, GoonFont.Weight.REGULAR), left + 1, y + 1.5f, 5.6f, 0xFFF2F0F5, false);
		String value = setting.display().replace('.', ',');
		GlassUi.text(g, value, right - 1 - GoonFont.width(value, 5.6f, GoonFont.Weight.REGULAR), y + 1.5f, 5.6f, 0xFFF2F0F5, false);
		float tx1 = left + 1, tw = right - left - 2, ty = y + 12.5f;
		if (numberDragging == setting) Ui.snap(key, (float) setting.fraction());
		float fraction = Ui.animate(key, (float) setting.fraction(), .45f);
		Shapes.roundRect(g, tx1, ty - .45f, tx1 + tw, ty + .45f, .45f, 0x40FFFFFF);
		Shapes.roundRect(g, tx1, ty - .45f, Math.max(tx1 + 1, tx1 + tw * fraction), ty + .45f, .45f, Ui.accent());
		float knob = Ui.animate(key + ":knob", numberDragging == setting || Ui.inside(mx, my, left, y + 7, right, y + 19) ? 1f : 0f, .55f);
		Shapes.roundRect(g, tx1 + tw * fraction - .55f, ty - 2.2f - knob * .5f, tx1 + tw * fraction + .55f, ty + 2.2f + knob * .5f, .5f, Ui.accent());
		listHit(left - 2, y + 7, right + 2, y + 19, () -> { numberDragging = setting; numberX1 = tx1 * cs; numberW = tw * cs; });
		return y + 21;
	}

	private int optionLines(ModeSetting mode, float width) {
		float x = 0;
		int lines = 1;
		for (String option : mode.modes()) {
			float w = GoonFont.width(option, 5.6f, GoonFont.Weight.REGULAR) + 3.2f;
			if (x > 0 && x + w > width) { lines++; x = 0; }
			x += w;
		}
		return lines;
	}

	/** Label, then every option inline with the selected one in the accent colour (Combatant's "Split Header Unified Divider"). */
	private float modeRow(GuiGraphicsExtractor g, ModeSetting setting, float left, float y, float right, float mx, float my) {
		GlassUi.text(g, setting.name(), left + 1, y + 1, 5.8f, 0xFFF2F0F5, false);
		float ox = left + 1.5f, oy = y + 10, width = right - left - 2;
		for (String option : setting.modes()) {
			float ow = GoonFont.width(option, 5.6f, GoonFont.Weight.REGULAR);
			if (ox > left + 1.5f && ox + ow - left > width) { ox = left + 1.5f; oy += 8.5f; }
			boolean selected = option.equals(setting.get());
			boolean hover = Ui.inside(mx, my, ox - 1, oy - 1, ox + ow + 1, oy + 7.5f);
			GoonFont.draw(g, option, ox, oy, 5.6f, GoonFont.Weight.REGULAR, selected ? Ui.accent() : hover ? 0xFFFFFFFF : 0xFFCFCBD5, false);
			listHit(ox - 1, oy - 1, ox + ow + 1, oy + 7.5f, () -> { setting.set(option); ConfigManager.markDirty(); });
			ox += ow + 3.2f;
		}
		return oy + 11;
	}

	private float buttonRow(GuiGraphicsExtractor g, String name, String action, float left, float y, float right, float mx, float my, Runnable run) {
		boolean hover = Ui.inside(mx, my, left, y, right, y + 17) && my >= clipTop && my <= clipBottom;
		Shapes.panel(g, left, y, right, y + 17, 3, hover ? 0x902A2730 : 0x60141217, 0x28FFFFFF);
		GlassUi.text(g, Ui.ellipsize(name, right - left - 34, 5.8f, GoonFont.Weight.REGULAR), left + 5, y + 5.4f, 5.8f, 0xFFF4F2F7, false);
		float aw = GoonFont.width(action, 5.4f, GoonFont.Weight.MEDIUM);
		GoonFont.draw(g, action, right - aw - 6, y + 5.7f, 5.4f, GoonFont.Weight.MEDIUM, Ui.accent(), false);
		listHit(left, y, right, y + 17, run);
		return y + 21;
	}

	@Override
	public void onClose() {
		ConfigManager.save();
		minecraft.gui.setScreen(parent);
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}

	private record Hit(float x1, float y1, float x2, float y2, Runnable action) {
	}
}
