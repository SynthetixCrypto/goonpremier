package dev.goonclient.client.mixin.xaero;

import dev.goonclient.client.gui.HudEditorScreen;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import xaero.hud.minimap.module.MinimapSession;

@Mixin(value = MinimapSession.class, remap = false)
public class XaeroSessionMixin {
	@Inject(method = "getHideMinimapUnderScreen", at = @At("RETURN"), cancellable = true)
	private void goonclient$editorPreview(CallbackInfoReturnable<Boolean> cir) {
		if (Minecraft.getInstance().gui.screen() instanceof HudEditorScreen) cir.setReturnValue(false);
	}
}
