package dev.goonclient.client.gui.render;

import com.mojang.blaze3d.platform.NativeImage;
import dev.goonclient.Goon;
import java.awt.BasicStroke;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.geom.Arc2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Path2D;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.resources.Identifier;
import org.joml.Matrix3x2f;

/**
 * Line icons, drawn as vector strokes on a 24-unit grid and rasterised with Java2D at the exact on-screen pixel size
 * (like {@link GoonFont}), so they stay crisp at every GUI scale and tint to any colour. Original artwork.
 */
public final class Icons {
	public enum Icon {
        CHEVRON_RIGHT(d -> d.poly(9, 5, 16, 12, 9, 19)),
		CHECK(d -> d.poly(5, 12.5f, 10, 17.5f, 19.5f, 7)),
		/** A switch, knob left (off) or right (on): the notification toggle. */
		TOGGLE_OFF(d -> { d.rrect(2, 6, 20, 12, 6); d.circle(8, 12, 2); }),
		TOGGLE_ON(d -> { d.rrect(2, 6, 20, 12, 6); d.circle(16, 12, 2); }),
		SEARCH(d -> { d.circle(10.5f, 10.5f, 6.5f); d.line(15.5f, 15.5f, 20, 20); }),
		CLOSE(d -> { d.line(6, 6, 18, 18); d.line(18, 6, 6, 18); }),
		MONITOR(d -> { d.rrect(3, 4, 18, 12, 2.5f); d.line(8, 20, 16, 20); d.line(12, 16, 12, 20); }),
		GLOBE(d -> { d.circle(12, 12, 9); d.shape(new Ellipse2D.Float(8, 3, 8, 18)); d.line(3, 12, 21, 12); }),
		SWORDS(d -> {
			d.line(4, 4, 15, 15); d.line(12.5f, 18.5f, 18.5f, 12.5f); d.line(16.5f, 16.5f, 20, 20);
			d.line(20, 4, 9, 15); d.line(5.5f, 12.5f, 11.5f, 18.5f); d.line(7.5f, 16.5f, 4, 20);
		}),
		BACKPACK(d -> {
			d.rrect(5, 8, 14, 13, 3.5f); d.shape(new Arc2D.Float(9, 4, 6, 7, 0, 180, Arc2D.OPEN));
			d.line(8.5f, 14, 15.5f, 14); d.line(8.5f, 14, 8.5f, 17); d.line(15.5f, 14, 15.5f, 17);
		}),
		EYE(d -> {
			Path2D p = new Path2D.Float(); p.moveTo(2, 12); p.quadTo(12, 2.5f, 22, 12); p.quadTo(12, 21.5f, 2, 12); p.closePath();
			d.shape(p); d.circle(12, 12, 3);
		}),
		EYE_OFF(d -> {
			Path2D p = new Path2D.Float(); p.moveTo(2, 12); p.quadTo(12, 2.5f, 22, 12); p.quadTo(12, 21.5f, 2, 12); p.closePath();
			d.shape(p); d.circle(12, 12, 3); d.line(4, 20, 20, 4);
		}),
		LAYERS(d -> { d.rrect(3, 8, 13, 10, 2); d.poly(7, 8, 7, 5.5f, 19, 5.5f, 19, 14, 16, 14); d.poly(10.5f, 5.5f, 10.5f, 3, 21.5f, 3, 21.5f, 10.5f, 19, 10.5f); }),
		MEMORY(d -> {
			d.rrect(2.5f, 7, 19, 10, 1.5f);
			for (int i = 0; i < 4; i++) d.rrect(5.5f + i * 3.6f, 9.5f, 1.6f, 3, .3f);
			d.line(2.5f, 15, 21.5f, 15);
		}),
		SATELLITE(d -> {
			d.poly(9, 8.5f, 15.5f, 15, 12.5f, 18, 6, 11.5f, 9, 8.5f);
			d.poly(8, 7.5f, 4.5f, 4, 2, 6.5f, 5.5f, 10);
			d.poly(16.5f, 16, 20, 19.5f, 17.5f, 22, 14, 18.5f);
			d.shape(new Arc2D.Float(14, 1, 9, 9, 270, 90, Arc2D.OPEN));
			d.shape(new Arc2D.Float(11.5f, -1.5f, 14, 14, 270, 90, Arc2D.OPEN));
		}),
		BRIEFCASE(d -> { d.rrect(3, 7, 18, 13, 2.5f); d.poly(9, 7, 9, 4.5f, 15, 4.5f, 15, 7); d.line(3, 12.5f, 21, 12.5f); }),
		SLIDERS(d -> {
			d.line(4, 7, 12.5f, 7); d.line(17.5f, 7, 20, 7); d.circle(15, 7, 2.5f);
			d.line(4, 17, 6.5f, 17); d.line(11.5f, 17, 20, 17); d.circle(9, 17, 2.5f);
		}),
		PALETTE(d -> {
			Path2D p = new Path2D.Float(); p.moveTo(12, 3); p.curveTo(6.5f, 3, 3, 7, 3, 12); p.curveTo(3, 17, 7, 21, 12, 21);
			p.curveTo(13.5f, 21, 14, 20, 13.5f, 18.5f); p.curveTo(13, 17, 14, 15.5f, 15.5f, 15.5f); p.lineTo(17.5f, 15.5f);
			p.curveTo(19.5f, 15.5f, 21, 14, 21, 12); p.curveTo(21, 7, 17, 3, 12, 3); p.closePath(); d.shape(p);
			d.dot(7.5f, 11, 1.4f); d.dot(10, 7, 1.4f); d.dot(14.5f, 7, 1.4f); d.dot(17, 10.5f, 1.4f);
		}),
		LAYOUT(d -> { d.rrect(3, 3, 18, 18, 2.5f); d.line(9.5f, 3, 9.5f, 21); d.line(9.5f, 10, 21, 10); d.circle(15.5f, 15.5f, 2); }),
		USER(d -> { d.circle(10, 8, 4); d.shape(new Arc2D.Float(3, 13.5f, 14, 13, 0, 180, Arc2D.OPEN)); d.line(15.5f, 19.5f, 21, 14); }),
		FOLDER(d -> {
			Path2D p = new Path2D.Float(); p.moveTo(3, 7); p.lineTo(3, 18.5f); p.quadTo(3, 20, 4.5f, 20); p.lineTo(19.5f, 20);
			p.quadTo(21, 20, 21, 18.5f); p.lineTo(21, 9.5f); p.quadTo(21, 8, 19.5f, 8); p.lineTo(12, 8); p.lineTo(10, 5);
			p.lineTo(4.5f, 5); p.quadTo(3, 5, 3, 6.5f); p.closePath(); d.shape(p); d.circle(15.5f, 14, 2.2f);
		}),
		FLASK(d -> {
			Path2D p = new Path2D.Float(); p.moveTo(10, 3); p.lineTo(10, 9); p.lineTo(4.8f, 18); p.quadTo(4, 20, 6.5f, 20);
			p.lineTo(17.5f, 20); p.quadTo(20, 20, 19.2f, 18); p.lineTo(14, 9); p.lineTo(14, 3); d.shape(p);
			d.line(8.5f, 3, 15.5f, 3); d.line(7, 15, 17, 15);
		}),
		KEYBOARD(d -> {
			d.rrect(2, 6, 20, 12, 2.5f);
			for (int i = 0; i < 4; i++) d.dot(6 + i * 4, 10, 1.1f);
			d.line(8, 14, 16, 14);
		}),
		TIMER(d -> { d.circle(12, 13.5f, 7.5f); d.line(12, 13.5f, 15, 10.5f); d.line(10, 2.5f, 14, 2.5f); }),
		GAUGE(d -> { d.shape(new Arc2D.Float(3, 5, 18, 18, 0, 180, Arc2D.OPEN)); d.line(12, 14, 16, 9.5f); d.dot(12, 14, 1.3f); }),
		CHIP(d -> {
			d.rrect(6, 6, 12, 12, 2);
			for (float p : new float[]{9.5f, 14.5f}) { d.line(p, 2.5f, p, 6); d.line(p, 18, p, 21.5f); d.line(2.5f, p, 6, p); d.line(18, p, 21.5f, p); }
		}),
		PIN(d -> {
			Path2D p = new Path2D.Float(); p.moveTo(12, 21); p.curveTo(12, 21, 5, 14.5f, 5, 9.5f); p.curveTo(5, 5.5f, 8, 3, 12, 3);
			p.curveTo(16, 3, 19, 5.5f, 19, 9.5f); p.curveTo(19, 14.5f, 12, 21, 12, 21); p.closePath(); d.shape(p); d.circle(12, 9.5f, 2.5f);
		}),
		WIND(d -> { d.line(3, 8, 15, 8); d.line(3, 12, 19, 12); d.line(3, 16, 12, 16); }),
		HEART(d -> {
			Path2D p = new Path2D.Float(); p.moveTo(12, 20); p.curveTo(5, 15, 2.5f, 11.5f, 3, 8); p.curveTo(3.5f, 5, 6, 3.5f, 8.5f, 4);
			p.curveTo(10.2f, 4.3f, 11.3f, 5.5f, 12, 6.8f); p.curveTo(12.7f, 5.5f, 13.8f, 4.3f, 15.5f, 4); p.curveTo(18, 3.5f, 20.5f, 5, 21, 8);
			p.curveTo(21.5f, 11.5f, 19, 15, 12, 20); p.closePath(); d.shape(p);
		}),
		SAVE(d -> { d.rrect(4, 4, 16, 16, 2.5f); d.line(8, 4, 8, 8.5f); d.line(8, 8.5f, 15, 8.5f); d.line(15, 8.5f, 15, 4); d.rrect(7.5f, 13, 9, 7, 1); }),
		DOWNLOAD(d -> { d.line(12, 4, 12, 15); d.poly(7, 10, 12, 15, 17, 10); d.line(5, 20, 19, 20); }),
		UPLOAD(d -> { d.line(12, 15, 12, 4); d.poly(7, 9, 12, 4, 17, 9); d.line(5, 20, 19, 20); }),
		TRASH(d -> {
			d.line(4, 7, 20, 7); Path2D p = new Path2D.Float(); p.moveTo(6, 7); p.lineTo(7, 20); p.lineTo(17, 20); p.lineTo(18, 7); d.shape(p);
			d.poly(9, 7, 9, 4, 15, 4, 15, 7); d.line(10, 11, 10, 16); d.line(14, 11, 14, 16);
		}),
		INFO(d -> { d.circle(12, 12, 9); d.line(12, 11, 12, 16.5f); d.dot(12, 7.8f, 1.2f); }),
		WARNING(d -> {
			Path2D p = new Path2D.Float(); p.moveTo(12, 3.5f); p.lineTo(21.5f, 20); p.lineTo(2.5f, 20); p.closePath(); d.shape(p);
			d.line(12, 9.5f, 12, 14); d.dot(12, 17, 1.1f);
		}),
		DOTS(d -> { d.dot(5, 12, 1.6f); d.dot(12, 12, 1.6f); d.dot(19, 12, 1.6f); }),
		SHIELD(d -> {
			Path2D p = new Path2D.Float(); p.moveTo(12, 3); p.lineTo(20, 6); p.lineTo(20, 11.5f); p.curveTo(20, 16.5f, 16.5f, 19.5f, 12, 21);
			p.curveTo(7.5f, 19.5f, 4, 16.5f, 4, 11.5f); p.lineTo(4, 6); p.closePath(); d.shape(p);
		}),
		GRID(d -> { d.rrect(3, 3, 7.5f, 7.5f, 1.5f); d.rrect(13.5f, 3, 7.5f, 7.5f, 1.5f); d.rrect(3, 13.5f, 7.5f, 7.5f, 1.5f); d.rrect(13.5f, 13.5f, 7.5f, 7.5f, 1.5f); }),
		PEN(d -> { d.line(4, 20, 8.5f, 19); d.line(4, 20, 5, 15.5f); d.line(5, 15.5f, 16.5f, 4); d.line(8.5f, 19, 20, 7.5f); d.line(16.5f, 4, 20, 7.5f); }),
		CUBE(d -> {
			d.poly(12, 3, 20, 7.5f, 20, 16.5f, 12, 21, 4, 16.5f, 4, 7.5f, 12, 3);
			d.poly(4, 7.5f, 12, 12, 20, 7.5f); d.line(12, 12, 12, 21);
		}),
		COG(d -> {
			d.circle(12, 12, 3.2f);
			for (int i = 0; i < 8; i++) {
				double a = Math.PI / 4 * i;
				d.line(12 + (float) Math.cos(a) * 6.2f, 12 + (float) Math.sin(a) * 6.2f, 12 + (float) Math.cos(a) * 9, 12 + (float) Math.sin(a) * 9);
			}
			d.circle(12, 12, 6.2f);
		});

		private final Consumer<Drawing> art;

		Icon(Consumer<Drawing> art) {
			this.art = art;
		}
	}

	private static final int MAX_CACHED = 96;
	private static final Map<Long, Cached> CACHE = new LinkedHashMap<>(32, 0.75f, true);
	private static final List<Identifier> RETIRED = new ArrayList<>();
	private static int nextId;

	private Icons() {
	}

	/** The icon each module category uses in menus and HUD rows. */
	public static Icon forCategory(dev.goonclient.client.module.Category category) {
		return switch (category) {
			case HUD -> Icon.MONITOR;
			case WORLD -> Icon.GLOBE;
			case COMBAT -> Icon.SWORDS;
			case INVENTORY -> Icon.BACKPACK;
			case VISUAL -> Icon.EYE;
			default -> Icon.SLIDERS;
		};
	}

	private record Cached(Identifier id, SmoothTexture texture) {
	}

	/** Evicted icons may still be queued for the frame being drawn; release them at the start of the next one. */
	public static void beginFrame() {
		RETIRED.forEach(id -> Minecraft.getInstance().getTextureManager().release(id));
		RETIRED.clear();
	}

	/** Draws an icon with its top-left at (x, y), {@code size} GUI units square, tinted {@code color}. */
	public static void draw(GuiGraphicsExtractor g, Icon icon, float x, float y, float size, int color) {
		if ((color >>> 24) == 0 || size <= 0) {
			return;
		}
		Matrix3x2f pose = g.pose();
		int guiScale = Px.guiScale();
		int pixels = Math.max(6, Math.round(size * pose.m00 * guiScale));
		SmoothTexture texture = texture(icon, pixels);
		int px = Math.round((pose.m00 * x + pose.m20) * guiScale);
		int py = Math.round((pose.m11 * y + pose.m21) * guiScale);
		QuadBatch batch = new QuadBatch(1);
		batch.add(px, py, px + pixels, py + pixels, 0, 0, 1, 1);
		Px.begin(g);
		batch.submit(g, texture, color);
		Px.end(g);
	}

	private static final Map<String, BufferedImage> MASKS = new java.util.HashMap<>();

	/**
	 * Draws a white-on-transparent picture icon from {@code assets/goonclient/textures/hud/elements/<name>.png}
	 * (Combatant's HUD element icons), downsampled to the exact pixel size and tinted. False if the file is missing.
	 */
	public static boolean drawPicture(GuiGraphicsExtractor g, String name, float x, float y, float size, int color) {
		if ((color >>> 24) == 0 || size <= 0) {
			return true;
		}
		BufferedImage source = MASKS.computeIfAbsent(name, n -> {
			try (var in = Icons.class.getResourceAsStream("/assets/goonclient/textures/hud/elements/" + n + ".png")) {
				return in == null ? null : javax.imageio.ImageIO.read(in);
			} catch (java.io.IOException e) {
				Goon.LOGGER.warn("Couldn't read HUD icon {}", n, e);
				return null;
			}
		});
		if (source == null) {
			return false;
		}
		Matrix3x2f pose = g.pose();
		int guiScale = Px.guiScale();
		int pixels = Math.max(4, Math.round(size * pose.m00 * guiScale));
		long key = (((long) name.hashCode()) << 24) ^ (1L << 62) | pixels;
		Cached cached = CACHE.get(key);
		if (cached == null) {
			// Area averaging keeps thin strokes from a 512px source smooth at 15-25px
			java.awt.Image scaled = source.getScaledInstance(pixels, pixels, java.awt.Image.SCALE_AREA_AVERAGING);
			BufferedImage image = new BufferedImage(pixels, pixels, BufferedImage.TYPE_INT_ARGB);
			Graphics2D g2 = image.createGraphics();
			g2.drawImage(scaled, 0, 0, null);
			g2.dispose();
			cached = register("picture_" + name, pixels, image);
			CACHE.put(key, cached);
			trim();
		}
		int px = Math.round((pose.m00 * x + pose.m20) * guiScale);
		int py = Math.round((pose.m11 * y + pose.m21) * guiScale);
		QuadBatch batch = new QuadBatch(1);
		batch.add(px, py, px + pixels, py + pixels, 0, 0, 1, 1);
		Px.begin(g);
		batch.submit(g, cached.texture(), color);
		Px.end(g);
		return true;
	}

	private static Cached register(String name, int pixels, BufferedImage image) {
		NativeImage pixelsImage = new NativeImage(pixels, pixels, false);
		for (int y = 0; y < pixels; y++) {
			for (int x = 0; x < pixels; x++) {
				pixelsImage.setPixel(x, y, (image.getRGB(x, y) & 0xFF000000) | 0xFFFFFF);
			}
		}
		Identifier id = Goon.id("dynamic/icon_" + name + "_" + pixels + "_" + nextId++);
		SmoothTexture texture = new SmoothTexture(id.toString(), pixelsImage);
		Minecraft.getInstance().getTextureManager().register(id, texture);
		return new Cached(id, texture);
	}

	private static void trim() {
		if (CACHE.size() > MAX_CACHED) {
			var eldest = CACHE.entrySet().iterator();
			RETIRED.add(eldest.next().getValue().id());
			eldest.remove();
		}
	}

	private static SmoothTexture texture(Icon icon, int pixels) {
		long key = ((long) icon.ordinal() << 20) | pixels;
		Cached cached = CACHE.get(key);
		if (cached != null) {
			return cached.texture();
		}
		BufferedImage image = new BufferedImage(pixels, pixels, BufferedImage.TYPE_INT_ARGB);
		Graphics2D g = image.createGraphics();
		g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		g.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
		g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
		float scale = pixels / 24f;
		g.scale(scale, scale);
		// About 1.5 screen pixels at small sizes, scaling up with the icon
		g.setStroke(new BasicStroke(Math.max(1.7f, 1.5f / scale), BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
		g.setColor(java.awt.Color.WHITE);
		icon.art.accept(new Drawing(g));
		g.dispose();
		Cached created = register(icon.name().toLowerCase(), pixels, image);
		CACHE.put(key, created);
		trim();
		return created.texture();
	}

	/** The pen icons draw with: strokes for outlines, fills for dots. */
	static final class Drawing {
		private final Graphics2D g;

		Drawing(Graphics2D g) {
			this.g = g;
		}

		void line(float x1, float y1, float x2, float y2) {
			g.draw(new Line2D.Float(x1, y1, x2, y2));
		}

		void poly(float... points) {
			Path2D p = new Path2D.Float();
			p.moveTo(points[0], points[1]);
			for (int i = 2; i + 1 < points.length; i += 2) {
				p.lineTo(points[i], points[i + 1]);
			}
			g.draw(p);
		}

		void circle(float cx, float cy, float r) {
			g.draw(new Ellipse2D.Float(cx - r, cy - r, r * 2, r * 2));
		}

		void dot(float cx, float cy, float r) {
			g.fill(new Ellipse2D.Float(cx - r, cy - r, r * 2, r * 2));
		}

		void rrect(float x, float y, float w, float h, float r) {
			g.draw(new RoundRectangle2D.Float(x, y, w, h, r * 2, r * 2));
		}

		void shape(Shape shape) {
			g.draw(shape);
		}
	}
}
