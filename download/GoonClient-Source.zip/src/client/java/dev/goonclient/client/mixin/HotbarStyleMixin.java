package dev.goonclient.client.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.mojang.renderpearl.api.pipeline.RenderPipeline;
import dev.goonclient.client.gui.HotbarStyle;
import dev.goonclient.client.gui.Ui;
import dev.goonclient.client.gui.render.Shapes;
import dev.goonclient.client.modules.utility.Interface;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.Hud;
import net.minecraft.resources.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(Hud.class)
public abstract class HotbarStyleMixin {
    @WrapOperation(method="extractItemHotbar",at=@At(value="INVOKE",target="Lnet/minecraft/client/gui/GuiGraphicsExtractor;blitSprite(Lcom/mojang/renderpearl/api/pipeline/RenderPipeline;Lnet/minecraft/resources/Identifier;IIII)V"))
    private void goon$hotbar(GuiGraphicsExtractor g,RenderPipeline pipeline,Identifier sprite,int x,int y,int width,int height,Operation<Void> original) {
        if(!Interface.glassHotbar() || !sprite.getNamespace().equals("minecraft")){original.call(g,pipeline,sprite,x,y,width,height);return;}
        switch(sprite.getPath()) {
            case "hud/hotbar" -> HotbarStyle.background(g,x,y,width,height);
            case "hud/hotbar_selection" -> {
                float origin=g.guiWidth()/2-92;
                float slot=(x-origin)/20f;
                float animated=Ui.animate("hotbar:selected-slot",slot,.8f);
                HotbarStyle.selected(g,origin+20*animated,y,width,height);
            }
            case "hud/hotbar_offhand_left", "hud/hotbar_offhand_right" -> HotbarStyle.offhand(g,x,y,width,height);
            default -> original.call(g,pipeline,sprite,x,y,width,height);
        }
    }
}
