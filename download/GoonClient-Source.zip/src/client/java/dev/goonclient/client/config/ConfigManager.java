package dev.goonclient.client.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.goonclient.Goon;
import dev.goonclient.client.hud.HudModule;
import dev.goonclient.client.hud.HudPosition;
import dev.goonclient.client.module.Module;
import dev.goonclient.client.module.ModuleManager;
import dev.goonclient.client.module.setting.Setting;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import net.fabricmc.loader.api.FabricLoader;

/** Saves module state, settings and HUD positions to config/goonclient/modules.json. */
public final class ConfigManager {
	public static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static final long SAVE_DELAY_MS = 1000;

	private static boolean dirty;
	private static long dirtySince;

	private ConfigManager() {
	}

	public static Path dir() {
		return FabricLoader.getInstance().getConfigDir().resolve(Goon.MOD_ID);
	}

	private static Path file() {
		return dir().resolve("modules.json");
	}

	public static void markDirty() {
		if (!dirty) {
			dirty = true;
			dirtySince = System.currentTimeMillis();
		}
	}

	/** Saves a second after the last change, so dragging a slider doesn't write every frame. */
	public static void tick() {
		if (dirty && System.currentTimeMillis() - dirtySince >= SAVE_DELAY_MS) {
			save();
		}
	}

	public static void load() {
		Path file = file();
		if (!Files.exists(file)) {
			return;
		}
		try (Reader reader = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
			JsonObject root = JsonParser.parseReader(reader).getAsJsonObject();
			apply(root, false, true);
		} catch (IOException | RuntimeException e) {
			Goon.LOGGER.error("Couldn't read {}, using defaults", file, e);
		}
	}

	public static void apply(JsonObject root, boolean live, boolean migrate) {
		JsonObject modules = root.getAsJsonObject("modules");
		if (modules == null) {
			return;
		}
		for (Module module : ModuleManager.all()) {
			JsonObject data = modules.getAsJsonObject(module.id());
			if (data == null) {
				continue;
			}
			if (data.has("enabled")) {
				if (live) module.setEnabled(data.get("enabled").getAsBoolean());
				else module.loadEnabled(data.get("enabled").getAsBoolean());
			}
			if (data.has("favorite")) module.loadFavorite(data.get("favorite").getAsBoolean());
			JsonObject settings = data.getAsJsonObject("settings");
			// A full setup restores exactly what it saved; entries without settings (built-in presets) only switch modules
			if (live && settings != null) {
				module.resetSettings();
				if (module instanceof HudModule hud) hud.setPosition(hud.defaultPosition());
			}
			if (settings != null) {
				for (Setting<?> setting : module.settings()) {
				JsonElement value = settings.get(setting.id());
				if (value != null) {
					setting.fromJson(value);
				}
				}
			}
			if (module instanceof HudModule hud && data.has("anchorX")) {
				HudPosition saved = new HudPosition(
				data.get("anchorX").getAsDouble(),
				data.get("anchorY").getAsDouble(),
				data.get("offsetX").getAsInt(),
				data.get("offsetY").getAsInt(),
				data.has("pivotX") ? data.get("pivotX").getAsDouble() : data.get("anchorX").getAsDouble(),
				data.has("pivotY") ? data.get("pivotY").getAsDouble() : data.get("anchorY").getAsDouble());
				// Panels nobody moved keep up with new defaults (e.g. the left column now clears the minimap)
				if (!migrate || !HudPosition.isOldLeftColumnDefault(saved, hud.defaultPosition())) {
				hud.setPosition(saved);
				}
			}
		}
	}

	public static void save() {
		dirty = false;
		writeAtomically(file(), GSON.toJson(capture()));
	}

	public static JsonObject capture() {
		JsonObject modules = new JsonObject();
		for (Module module : ModuleManager.all()) {
			JsonObject data = new JsonObject();
			data.addProperty("enabled", module.isEnabled());
			data.addProperty("favorite", module.isFavorite());
			// Only panels the player moved store a position, so the rest pick up new defaults in later versions
			if (module instanceof HudModule hud && !hud.position().equals(hud.defaultPosition())) {
				HudPosition position = hud.position();
				data.addProperty("anchorX", position.anchorX());
				data.addProperty("anchorY", position.anchorY());
				data.addProperty("offsetX", position.offsetX());
				data.addProperty("offsetY", position.offsetY());
				data.addProperty("pivotX", position.pivotX());
				data.addProperty("pivotY", position.pivotY());
			}
			JsonObject settings = new JsonObject();
			for (Setting<?> setting : module.settings()) {
				settings.add(setting.id(), setting.toJson());
			}
			data.add("settings", settings);
			modules.add(module.id(), data);
		}
		JsonObject root = new JsonObject();
		root.addProperty("version", 1);
		root.add("modules", modules);
		return root;
	}

	/** Writes to a temp file first so a crash mid-write can't corrupt the config. */
	public static void writeAtomically(Path file, String content) {
		try {
			Files.createDirectories(file.getParent());
			Path temp = file.resolveSibling(file.getFileName() + ".tmp");
			try (Writer writer = Files.newBufferedWriter(temp, StandardCharsets.UTF_8)) {
				writer.write(content);
			}
			Files.move(temp, file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
		} catch (IOException e) {
			Goon.LOGGER.error("Couldn't save {}", file, e);
		}
	}
}
