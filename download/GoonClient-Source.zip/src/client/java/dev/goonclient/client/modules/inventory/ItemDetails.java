package dev.goonclient.client.modules.inventory;

import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.Module;
import dev.goonclient.client.module.setting.BooleanSetting;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;

/** Optional, bounded metadata from the hovered stack. No inventory queries, remote data or screen changes. */
public final class ItemDetails extends Module {
    private static ItemDetails instance;
    private static boolean registered;
    private final BooleanSetting shift=add(new BooleanSetting("shift", "Only while holding Shift", true));
    private final BooleanSetting durability=add(new BooleanSetting("durability", "Durability and percentage", true));
    private final BooleanSetting stackSize=add(new BooleanSetting("stack_size", "Stack count and capacity", true));
    private final BooleanSetting food=add(new BooleanSetting("food", "Food hunger and saturation", false));
    private final BooleanSetting books=add(new BooleanSetting("books", "Bounded first-page book preview", true));
    private final BooleanSetting contents=add(new BooleanSetting("contents", "Known container stack count", false));
    private final BooleanSetting identifier=add(new BooleanSetting("identifier", "Item identifier", false));

    public ItemDetails(){
        super("item_details","Item Details","Shift-hover durability, stack information and short book previews",Category.INVENTORY,false);
        instance=this;
    }
    public static void register(){
        if(registered)return;registered=true;
        ItemTooltipCallback.EVENT.register((stack,context,flags,lines)->{
            var self=instance;var mc=Minecraft.getInstance();
            if(self==null||!self.isEnabled()||mc.player==null||stack.isEmpty()||(self.shift.isOn()&&!mc.hasShiftDown()))return;
            self.append(mc,stack,lines);
        });
    }
    private void append(Minecraft mc,ItemStack stack,List<Component> lines){
        List<String> extra=new ArrayList<>(10);
        if(durability.isOn()&&stack.isDamageableItem()){
            int max=stack.getMaxDamage();int left=Math.max(0,Math.min(max,max-stack.getDamageValue()));
            if(max>0)extra.add("Durability: "+left+" / "+max+" ("+Math.round(left*100.0/max)+"%)");
        }
        if(stackSize.isOn()&&stack.getMaxStackSize()>1)extra.add("Stack: "+stack.getCount()+" / "+stack.getMaxStackSize());
        var nutrition=stack.get(DataComponents.FOOD);
        if(food.isOn()&&nutrition!=null&&Float.isFinite(nutrition.saturation()))
            extra.add(String.format(Locale.ROOT,"Food: +%d hunger / +%.1f saturation",nutrition.nutrition(),nutrition.saturation()));
        var container=stack.get(DataComponents.CONTAINER);
        if(contents.isOn()&&container!=null){
            int seen=0;var iterator=container.nonEmptyItems().iterator();
            while(seen<64&&iterator.hasNext()){iterator.next();seen++;}
            extra.add("Known contents: "+seen+(iterator.hasNext()?"+":"")+" nonempty stacks");
        }
        if(books.isOn()){
            // Preserve the player's text-filtering preference. Plain text only, never execute click events.
            boolean filtered=mc.isTextFilteringEnabled();
            var written=stack.get(DataComponents.WRITTEN_BOOK_CONTENT);
            var writable=stack.get(DataComponents.WRITABLE_BOOK_CONTENT);
            String first=null;int pages=0;
            if(written!=null){pages=written.pages().size();if(pages>0)first=written.pages().getFirst().get(filtered).getString();}
            else if(writable!=null){pages=writable.pages().size();if(pages>0)first=writable.pages().getFirst().get(filtered);}
            if(written!=null||writable!=null){
                extra.add("Book: "+pages+" pages");
                if(first!=null&&!first.isBlank())extra.addAll(preview(first));
            }
        }
        if(identifier.isOn()){
            String id=BuiltInRegistries.ITEM.getKey(stack.getItem()).toString();
            if(lines.stream().noneMatch(line->line.getString().equals(id)))extra.add(id);
        }
        if(extra.isEmpty())return;
        lines.add(Component.literal("Goon · Item Details").withStyle(ChatFormatting.DARK_AQUA));
        for(String text:extra)lines.add(Component.literal(text).withStyle(ChatFormatting.GRAY));
    }
    private static List<String> preview(String page){
        // Limit work before whitespace/word wrapping. Never split a surrogate pair.
        boolean cut=page.length()>512;
        if(cut){int end=512;if(Character.isHighSurrogate(page.charAt(end-1)))end--;page=page.substring(0,end);}
        int count=page.codePointCount(0,page.length());cut|=count>256;
        if(count>256)page=page.substring(0,page.offsetByCodePoints(0,256));
        page=page.replaceAll("[\\p{Cntrl}\\s]+"," ").trim();
        List<String> result=new ArrayList<>(4);int offset=0;
        while(offset<page.length()&&result.size()<4){
            int remaining=page.codePointCount(offset,page.length());
            int end=page.offsetByCodePoints(offset,Math.min(42,remaining));
            if(end<page.length()){
                int space=page.lastIndexOf(' ',end);
                if(space>offset)end=space;
            }
            result.add(page.substring(offset,end).strip());offset=end;
            while(offset<page.length()&&page.charAt(offset)==' ')offset++;
        }
        if(!result.isEmpty()&&(cut||offset<page.length()))result.set(result.size()-1,result.getLast()+" …");
        return result;
    }
}
