package dev.goonclient.client.mixin;

import dev.goonclient.client.modules.visual.CameraComfort;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.state.GameRenderState;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
public abstract class CameraComfortMixin {
    @Shadow @Final private GameRenderState gameRenderState;
    @Inject(method = "extractOptions", at = @At("TAIL"))
    private void goon$cameraOptions(CallbackInfo ci) { CameraComfort.apply(gameRenderState.optionsRenderState); }
}
