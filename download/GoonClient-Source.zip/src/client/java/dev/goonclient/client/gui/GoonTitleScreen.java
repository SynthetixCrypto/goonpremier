package dev.goonclient.client.gui;

import dev.goonclient.Goon;
import dev.goonclient.client.compat.ModMenuCompat;
import dev.goonclient.client.gui.render.Backdrop;
import dev.goonclient.client.gui.render.GoonFont;
import dev.goonclient.client.gui.render.Shapes;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen;
import net.minecraft.client.gui.screens.multiplayer.SafetyScreen;
import net.minecraft.client.gui.screens.options.OptionsScreen;
import net.minecraft.client.gui.screens.worldselection.SelectWorldScreen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;

/**
 * The Goon Client main menu: the blurred panorama shaded on the left, a column of buttons that slide in one after
 * another, a "What's new" card from the bundled changelog and an account card.
 */
public class GoonTitleScreen extends Screen implements GoonScreen {
	private static final float BUTTON_WIDTH = 200;
	private static final float BUTTON_GAP = 6;
	private static final float CARD_WIDTH = 200;
	private static List<String> news;

	private final List<Entry> entries = new ArrayList<>();
	private final String clientVersion;
	private final String gameVersion;
	private long openedAt;
	private float s = 1;
	private float vw;
	private float vh;

	public GoonTitleScreen() {
		super(Component.translatable("narrator.screen.title"));
		this.clientVersion = versionOf(Goon.MOD_ID);
		this.gameVersion = versionOf("minecraft");
	}

	private static String versionOf(String modId) {
		return FabricLoader.getInstance().getModContainer(modId)
			.map(container -> container.getMetadata().getVersion().getFriendlyString()).orElse("?");
	}

	/** The "[+] ..." lines of the bundled CHANGELOG.md (the same notes posted in Discord). */
	private static List<String> news() {
		if (news == null) {
			news = new ArrayList<>();
			try (InputStream in = GoonTitleScreen.class.getResourceAsStream("/assets/goonclient/CHANGELOG.md")) {
				if (in != null) {
					BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
					String line;
					while ((line = reader.readLine()) != null) {
						if (line.startsWith("[+]")) {
							news.add(line.substring(3).trim());
						}
					}
				}
			} catch (Exception e) {
				Goon.LOGGER.warn("Couldn't read the bundled changelog", e);
			}
		}
		return news;
	}

	@Override
	protected void init() {
		if (openedAt == 0) {
			openedAt = System.currentTimeMillis();
		}
		s = Ui.menuScale(width, height);
		vw = width / s;
		vh = height / s;
		entries.clear();
		entries.add(new Entry("Singleplayer", Menus.Style.PRIMARY, () -> minecraft.gui.setScreen(new SelectWorldScreen(this))));
		entries.add(new Entry("Multiplayer", Menus.Style.NORMAL, () -> minecraft.gui.setScreen(minecraft.options.skipMultiplayerWarning
			? new JoinMultiplayerScreen(this) : new SafetyScreen(this))));
		entries.add(new Entry("Goon Client", Menus.Style.NORMAL, () -> minecraft.gui.setScreen(new ClickGuiScreen(this))));
		entries.add(new Entry("Wardrobe", Menus.Style.NORMAL, () -> minecraft.gui.setScreen(new CosmeticsScreen(this))));
		if (FabricLoader.getInstance().isModLoaded("modmenu")) {
			entries.add(new Entry("Mods", Menus.Style.NORMAL, () -> minecraft.gui.setScreen(ModMenuCompat.modsScreen(this))));
		}
		entries.add(new Entry("Options", Menus.Style.NORMAL, () -> minecraft.gui.setScreen(new OptionsScreen(this, minecraft.options))));
		entries.add(new Entry("Screenshots", Menus.Style.NORMAL, () -> minecraft.gui.setScreen(new ScreenshotScreen(this))));
		entries.add(new Entry("Quit Game", Menus.Style.DANGER, minecraft::stop));
	}

	@Override
	public void extractBackground(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
		// Our own background (Interface > Menu background) replaces the panorama through ScreenMixin; only the vanilla
		// panorama needs blurring
		extractPanorama(g, partialTick);
		boolean ours = Backdrop.replacesPanorama();
		if (!ours) {
			extractBlurredBackground(g);
		}
		float open = Ui.easeOutCubic((System.currentTimeMillis() - openedAt) / 700f);
		g.fill(0, 0, width, height, ours ? 0x1F090A0C : 0x59090A0C);
		Menus.sideShade(g, width, height, 0.6f, 0.8f * open);
		g.fillGradient(0, height / 2, width, height, 0x00090A0C, 0x99090A0C);
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor g, int realMouseX, int realMouseY, float partialTick) {
		int mouseX = (int) (realMouseX / s);
		int mouseY = (int) (realMouseY / s);
		g.pose().pushMatrix();
		g.pose().scale(s, s);
		boolean narrow = vw < 440;
		float left = narrow ? (vw - BUTTON_WIDTH) / 2f : Math.max(24, vw * 0.08f);
		float titleSize = vw >= 640 ? 26 : 19;
		float markSize = titleSize * 1.05f;
		float buttons = entries.size() * (Menus.BUTTON_HEIGHT + BUTTON_GAP) - BUTTON_GAP;
		float top = Math.max(10, (vh - 30 - markSize - 26 - buttons) / 2f);

		// Wordmark: the mark, then GOON in white and CLIENT in the accent, rising in
		float head = Menus.stagger(openedAt, 0, 0, 600);
		float rise = (1 - head) * 10;
		float titleWidth = GoonFont.width("GOON CLIENT", titleSize, GoonFont.Weight.BOLD);
		float markX = narrow ? (vw - titleWidth - markSize - 10) / 2f : left;
		Ui.logoMark(g, font, markX, top + rise, markSize, head);
		float wordX = markX + markSize + 10, wordY = top + rise + (markSize - titleSize) / 2f + 0.5f;
		GoonFont.draw(g, "GOON ", wordX, wordY, titleSize, GoonFont.Weight.BOLD, Ui.withAlpha(0xFFF4F4F4, head), false);
		GoonFont.draw(g, "CLIENT", wordX + GoonFont.width("GOON ", titleSize, GoonFont.Weight.BOLD), wordY, titleSize, GoonFont.Weight.BOLD,
			Ui.withAlpha(Ui.accent(), head), false);
		String tagline = "PvE client for Minecraft " + gameVersion;
		float taglineX = narrow ? (vw - GoonFont.width(tagline, 8.6f, GoonFont.Weight.REGULAR)) / 2f : left;
		GoonFont.draw(g, tagline, taglineX, top + markSize + 9 + rise, 8.6f, GoonFont.Weight.REGULAR, Ui.withAlpha(Ui.MUTED, head), true);

		float y = top + markSize + 30;
		for (int i = 0; i < entries.size(); i++) {
			Entry entry = entries.get(i);
			if (i == entries.size() - 1) {
				y += 6;
			}
			entry.x = left;
			entry.y = y;
			Menus.button(g, entry.label, left, y, BUTTON_WIDTH, mouseX, mouseY, Menus.stagger(openedAt, i, 140, 420), entry.style);
			y += Menus.BUTTON_HEIGHT + BUTTON_GAP;
		}

		float fade = Menus.stagger(openedAt, 0, 200, 600);
		String footer = "Goon Client " + clientVersion + "   Minecraft " + gameVersion + "   Fabric";
		GoonFont.draw(g, footer, narrow ? 8 : left, vh - 16, 7.4f, GoonFont.Weight.REGULAR, Ui.withAlpha(Ui.FAINT, fade), true);
		String backgroundNote = Backdrop.customStatus();
		if (backgroundNote != null) {
			GoonFont.draw(g, backgroundNote, narrow ? 8 : left, vh - 27, 7.4f, GoonFont.Weight.REGULAR, Ui.withAlpha(Ui.MUTED, fade), true);
		}
		if (!narrow && vw >= 600) {
			drawNews(g);
		}
		drawAccount(g, fade);
		g.pose().popMatrix();
	}

	/** "What's new" card, top right. */
	private void drawNews(GuiGraphicsExtractor g) {
		List<String> lines = news();
		if (lines.isEmpty()) {
			return;
		}
		float appear = Menus.stagger(openedAt, 2, 260, 520);
		int shown = Math.min(5, lines.size());
		float x1 = vw - CARD_WIDTH - 18 + (1 - appear) * 16;
		float y1 = 18;
		float rowHeight = 21;
		float h = 34 + shown * rowHeight + (lines.size() > shown ? 12 : 0) + 6;
		GlassUi.window(g, x1, y1, CARD_WIDTH, h, appear);
		GoonFont.draw(g, "What's new", x1 + 12, y1 + 11, 9.2f, GoonFont.Weight.BOLD, Ui.withAlpha(Ui.TEXT, appear), false);
		String version = "v" + clientVersion;
		float badge = GoonFont.width(version, 7.2f, GoonFont.Weight.BOLD) + 10;
		Shapes.roundRect(g, x1 + CARD_WIDTH - 12 - badge, y1 + 10, x1 + CARD_WIDTH - 12, y1 + 22, 6, Ui.withAlpha(Ui.withAlpha(Ui.accent(), 0.18f), appear));
		GoonFont.draw(g, version, x1 + CARD_WIDTH - 12 - badge + 5, y1 + 12.5f, 7.2f, GoonFont.Weight.BOLD, Ui.withAlpha(Ui.accent(), appear), false);
		float y = y1 + 32;
		for (int i = 0; i < shown; i++) {
			Shapes.circle(g, x1 + 15, y + 4.5f, 1.8f, Ui.withAlpha(Ui.accent(), appear));
			String text = lines.get(i);
			// "Feature: details" -> just the feature name; otherwise shortened to fit
			int colon = text.indexOf(':');
			String first = Ui.ellipsize(colon > 0 ? text.substring(0, colon) : text, CARD_WIDTH - 36, 7.4f, GoonFont.Weight.REGULAR);
			GoonFont.draw(g, first, x1 + 22, y, 7.4f, GoonFont.Weight.REGULAR, Ui.withAlpha(0xFFC9CCD2, appear), false);
			y += rowHeight;
		}
		if (lines.size() > shown) {
			GoonFont.draw(g, "+" + (lines.size() - shown) + " more in the changelog", x1 + 12, y - 4, 7.2f, GoonFont.Weight.REGULAR,
				Ui.withAlpha(Ui.FAINT, appear), false);
		}
	}

	private void drawAccount(GuiGraphicsExtractor g, float alpha) {
		String name = minecraft.getUser().getName();
		float cardWidth = Math.max(GoonFont.width(name, 8.6f, GoonFont.Weight.BOLD), GoonFont.width("Signed in", 7.4f, GoonFont.Weight.REGULAR)) + 44;
		float x2 = vw - 12;
		float x1 = x2 - cardWidth;
		float y1 = vh - 40;
		float y2 = vh - 12;
		GlassUi.window(g, x1, y1, x2 - x1, y2 - y1, alpha);
		// Initial in an accent circle stands in for the skin head
		Shapes.circle(g, x1 + 15, y1 + 14, 9, Ui.withAlpha(Ui.accent(), alpha));
		String initial = name.isEmpty() ? "?" : name.substring(0, 1).toUpperCase();
		float iw = GoonFont.width(initial, 8.6f, GoonFont.Weight.BOLD);
		GoonFont.draw(g, initial, x1 + 15 - iw / 2f, y1 + 9.5f, 8.6f, GoonFont.Weight.BOLD, Ui.withAlpha(Ui.ON_ACCENT, alpha), false);
		GoonFont.draw(g, name, x1 + 30, y1 + 5, 8.6f, GoonFont.Weight.BOLD, Ui.withAlpha(Ui.TEXT, alpha), false);
		GoonFont.draw(g, "Signed in", x1 + 30, y1 + 15.5f, 7.4f, GoonFont.Weight.REGULAR, Ui.withAlpha(Ui.MUTED, alpha), false);
	}

	@Override
	public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
		double mx = event.x() / s;
		double my = event.y() / s;
		for (Entry entry : entries) {
			if (Ui.inside(mx, my, entry.x, entry.y, entry.x + BUTTON_WIDTH, entry.y + Menus.BUTTON_HEIGHT)) {
				minecraft.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, 1.0f));
				entry.action.run();
				return true;
			}
		}
		return super.mouseClicked(event, doubleClick);
	}

	@Override
	public boolean shouldCloseOnEsc() {
		return false;
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}

	private static final class Entry {
		private final String label;
		private final Menus.Style style;
		private final Runnable action;
		private float x;
		private float y;

		private Entry(String label, Menus.Style style, Runnable action) {
			this.label = label;
			this.style = style;
			this.action = action;
		}
	}
}
