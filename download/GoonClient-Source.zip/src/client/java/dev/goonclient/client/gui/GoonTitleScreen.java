package dev.goonclient.client.gui;

import com.mojang.blaze3d.platform.InputConstants;
import dev.goonclient.Goon;
import dev.goonclient.client.compat.ModMenuCompat;
import dev.goonclient.client.gui.render.Backdrop;
import dev.goonclient.client.gui.render.GoonFont;
import dev.goonclient.client.gui.render.Icons;
import dev.goonclient.client.gui.render.Shapes;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen;
import net.minecraft.client.gui.screens.multiplayer.SafetyScreen;
import net.minecraft.client.gui.screens.options.OptionsScreen;
import net.minecraft.client.gui.screens.worldselection.SelectWorldScreen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;

/** Original, minimal Goon title: branding, two play controls and a compact tools row. */
public class GoonTitleScreen extends Screen implements GoonScreen {
    private final List<Entry> entries = new ArrayList<>();
    private final String clientVersion = versionOf(Goon.MOD_ID);
    private final String gameVersion = versionOf("minecraft");
    private long openedAt;
    private float scale = 1, canvasW, canvasH, centreX, centreY;
    private int focused = -1;

    public GoonTitleScreen() { super(Component.literal("Goon Client main menu")); }

    private static String versionOf(String id) {
        return FabricLoader.getInstance().getModContainer(id)
            .map(c -> c.getMetadata().getVersion().getFriendlyString()).orElse("?");
    }

    @Override
    protected void init() {
        if (openedAt == 0) openedAt = System.currentTimeMillis();
        scale = Math.max(.01f, Math.min(1f, Math.min(width / 480f, height / 360f)));
        canvasW = width / scale; canvasH = height / scale;
        centreX = canvasW / 2; centreY = canvasH / 2;
        entries.clear();
        add("Singleplayer", Icons.Icon.CUBE, () -> minecraft.gui.setScreen(new SelectWorldScreen(this)));
        add("Multiplayer", Icons.Icon.GLOBE, () -> minecraft.gui.setScreen(minecraft.options.skipMultiplayerWarning
            ? new JoinMultiplayerScreen(this) : new SafetyScreen(this)));
        add("Modules", Icons.Icon.SLIDERS, () -> minecraft.gui.setScreen(new ClickGuiScreen(this)));
        add("Wardrobe", Icons.Icon.BACKPACK, () -> minecraft.gui.setScreen(new CosmeticsScreen(this)));
        add("HUD layout", Icons.Icon.LAYOUT, () -> minecraft.gui.setScreen(new HudEditorScreen(this)));
        add("Options", Icons.Icon.COG, () -> minecraft.gui.setScreen(new OptionsScreen(this, minecraft.options)));
        if (FabricLoader.getInstance().isModLoaded("modmenu")) {
            add("Mods", Icons.Icon.FOLDER, () -> minecraft.gui.setScreen(ModMenuCompat.modsScreen(this)));
        }
        add("Screenshots", Icons.Icon.MONITOR, () -> minecraft.gui.setScreen(new ScreenshotScreen(this)));
        add("Quit Game", Icons.Icon.CLOSE, minecraft::stop);
        int tools = entries.size() - 3;
        for (int i = 0; i < entries.size(); i++) {
            Entry e = entries.get(i);
            if (i < 2) {
                e.x = centreX - 118; e.y = centreY - 4 + i * 43; e.w = 236; e.h = 34;
            } else if (i == entries.size() - 1) {
                e.x = canvasW - 88; e.y = canvasH - 37; e.w = 72; e.h = 23;
            } else {
                e.x = centreX - (tools * 34 - 8) / 2f + (i - 2) * 34;
                e.y = centreY + 91; e.w = 26; e.h = 26;
            }
        }
        if (focused >= entries.size()) focused = -1;
    }

    private void add(String label, Icons.Icon icon, Runnable action) { entries.add(new Entry(label, icon, action)); }

    @Override
    public void extractBackground(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
        extractPanorama(g, partialTick);
        if (!Backdrop.replacesPanorama()) extractBlurredBackground(g);
        g.fill(0, 0, width, height, 0x3307090C);
        g.fillGradient(0, height / 2, width, height, 0x0007090C, 0x7007090C);
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int realMouseX, int realMouseY, float partialTick) {
        float mx = realMouseX / scale, my = realMouseY / scale;
        float alpha = .5f + .5f * Ui.easeOutCubic((System.currentTimeMillis() - openedAt) / 240f);
        g.pose().pushMatrix(); g.pose().scale(scale, scale);
        float titleSize = 29, logoSize = 70;
        Shapes.shadow(g, centreX - 35, centreY - 154, centreX + 35, centreY - 84, 13, 20, 6, .3f * alpha);
        Ui.logoMark(g, font, centreX - logoSize / 2, centreY - 154, logoSize, alpha);
        float words = GoonFont.width("GOON CLIENT", titleSize, GoonFont.Weight.BOLD);
        float left = centreX - words / 2;
        text(g, "GOON ", left, centreY - 72, titleSize, Ui.TEXT, true, alpha);
        text(g, "CLIENT", left + GoonFont.width("GOON ", titleSize, GoonFont.Weight.BOLD), centreY - 72, titleSize, Ui.accent(), true, alpha);
        centered(g, "Minecraft " + gameVersion, centreY - 30, 7.5f, GlassUi.LABEL, alpha);
        int tools = entries.size() - 3;
        float dockW = tools * 34 + 8;
        Shapes.panel(g, centreX - dockW / 2, centreY + 85, centreX + dockW / 2, centreY + 123,
            9, Ui.withAlpha(GlassUi.themedSurface(0xA00E1117), alpha), Ui.withAlpha(0x24FFFFFF, alpha));
        String hoveredTool = null;
        for (int i = 0; i < entries.size(); i++) {
            Entry e = entries.get(i);
            boolean hover = Ui.inside(mx, my, e.x, e.y, e.x + e.w, e.y + e.h);
            boolean focus = focused == i;
            float lit = Ui.animate("title:hover:" + e.label, hover || focus ? 1 : 0, .55f);
            boolean play = i < 2, quit = i == entries.size() - 1;
            int accent = quit ? Ui.BAD : Ui.accent();
            int fill = Ui.lerp(lit * .18f + (i == 0 ? .055f : 0), GlassUi.themedSurface(0xD0121419), accent);
            int edge = Ui.lerp(lit, i == 0 ? Ui.withAlpha(accent, .4f) : 0x3BFFFFFF, Ui.withAlpha(accent, .9f));
            // Only the main actions have a persistent surface; tools recede until hovered.
            if (play || lit > .01f) {
                Shapes.panel(g, e.x, e.y, e.x + e.w, e.y + e.h, play ? 4 : 6, Ui.withAlpha(fill, alpha * (play ? 1 : lit)), Ui.withAlpha(edge, alpha * (play ? 1 : lit)));
                if (play) dev.goonclient.client.hud.HudRenderUtil.rim(g, e.x, e.y, e.w, e.h, 4, .5f * alpha);
            }
            if (play) {
                Icons.draw(g, e.icon, e.x + 13, e.y + 9, 16, Ui.withAlpha(Ui.lerp(i == 0 ? .6f + .4f * lit : lit, GlassUi.LABEL, accent), alpha));
                float tw = GoonFont.width(e.label, 10, GoonFont.Weight.BOLD);
                text(g, e.label, centreX - tw / 2, e.y + 12, 10, Ui.TEXT, true, alpha);
            } else if (quit) {
                Icons.draw(g, e.icon, e.x + 8, e.y + 6, 11, Ui.withAlpha(Ui.lerp(lit, GlassUi.LABEL, accent), alpha));
                text(g, "Quit Game", e.x + 25, e.y + 8, 7.2f, Ui.lerp(lit, GlassUi.LABEL, accent), false, alpha);
            } else {
                Icons.draw(g, e.icon, e.x + 6, e.y + 6, 14, Ui.withAlpha(Ui.lerp(lit, GlassUi.LABEL, accent), alpha));
                if (hover || focus) hoveredTool = e.label;
            }
        }
        if (hoveredTool != null) centered(g, hoveredTool, centreY + 130, 7.4f, Ui.TEXT, alpha);
        text(g, minecraft.getUser().getName(), 16, canvasH - 34, 7.5f, GlassUi.LABEL, false, alpha);
        text(g, "Goon Client " + clientVersion + "  /  Fabric", 16, canvasH - 20, 6.8f, GlassUi.MUTED, false, alpha);
        String status = Backdrop.customStatus();
        if (status != null) centered(g, Ui.ellipsize(status, 350, 7, GoonFont.Weight.REGULAR), canvasH - 18, 7, GlassUi.LABEL, alpha);
        g.pose().popMatrix();
    }

    private void centered(GuiGraphicsExtractor g, String value, float y, float size, int color, float alpha) {
        text(g, value, centreX - GoonFont.width(value, size, GoonFont.Weight.REGULAR) / 2, y, size, color, false, alpha);
    }
    private static void text(GuiGraphicsExtractor g, String value, float x, float y, float size, int color, boolean bold, float alpha) {
        GoonFont.draw(g, value, x, y, size, bold ? GoonFont.Weight.BOLD : GoonFont.Weight.REGULAR, Ui.withAlpha(color, alpha), false);
    }
    private void activate(Entry e) {
        minecraft.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, 1f));
        e.action.run();
    }
    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (event.button() != InputConstants.MOUSE_BUTTON_LEFT) return super.mouseClicked(event, doubleClick);
        double mx = event.x() / scale, my = event.y() / scale;
        for (Entry e : entries) if (Ui.inside(mx, my, e.x, e.y, e.x + e.w, e.y + e.h)) {
            focused = -1; activate(e); return true;
        }
        return super.mouseClicked(event, doubleClick);
    }
    @Override
    public boolean keyPressed(KeyEvent event) {
        int key = event.key();
        if (key == InputConstants.KEY_TAB || key == InputConstants.KEY_RIGHT || key == InputConstants.KEY_DOWN
            || key == InputConstants.KEY_LEFT || key == InputConstants.KEY_UP) {
            int step = key == InputConstants.KEY_LEFT || key == InputConstants.KEY_UP || (key == InputConstants.KEY_TAB && event.hasShiftDown()) ? -1 : 1;
            focused = focused < 0 ? (step > 0 ? 0 : entries.size() - 1) : Math.floorMod(focused + step, entries.size());
            return true;
        }
        if ((key == InputConstants.KEY_RETURN || key == InputConstants.KEY_SPACE) && focused >= 0) {
            activate(entries.get(focused)); return true;
        }
        return super.keyPressed(event);
    }
    @Override public boolean shouldCloseOnEsc() { return false; }
    @Override public boolean isPauseScreen() { return false; }

    private static final class Entry {
        final String label;
        final Icons.Icon icon;
        final Runnable action;
        float x, y, w, h;
        Entry(String label, Icons.Icon icon, Runnable action) { this.label = label; this.icon = icon; this.action = action; }
    }
}
