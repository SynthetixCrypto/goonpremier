package dev.goonclient.client.modules.inventory;

import dev.goonclient.client.hud.HudPosition;
import dev.goonclient.client.gui.Ui;
import dev.goonclient.client.hud.HudModule;
import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.setting.NumberSetting;
import dev.goonclient.client.tracker.AdventureLog;
import dev.goonclient.client.tracker.LootTracker;
import dev.goonclient.client.tracker.SessionStats;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/** "+12 Cobblestone" popups for items you pick up, merged per item while they're on screen. */
public class PickupNotifier extends HudModule {
	private static PickupNotifier instance;

	private final NumberSetting duration = add(new NumberSetting("duration", "Show for", 4, 1, 10, 0.5, "s"));
	private final NumberSetting maxRows = add(new NumberSetting("max_rows", "Max rows", 6, 1, 12, 1));
	private final List<Pickup> pickups = new ArrayList<>();

	public PickupNotifier() {
		super("pickup_notifier", "Pickup Notifier", "Shows what you just picked up", Category.INVENTORY, true, HudPosition.rightMiddle(2, 5));
		instance = this;
	}

	/** Called from the item pickup packet handler on the main thread. */
	public static void onTakeItem(int itemEntityId, int playerId, int amount) {
		Minecraft mc = Minecraft.getInstance();
		if (mc.player == null || mc.level == null || playerId != mc.player.getId()) {
			return;
		}
		Entity entity = mc.level.getEntity(itemEntityId);
		if (!(entity instanceof ItemEntity itemEntity)) {
			return;
		}
		SessionStats.onPickup(amount);
		LootTracker.onPickup(itemEntity.getItem(), amount);
		AdventureLog.onPickup(itemEntity.getItem(), amount);
		if (instance != null && instance.isEnabled()) {
			instance.add(itemEntity.getItem(), amount);
		}
	}

	private void add(ItemStack stack, int amount) {
		long now = System.currentTimeMillis();
		for (Pickup pickup : pickups) {
			if (pickup.item == stack.getItem()) {
				pickup.count += amount;
				pickup.time = now;
				return;
			}
		}
		pickups.add(0, new Pickup(stack.getItem(), stack.copyWithCount(1), amount, now));
	}

	@Override
	public boolean isVisible(Minecraft mc) {
		return !pickups.isEmpty();
	}

	@Override
	protected boolean isTransient() {
		return true;
	}

	@Override
	protected void render(GuiGraphicsExtractor g, Minecraft mc, boolean editing) {
		long now = System.currentTimeMillis();
		long showMs = Math.round(duration.get() * 1000);
		pickups.removeIf(p -> now - p.time > showMs);
		List<Pickup> rows = new ArrayList<>(pickups);
		if (rows.isEmpty() && editing) {
			rows.add(new Pickup(Items.COBBLESTONE, new ItemStack(Items.COBBLESTONE), 37, now));
			rows.add(new Pickup(Items.DIAMOND, new ItemStack(Items.DIAMOND), 3, now));
		}
		if (rows.isEmpty()) {
			setSize(1, 1);
			return;
		}
		Font font = mc.font;
		int width = 0;
		Iterator<Pickup> it = rows.iterator();
		int count = 0;
		while (it.hasNext()) {
			Pickup pickup = it.next();
			if (count++ >= maxRows.intValue()) {
				it.remove();
				continue;
			}
			width = Math.max(width, 20 + Ui.boldWidth(font, "+" + pickup.count + " ") + Ui.width(font, pickup.name()) + 5);
		}
		int y = 0;
		for (Pickup pickup : rows) {
			float age = (now - pickup.time) / (float) showMs;
			float alpha = age > 0.75f ? 1f - (age - 0.75f) / 0.25f : 1f;
			Ui.roundRect(g, 0, y, width, y + 18, 4, Ui.withAlpha(Ui.HUD_BACKGROUND, alpha));
			if (alpha > 0.3f) {
				g.item(pickup.icon, 2, y + 1);
			}
			String amount = "+" + pickup.count + " ";
			Ui.bold(g, font, amount, 20, y + 5, Ui.withAlpha(Ui.accent(), alpha), true);
			Ui.text(g, font, pickup.name(), 20 + Ui.boldWidth(font, amount), y + 5, Ui.withAlpha(Ui.TEXT, alpha), true);
			y += 20;
		}
		setSize(width, y - 2);
	}

	private static final class Pickup {
		private final Item item;
		private final ItemStack icon;
		private int count;
		private long time;

		private Pickup(Item item, ItemStack icon, int count, long time) {
			this.item = item;
			this.icon = icon;
			this.count = count;
			this.time = time;
		}

		private String name() {
			return icon.getHoverName().getString();
		}
	}
}
