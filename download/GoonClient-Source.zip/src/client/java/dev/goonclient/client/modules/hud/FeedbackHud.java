/*
 * This file incorporates code from the Combatant Client distribution.
 * Copyright (c) 2026 pivosos2007.
 * Licensed under the GNU General Public License v3.0.
 * Modified for Goon Client, 2026-10-04: HudNotifier.java toast geometry (scale 1.35, 16-unit box, toggle |
 * pipe | Onest Medium text, progress line along the top, glass fill) and colours; rounded and rimmed like the
 * reference screenshot's liquid-glass pill. Drawn with Goon's renderer; Goon's own notice queue and timing.
 */
package dev.goonclient.client.modules.hud;

import dev.goonclient.client.gui.Ui;
import dev.goonclient.client.gui.render.BackdropBlur;
import dev.goonclient.client.gui.render.Icons;
import dev.goonclient.client.gui.render.Shapes;
import dev.goonclient.client.hud.HudModule;
import dev.goonclient.client.hud.HudPosition;
import dev.goonclient.client.hud.HudRenderUtil;
import dev.goonclient.client.hud.HudRenderUtil.Font;
import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.setting.NumberSetting;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/** Small bounded notification stack; lifetime and motion use monotonic time, never FPS. */
public final class FeedbackHud extends HudModule {
    // HudNotifier.java, in its own units
    private static final float SCALE = 1.35f, BOX_HEIGHT = 16, GAP = 3, LEFT_PAD = 7, RIGHT_PAD = 9, TOGGLE_W = 20,
        TOGGLE_PIPE_GAP = 4.5f, PIPE_TEXT_GAP = 6, PROGRESS_H = 1.35f, TEXT = 18 * .95f, SLIDE = 7, MIN_WIDTH = 60;
    private static final int GLASS_BG = HudRenderUtil.GLASS_BG, TEXT_COLOR = 0xFFF7FAFF, PROGRESS_TRACK = 0x33FFFFFF, PROGRESS_FILL = 0xC4FFFFFF;

    private static FeedbackHud instance;
    private static final List<Notice> NOTICES = new ArrayList<>();
    private final NumberSetting duration = add(new NumberSetting("duration", "Show for", 3, 1, 6, .5, "s"));
    private record Notice(String id, String title, String message, boolean positive, long started, long duration) { }

    public FeedbackHud() {
        super("notifications", "Notifications", "Animated module-toggle feedback and potion-expiry warnings", Category.HUD, true, HudPosition.bottomRight(5, 37));
        instance = this;
    }

    public static void post(String id, String title, String message, boolean positive) {
        if (instance == null || !instance.isEnabled()) return;
        prune(); NOTICES.removeIf(n -> n.id.equals(id));
        if (NOTICES.size() >= 3) NOTICES.removeFirst();
        NOTICES.add(new Notice(id, title, message, positive, System.nanoTime(), (long)(instance.duration.get() * 1_000_000_000L)));
    }
    public static void clear() { NOTICES.clear(); }
    public static int count() { prune(); return NOTICES.size(); }
    private static void prune() { long now = System.nanoTime(); NOTICES.removeIf(n -> now - n.started >= n.duration); }
    @Override protected void onDisable() { clear(); }
    @Override public void onTick(Minecraft mc) { if (mc.level == null) clear(); else prune(); }
    @Override public boolean isVisible(Minecraft mc) { return count() > 0; }

    /** HudNotifier's box height: max(16, text line + 6). */
    private static float boxHeight() {
        return Math.max(BOX_HEIGHT, TEXT + 6);
    }

    /** GUI units per notifier unit: HudScale * TextSizing.scaleForSize(20) * 1.35. */
    private static float unit() {
        return HudRenderUtil.resolutionScale() * (20f / 18f) * SCALE;
    }

    @Override protected void measurePreview(Minecraft mc) { size(width("Fullbright", "Enabled"), 1); }

    @Override protected void renderPreview(GuiGraphicsExtractor g, Minecraft mc) {
        float w = width("Fullbright", "Enabled");
        size(w, 1);
        scaled(g, () -> toast(g, "Fullbright", "Enabled", true, 0, 1, .65f, w));
    }

    @Override protected void measure(Minecraft mc, boolean editing) {
        prune();
        size(widest(), Math.max(1, NOTICES.size()));
    }

    private static float widest() {
        float w = MIN_WIDTH;
        for (var n : NOTICES) w = Math.max(w, width(n.title, n.message));
        return w;
    }

    private void size(float width, int rows) {
        float k = unit();
        setSize(Math.round(Math.max(MIN_WIDTH, width) * k), Math.round((rows * boxHeight() + (rows - 1) * GAP) * k));
    }

    @Override protected void render(GuiGraphicsExtractor g, Minecraft mc, boolean editing) {
        measure(mc, editing);
        if (NOTICES.isEmpty()) { if (editing) renderPreview(g, mc); return; }
        long now = System.nanoTime();
        float total = widest();
        scaled(g, () -> {
            for (int i = 0; i < NOTICES.size(); i++) {
                var n = NOTICES.get(i);
                float age = (now - n.started) / 1_000_000_000f;
                float left = (n.duration - (now - n.started)) / 1_000_000_000f;
                float alpha = Math.min(Ui.easeOutCubic(age / .4f), Ui.easeOutCubic(left / .26f));
                // Newest at the bottom, sliding in from the right
                toast(g, n.title, n.message, n.positive, i * (boxHeight() + GAP), alpha, left / Math.max(1e-3f, n.duration / 1_000_000_000f), total);
            }
        });
    }

    private static void scaled(GuiGraphicsExtractor g, Runnable draw) {
        float k = unit();
        g.pose().pushMatrix();
        g.pose().scale(k, k);
        try {
            draw.run();
        } finally {
            g.pose().popMatrix();
        }
    }

    /** "Fullbright - enabled!" style text, as in the reference notification. */
    private static String text(String title, String message) {
        String m = message.equals("Enabled") || message.equals("Disabled") ? message.toLowerCase(java.util.Locale.ROOT) + "!" : message;
        return title + " - " + m;
    }

    private static float width(String title, String message) {
        return LEFT_PAD + TOGGLE_W + TOGGLE_PIPE_GAP + HudRenderUtil.width("|", TEXT, Font.ONEST_MEDIUM) + PIPE_TEXT_GAP
            + HudRenderUtil.width(text(title, message), TEXT, Font.ONEST_MEDIUM) + RIGHT_PAD;
    }

    private static void toast(GuiGraphicsExtractor g, String title, String message, boolean positive, float y, float alpha, float remaining, float totalWidth) {
        if (alpha <= .001f) return;
        float w = width(title, message), h = boxHeight(), x = totalWidth - w + (1 - alpha) * SLIDE;
        int bg = HudRenderUtil.scaleAlpha(GLASS_BG, alpha);
        // The reference shows the liquid-glass pill fully rounded with a bright rim
        HudRenderUtil.glassFill(g, x, y, w, h, h * .5f, h * .5f, bg, bg, BackdropBlur.available(), alpha);
        HudRenderUtil.rim(g, x, y, w, h, h * .5f, alpha);
        // Time left, along the flat top edge
        float px = x + .45f, py = y + .08f, pw = Math.max(0, w - .9f);
        int track = HudRenderUtil.scaleAlpha(PROGRESS_TRACK, alpha), fill = HudRenderUtil.scaleAlpha(PROGRESS_FILL, alpha);
        Shapes.gradientRect(g, px, py, px + pw, py + PROGRESS_H, 0, 0, track, track);
        float done = pw * Math.max(0, Math.min(1, remaining));
        if (done > 0) Shapes.gradientRect(g, px, py, px + done, py + PROGRESS_H, 0, 0, fill, fill);

        // Module toggles use the accent; amber is for real warnings (an effect running out)
        boolean toggle = message.equals("Enabled") || message.equals("Disabled");
        int accent = Ui.withAlpha(positive || toggle ? HudRenderUtil.accent() : Ui.WARN, alpha);
        Icons.Icon icon = toggle ? (message.equals("Enabled") ? Icons.Icon.TOGGLE_ON : Icons.Icon.TOGGLE_OFF) : Icons.Icon.WARNING;
        Icons.draw(g, icon, x + LEFT_PAD, y + (h - TOGGLE_W) * .5f, TOGGLE_W, accent);

        // The text breathes between 78% and 100% brightness; the pipe follows it
        float wave = .5f + .5f * (float) Math.sin(System.currentTimeMillis() / 1000.0 * 2.2);
        float darken = .78f + .22f * wave;
        int text = darken(HudRenderUtil.scaleAlpha(TEXT_COLOR, .88f * alpha), darken);
        int pipe = darken(HudRenderUtil.scaleAlpha(HudRenderUtil.mixColor(TEXT_COLOR, PROGRESS_TRACK, .55f), .72f * alpha), darken * .96f);
        float pipeX = x + LEFT_PAD + TOGGLE_W + TOGGLE_PIPE_GAP, top = y + (h - TEXT) * .5f + .8f;
        HudRenderUtil.text(g, "|", pipeX, top, TEXT, Font.ONEST_MEDIUM, pipe);
        HudRenderUtil.text(g, text(title, message), pipeX + HudRenderUtil.width("|", TEXT, Font.ONEST_MEDIUM) + PIPE_TEXT_GAP, top, TEXT,
            Font.ONEST_MEDIUM, text);
    }

    private static int darken(int color, float factor) {
        int r = Math.round(((color >> 16) & 0xFF) * factor), gr = Math.round(((color >> 8) & 0xFF) * factor), b = Math.round((color & 0xFF) * factor);
        return (color & 0xFF000000) | (r << 16) | (gr << 8) | b;
    }
}
