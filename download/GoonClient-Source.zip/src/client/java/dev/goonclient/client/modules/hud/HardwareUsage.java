package dev.goonclient.client.modules.hud;

import dev.goonclient.client.gui.render.Icons;
import com.sun.management.OperatingSystemMXBean;
import dev.goonclient.client.hud.HudPosition;
import dev.goonclient.client.hud.TextHudModule;
import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.setting.BooleanSetting;
import java.lang.management.ManagementFactory;
import java.util.List;
import net.minecraft.client.Minecraft;

/** Once-per-second CPU sampling and Minecraft's asynchronous GPU frame timer. */
public final class HardwareUsage extends TextHudModule {
	private static HardwareUsage instance;
	private final BooleanSetting systemCpu = add(new BooleanSetting("system_cpu", "Show whole-system CPU", true));
	private final java.lang.management.OperatingSystemMXBean os = ManagementFactory.getOperatingSystemMXBean();
	private long lastSample;
	private long lastCpu = -1;
	private long lastWall;
	private double cpu = -1, gameCpu = -1, gpu = -1;

	public HardwareUsage() {
		super("hardware_usage", "Hardware Usage", "CPU usage and GPU frame load. GPU is Minecraft render time as a share of frame time, not whole-system usage.",
			Category.HUD, false, HudPosition.leftColumn(88));
		instance = this;
	}

	@Override
	protected Icons.Icon icon() {
		return Icons.Icon.CHIP;
	}

	public static boolean needsGpuTiming() {
		return instance != null && instance.isEnabled() && Minecraft.getInstance().level != null;
	}

	@Override
	public void onTick(Minecraft mc) {
		long now = System.nanoTime();
		if (now - lastSample < 1_000_000_000L) return;
		lastSample = now;
		try {
			cpu = os instanceof OperatingSystemMXBean bean ? bean.getCpuLoad() * 100 : -1;
		} catch (RuntimeException e) {
			cpu = -1;
		}
		long currentCpu = ProcessHandle.current().info().totalCpuDuration().map(java.time.Duration::toNanos).orElse(-1L);
		gameCpu = lastCpu >= 0 && currentCpu >= lastCpu && lastWall > 0 ?
			(currentCpu - lastCpu) * 100.0 / (now - lastWall) / Math.max(1, os.getAvailableProcessors()) : -1;
		lastCpu = currentCpu;
		lastWall = now;
		double measuredGpu = mc.getGpuUtilization();
		gpu = mc.level != null && Double.isFinite(measuredGpu) && measuredGpu > 0 ? Math.min(100, measuredGpu) : -1;
	}

	@Override
	protected void onDisable() {
		lastSample = 0;
		lastCpu = -1;
		lastWall = 0;
		cpu = gameCpu = gpu = -1;
	}

	@Override
	protected void collect(Minecraft mc, List<Line> lines, boolean editing) {
		if (systemCpu.isOn()) lines.add(new Line("CPU", percent(cpu)));
		lines.add(new Line("Game CPU", percent(gameCpu)));
		lines.add(new Line("GPU frame", percent(gpu)));
	}

	private static String percent(double value) {
		return !Double.isFinite(value) || value < 0 ? "N/A" : Math.round(Math.min(100, value)) + "%";
	}
}
