package dev.goonclient.client.gui;

import com.mojang.blaze3d.platform.InputConstants;
import dev.goonclient.client.gui.render.GoonFont;
import dev.goonclient.client.gui.render.Shapes;
import dev.goonclient.client.modules.inventory.ContainerMemory;
import dev.goonclient.client.tracker.ContainerBookmarks;
import dev.goonclient.client.waypoint.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.*;
import net.minecraft.network.chat.Component;

/** Familiar glass list/detail window. Search names and item IDs; snapshots are visibly dated. */
public final class ContainerBookmarksScreen extends Screen implements GoonScreen {
    private record Hit(float x1,float y1,float x2,float y2,Runnable run){}
    private final Screen parent;
    private final List<Hit> hits=new ArrayList<>();
    private int focus=-1;
    private List<ContainerBookmarks.Entry> results=List.of();
    private String query="",selected="",status="",armed="";
    private long revision=-1,armedAt;
    private float s,x,y,w,h,top,bottom,divider,scroll,detailScroll;
    private boolean searchFocus;
    public ContainerBookmarksScreen(Screen parent){super(Component.literal("Container bookmarks"));this.parent=parent;}
    @Override protected void init(){GlassUi.hideHud(minecraft);s=Math.max(.01f,Math.min(Ui.menuScale(width,height),Math.min(width/640f,height/420f)));float vw=width/s,vh=height/s;w=Math.min(640,vw-28);h=Math.min(390,vh-30);x=(vw-w)/2;y=(vh-h)/2;divider=x+w*.46f;top=y+103;bottom=y+h-53;}
    public void search(String text){query=text;revision=-1;scroll=0;refresh();}
    public List<ContainerBookmarks.Entry> results(){refresh();return results;}
    private static final DateTimeFormatter OPENED_TIME=DateTimeFormatter.ofPattern("MMM d, HH:mm");
    private void refresh(){
        if(revision==ContainerBookmarks.revision())return;revision=ContainerBookmarks.revision();String needle=query.toLowerCase(Locale.ROOT).strip();
        results=ContainerBookmarks.all().stream().filter(e->needle.isEmpty()||e.title().toLowerCase(Locale.ROOT).contains(needle)||e.items().stream().anyMatch(i->i.name().toLowerCase(Locale.ROOT).contains(needle)||i.id().contains(needle))).sorted(Comparator.comparingLong(ContainerBookmarks.Entry::seen).reversed()).toList();
        if(results.stream().noneMatch(e->e.id().equals(selected))){selected=results.isEmpty()?"":results.getFirst().id();detailScroll=0;}
        scroll=Math.max(0,Math.min(scroll,Math.max(0,results.size()*47-(bottom-top))));
    }
    private ContainerBookmarks.Entry selected(){return results.stream().filter(e->e.id().equals(selected)).findFirst().orElse(null);}
    private static void text(GuiGraphicsExtractor g,String value,float x,float y,float size,boolean bold,int color){GoonFont.draw(g,value,x,y,size,bold?GoonFont.Weight.BOLD:GoonFont.Weight.REGULAR,color==Ui.MUTED?GlassUi.LABEL:color,false);}
    private static String shorten(String value,float width,float size,boolean bold){return Ui.ellipsize(value,width,size,bold?GoonFont.Weight.BOLD:GoonFont.Weight.REGULAR);}
    @Override public void extractRenderState(GuiGraphicsExtractor g,int realX,int realY,float partial){
        refresh();hits.clear();int mx=(int)(realX/s),my=(int)(realY/s);g.pose().pushMatrix();g.pose().scale(s,s);GlassUi.panel(g,x,y,w,h,1);
        text(g,"Container bookmarks",x+18,y+16,15,true,Ui.TEXT);button(g,"Done",x+w-70,y+15,52,mx,my,true,this::onClose);
        text(g,ContainerBookmarks.active()?shorten(ContainerBookmarks.worldName()+" · "+ContainerBookmarks.size()+" / 256 remembered",w-180,8.2f,false):"Join a world or server to browse its containers.",x+18,y+42,8.2f,false,Ui.MUTED);
        float fieldRight=divider-11;
        Shapes.panel(g,x+18,y+64,fieldRight,y+88,5,Ui.FIELD,searchFocus?Ui.accent():Ui.BORDER);
        text(g,shorten(query.isEmpty()?"Search items or containers":query,fieldRight-x-34,8.2f,false),x+25,y+72,8.2f,false,query.isEmpty()?Ui.MUTED:Ui.TEXT);
        if(searchFocus&&(System.currentTimeMillis()/530)%2==0){float cx=x+25+(query.isEmpty()?0:GoonFont.width(shorten(query,fieldRight-x-34,8.2f,false),8.2f,GoonFont.Weight.REGULAR));Shapes.rect(g,cx,y+69,cx+.6f,y+83,Ui.accent());}
        hits.add(new Hit(x+18,y+64,fieldRight,y+88,()->searchFocus=true));
        button(g,ContainerMemory.recording()?"Recording: on":"Enable recording",divider+13,y+64,w-(divider-x)-31,mx,my,ContainerBookmarks.active(),()->ContainerMemory.setRecording(!ContainerMemory.recording()));
        Shapes.rect(g,divider,y+103,divider+.5f,bottom,Ui.BORDER);
        g.enableScissor((int)(x+14),(int)top,(int)(divider-8),(int)bottom);
        for(int i=0;i<results.size();i++){
            var e=results.get(i);float ry=top+i*47-scroll;if(ry+44<=top||ry>=bottom)continue;
            boolean chosen=e.id().equals(selected),hover=Ui.inside(mx,my,x+18,Math.max(top,ry),divider-11,Math.min(bottom,ry+43));
            if(chosen||hover)Shapes.roundRect(g,x+18,ry,divider-11,ry+43,5,chosen?Ui.withAlpha(Ui.accent(),.16f):Ui.RAISED);
            text(g,shorten(e.title(),divider-x-52,9,true),x+25,ry+7,9,true,Ui.TEXT);
            text(g,e.x()+" "+e.y()+" "+e.z()+" · "+e.items().size()+" item types",x+25,ry+23,7.6f,false,Ui.MUTED);
            hits.add(new Hit(x+18,Math.max(ry,top),divider-11,Math.min(ry+43,bottom),()->{selected=e.id();detailScroll=0;searchFocus=false;armed="";}));
        }
        if(results.isEmpty())text(g,ContainerBookmarks.active()?(query.isBlank()?"Open a container with recording enabled.":"No remembered items match."):"No world loaded.",x+24,top+8,8,false,Ui.MUTED);
        g.disableScissor();bar(g,divider-8,scroll,Math.max(0,results.size()*47-(bottom-top)),top,bottom);
        var e=selected();float dx=divider+13,dw=x+w-18-dx;
        if(e!=null){
            text(g,shorten(e.title(),dw,11,true),dx,top+3,11,true,Ui.TEXT);
            text(g,shorten(e.dimension()+" · "+e.x()+" "+e.y()+" "+e.z(),dw,7.6f,false),dx,top+22,7.6f,false,Ui.MUTED);
            String time=Instant.ofEpochMilli(e.seen()).atZone(ZoneId.systemDefault()).format(OPENED_TIME);
            text(g,"Last opened "+time+" · contents may have changed",dx,top+37,7.4f,false,Ui.WARN);
            float itemTop=top+58,itemBottom=bottom-39;
            detailScroll=Math.max(0,Math.min(detailScroll,Math.max(0,e.items().size()*18-(itemBottom-itemTop))));
            g.enableScissor((int)dx,(int)itemTop,(int)(x+w-16),(int)itemBottom);
            for(int i=0;i<e.items().size();i++){
                var item=e.items().get(i);float iy=itemTop+i*18-detailScroll;if(iy+18<=itemTop||iy>=itemBottom)continue;
                String count=Long.toString(item.count());float cw=GoonFont.width(count,8.2f,GoonFont.Weight.BOLD);
                text(g,shorten(item.name(),dw-cw-17,8.2f,false),dx,iy+4,8.2f,false,Ui.TEXT);text(g,count,dx+dw-cw-6,iy+4,8.2f,true,Ui.TEXT);
            }
            if(e.items().isEmpty())text(g,"Empty when last opened.",dx,itemTop+4,8.2f,false,Ui.MUTED);
            g.disableScissor();bar(g,dx+dw-2,detailScroll,Math.max(0,e.items().size()*18-(itemBottom-itemTop)),itemTop,itemBottom);
            float bw=(dw-10)/3,by=bottom-27;
            button(g,"Waypoint",dx,by,bw,mx,my,true,()->{WaypointManager.add(new Waypoint("Container_"+e.x()+"_"+e.y()+"_"+e.z(),e.x(),e.y(),e.z(),e.dimension(),WaypointManager.nextColor(),false,System.currentTimeMillis()));status="Waypoint saved.";});
            button(g,"Copy coords",dx+bw+5,by,bw,mx,my,true,()->{minecraft.keyboardHandler.setClipboard(e.x()+" "+e.y()+" "+e.z()+" ("+e.dimension()+")");status="Coordinates copied.";});
            button(g,armed.equals(e.id())?"Confirm":"Forget",dx+2*bw+10,by,bw,mx,my,true,()->{if(armed.equals(e.id())&&System.currentTimeMillis()-armedAt<5000){ContainerBookmarks.remove(e.id());armed="";status="Bookmark removed.";}else{armed=e.id();armedAt=System.currentTimeMillis();status="Click Confirm to remove this bookmark.";}});
        }
        if(!armed.isEmpty()&&System.currentTimeMillis()-armedAt>=5000)armed="";
        String note=!ContainerBookmarks.error().isEmpty()?ContainerBookmarks.error():status.isEmpty()?"Remembered contents only. Search never opens containers or requests unseen items.":status;
        text(g,shorten(note,w-36,7.6f,false),x+18,y+h-29,7.6f,false,ContainerBookmarks.error().isEmpty()?Ui.MUTED:Ui.WARN);
        if(focus>=0&&focus<hits.size()){var f=hits.get(focus);Shapes.outline(g,f.x1()-1,f.y1()-1,f.x2()+1,f.y2()+1,5,Ui.accent());}
        g.pose().popMatrix();super.extractRenderState(g,realX,realY,partial);
    }
    private void button(GuiGraphicsExtractor g,String label,float bx,float by,float bw,int mx,int my,boolean enabled,Runnable run){boolean hover=enabled&&Ui.inside(mx,my,bx,by,bx+bw,by+24);Shapes.panel(g,bx,by,bx+bw,by+24,5,hover?Ui.RAISED_HOVER:Ui.RAISED,Ui.BORDER);String shown=shorten(label,bw-10,7.6f,true);text(g,shown,bx+(bw-GoonFont.width(shown,7.6f,GoonFont.Weight.BOLD))/2,by+8,7.6f,true,enabled?Ui.TEXT:Ui.FAINT);if(enabled)hits.add(new Hit(bx,by,bx+bw,by+24,()->{searchFocus=false;run.run();}));}
    private static void bar(GuiGraphicsExtractor g,float x,float scroll,float max,float top,float bottom){if(max<=0)return;float height=bottom-top,thumb=Math.max(16,height*height/(height+max));float yy=top+(height-thumb)*scroll/max;Shapes.roundRect(g,x,yy,x+2,yy+thumb,1,Ui.BORDER_STRONG);}
    @Override public boolean mouseClicked(MouseButtonEvent e,boolean twice){if(e.button()!=InputConstants.MOUSE_BUTTON_LEFT)return true;double mx=e.x()/s,my=e.y()/s;for(int i=hits.size()-1;i>=0;i--){var hit=hits.get(i);if(Ui.inside(mx,my,hit.x1(),hit.y1(),hit.x2(),hit.y2())){focus=i;hit.run().run();return true;}}searchFocus=false;return true;}
    @Override public boolean mouseScrolled(double mx,double my,double dx,double dy){mx/=s;my/=s;if(!Ui.inside(mx,my,x+18,top,x+w-18,bottom))return false;if(mx<divider)scroll=Math.max(0,Math.min(Math.max(0,results.size()*47-(bottom-top)),scroll-(float)dy*30));else detailScroll=Math.max(0,detailScroll-(float)dy*30);return true;}
    @Override public boolean charTyped(CharacterEvent e){if(searchFocus&&e.isAllowedChatCharacter()&&query.length()+e.codepointAsString().length()<=96){search(query+e.codepointAsString());return true;}return super.charTyped(e);}
    @Override public boolean keyPressed(KeyEvent e){
        if(e.key()==InputConstants.KEY_ESCAPE){if(searchFocus&&!query.isEmpty())search("");else onClose();return true;}
        if(e.hasControlDown()&&e.key()==InputConstants.KEY_F){searchFocus=true;focus=1;return true;}
        if(e.key()==InputConstants.KEY_TAB&&!hits.isEmpty()){focus=Math.floorMod(focus+(e.hasShiftDown()?-1:1),hits.size());searchFocus=focus==1;return true;}
        if(e.key()==InputConstants.KEY_RETURN&&focus>=0&&focus<hits.size()){hits.get(focus).run().run();return true;}
        if(searchFocus&&e.hasControlDown()&&e.key()==InputConstants.KEY_V){String value=minecraft.keyboardHandler.getClipboard().codePoints().filter(c->!Character.isISOControl(c)).collect(StringBuilder::new,StringBuilder::appendCodePoint,StringBuilder::append).toString();search((query+value).substring(0,Math.min(96,query.length()+value.length())));return true;}
        if(searchFocus&&e.key()==InputConstants.KEY_BACKSPACE){search(e.hasControlDown()?"":query.isEmpty()?"":query.substring(0,query.offsetByCodePoints(query.length(),-1)));return true;}
        if(e.key()==InputConstants.KEY_UP||e.key()==InputConstants.KEY_DOWN){int i=results.indexOf(selected());i=Math.max(0,Math.min(results.size()-1,i+(e.key()==InputConstants.KEY_UP?-1:1)));if(!results.isEmpty()){selected=results.get(i).id();detailScroll=0;float ry=i*47;if(ry<scroll)scroll=ry;else if(ry+44>scroll+bottom-top)scroll=ry+44-(bottom-top);}return true;}
        return super.keyPressed(e);
    }
    @Override public void removed(){GlassUi.restoreHud(minecraft);}
    @Override public void onClose(){minecraft.gui.setScreen(parent);}
    @Override public boolean isPauseScreen(){return false;}
}
