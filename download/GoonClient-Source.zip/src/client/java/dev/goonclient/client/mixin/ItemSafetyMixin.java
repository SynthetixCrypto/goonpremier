package dev.goonclient.client.mixin;

import dev.goonclient.client.modules.inventory.ItemGuard;
import dev.goonclient.client.modules.inventory.ToolSaver;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.MultiPlayerGameMode;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.item.component.PiercingWeapon;
import net.minecraft.world.item.component.SwingAnimation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Cancel before vanilla predicts the inventory change or sends the action packet. */
@Mixin(MultiPlayerGameMode.class)
public abstract class ItemSafetyMixin {
    @Inject(method = "dropItem", at = @At("HEAD"), cancellable = true)
    private void goonclient$guardHotbar(LocalPlayer player, boolean wholeStack, CallbackInfo ci) {
        if (ItemGuard.blockDrop(player, player.getMainHandItem())) ci.cancel();
    }

    @Inject(method = "handleContainerInput", at = @At("HEAD"), cancellable = true)
    private void goonclient$guardInventory(int containerId, int slot, int button, ContainerInput action, Player player, CallbackInfo ci) {
        if (ItemGuard.blockContainerDrop(containerId, slot, action, player)) ci.cancel();
    }

    @Inject(method = {"startDestroyBlock", "continueDestroyBlock"}, at = @At("HEAD"), cancellable = true)
    private void goonclient$saveMiningTool(BlockPos pos, Direction face, CallbackInfoReturnable<Boolean> cir) {
        var mc = Minecraft.getInstance();
        if (ToolSaver.blockAction(mc.player, true)) {
            ((MultiPlayerGameMode) (Object) this).stopDestroyBlock();
            cir.setReturnValue(false);
        }
    }

    @Inject(method = "attack", at = @At("HEAD"), cancellable = true)
    private void goonclient$saveMeleeTool(Player player, Entity target, CallbackInfo ci) {
        if (ToolSaver.blockAction(player, false)) ci.cancel();
    }

    @Inject(method = "piercingAttack", at = @At("HEAD"), cancellable = true)
    private void goonclient$savePiercingTool(SwingAnimation animation, PiercingWeapon weapon, CallbackInfo ci) {
        if (ToolSaver.blockAction(Minecraft.getInstance().player, false)) ci.cancel();
    }
}
