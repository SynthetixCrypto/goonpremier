package dev.goonclient.client.module.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonNull;

/** Not a stored value: a row in the module's settings with a button that runs an action (reset, open, ...). */
public class ButtonSetting extends Setting<String> {
	private final Runnable action;

	public ButtonSetting(String id, String name, String buttonLabel, Runnable action) {
		super(id, name, buttonLabel);
		this.action = action;
	}

	public String buttonLabel() {
		return get();
	}

	public void press() {
		action.run();
	}

	@Override
	public JsonElement toJson() {
		return JsonNull.INSTANCE;
	}

	@Override
	public void fromJson(JsonElement json) {
	}
}
