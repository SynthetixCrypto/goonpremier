package dev.goonclient.client;

import com.mojang.blaze3d.platform.InputConstants;
import dev.goonclient.Goon;
import dev.goonclient.client.gui.AdventureLogScreen;
import dev.goonclient.client.gui.ClickGuiScreen;
import dev.goonclient.client.hud.HudRenderer;
import dev.goonclient.client.waypoint.Waypoint;
import dev.goonclient.client.waypoint.WaypointManager;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;

public final class GoonKeys {
	private static final KeyMapping.Category CATEGORY = KeyMapping.Category.register(Goon.id("general"));

	// 26.3 uses SDL3: always use InputConstants key codes, never GLFW ones
	public static final KeyMapping OPEN_MENU = register("open_menu", InputConstants.KEY_RSHIFT);
	public static final KeyMapping TOGGLE_HUD = register("toggle_hud", InputConstants.KEY_H);
	public static final KeyMapping ZOOM = register("zoom", InputConstants.KEY_C);
	public static final KeyMapping FREELOOK = register("freelook", InputConstants.KEY_LALT);
	public static final KeyMapping ADD_WAYPOINT = register("add_waypoint", InputConstants.UNKNOWN.getValue());
	public static final KeyMapping ADVENTURE_LOG = register("adventure_log", InputConstants.KEY_J);

	private GoonKeys() {
	}

	private static KeyMapping register(String name, int key) {
		return KeyMappingHelper.registerKeyMapping(new KeyMapping("key.goonclient." + name, InputConstants.Type.KEYBOARD, key, CATEGORY));
	}

	/** Forces class loading so every key is registered during client init. */
	static void init() {
	}

	static void tick(Minecraft mc) {
		while (OPEN_MENU.consumeClick()) {
			if (mc.gui.screen() == null) {
				mc.gui.setScreen(new ClickGuiScreen(null));
			}
		}
		while (ADVENTURE_LOG.consumeClick()) {
			if (mc.gui.screen() == null) {
				mc.gui.setScreen(new AdventureLogScreen(null));
			}
		}
		while (TOGGLE_HUD.consumeClick()) {
			HudRenderer.toggleHidden();
		}
		while (ADD_WAYPOINT.consumeClick()) {
			if (mc.player != null && mc.level != null) {
				BlockPos pos = mc.player.blockPosition();
				String name = "Waypoint " + (WaypointManager.all().size() + 1);
				WaypointManager.add(new Waypoint(name, pos.getX(), pos.getY(), pos.getZ(), mc.level.dimension().identifier().toString(),
					WaypointManager.nextColor(), false, System.currentTimeMillis()));
				GoonChat.info("Added '" + name + "' at " + pos.getX() + " " + pos.getY() + " " + pos.getZ());
			}
		}
	}
}
