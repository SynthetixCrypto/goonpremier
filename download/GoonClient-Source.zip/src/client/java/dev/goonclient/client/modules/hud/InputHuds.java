package dev.goonclient.client.modules.hud;

import dev.goonclient.client.gui.Ui;
import dev.goonclient.client.hud.HudModule;
import dev.goonclient.client.hud.HudPosition;
import dev.goonclient.client.hud.TextHudModule;
import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.setting.BooleanSetting;
import dev.goonclient.client.tracker.ClickHistory;
import java.util.List;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/** Movement keys follow the player's actual bindings, including mouse buttons and custom keyboard layouts. */
public final class InputHuds {
	private static Keystrokes keys;
	private static Cps cps;
	private InputHuds() { }
	public static boolean trackingClicks() { return keys != null && keys.isEnabled() || cps != null && cps.isEnabled(); }

	public static final class Keystrokes extends HudModule {
		private final BooleanSetting mouse = add(new BooleanSetting("mouse", "Mouse buttons and CPS", true));
		private final BooleanSetting jump = add(new BooleanSetting("jump", "Jump key", true));
		private final BooleanSetting sneak = add(new BooleanSetting("sneak", "Sneak and sprint", false));
		public Keystrokes() {
			super("keystrokes", "Keystrokes", "Animated movement keys, jump and mouse clicks using your actual bindings", Category.HUD, false, HudPosition.topRight(2, 80));
			keys = this;
		}
		@Override protected void measurePreview(Minecraft mc) { measure(mc, true); }
		@Override protected void renderPreview(GuiGraphicsExtractor g, Minecraft mc) { render(g, mc, true); }
		@Override protected void measure(Minecraft mc, boolean editing) {
			setSize(74, 48 + (jump.isOn() ? 16 : 0) + (mouse.isOn() ? 22 : 0) + (sneak.isOn() ? 18 : 0));
		}
		@Override protected void render(GuiGraphicsExtractor g, Minecraft mc, boolean editing) {
			measure(mc, editing);
			key(g, mc, mc.options.keyUp, 25, 0, 24, 22, "up");
			key(g, mc, mc.options.keyLeft, 0, 25, 24, 22, "left");
			key(g, mc, mc.options.keyDown, 25, 25, 24, 22, "back");
			key(g, mc, mc.options.keyRight, 50, 25, 24, 22, "right");
			int y=48;
			if (jump.isOn()) { key(g, mc, mc.options.keyJump, 0, y, 74, 14, "jump"); y+=16; }
			if (mouse.isOn()) {
				cell(g, mc, "L " + ClickHistory.count(false), mc.mouseHandler.isLeftPressed(), 0, y, 36, 20, "mouse-left");
				cell(g, mc, "R " + ClickHistory.count(true), mc.mouseHandler.isRightPressed(), 38, y, 36, 20, "mouse-right"); y+=22;
			}
			if (sneak.isOn()) {
				key(g, mc, mc.options.keyShift, 0, y, 36, 16, "sneak");
				key(g, mc, mc.options.keySprint, 38, y, 36, 16, "sprint");
			}
		}
		private void key(GuiGraphicsExtractor g, Minecraft mc, KeyMapping mapping, int x, int y, int w, int h, String id) {
			cell(g, mc, mapping.getTranslatedKeyMessage().getString(), mapping.isDown(), x, y, w, h, id);
		}
		private void cell(GuiGraphicsExtractor g, Minecraft mc, String label, boolean pressed, int x, int y, int w, int h, String id) {
			float on = Ui.animate("keys:" + id, pressed ? 1 : 0, .8f);
			Ui.roundRect(g, x, y, x+w, y+h, 3, Ui.lerp(on, Ui.HUD_BACKGROUND, Ui.accent()));
			label=Ui.ellipsize(mc.font, label, w-6, false);
			Ui.text(g, mc.font, label, x+(w-Ui.width(mc.font,label))/2, y+(h-9)/2, Ui.lerp(on,Ui.TEXT,Ui.ON_ACCENT), true);
		}
	}

	public static final class Cps extends TextHudModule {
		private final BooleanSetting right = add(new BooleanSetting("right", "Show right clicks", true));
		public Cps() {
			super("cps", "Click Rate", "Left and right mouse presses in the last second; menu clicks are excluded", Category.HUD, false, HudPosition.topRight(2, 55));
			cps = this;
		}
		@Override protected void collect(Minecraft mc, List<Line> lines, boolean editing) {
			lines.add(new Line("CPS", right.isOn() ? ClickHistory.count(false) + " L / " + ClickHistory.count(true) + " R" : Integer.toString(ClickHistory.count(false))));
		}
	}
}
