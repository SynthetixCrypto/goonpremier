package dev.goonclient.client.compat;

import net.minecraft.client.gui.screens.Screen;

/** Only loaded when Sodium is installed; its factory also supports replacement settings UIs. */
public final class SodiumCompat {
	private SodiumCompat() {
	}

	public static Screen videoScreen(Screen parent) {
		try {
			return (Screen) Class.forName("net.caffeinemc.mods.sodium.client.gui.VideoSettingsScreen")
				.getMethod("createScreen", Screen.class).invoke(null, parent);
		} catch (ReflectiveOperationException e) {
			throw new IllegalStateException("Couldn't open Sodium video settings", e);
		}
	}
}
