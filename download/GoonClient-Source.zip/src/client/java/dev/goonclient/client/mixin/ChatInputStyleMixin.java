package dev.goonclient.client.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import dev.goonclient.client.gui.render.Icons;
import dev.goonclient.client.gui.render.Shapes;
import dev.goonclient.client.modules.utility.Interface;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.ChatScreen;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Glass chat: the input line becomes a rounded field with a search icon and a "Message..." hint. */
@Mixin(ChatScreen.class)
public abstract class ChatInputStyleMixin {
	@Shadow
	protected EditBox input;

	@Inject(method = "init", at = @At("TAIL"))
	private void goonclient$styleInput(CallbackInfo ci) {
		if (!Interface.glassChat() || input == null) return;
		// Room on the left for the icon
		input.setX(input.getX() + 12);
		input.setWidth(input.getWidth() - 12);
		input.setHint(Component.literal("Message...").withStyle(style -> style.withColor(0x8F8A96)));
	}

	@WrapOperation(method = "extractRenderState", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/GuiGraphicsExtractor;fill(IIIII)V"))
	private void goonclient$field(GuiGraphicsExtractor g, int x0, int y0, int x1, int y1, int color, Operation<Void> original) {
		if (!Interface.glassChat()) {
			original.call(g, x0, y0, x1, y1, color);
			return;
		}
		Shapes.panel(g, x0, y0 - 1, x1, y1 + 1, 4, 0xB21E1A1E, 0x2EFFFFFF);
		Icons.draw(g, Icons.Icon.SEARCH, x0 + 3.5f, y0 + 1.5f, 8, 0xFF9C98A4);
	}
}
