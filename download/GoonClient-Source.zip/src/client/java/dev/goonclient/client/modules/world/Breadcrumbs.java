package dev.goonclient.client.modules.world;

import dev.goonclient.client.gui.Ui;
import dev.goonclient.client.module.Category;
import dev.goonclient.client.module.Module;
import dev.goonclient.client.module.setting.ButtonSetting;
import dev.goonclient.client.module.setting.NumberSetting;
import dev.goonclient.client.render.WorldRender;
import java.util.ArrayDeque;
import java.util.UUID;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.gizmos.Gizmos;
import net.minecraft.world.phys.Vec3;

/** Tick-sampled, bounded local trail. No file or network history is recorded. */
public final class Breadcrumbs extends Module implements WorldRender.Renderable {
    private record Point(Vec3 position, long tick) {}
    private final NumberSetting duration = add(new NumberSetting("duration", "Trail lifetime", 15, 3, 60, 1, " s"));
    private final NumberSetting spacing = add(new NumberSetting("spacing", "Point spacing", .3, .1, 2, .1, " m"));
    private final NumberSetting width = add(new NumberSetting("width", "Line width", 2, 1, 4, .25));
    private final ArrayDeque<Point> points = new ArrayDeque<>();
    private ClientLevel level;
    private UUID player;
    private long tick;
    public Breadcrumbs() {
        super("breadcrumbs", "Breadcrumbs", "A fading movement trail to retrace your route; clears on teleport or world change", Category.WORLD, false);
        add(new ButtonSetting("clear", "Clear current trail", "Clear", this::clear));
    }
    private void clear() { points.clear(); level = null; player = null; tick = 0; }
    @Override protected void onDisable() { clear(); }
    @Override public void onTick(Minecraft mc) {
        if (mc.level == null || mc.player == null || !mc.player.isAlive()) { clear(); return; }
        if (mc.isPaused()) return;
        if (level != mc.level || !mc.player.getUUID().equals(player)) { clear(); level = mc.level; player = mc.player.getUUID(); }
        Vec3 current = mc.player.position().add(0, .06, 0);
        if (!points.isEmpty() && current.distanceToSqr(points.peekLast().position) > 64) points.clear();
        tick++;
        long lifetime = duration.intValue() * 20L;
        while (!points.isEmpty() && tick - points.peekFirst().tick >= lifetime) points.removeFirst();
        if (points.isEmpty() || current.distanceToSqr(points.peekLast().position) >= spacing.get() * spacing.get()) {
            if (points.size() >= 512) points.removeFirst();
            points.addLast(new Point(current, tick));
        }
    }
    @Override public void renderWorld(Minecraft mc, Camera camera, float partialTick) {
        if (level != mc.level || mc.player == null || !mc.player.getUUID().equals(player)) return;
        Point previous = null;
        for (Point point : points) {
            float fade = Math.max(0, 1 - (tick - point.tick + partialTick) / (duration.floatValue() * 20));
            if (previous != null) Gizmos.line(previous.position, point.position, Ui.withAlpha(Ui.accent(), .8f * fade), width.floatValue());
            previous = point;
        }
        if (previous != null && mc.player.isAlive()) {
            Vec3 current = mc.player.getPosition(partialTick).add(0, .06, 0);
            if (current.distanceToSqr(previous.position) < 64) Gizmos.line(previous.position, current, Ui.accent(), width.floatValue());
        }
    }
}
