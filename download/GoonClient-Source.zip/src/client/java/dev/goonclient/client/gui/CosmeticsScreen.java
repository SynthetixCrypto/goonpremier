package dev.goonclient.client.gui;

import dev.goonclient.client.cosmetics.CapeCatalog;
import dev.goonclient.client.cosmetics.CapeTextures;
import dev.goonclient.client.cosmetics.Cosmetics;
import dev.goonclient.client.gui.render.GoonFont;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.Component;

/** Paginated wardrobe: actual cape textures, immediate equip, and explicit friend sharing. */
public final class CosmeticsScreen extends Screen implements GoonScreen {
    private record Hit(float x,float y,float w,float h,Runnable action) {}
    /** Theme muted text lifted for contrast on the see-through glass window. */
    private static final int MUTED = 0xFFB9BDC6;
    private final Screen parent;
    private final List<Hit> hits = new ArrayList<>();
    private float scale,x,y;
    private int page;
    private boolean front;
    public CosmeticsScreen(Screen parent) { super(Component.literal("Goon wardrobe")); this.parent=parent; page=Math.max(0,CapeCatalog.CAPES.indexOf(CapeCatalog.find(Cosmetics.selected()))/6); }
    @Override protected void init() { scale=Ui.menuScale(width,height); x=(width/scale-570)/2; y=(height/scale-340)/2; }
    @Override public void extractRenderState(GuiGraphicsExtractor g,int realX,int realY,float partialTick) {
        hits.clear(); int mx=(int)(realX/scale),my=(int)(realY/scale);
        g.pose().pushMatrix(); g.pose().scale(scale,scale);
        GlassUi.window(g,x,y,570,340,1);
        GoonFont.draw(g,"Goon wardrobe",x+20,y+17,13,GoonFont.Weight.BOLD,0xFFF4F4F4,false);
        label(g,(CapeCatalog.CAPES.size()-1)+" original capes. Made for the crew.",x+20,y+39,0xFFD3D6DD);
        button(g,"Done",x+486,y+18,64,mx,my,true,this::onClose);
        for(int i=page*6;i<Math.min(page*6+6,CapeCatalog.CAPES.size());i++) {
            var cape=CapeCatalog.CAPES.get(i); int cell=i-page*6;
            float cx=x+20+(cell%2)*170,cy=y+66+(cell/2)*55;
            boolean equipped=Cosmetics.selected().equals(cape.id()),hover=Ui.inside(mx,my,cx,cy,cx+160,cy+49);
            float h=Ui.animate("wardrobe:hover:"+cape.id(),hover?1:0,.6f);
            float e=Ui.animate("wardrobe:equip:"+cape.id(),equipped?1:0,.5f);
            dev.goonclient.client.gui.render.Shapes.panel(g,cx,cy,cx+160,cy+49,6,Ui.lerp(h,GlassUi.CONTROL,GlassUi.CONTROL_HOVER),Ui.lerp(e,GlassUi.GLASS_EDGE,Ui.withAlpha(Ui.accent(),.9f)));
            preview(g,cape.id(),cx+10,cy+7,22,35,false);
            bold(g,cape.name(),cx+43,cy+11,Ui.TEXT);
            label(g,equipped?"Equipped":"Click to equip",cx+43,cy+29,equipped?Ui.accent():MUTED);
            hits.add(new Hit(cx,cy,160,49,()->Cosmetics.equip(cape.id())));
        }
        int pages=(CapeCatalog.CAPES.size()+5)/6;
        button(g,"Previous",x+20,y+232,80,mx,my,page>0,()->page--);
        label(g,(page+1)+" / "+pages,x+164,y+241,MUTED);
        button(g,"Next",x+270,y+232,80,mx,my,page+1<pages,()->page++);
        dev.goonclient.client.gui.render.Shapes.gradientRect(g,x+364,y+66,x+550,y+256,6,6,GlassUi.CONTENT_TOP,GlassUi.CONTENT_BOTTOM);
        dev.goonclient.client.gui.render.Shapes.outline(g,x+364,y+66,x+550,y+256,6,GlassUi.GLASS_EDGE);
        var cape=CapeCatalog.find(Cosmetics.selected());
        bold(g,cape.name(),x+378,y+76,Ui.TEXT);
        preview(g,cape.id(),x+427,y+98,60,96,front);
        button(g,front?"Show back":"Show front",x+451,y+201,85,mx,my,!cape.id().equals("none"),()->front=!front);
        label(g,"F5 in game",x+378,y+209,MUTED);
        String first=cape.description(),second="";
        while(GoonFont.width(first,8.5f,GoonFont.Weight.REGULAR)>157&&first.contains(" ")){int cut=first.lastIndexOf(' ');second=first.substring(cut+1)+(second.isEmpty()?"":" "+second);first=first.substring(0,cut);}
        label(g,first,x+378,y+232,MUTED);
        if(!second.isEmpty())label(g,Ui.ellipsize(second,157,8.5f,GoonFont.Weight.REGULAR),x+378,y+244,MUTED);
        label(g,"Show Goon cosmetics",x+20,y+272,Ui.TEXT);
        Ui.toggleSwitch(g,x+171,y+272,Ui.animate("wardrobe:visible",Cosmetics.visible()?1:0,.5f),1);
        hits.add(new Hit(x+20,y+264,178,28,Cosmetics::toggleVisible));
        label(g,"Share with friends",x+212,y+272,Ui.TEXT);
        Ui.toggleSwitch(g,x+334,y+272,Ui.animate("wardrobe:sharing",Cosmetics.sharing()?1:0,.5f),1);
        hits.add(new Hit(x+212,y+264,147,28,Cosmetics::toggleSharing));
        button(g,Cosmetics.busy()?"Connecting…":"Share equipped cape",x+374,y+266,176,mx,my,Cosmetics.configured()&&Cosmetics.sharing()&&!Cosmetics.busy(),Cosmetics::publish);
        String status=!Cosmetics.configured()?"Local capes ready. Friend sharing needs the owner's cosmetic service.":Cosmetics.status();
        label(g,Ui.ellipsize(status,528,8.5f,GoonFont.Weight.REGULAR),x+20,y+310,MUTED);
        g.pose().popMatrix();
    }
    private void preview(GuiGraphicsExtractor g,String id,float px,float py,int w,int h,boolean front) {
        var texture=CapeTextures.texture(id);
        if(texture!=null)g.blit(RenderPipelines.GUI_TEXTURED,texture.texturePath(),(int)px,(int)py,(front?1:12)*CapeTextures.UV_SCALE,CapeTextures.UV_SCALE,w,h,10*CapeTextures.UV_SCALE,16*CapeTextures.UV_SCALE,CapeTextures.WIDTH,CapeTextures.HEIGHT);
        else { Ui.roundOutline(g,px,py,px+w,py+h,3,Ui.BORDER_STRONG,Ui.CONTROL); label(g,"—",px+w/2-3,py+h/2-4,MUTED); }
    }
    private void label(GuiGraphicsExtractor g,String text,float px,float py,int color){GoonFont.draw(g,text,px,py,8.5f,GoonFont.Weight.REGULAR,color,false);}
    private void bold(GuiGraphicsExtractor g,String text,float px,float py,int color){GoonFont.draw(g,text,px,py,8.5f,GoonFont.Weight.BOLD,color,false);}
    private void button(GuiGraphicsExtractor g,String label,float bx,float by,float bw,int mx,int my,boolean enabled,Runnable action){Menus.button(g,label,bx,by,bw,enabled?mx:-1,enabled?my:-1,enabled?1:.45f,Menus.Style.NORMAL);if(enabled)hits.add(new Hit(bx,by,bw,24,action));}
    @Override public boolean mouseClicked(MouseButtonEvent event,boolean doubleClick){if(event.button()==1)for(Hit hit:hits)if(Ui.inside(event.x()/scale,event.y()/scale,hit.x,hit.y,hit.x+hit.w,hit.y+hit.h)){hit.action.run();return true;}return super.mouseClicked(event,doubleClick);}
    @Override public boolean mouseScrolled(double mx,double my,double dx,double dy){if(Ui.inside(mx/scale,my/scale,x+20,y+66,x+350,y+256)&&dy!=0){page=Math.max(0,Math.min((CapeCatalog.CAPES.size()-1)/6,page+(dy<0?1:-1)));return true;}return false;}
    @Override public void onClose(){minecraft.gui.setScreen(parent);}
    @Override public boolean isPauseScreen(){return false;}
}
