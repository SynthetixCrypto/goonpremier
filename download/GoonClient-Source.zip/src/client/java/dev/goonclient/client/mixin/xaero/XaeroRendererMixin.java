package dev.goonclient.client.mixin.xaero;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import dev.goonclient.client.modules.hud.MinimapHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(targets = "xaero.hud.minimap.module.MinimapRenderer", remap = false)
public class XaeroRendererMixin {
	/** The enlarged map uses the same Goon anchor, so its drawn bounds remain the bounds reserved by the HUD. */
	@ModifyExpressionValue(method = "render(Lxaero/hud/minimap/module/MinimapSession;Lxaero/hud/render/module/ModuleRenderContext;Lnet/minecraft/client/gui/GuiGraphicsExtractor;F)V",
		at = @At(value = "INVOKE", target = "Ljava/lang/Boolean;booleanValue()Z"))
	private boolean goonclient$keepAnchor(boolean centered) {
		return !MinimapHud.integrated() && centered;
	}
}
