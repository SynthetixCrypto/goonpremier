Goon Client v0.18.3 — survival companions

[+] Expedition Planner: saved Exploration, Nether and boss-trip packing lists with actual carried-item counts, manual checklists and waypoint destinations.
[+] Performance Notebook: record a 60-second gameplay window, review frame-time spikes and export a local CSV and summary.
[+] Launch Checkup: inspect local mod archives and save an advisory report from the launcher. It changes no mods; Fabric decides compatibility.
[+] Private RAM reading alongside resident RAM and Java heap, with clear labels.
[-] Main-menu HUD editing now shows live RAM instead of the old fixed example.
[-] Drafts survive clearing saved expedition plans; plan switching and delete confirmations keep the correct target.
[-] Performance captures exclude menus, loading, pause and focus transitions, including brief transitions between frames.
[-] Bounded local file reads and mod archive inspection handle damaged or oversized inputs without overwriting originals.
[-] Website updated with the new tools, current downloads and all sixteen current main-menu previews.

Open Expedition Planner under Inventory. Open Performance Notebook from FPS Graph. Reports and plans stay local. Includes the launcher and container housekeeping improvements from 0.18.2.
