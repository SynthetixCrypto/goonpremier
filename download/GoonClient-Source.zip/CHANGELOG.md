# Goon Client v0.17.3 - Microsoft verification page

[-] Sign-in opens the exact verification page supplied by Microsoft, without the unsupported code-prefill shortcut.
[-] Paste the copied code on Microsoft's page, then continue signing in there.
[-] Keeps Goon's approved app ID and the Xbox-specific permissions.
[+] Retains the new G logo, boxed glass menu and themed previews.
