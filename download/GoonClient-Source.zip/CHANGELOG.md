# Goon Client v0.17.2 - Microsoft sign-in correction

[-] Microsoft sign-in now requests the Xbox-specific refresh permission used by Prism Launcher and Microsoft's Xbox documentation.
[-] Updated both first sign-in and saved-account refresh; Goon's own approved app ID stays in use.
[+] Keeps the new cut-corner G logo, matching launcher and sixteen themed website previews.
[-] Source remains a separate download, outside the launcher.
