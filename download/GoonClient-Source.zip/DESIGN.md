# Companion windows — 0.18.3

Expedition Planner and Performance Notebook reuse GlassUi, existing fonts, theme and clipped windows.
No new menu/brand direction. Explicit Save/Discard for plans, stable action IDs for keyboard focus, disabled
controls rechecked at activation, no-world safe states and temporary HUD hiding restored on every exit.
Launch Checkup uses the existing fixed launcher surface and palette. Scan results are immutable; pack changes
invalidate stale results. Reports are explicit local actions. RAM labels distinguish private/resident/heap;
no-world memory editing uses the same safe live collector, with no registry/item access.

# Launcher appearance - 0.18.1

Native Swing launcher, fixed 1000x620, existing Inter regular/bold and original cut-corner G. Owner-selected default:
Sky (#4DA3FF / #8EC6FF on #0F1520). Eight selectable palettes change the launcher surface/accent/labels/logo together.
Primary labels use #09111B for contrast; secondary labels mix the selected second accent toward #F4F4F4 by 69%.
Glass uses theme base plus a subtle light top, darker bottom and one-pixel rim. Sidebar remains 210px; content begins
at 244px. Home keeps Play in a 326px-high left surface and changelog in a 292px right column, with theme/folder controls
below. Appearance uses four theme columns by two rows, then three background choices and one motion toggle.
Original cached vector night landscape/topographic lines/quiet surface. No borrowed art; no decorative image processing
per frame. Motion is small drifting lights, optional and inactive when the window loses focus. In-game UI is unchanged.
Theme previews show the scene and actual G mark; selected border + text, not color alone. Controls fit the fixed window;
Tab/Shift-Tab/Enter/Space/Esc, readable busy/error/sign-in states, and saved preferences keep the launcher usable.
Evidence and exact limitations are recorded in HANDOFF.md at 0.18.1.

# Current main menu - 0.17.6

Preserve the owner's simplicity request, strengthen the hierarchy: a standalone 70-unit G emblem above a bold
29-unit wordmark, two 236x34 play controls with sharper 4-unit corners, and one low-profile glass dock for tool
icons. Selected accent emphasises branding, the first action and hover/focus. HUD rim and theme base carry the
material. No surrounding dashboard, news, cards or account panel. Background choice and all actions retained.
The minimum virtual canvas remains 480x360. Title tour and installed startup are required before delivery.

# Current main menu - 0.17.5

Owner rejected the dashboard/card composition in favour of a minimal title. Centred mark/wordmark, Minecraft
version, two vertically stacked 216x30 glass play controls and one six-icon tools row. Controls use the existing
theme base/accent and HudRenderUtil.rim. Icon labels appear on hover/focus. Account/version and Quit sit in
opposite footer corners. No outer shell, news section, repeated card grid or account panel. The chosen animated,
custom-image, panorama or solid background remains the player's preference. Smooth finite hover/fade, stable
pointer geometry and minimum virtual canvas 480x360; parent navigation and no-world HUD access stay intact.

# Current brand - 0.17.1

Original cut-corner G: one continuous 100-unit polygon with diagonal shoulders, an open upper-right arm and inset
horizontal crossbar. Flat theme accent, no glyph glow. Dark rounded-square tile (radius 19), understated rim and
surface shading. LogoArt.java and marketing/brand/logo.py share points. Wordmark and boxed ClickGUI geometry stay.
Website layout/CSS retained; assets, current product details and separate downloads refreshed.

# Current module-menu direction — 0.17.0

Owner supplied screenshots of a centered module box and Lunar's icon-card grid; layout follows those references.
Preserve Goon's existing Combatant-derived glass material, logo, Inter fonts and selected accent. One 440x270
virtual window: wordmark/search/Settings/Wardrobe/close in the header, seven category tabs below, then a three-column
card viewport and a fixed footer. Cards: original vector icon, name, two-line description, Options row, state button.
State colors animate to the theme accent. The footer holds state/favorite filters, Adventure Log, count and Edit HUD layout.
No dropdown category columns or detached module-browser navigation. Module settings retain the existing popup/studio.
Clipping applies to both drawing and input; header/footer/outside wheel cannot scroll cards. Full descriptions appear
on hover only when shortened. Existing HUD styling, positions and editor behavior remain intact.

# Goon brand — 0.15.0

- **Mark:** a dark glass tile (Noir surface #1E2027 to #0C0D10, faint top sheen, hairline rim) holding a
  rounded-square "G" in the theme accent (#E16B78 for Noir) with a soft glow. Geometry in a 100-unit box: tile
  3..97 r23; G outer 21..79 r17, stroke 12, top arm ends square where its straight edge ends, bar from the centre to
  the right edge at mid height. Deliberately square, not a circular G (avoids Google's mark).
  Sources: `marketing/brand/logo.py` (PNG/SVG/ICO, `out/`), `gui/render/LogoArt` (Java2D, any accent), `Logo` (GUI).
- **Wordmark:** "GOON" in #F4F4F4 and "CLIENT" in the accent, Inter Bold. Used on the title screen, launcher, site.
- **Type:** Inter (UI, titles), Onest (numbers and labels), Comfortaa (hint footers only). Poppins is retired.
- **Capes:** `cosmetics/CapeArt` (pure Java2D): charcoal cloth, glass sheen, the mark in the cape colour, a motif
  fading up from the hem, GOON NATION. Nation Noir (pink) is the signature cape; IDs never change.
  `marketing/brand/CapeLineup.java` renders all capes for the site.
- **Website** (goonpremier): same Noir glass system in CSS, theme swatches swap `--a1/--a2` and the themed
  screenshots (`shot-<key>[-<theme>]-<w>.webp`). Images come from `marketing/brand/site_images.py`.
- **Launcher:** `Draw` carries the accent, Inter fonts, glass panels, the accent glow and the wordmark.

# Goon HUD glass — 0.14.0

## Current direction

Owner-requested source port of Combatant's GPL-3.0-only HUD, with GPL-3.0-only relicensing authorized. NOTICE lists
the exact upstream snapshot and adapted files/assets. Earlier "no imported assets" notes below are historical.
Goon retains its native renderer, Inter/Comfortaa text and data providers. This is not a claim of pixel-identical
MSDF text or Combatant's Fresnel/refraction shader. No cheat modules or entire third-party renderer are transplanted.

- Compact pill dimensions, divider and icon placements come from Fps/Memory/SpeedBps/Coordinates.
- List header, row pitch, minimum widths and radii follow ScriptedListHudPanel; Inventory and TargetHud dimensions
  are ported explicitly. Target's default center is 71.5% down the screen, leaving the crosshair unobstructed.
- Glass samples a shared full-resolution world texture captured just before GuiRenderer.prepare(), after the scene
  and before any HUD is drawn. Two native box-blur passes, one horizontal and one vertical, run once per frame.
- Rounded masks use one-pixel alpha fringes and the native GUI texture pipeline. All panels reuse the same texture.
- Strength follows Interface's Background blur control; 0 skips allocation/capture/blur, keeping the tint fallback.
- Window resize reallocates the target. Native shader resource reload refreshes the post chain. A render failure
  disables the effect for the session and logs it, retaining readable tinted surfaces.
- Main-menu HUD editing uses the existing safe preview path without a world texture. Menus in-world retain scissor
  clipping and pointer geometry; module/settings glass no longer blurs the full world.
- HUD collision reserves the actual unfocused chat background from the preceding frame, frozen while chat is open,
  rather than the entire empty configured rectangle. Minimap and native hotbar reservations remain intact.

## Evidence

Two complete `runClient -PmenuPreview` tours compiled and exited successfully on 2026-10-04. Compared live HUD and
menu captures to the supplied Combatant reference. Blur log: 1,259 captures for 5,931 panel regions on the final tour;
no HUD blur failure. Second tour confirmed the target card moved below the crosshair. No uncapped FPS benchmark,
shader-pack compatibility matrix or real Microsoft login was run in this change. Packaged startup is recorded in
HANDOFF.md after verification. Current screenshots: run/screenshots/goon-menu-*.png (except old scroll captures).

## Historical design notes

# Goon glass workspace — 0.12.0

The owner explicitly selected all seven Combatant reference screenshots as the visual direction. Use original native rendering: pale graphite/lavender translucent surfaces, fine bright edges, compact navigation, small smooth text, Goon's selected accent. No imported reference code/assets. A glass effect is part of the requested reference, not a generic decoration to remove.

## Screen family

- Floating module columns retain independent clipped scroll viewports and exact pointer/thumb geometry.
- Settings studio: 480×294 virtual window, five-item navigation rail, separated title/search row, clipped body, persistent footer. Minimum virtual workspace 640×380 supports large GUI scales.
- HUD cards have real names/descriptions, enabled state and settings navigation; theme cards show ten palette swatches and a clearly marked applied accent.
- Interface uses compact Visual/Menus/Tools groups and the real Boolean/Number/Mode/Button settings. No duplicate config store.
- Saved setups retain load/overwrite/delete/undo/save and confirmations in the shared frosted material.
- Editor inspector sits beside the live or sample HUD, reserves its rectangle and supports temporary solo preview. Native hotbar region and the hint row remain separate.
- Multirow text HUDs get a header/divider; single-line counters remain small. Optional native hotbar/chat surface replacements keep Minecraft geometry and content.

## Evidence and limits

One first visual batch, one correction batch, one final confirmation at 1600×900 / GUI scales 2 and 3. Nine captures in run/screenshots/goon-0120-*. No-world editor rendered successfully; this is not evidence of input/drag behavior or in-world HUD collision. No tests, gameplay/FPS claims or packaged-launch verification. Shader lighting/scenery and external media widgets shown by the reference are separate from these UI surfaces. Final source compiled; static UI detector reported no findings.

## Earlier design record

# Goon menu design — 0.11.1

Native Java interface, existing fractional layout plus pixel-aligned antialiased glyph atlases and batched shapes. User-selected reference is Combatant: floating frosted category columns, short rows, compact centered navigation, separate settings surface. No imported reference assets or code.

Goon branding and seven existing accents; neutral graphite glass surfaces and muted inactive text. Accent denotes enabled/selected state. Per-column clipping governs both render and hit geometry. Wheel eases independently; thumb dragging snaps one-to-one. State transitions finish. Full descriptions appear in delayed help; row names wrap at narrow widths. Separate appearance gallery exposes the global accent and Glass/Solid material. Preserve profiles, wardrobe, main-menu-safe HUD editing, log, module reset and shortcut conflict guards.

Inspection covered 1600×900 menu-only captures at actual GUI scales 2 and 3, one initial pass plus one refinement/confirmation. No gameplay, interaction assertions or benchmark claims. Future UI work should preserve independent scroll bounds and use the existing native renderer rather than adding a browser/native bridge solely for controls.

Wheel events stay inside ClickGUI while only the hovered category or settings viewport changes scroll. HUD auto-stacking reserves vanilla chat using its scaled baseline, whole-row height and full right padding, alongside the hotbar and minimap. The 0.11.1 repair clears transient input on resize/screen changes, keeps outgoing settings stationary during their fade, makes dragged sliders follow the pointer, and fits the six-column workspace below the usual scale floor. Typing from settings always reveals the search being edited. The 0.11.1 compile and launcher packaging succeeded; current interaction and HUD behavior remain unverified in game.

## 0.16.0: classic menu on glass, editor feel

The module browser is the original sidebar-and-cards layout again, drawn on the Combatant glass (GlassUi.window, live BackdropBlur, accent-tinted
cards with a left bar and a small toggle). Edit-HUD-layout is a primary accent button in the sidebar and on the Studio HUD page. The HUD editor
chrome reserves nothing on screen, hints are a single row under the nav pill, and the inspector floats opposite the selected panel and can be
moved by its title. Rule of thumb for all GUI drawing: fewer, larger elements (QuadBatch) because vanilla's GuiRenderState checks each new
element against those already submitted.

## 0.17.4: HUD arrangement and companion windows

Automatic HUD layout packs the edges around native map/chat/hotbar bounds and leaves the centre of the world clear.
Small compass/clock/attack controls retain their intentional positions; larger target cards and warnings use edge lanes.
Crowded layouts fit down as a group. Manual pins stay exact. Editor outlines mark focus only, and actions sit beside navigation.
Main/pause/Options menus share the current boxed glass material, original G mark and selected theme base/accent.

