package dev.goonclient.launcher;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HexFormat;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Downloads files in parallel and verifies their SHA-1. Before downloading, it looks for an identical file
 * (same relative path, same hash) in "seed" folders such as the official launcher's .minecraft, and hard-links
 * or copies it instead. Seed folders are only ever read.
 */
final class Downloader {
	record Item(String url, Path target, String sha1, long size, String seedPath) {
	}

	interface Progress {
		void update(long doneBytes, long totalBytes, String current);
	}

	static final HttpClient HTTP = HttpClient.newBuilder()
		.followRedirects(HttpClient.Redirect.NORMAL)
		.connectTimeout(Duration.ofSeconds(15))
		.build();

	private final List<Path> seeds;

	Downloader(List<Path> seeds) {
		this.seeds = seeds;
	}

	/** Makes every item present and correct. Existing targets are trusted by size unless {@code verify} is set. */
	void fetchAll(List<Item> items, boolean verify, Progress progress) throws IOException, InterruptedException {
		List<Item> missing = new ArrayList<>();
		for (Item item : items) {
			if (!isValid(item, verify) && !reuseFromSeed(item)) {
				missing.add(item);
			}
		}
		long total = missing.stream().mapToLong(Item::size).sum();
		AtomicLong done = new AtomicLong();
		ExecutorService pool = Executors.newFixedThreadPool(8);
		try {
			List<Future<?>> futures = new ArrayList<>();
			for (Item item : missing) {
				futures.add(pool.submit(() -> {
					download(item, bytes -> progress.update(done.addAndGet(bytes), total, item.target().getFileName().toString()));
					return null;
				}));
			}
			for (Future<?> future : futures) {
				try {
					future.get();
				} catch (ExecutionException e) {
					throw e.getCause() instanceof IOException io ? io : new IOException(e.getCause());
				}
			}
		} finally {
			pool.shutdownNow();
		}
	}

	private static boolean isValid(Item item, boolean verify) throws IOException {
		Path target = item.target();
		if (!Files.isRegularFile(target)) {
			return false;
		}
		if (item.size() > 0 && Files.size(target) != item.size()) {
			return false;
		}
		return !verify || item.sha1() == null || sha1(target).equalsIgnoreCase(item.sha1());
	}

	private boolean reuseFromSeed(Item item) throws IOException {
		if (item.seedPath() == null || item.sha1() == null) {
			return false;
		}
		for (Path seed : seeds) {
			Path source = seed.resolve(item.seedPath());
			if (Files.isRegularFile(source) && (item.size() <= 0 || Files.size(source) == item.size())
				&& sha1(source).equalsIgnoreCase(item.sha1())) {
				Files.createDirectories(item.target().getParent());
				Files.deleteIfExists(item.target());
				try {
					Files.createLink(item.target(), source);
				} catch (IOException | UnsupportedOperationException e) {
					Files.copy(source, item.target(), StandardCopyOption.REPLACE_EXISTING);
				}
				return true;
			}
		}
		return false;
	}

	private interface Counter {
		void add(long bytes);
	}

	private static void download(Item item, Counter counter) throws IOException, InterruptedException {
		Path target = item.target();
		Files.createDirectories(target.getParent());
		Path part = target.resolveSibling(target.getFileName() + ".part");
		HttpResponse<InputStream> response = HTTP.send(request(item.url()), HttpResponse.BodyHandlers.ofInputStream());
		if (response.statusCode() != 200) {
			throw new IOException("Download failed (" + response.statusCode() + "): " + item.url());
		}
		MessageDigest digest = digest();
		try (InputStream in = response.body(); OutputStream out = Files.newOutputStream(part)) {
			byte[] buffer = new byte[64 * 1024];
			int read;
			while ((read = in.read(buffer)) != -1) {
				out.write(buffer, 0, read);
				digest.update(buffer, 0, read);
				counter.add(read);
			}
		}
		if (item.sha1() != null && !HexFormat.of().formatHex(digest.digest()).equalsIgnoreCase(item.sha1())) {
			Files.deleteIfExists(part);
			throw new IOException(target.getFileName() + " didn't match its checksum. Try again.");
		}
		Files.move(part, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
	}

	static HttpRequest request(String url) {
		return HttpRequest.newBuilder(URI.create(url))
			.header("User-Agent", "goonclient-launcher")
			.timeout(Duration.ofMinutes(5))
			.build();
	}

	static String text(String url) throws IOException, InterruptedException {
		HttpResponse<String> response = HTTP.send(request(url), HttpResponse.BodyHandlers.ofString());
		if (response.statusCode() != 200) {
			throw new IOException("Request failed (" + response.statusCode() + "): " + url);
		}
		return response.body();
	}

	static String sha1(Path file) throws IOException {
		MessageDigest digest = digest();
		try (InputStream in = Files.newInputStream(file)) {
			byte[] buffer = new byte[64 * 1024];
			int read;
			while ((read = in.read(buffer)) != -1) {
				digest.update(buffer, 0, read);
			}
		}
		return HexFormat.of().formatHex(digest.digest());
	}

	private static MessageDigest digest() {
		try {
			return MessageDigest.getInstance("SHA-1");
		} catch (NoSuchAlgorithmException e) {
			throw new IllegalStateException(e);
		}
	}
}
