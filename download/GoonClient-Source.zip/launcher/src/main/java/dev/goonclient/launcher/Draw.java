package dev.goonclient.launcher;

import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.io.InputStream;

/** Colours, fonts and drawing helpers shared by the launcher UI: the client's Noir glass look. */
final class Draw {
	/** Noir accent, and its lighter end for gradients. */
	static Color ACCENT = new Color(0xE16B78);
	static Color ACCENT_2 = new Color(0xF0939D);
	static final Color TEXT = new Color(0xF4F4F4);
	static Color MUTED = new Color(0x8F949E);
	static final Color GOOD = new Color(0x4ADE80);
	static final Color WARN = new Color(0xF5B83D);
	static final Color BAD = new Color(0xF0616D);
	static Color GLASS = new Color(0x14, 0x16, 0x1B);
	static Color CONTROL = new Color(0x26282E);
	/** Text on top of the accent. */
	static Color ON_ACCENT = Color.WHITE;

	private static LauncherTheme currentTheme;
	static void theme(LauncherTheme theme) {
        if(theme.equals(currentTheme))return;
        currentTheme=theme;
        ACCENT=theme.color();ACCENT_2=new Color(theme.second());GLASS=theme.ground();
        CONTROL=mix(GLASS,Color.WHITE,.095f);MUTED=mix(ACCENT_2,TEXT,.69f);
        ON_ACCENT=new Color(0x09111B);
    }

    private static Font regular;
	private static Font bold;

	private Draw() {
	}

	static void loadFonts() {
		regular = load("/fonts/inter-regular.ttf", Font.PLAIN);
		bold = load("/fonts/inter-bold.ttf", Font.BOLD);
	}

	private static Font load(String path, int fallbackStyle) {
		try (InputStream in = Draw.class.getResourceAsStream(path)) {
			if (in != null) {
				return Font.createFont(Font.TRUETYPE_FONT, in);
			}
		} catch (Exception ignored) {
			// Fall back to the system font below
		}
		return new Font(Font.SANS_SERIF, fallbackStyle, 12);
	}

	static Font regular(float size) {
		return regular.deriveFont(size);
	}

	static Font bold(float size) {
		return bold.deriveFont(size);
	}

	static void quality(Graphics2D g) {
		g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
		g.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_ON);
		g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
		g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
		g.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
	}

	static Color alpha(Color color, float alpha) {
		int a = Math.round(Math.max(0f, Math.min(1f, alpha)) * color.getAlpha());
		return new Color(color.getRed(), color.getGreen(), color.getBlue(), a);
	}

	static Color mix(Color from, Color to, float t) {
		float k = Math.max(0f, Math.min(1f, t));
		return new Color(
			Math.round(from.getRed() + (to.getRed() - from.getRed()) * k),
			Math.round(from.getGreen() + (to.getGreen() - from.getGreen()) * k),
			Math.round(from.getBlue() + (to.getBlue() - from.getBlue()) * k),
			Math.round(from.getAlpha() + (to.getAlpha() - from.getAlpha()) * k));
	}

	static Shape round(double x, double y, double w, double h, double r) {
		return new RoundRectangle2D.Double(x, y, w, h, r * 2, r * 2);
	}

	/**
	 * Frosted glass panel, like the client's: a translucent charcoal gradient over the blurred background, a faint sheen
	 * across the top and a hairline rim that is brighter at the top.
	 */
	static void glass(Graphics2D g, double x, double y, double w, double h, double r, float opacity) {
		float o = Math.min(1f, opacity + 0.1f);
		Shape shape = round(x, y, w, h, r);
		g.setPaint(new GradientPaint(0, (float) y, alpha(mix(GLASS,Color.WHITE,.07f), o * 0.82f), 0, (float) (y + h), alpha(mix(GLASS,Color.BLACK,.3f), o)));
		g.fill(shape);
		g.setPaint(new GradientPaint(0, (float) y, new Color(255, 255, 255, 12), 0, (float) (y + Math.min(h, 120) * 0.6), new Color(255, 255, 255, 0)));
		g.fill(shape);
		g.setStroke(new BasicStroke(1f));
		g.setPaint(new GradientPaint(0, (float) y, new Color(255, 255, 255, 38), 0, (float) (y + h), new Color(255, 255, 255, 12)));
		g.draw(round(x + 0.5, y + 0.5, w - 1, h - 1, r));
	}

	/** A soft glow around a rounded rectangle in {@code color} (the accent behind primary buttons). */
	static void glow(Graphics2D g, double x, double y, double w, double h, double r, Color color, float strength) {
		for (int i = 18; i >= 2; i -= 2) {
			float a = strength * (1f - i / 19f) * 0.09f;
			g.setColor(alpha(color, a));
			g.setStroke(new BasicStroke(i));
			g.draw(round(x, y, w, h, r));
		}
	}

	/** The wordmark: GOON in white and CLIENT in the accent. */
	static void wordmark(Graphics2D g, Font font, float x, float y, float alpha) {
		g.setFont(font);
		g.setColor(alpha(TEXT, alpha));
		g.drawString("GOON ", x, y);
		g.setColor(alpha(ACCENT, alpha));
		g.drawString("CLIENT", x + g.getFontMetrics(font).stringWidth("GOON "), y);
	}

	static void text(Graphics2D g, String text, Font font, Color color, float x, float y) {
		g.setFont(font);
		g.setColor(color);
		g.drawString(text, x, y);
	}

	static int width(Graphics2D g, String text, Font font) {
		return g.getFontMetrics(font).stringWidth(text);
	}

	static void centered(Graphics2D g, String text, Font font, Color color, double cx, double cy) {
		FontMetrics metrics = g.getFontMetrics(font);
		float x = (float) (cx - metrics.stringWidth(text) / 2.0);
		float y = (float) (cy + (metrics.getAscent() - metrics.getDescent()) / 2.0);
		text(g, text, font, color, x, y);
	}

	static void withOpacity(Graphics2D g, float alpha, Runnable draw) {
		var previous = g.getComposite();
		g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, Math.max(0f, Math.min(1f, alpha))));
		draw.run();
		g.setComposite(previous);
	}

	/** Gaussian-like blur: three passes of a separable box blur. */
	static BufferedImage blur(BufferedImage source, int radius) {
		int w = source.getWidth();
		int h = source.getHeight();
		int[] pixels = source.getRGB(0, 0, w, h, null, 0, w);
		int[] buffer = new int[pixels.length];
		for (int pass = 0; pass < 3; pass++) {
			boxBlur(pixels, buffer, w, h, radius, true);
			boxBlur(buffer, pixels, w, h, radius, false);
		}
		BufferedImage out = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
		out.setRGB(0, 0, w, h, pixels, 0, w);
		return out;
	}

	private static void boxBlur(int[] in, int[] out, int w, int h, int r, boolean horizontal) {
		int outer = horizontal ? h : w;
		int inner = horizontal ? w : h;
		for (int o = 0; o < outer; o++) {
			long sr = 0;
			long sg = 0;
			long sb = 0;
			for (int i = -r; i <= r; i++) {
				int p = in[index(o, Math.max(0, Math.min(inner - 1, i)), w, horizontal)];
				sr += (p >> 16) & 0xFF;
				sg += (p >> 8) & 0xFF;
				sb += p & 0xFF;
			}
			int size = r * 2 + 1;
			for (int i = 0; i < inner; i++) {
				out[index(o, i, w, horizontal)] = 0xFF000000 | (int) (sr / size) << 16 | (int) (sg / size) << 8 | (int) (sb / size);
				int add = in[index(o, Math.min(inner - 1, i + r + 1), w, horizontal)];
				int remove = in[index(o, Math.max(0, i - r), w, horizontal)];
				sr += ((add >> 16) & 0xFF) - ((remove >> 16) & 0xFF);
				sg += ((add >> 8) & 0xFF) - ((remove >> 8) & 0xFF);
				sb += (add & 0xFF) - (remove & 0xFF);
			}
		}
	}

	private static int index(int outer, int inner, int w, boolean horizontal) {
		return horizontal ? outer * w + inner : inner * w + outer;
	}
}
