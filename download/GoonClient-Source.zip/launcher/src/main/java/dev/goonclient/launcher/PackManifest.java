package dev.goonclient.launcher;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream;

/**
 * The modpack: modrinth.index.json + overrides. Either the one bundled into the launcher at build time
 * ({@code archive == null}) or a newer .mrpack the {@link Updater} downloaded from the website.
 */
record PackManifest(String version, String minecraft, String fabricLoader, List<PackFile> files, List<String> overrides, Path archive, List<PackFile> bundled) {
	/** Hosts the .mrpack format allows downloads from. Anything else is refused. */
	private static final Set<String> DOWNLOAD_HOSTS = Set.of("cdn.modrinth.com", "github.com", "raw.githubusercontent.com", "gitlab.com");

	record PackFile(String path, String url, String sha1, String sha512, long size) {
		/** "mods/sodium-fabric-0.9.2+mc26.3.jar" -> "sodium-fabric-0.9.2+mc26.3.jar" */
		String fileName() {
			return path.substring(path.lastIndexOf('/') + 1);
		}
	}

	/** The pack bundled into the launcher. */
	static PackManifest load() throws IOException {
		JsonObject index;
		try (InputStream in = resource("/pack/modrinth.index.json")) {
			index = JsonParser.parseReader(new InputStreamReader(in, StandardCharsets.UTF_8)).getAsJsonObject();
		}
		List<String> overrides = new ArrayList<>();
		try (InputStream in = resource("/pack/overrides.txt")) {
			for (String line : new String(in.readAllBytes(), StandardCharsets.UTF_8).split("\n")) {
				if (!line.isBlank()) {
					overrides.add(line.trim());
				}
			}
		}
		return parse(index, overrides, null);
	}

	/** A downloaded .mrpack. Checks every path and download link, since this one came over the internet. */
	static PackManifest fromArchive(Path mrpack) throws IOException {
		try (ZipFile zip = new ZipFile(mrpack.toFile())) {
			ZipEntry indexEntry = zip.getEntry("modrinth.index.json");
			if (indexEntry == null) {
				throw new IOException(mrpack.getFileName() + " isn't a modpack (no modrinth.index.json)");
			}
			JsonObject index;
			try (InputStream in = zip.getInputStream(indexEntry)) {
				index = JsonParser.parseReader(new InputStreamReader(in, StandardCharsets.UTF_8)).getAsJsonObject();
			}
			List<String> overrides = new ArrayList<>();
			Enumeration<? extends ZipEntry> entries = zip.entries();
			while (entries.hasMoreElements()) {
				ZipEntry entry = entries.nextElement();
				if (!entry.isDirectory() && entry.getName().startsWith("overrides/")) {
					String path = entry.getName().substring("overrides/".length());
					requireSafePath(path);
					overrides.add(path);
				}
			}
			PackManifest pack = parse(index, overrides, mrpack);
			for (PackFile file : pack.files()) {
				requireSafePath(file.path());
				URI url = URI.create(file.url());
				if (!"https".equals(url.getScheme()) || !DOWNLOAD_HOSTS.contains(url.getHost())) {
					throw new IOException("The update links " + file.fileName() + " from " + url.getHost() + ", which isn't allowed");
				}
			}
			return pack;
		} catch (RuntimeException e) {
			throw new IOException("Couldn't read " + mrpack.getFileName() + ": " + e.getMessage(), e);
		}
	}

	private static PackManifest parse(JsonObject index, List<String> overrides, Path archive) {
		List<PackFile> files = new ArrayList<>();
		for (JsonElement element : index.getAsJsonArray("files")) {
			JsonObject file = element.getAsJsonObject();
			JsonObject hashes = file.getAsJsonObject("hashes");
			files.add(new PackFile(
				file.get("path").getAsString(),
				file.getAsJsonArray("downloads").get(0).getAsString(),
				hashes.get("sha1").getAsString(),
				hashes.get("sha512").getAsString(),
				file.get("fileSize").getAsLong()));
		}
		List<PackFile> bundled = new ArrayList<>();
        if (index.has("goonclient") && index.getAsJsonObject("goonclient").has("bundledMods")) {
            for (JsonElement e : index.getAsJsonObject("goonclient").getAsJsonArray("bundledMods")) {
                JsonObject m=e.getAsJsonObject();
                bundled.add(new PackFile("mods/"+m.get("file").getAsString(), "", "", m.get("sha512").getAsString(), 0));
            }
        }
        JsonObject dependencies = index.getAsJsonObject("dependencies");
		return new PackManifest(
			index.get("versionId").getAsString(),
			dependencies.get("minecraft").getAsString(),
			dependencies.get("fabric-loader").getAsString(),
			List.copyOf(files),
			List.copyOf(overrides),
			archive, List.copyOf(bundled));
	}

	/** Relative, inside the game folder, no tricks: "mods/x.jar" yes, "../x", "/x", "C:x" no. */
	private static void requireSafePath(String path) throws IOException {
		boolean safe = !path.isBlank() && !path.startsWith("/") && !path.startsWith("\\") && !path.contains(":")
			&& !path.contains("\\");
		if (safe) {
			for (String part : path.split("/")) {
				if (part.isEmpty() || part.equals("..") || part.equals(".")) {
					safe = false;
					break;
				}
			}
		}
		if (!safe) {
			throw new IOException("The update contains an unsafe file path: " + path);
		}
	}

	/** An override's contents ("mods/goonclient-0.4.0.jar", "config/..."). */
	InputStream openOverride(String path) throws IOException {
		if (archive == null) {
			return resource("/pack/overrides/" + path);
		}
		try (ZipFile zip = new ZipFile(archive.toFile())) {
			ZipEntry entry = zip.getEntry("overrides/" + path);
			if (entry == null) {
				throw new IOException("Missing " + path + " in " + archive.getFileName());
			}
			try (InputStream in = zip.getInputStream(entry)) {
				return new ByteArrayInputStream(in.readAllBytes());
			}
		}
	}

	private static InputStream entryStream(ZipFile zip, String path) throws IOException {
		ZipEntry entry = zip.getEntry("overrides/" + path);
		if (entry == null) {
			throw new IOException("Missing " + path + " in " + zip.getName());
		}
		return zip.getInputStream(entry);
	}

	/** The newest changelog section, read from the Goon Client jar inside the pack, so it always matches the pack. */
	String changelogText() {
		for (String path : overrides) {
			if (path.startsWith("mods/goonclient-") && path.endsWith(".jar")) {
				// Stream the nested jar instead of buffering it: the combined client jar is ~30 MB, the changelog 1 KB
				try (ZipFile zip = archive == null ? null : new ZipFile(archive.toFile());
					 InputStream raw = zip == null ? resource("/pack/overrides/" + path) : entryStream(zip, path);
					 ZipInputStream jar = new ZipInputStream(raw)) {
					ZipEntry entry;
					while ((entry = jar.getNextEntry()) != null) {
						if (entry.getName().equals("assets/goonclient/CHANGELOG.md")) {
							return new String(jar.readAllBytes(), StandardCharsets.UTF_8);
						}
					}
				} catch (IOException ignored) {
					// Fall back to the launcher's own copy
				}
			}
		}
		return null;
	}

	static InputStream resource(String path) throws IOException {
		InputStream in = PackManifest.class.getResourceAsStream(path);
		if (in == null) {
			throw new IOException("Missing bundled file " + path);
		}
		return in;
	}

	String fabricProfileId() {
		return "fabric-loader-" + fabricLoader + "-" + minecraft;
	}

    String clientJarPath() {
        return overrides.stream().filter(o -> o.startsWith("mods/goonclient-") && o.endsWith(".jar")).findFirst().orElse("mods/goonclient-"+version+".jar");
    }

    int modCount() {
		// The bundled mods plus Goon Client itself (shipped as an override)
		return files.size() + bundled.size() + (int) overrides.stream().filter(o -> o.startsWith("mods/")).count();
	}
}
