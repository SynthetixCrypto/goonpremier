package dev.goonclient.launcher;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.Duration;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HexFormat;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Installs or updates Goon Client:
 * the Fabric profile in .minecraft/versions, the mods in the Goon Client game folder (verified by hash),
 * default configs, and a "Goon Client" installation in the official launcher.
 */
final class Installer {
	static final String PROFILE_KEY = "goonclient";
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
	private static final String MANAGED_FILE = ".goonclient-managed.json";

	interface Listener {
		void update(String status, double progress);
	}

	private final PackManifest pack;
	private final Path minecraftDir;
	private final Path gameDir;
	private final Settings settings;
	private final HttpClient http = HttpClient.newBuilder()
		.followRedirects(HttpClient.Redirect.NORMAL)
		.connectTimeout(Duration.ofSeconds(15))
		.build();

	Installer(PackManifest pack, Path minecraftDir, Path gameDir, Settings settings) {
		this.pack = pack;
		this.minecraftDir = minecraftDir;
		this.gameDir = gameDir;
		this.settings = settings;
	}

	boolean minecraftLauncherFound() {
		return Files.isRegularFile(minecraftDir.resolve("launcher_profiles.json"));
	}

	/** Quick offline check: is every mod present with the right size? */
	boolean isInstalled(PackManifest.PackFile file) {
		Path target = gameDir.resolve(file.path());
		try {
			return Files.isRegularFile(target) && Files.size(target) == file.size();
		} catch (IOException e) {
			return false;
		}
	}

	/** Full install for playing through the official Minecraft Launcher. */
	void install(Listener listener, boolean repair) throws IOException, InterruptedException {
		if (!minecraftLauncherFound()) {
			throw new IOException("Couldn't find the official Minecraft Launcher's files in " + minecraftDir
				+ ". Install the Minecraft Launcher, open it once, then try again.");
		}
		listener.update("Setting up Fabric " + pack.fabricLoader() + " for Minecraft " + pack.minecraft() + "...", 0.02);
		installFabricProfile();
		installPack(listener, repair);
		listener.update("Adding the Goon Client installation to the Minecraft Launcher...", 0.98);
		writeLauncherProfile();
		listener.update("Ready", 1.0);
	}

	/** Mods, Goon Client itself and default configs into the game folder. Enough for launching directly. */
	void installPack(Listener listener, boolean repair) throws IOException, InterruptedException {
		Files.createDirectories(gameDir.resolve("mods"));
		Set<String> managed = new LinkedHashSet<>();
		installMods(listener, repair, managed);
		listener.update("Applying default settings...", 0.96);
		installOverrides(managed);
		removeStale(managed);
	}

	private void installFabricProfile() throws IOException, InterruptedException {
		String id = pack.fabricProfileId();
		Path dir = minecraftDir.resolve("versions").resolve(id);
		Path json = dir.resolve(id + ".json");
		if (!Files.isRegularFile(json)) {
			String url = "https://meta.fabricmc.net/v2/versions/loader/" + pack.minecraft() + "/" + pack.fabricLoader() + "/profile/json";
			HttpResponse<String> response = http.send(request(url), HttpResponse.BodyHandlers.ofString());
			if (response.statusCode() != 200) {
				throw new IOException("Fabric's servers answered " + response.statusCode() + " for " + url);
			}
			Files.createDirectories(dir);
			Files.writeString(json, response.body(), StandardCharsets.UTF_8);
		}
		// The Fabric installer leaves an empty jar next to the profile to keep the launcher happy; do the same
		Path dummyJar = dir.resolve(id + ".jar");
		if (!Files.exists(dummyJar)) {
			Files.createFile(dummyJar);
		}
	}

	private void installMods(Listener listener, boolean repair, Set<String> managed) throws IOException, InterruptedException {
		List<PackManifest.PackFile> needed = new ArrayList<>();
		int checked = 0;
		for (PackManifest.PackFile file : pack.files()) {
			managed.add(file.path());
			listener.update("Checking " + file.fileName() + "...", 0.05 + 0.15 * checked++ / pack.files().size());
			Path target = gameDir.resolve(file.path());
			boolean valid = Files.isRegularFile(target) && Files.size(target) == file.size()
				&& (!repair || hash(target, "SHA-1").equalsIgnoreCase(file.sha1()));
			if (!valid) {
				needed.add(file);
			}
		}
		long total = needed.stream().mapToLong(PackManifest.PackFile::size).sum();
		long[] done = {0};
		for (PackManifest.PackFile file : needed) {
			download(file, listener, done, total);
		}
	}

	private void download(PackManifest.PackFile file, Listener listener, long[] done, long total) throws IOException, InterruptedException {
		Path target = gameDir.resolve(file.path());
		Path part = target.resolveSibling(file.fileName() + ".part");
		Files.createDirectories(target.getParent());
		HttpResponse<InputStream> response = http.send(request(file.url()), HttpResponse.BodyHandlers.ofInputStream());
		if (response.statusCode() != 200) {
			throw new IOException("Download of " + file.fileName() + " failed (" + response.statusCode() + ")");
		}
		MessageDigest sha512 = digest("SHA-512");
		try (InputStream in = response.body(); OutputStream out = Files.newOutputStream(part)) {
			byte[] buffer = new byte[64 * 1024];
			int read;
			while ((read = in.read(buffer)) != -1) {
				out.write(buffer, 0, read);
				sha512.update(buffer, 0, read);
				done[0] += read;
				listener.update("Downloading " + file.fileName() + "...", 0.2 + 0.75 * done[0] / Math.max(1, total));
			}
		}
		String actual = HexFormat.of().formatHex(sha512.digest());
		if (!actual.equalsIgnoreCase(file.sha512())) {
			Files.deleteIfExists(part);
			throw new IOException(file.fileName() + " didn't match its published checksum, so it wasn't installed. Try again.");
		}
		Files.move(part, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
	}

	/** Goon Client itself is always refreshed; config defaults are only written if you don't have that file yet. */
	private void installOverrides(Set<String> managed) throws IOException {
		for (String path : pack.overrides()) {
			Path target = gameDir.resolve(path);
			boolean isMod = path.startsWith("mods/");
			if (!isMod && Files.exists(target)) {
				continue;
			}
			Files.createDirectories(target.getParent());
			try (InputStream in = pack.openOverride(path)) {
				Files.copy(in, target, StandardCopyOption.REPLACE_EXISTING);
			}
			if (isMod) {
				managed.add(path);
			}
		}
	}

	/** Deletes mods this launcher installed before that are no longer in the pack. Mods you added yourself are left alone. */
	private void removeStale(Set<String> managed) throws IOException {
		Path stateFile = gameDir.resolve(MANAGED_FILE);
		if (Files.isRegularFile(stateFile)) {
			try {
				for (JsonElement element : JsonParser.parseString(Files.readString(stateFile)).getAsJsonArray()) {
					String path = element.getAsString();
					if (!managed.contains(path) && path.startsWith("mods/")) {
						Files.deleteIfExists(gameDir.resolve(path));
					}
				}
			} catch (RuntimeException ignored) {
				// Unreadable state: skip cleanup rather than risk deleting the wrong thing
			}
		}
		JsonArray array = new JsonArray();
		managed.forEach(array::add);
		Files.writeString(stateFile, GSON.toJson(array), StandardCharsets.UTF_8);
	}

	private void writeLauncherProfile() throws IOException {
		Path file = minecraftDir.resolve("launcher_profiles.json");
		Path backup = minecraftDir.resolve("launcher_profiles.json.goonclient-backup");
		if (!Files.exists(backup)) {
			Files.copy(file, backup);
		}
		JsonObject root = JsonParser.parseString(Files.readString(file, StandardCharsets.UTF_8)).getAsJsonObject();
		JsonObject profiles = root.has("profiles") ? root.getAsJsonObject("profiles") : new JsonObject();
		JsonObject profile = profiles.has(PROFILE_KEY) ? profiles.getAsJsonObject(PROFILE_KEY) : new JsonObject();
		String now = Instant.now().truncatedTo(ChronoUnit.MILLIS).toString();
		if (!profile.has("created")) {
			profile.addProperty("created", now);
		}
		profile.addProperty("name", "Goon Client");
		profile.addProperty("type", "custom");
		profile.addProperty("lastVersionId", pack.fabricProfileId());
		profile.addProperty("gameDir", gameDir.toAbsolutePath().toString());
		profile.addProperty("javaArgs", "-Xmx" + settings.memoryGb + "G -Xms1G -XX:+UseG1GC -XX:+ParallelRefProcEnabled -XX:MaxGCPauseMillis=200");
		// Most recently used, so the launcher shows it first
		profile.addProperty("lastUsed", now);
		String icon = iconDataUri();
		if (icon != null) {
			profile.addProperty("icon", icon);
		}
		profiles.add(PROFILE_KEY, profile);
		root.add("profiles", profiles);
		Path temp = file.resolveSibling("launcher_profiles.json.tmp");
		Files.writeString(temp, GSON.toJson(root), StandardCharsets.UTF_8);
		Files.move(temp, file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
	}

	private static String iconDataUri() {
		try (InputStream in = Installer.class.getResourceAsStream("/icon.png")) {
			return in == null ? null : "data:image/png;base64," + Base64.getEncoder().encodeToString(in.readAllBytes());
		} catch (IOException e) {
			return null;
		}
	}

	private static HttpRequest request(String url) {
		return HttpRequest.newBuilder(URI.create(url))
			.header("User-Agent", "goonclient-launcher")
			.timeout(Duration.ofMinutes(5))
			.build();
	}

	private static MessageDigest digest(String algorithm) {
		try {
			return MessageDigest.getInstance(algorithm);
		} catch (NoSuchAlgorithmException e) {
			throw new IllegalStateException(e);
		}
	}

	private static String hash(Path file, String algorithm) throws IOException {
		MessageDigest digest = digest(algorithm);
		try (InputStream in = Files.newInputStream(file)) {
			byte[] buffer = new byte[64 * 1024];
			int read;
			while ((read = in.read(buffer)) != -1) {
				digest.update(buffer, 0, read);
			}
		}
		return HexFormat.of().formatHex(digest.digest());
	}
}
