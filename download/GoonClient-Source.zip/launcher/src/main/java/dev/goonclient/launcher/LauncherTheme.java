package dev.goonclient.launcher;

import java.awt.Color;
import java.util.List;

/** Launcher-only palettes; never overwrite a player's in-game theme. */
record LauncherTheme(String name,int accent,int second,int base) {
    static final String DEFAULT="Sky";
    static final List<LauncherTheme> ALL=List.of(
        new LauncherTheme("Sky",0x4DA3FF,0x8EC6FF,0x0F1520),
        new LauncherTheme("Noir",0xE16B78,0xF0939D,0x16141A),
        new LauncherTheme("Aurora",0x2DD9C3,0x9B8CF0,0x0F1718),
        new LauncherTheme("Violet",0x9D8CFF,0xC4B9FF,0x14121D),
        new LauncherTheme("Mint",0x43E0B2,0x7FEBBE,0x0F1513),
        new LauncherTheme("Amber",0xE69A43,0xF2C27A,0x1A1510),
        new LauncherTheme("Rose",0xFF6B9A,0xFF9DBC,0x1C1218),
        new LauncherTheme("White",0xE6E7EA,0xFFFFFF,0x151518));
    private static final java.util.Map<String,LauncherTheme> BY_NAME=ALL.stream().collect(java.util.stream.Collectors.toUnmodifiableMap(LauncherTheme::name,t->t));
    static LauncherTheme find(String name){return name==null?ALL.getFirst():BY_NAME.getOrDefault(name,ALL.getFirst());}
    Color color(){return new Color(accent);}
    Color ground(){return new Color(base);}
}
