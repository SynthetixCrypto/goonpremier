package dev.goonclient.launcher;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.Duration;
import java.util.HexFormat;
import java.util.Properties;

/**
 * Keeps the pack up to date without a new launcher: on start it reads latest.json from the website
 * (written by {@code ./gradlew site}), downloads a newer .mrpack into the game folder's updates/ folder, checks its
 * SHA-512 and contents, and hands it over. Next start uses the cached copy straight away, even offline.
 */
final class Updater {
	private static final long MAX_PACK_BYTES = 64L << 20;
	private static final HttpClient HTTP = HttpClient.newBuilder()
		.followRedirects(HttpClient.Redirect.NORMAL)
		.connectTimeout(Duration.ofSeconds(8))
		.build();

	/** What the website says is current. */
	record Release(String version, URI mrpack, String sha512, long size, String minLauncher, URI page) {
	}

	/** The outcome of a check: a pack to switch to, or a newer launcher to point the player at (either may be null). */
	record Result(PackManifest pack, Release launcherNeeded) {
	}

	private Updater() {
	}

	/** The newest pack already on disk: a cached update if it's newer than the bundled pack, else the bundled one. */
	static PackManifest newestCached(Path gameDir, PackManifest bundled) {
		PackManifest best = bundled;
		Path dir = updatesDir(gameDir);
		if (!Files.isDirectory(dir)) {
			return best;
		}
		try (DirectoryStream<Path> files = Files.newDirectoryStream(dir, "GoonClient-*.mrpack")) {
			for (Path file : files) {
				try {
					PackManifest pack = PackManifest.fromArchive(file);
					if (compare(pack.version(), best.version()) > 0) {
						best = pack;
					}
				} catch (IOException e) {
					// Damaged download: drop it, the next check fetches it again
					Files.deleteIfExists(file);
				}
			}
		} catch (IOException ignored) {
			// Can't read the folder: play the bundled pack
		}
		return best;
	}

	/**
	 * Asks the website for the latest release. Downloads and returns a newer pack if this launcher can run it; if the
	 * release needs a newer launcher, says so instead. Network trouble just means "no update".
	 */
	static Result check(Path gameDir, PackManifest current, String launcherVersion) {
		try {
			URI url = updateUrl();
			if (url == null) {
				return new Result(null, null);
			}
			Release release = fetchRelease(url);
			if (compare(release.version(), current.version()) <= 0) {
				return new Result(null, null);
			}
			if (compare(launcherVersion, release.minLauncher()) < 0) {
				return new Result(null, release);
			}
			return new Result(download(gameDir, release), null);
		} catch (IOException | RuntimeException e) {
			System.out.println("[updater] Update check failed: " + e.getMessage());
			return new Result(null, null);
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
			return new Result(null, null);
		}
	}

	private static URI updateUrl() throws IOException {
		try (InputStream in = Updater.class.getResourceAsStream("/update.properties")) {
			if (in == null && System.getProperty("goonclient.updateUrl") == null) {
				return null;
			}
			Properties properties = new Properties();
			if (in != null) {
				properties.load(in);
			}
			// -Dgoonclient.updateUrl=... points a test launcher at a local copy of the site
			String value = System.getProperty("goonclient.updateUrl", properties.getProperty("update_url", "")).trim();
			return value.isEmpty() ? null : allowed(URI.create(value));
		}
	}

	private static Release fetchRelease(URI url) throws IOException, InterruptedException {
		HttpResponse<String> response = HTTP.send(request(url), HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
		if (response.statusCode() != 200) {
			throw new IOException("the website answered " + response.statusCode());
		}
		JsonObject json = JsonParser.parseString(response.body()).getAsJsonObject();
		URI mrpack = allowed(URI.create(json.get("mrpack").getAsString()));
		return new Release(
			json.get("version").getAsString(),
			mrpack,
			json.get("sha512").getAsString(),
			json.get("size").getAsLong(),
			json.has("minLauncher") ? json.get("minLauncher").getAsString() : "0",
			json.has("page") ? URI.create(json.get("page").getAsString()) : null);
	}

	private static PackManifest download(Path gameDir, Release release) throws IOException, InterruptedException {
		if (release.size() <= 0 || release.size() > MAX_PACK_BYTES) {
			throw new IOException("the pack size looks wrong (" + release.size() + " bytes)");
		}
		if (!release.version().matches("[0-9A-Za-z.+-]{1,32}")) {
			throw new IOException("odd version name " + release.version());
		}
		Path dir = updatesDir(gameDir);
		Files.createDirectories(dir);
		Path target = dir.resolve("GoonClient-" + release.version() + ".mrpack");
		if (!Files.isRegularFile(target)) {
			Path part = dir.resolve(target.getFileName() + ".part");
			HttpResponse<InputStream> response = HTTP.send(request(release.mrpack()), HttpResponse.BodyHandlers.ofInputStream());
			if (response.statusCode() != 200) {
				throw new IOException("the pack download answered " + response.statusCode());
			}
			MessageDigest sha512 = digest();
			long total = 0;
			try (InputStream in = response.body(); OutputStream out = Files.newOutputStream(part)) {
				byte[] buffer = new byte[64 * 1024];
				int read;
				while ((read = in.read(buffer)) != -1) {
					total += read;
					if (total > MAX_PACK_BYTES) {
						throw new IOException("the pack download is bigger than expected");
					}
					out.write(buffer, 0, read);
					sha512.update(buffer, 0, read);
				}
			} catch (IOException e) {
				Files.deleteIfExists(part);
				throw e;
			}
			String actual = HexFormat.of().formatHex(sha512.digest());
			if (total != release.size() || !actual.equalsIgnoreCase(release.sha512())) {
				Files.deleteIfExists(part);
				throw new IOException("the downloaded pack didn't match its checksum");
			}
			Files.move(part, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
		}
		PackManifest pack;
		try {
			pack = PackManifest.fromArchive(target);
		} catch (IOException e) {
			Files.deleteIfExists(target);
			throw e;
		}
		if (!pack.version().equals(release.version())) {
			Files.deleteIfExists(target);
			throw new IOException("the pack says it's " + pack.version() + ", not " + release.version());
		}
		removeOlder(dir, target);
		System.out.println("[updater] Downloaded Goon Client " + pack.version());
		return pack;
	}

	/** Keeps just the newest cached pack. */
	private static void removeOlder(Path dir, Path keep) {
		try (DirectoryStream<Path> files = Files.newDirectoryStream(dir, "GoonClient-*.mrpack")) {
			for (Path file : files) {
				if (!file.equals(keep)) {
					Files.deleteIfExists(file);
				}
			}
		} catch (IOException ignored) {
			// Old copies only cost disk space
		}
	}

	/** https only, except plain http to this computer for testing against a local copy of the site. */
	private static URI allowed(URI url) throws IOException {
		boolean local = "http".equals(url.getScheme()) && ("localhost".equals(url.getHost()) || "127.0.0.1".equals(url.getHost()));
		if (!"https".equals(url.getScheme()) && !local) {
			throw new IOException("refusing a non-https link: " + url);
		}
		return url;
	}

	private static Path updatesDir(Path gameDir) {
		return gameDir.resolve("updates");
	}

	private static HttpRequest request(URI url) {
		return HttpRequest.newBuilder(url)
			.timeout(Duration.ofSeconds(30))
			.header("User-Agent", "GoonClient-Launcher")
			.GET()
			.build();
	}

	private static MessageDigest digest() {
		try {
			return MessageDigest.getInstance("SHA-512");
		} catch (NoSuchAlgorithmException e) {
			throw new IllegalStateException(e);
		}
	}

	/** Compares dotted versions numerically ("0.10.0" > "0.9.2"); anything after a "-" or "+" is ignored. */
	static int compare(String a, String b) {
		String[] left = a.split("[-+]", 2)[0].split("\\.");
		String[] right = b.split("[-+]", 2)[0].split("\\.");
		for (int i = 0; i < Math.max(left.length, right.length); i++) {
			int l = i < left.length ? number(left[i]) : 0;
			int r = i < right.length ? number(right[i]) : 0;
			if (l != r) {
				return Integer.compare(l, r);
			}
		}
		return 0;
	}

	private static int number(String part) {
		try {
			return Integer.parseInt(part.trim());
		} catch (NumberFormatException e) {
			return 0;
		}
	}
}
