package dev.goonclient.launcher;

import com.google.gson.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.security.MessageDigest;
import java.time.Instant;
import java.util.*;
import java.util.zip.ZipFile;

/** Local, advisory archive/metadata inventory. Never loads classes, resolves the mod graph or alters mods. */
final class LaunchCheckup {
    record Finding(String title,String detail) {}
    record Report(Instant at,int roots,int candidates,boolean complete,List<Finding> findings) {
        Report { findings=List.copyOf(findings); }
        String summary(){return !complete?"Check incomplete":findings.isEmpty()?"No archive issues found":"Review "+findings.size()+" findings";}
        String text(){
            var out=new StringBuilder("Goon Client — Launch Checkup\n").append(at).append('\n').append(summary()).append('\n')
                .append(roots).append(" root archives; ").append(candidates).append(" unique mod candidates.\n\n")
                .append("Advisory inventory only. Fabric decides dependency versions, optional candidates and compatibility at launch.\n")
                .append("No classes executed, mods changed, account details, file paths or logs included.\n\n");
            for(var f:findings)out.append("• ").append(f.title()).append("\n  ").append(f.detail()).append("\n\n");
            return out.toString();
        }
    }
    private record Mod(String id,String source,Set<String> provides,Set<String> depends) {}
    private final List<Finding> findings=new ArrayList<>();
    private final List<Mod> mods=new ArrayList<>();
    private final Set<String> nestedHashes=new HashSet<>();
    private final List<Path> temporary=new ArrayList<>();
    private final long started=System.nanoTime();
    private long bytes;
    private int roots;
    private boolean complete=true;
    private Path temp;
    private LaunchCheckup(){}

    static Report scan(Path gameDir,PackManifest pack){return new LaunchCheckup().run(gameDir,pack);}
    private Report run(Path gameDir,PackManifest pack){
        try{
            Path folder=gameDir.resolve("mods");
            if(!Files.isDirectory(folder)){add("Nothing installed yet","Press Play to install the pack, then check again.");return report();}
            temp=Files.createTempDirectory("goon-checkup-");
            List<Path> jars;
            jars=new ArrayList<>();
            try(var files=Files.newDirectoryStream(folder)){
                int entries=0;for(Path entry:files){budget(0);if(++entries>4096)throw new Limit();
                    String name=entry.getFileName().toString();if(name.endsWith(".jar")&&!name.startsWith(".")){jars.add(entry);if(jars.size()>256)throw new Limit();}}
            }
            jars.sort(Comparator.naturalOrder());
            if(jars.size()>256)throw new IOException("limit");
            Set<String> expected=new HashSet<>(pack.overrides());pack.files().forEach(f->expected.add(f.path()));
            for(Path jar:jars){
                if(Files.isHidden(jar))continue;
                roots++;String source=(expected.contains("mods/"+jar.getFileName())?"Pack archive ":"Added archive ")+roots;
                try{
                    var before=Files.readAttributes(jar,BasicFileAttributes.class);
                    if(!before.isRegularFile()||before.size()>128L*1024*1024)throw new IOException("limit");
                    archive(jar,source,0);
                    var after=Files.readAttributes(jar,BasicFileAttributes.class);
                    if(before.size()!=after.size()||!before.lastModifiedTime().equals(after.lastModifiedTime())||!Objects.equals(before.fileKey(),after.fileKey())){complete=false;add("Files changed during the check",source+" changed. Finish installing, then check again.");}
                }catch(Limit e){throw e;}
                catch(Exception e){complete=false;add("Unreadable archive or metadata",source+" could not be inspected. Use Mods folder to review added files, or Repair for the pack.");}
            }
            if(!Files.isRegularFile(gameDir.resolve(pack.clientJarPath())))add("Goon Client is not installed","Press Play to install the client jar. This check does not install files.");
            if(Files.exists(gameDir.resolve("config/fabric_loader_dependencies.json"))){complete=false;add("Dependency overrides present","Custom Fabric dependency overrides were not evaluated. Fabric's own launch result is authoritative.");}
            var ids=new LinkedHashMap<String,List<Mod>>();var available=new HashSet<>(Set.of("minecraft","java","fabricloader","mixinextras"));
            for(var mod:mods){ids.computeIfAbsent(mod.id(),k->new ArrayList<>()).add(mod);available.add(mod.id());available.addAll(mod.provides());}
            ids.forEach((id,list)->{if(list.size()>1&&(list.stream().map(m->m.source().replace(" → nested", "")).distinct().count()>1||list.stream().anyMatch(m->!m.source().contains(" → nested"))))add("Multiple candidates: "+id,list.size()+" candidates were found. This can be valid; Fabric selects compatible versions. Review added copies if startup fails.");});
            for(var mod:mods)for(String dependency:mod.depends())if(!available.contains(dependency))add("Dependency not in inventory: "+dependency,"Declared by "+mod.id()+" ("+mod.source()+"). Nested candidates may be optional; this is not a dependency-resolution verdict.");
        }catch(Exception e){complete=false;add("Check stopped early","The folder was unreadable or a safety limit was reached. Close installers and check again. Existing files were retained.");}
        finally{
            for(int i=temporary.size()-1;i>=0;i--)try{Files.deleteIfExists(temporary.get(i));}catch(IOException ignored){complete=false;}
            if(temp!=null)try{Files.deleteIfExists(temp);}catch(IOException ignored){complete=false;}
        }
        return report();
    }
    private Report report(){return new Report(Instant.now(),roots,mods.size(),complete,findings);}
    private void add(String title,String detail){if(findings.size()<50)findings.add(new Finding(title,detail));else complete=false;}
    private void budget(long n)throws Limit{bytes+=n;if(bytes>192L*1024*1024||mods.size()>=512||System.nanoTime()-started>8_000_000_000L)throw new Limit();}
    private byte[] read(ZipFile zip,String name,int limit)throws IOException{
        budget(0);var entry=zip.getEntry(name);if(entry==null)return null;
        if(entry.getSize()>limit)throw new Limit();
        long remaining=192L*1024*1024-bytes;
        int allowance=(int)Math.min(limit,remaining);if(allowance<=0)throw new Limit();
        try(var in=zip.getInputStream(entry)){var value=in.readNBytes(allowance+1);budget(value.length);if(value.length>allowance)throw new Limit();return value;}
    }
    private void archive(Path file,String source,int depth)throws Exception{
        budget(0);if(depth>8)throw new Limit();
        validateZipIndex(file);
        try(var zip=new ZipFile(file.toFile())){
            byte[] json=read(zip,"fabric.mod.json",128*1024);
            if(json==null){if(depth==0)add("No Fabric metadata",source+" has no fabric.mod.json. It may be for a different loader or a non-mod library.");return;}
            validateJsonDepth(json);
            var data=JsonParser.parseString(new String(json,StandardCharsets.UTF_8)).getAsJsonObject();
            String id=data.get("id").getAsString();if(!validId(id))throw new IOException("id");
            if(!data.has("version")||!data.get("version").isJsonPrimitive()||!data.getAsJsonPrimitive("version").isString()||data.get("version").getAsString().isBlank()||data.get("version").getAsString().length()>256)throw new IOException("version");
            if(data.has("environment")&&(!data.get("environment").isJsonPrimitive()||!data.getAsJsonPrimitive("environment").isString()||!Set.of("*","client","server").contains(data.get("environment").getAsString()))){complete=false;add("Unsupported environment metadata",source+" requires Fabric's own metadata parser.");return;}
            if(data.has("environment")&&data.get("environment").getAsString().equals("server"))return;
            if(!data.has("schemaVersion")||!data.get("schemaVersion").isJsonPrimitive()||!data.getAsJsonPrimitive("schemaVersion").isNumber()||data.get("schemaVersion").getAsBigDecimal().intValueExact()!=1){complete=false;add("Legacy or newer metadata: "+id,"Only schema 1 is inventoried here. Fabric handles the actual loading rules.");return;}
            var provides=new HashSet<String>();if(data.has("provides"))for(var alias:data.getAsJsonArray("provides")){if(!alias.isJsonPrimitive()||!alias.getAsJsonPrimitive().isString())throw new IOException("alias");String value=alias.getAsString();if(!validId(value))throw new IOException("alias");provides.add(value);}
            var depends=new HashSet<String>();if(data.has("depends"))for(String value:data.getAsJsonObject("depends").keySet()){if(!validId(value))throw new IOException("id");validatePredicateShape(data.getAsJsonObject("depends").get(value));depends.add(value);}
            mods.add(new Mod(id,source,Set.copyOf(provides),Set.copyOf(depends)));
            if(data.has("jars"))for(var value:data.getAsJsonArray("jars")){
                String name=value.getAsJsonObject().get("file").getAsString();
                if(name.length()>512||name.startsWith("/")||name.contains("\\")||Arrays.asList(name.split("/")).contains(".."))throw new IOException("path");
                byte[] child=read(zip,name,48*1024*1024);
                if(child==null){add("Declared nested archive missing: "+id,"Fabric may ignore this candidate; a required dependency could still fail. Check the pack or added mod.");continue;}
                String hash=HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(child));if(!nestedHashes.add(hash))continue;
                Path nested=temp.resolve("nested-"+temporary.size()+".jar");temporary.add(nested);Files.write(nested,child);
                archive(nested,source+" → nested",depth+1);
            }
        }
    }
    /** Bound central-directory allocation before ZipFile opens untrusted archives. ZIP64 is left to Fabric. */
    private void validateZipIndex(Path file)throws IOException{
        budget(0);try(var in=new RandomAccessFile(file.toFile(),"r")){
            long size=in.length();if(size<22)throw new IOException("zip index");if(size>128L*1024*1024)throw new Limit();
            int length=(int)Math.min(size,65557);byte[] tail=new byte[length];in.seek(size-length);in.readFully(tail);
            ByteBuffer end=ByteBuffer.wrap(tail).order(ByteOrder.LITTLE_ENDIAN);int at=-1;
            for(int i=length-22;i>=0;i--)if(end.getInt(i)==0x06054b50&&i+22+Short.toUnsignedInt(end.getShort(i+20))==length){at=i;break;}
            if(at<0)throw new IOException("zip index");
            int count=Short.toUnsignedInt(end.getShort(at+10));long bytes=Integer.toUnsignedLong(end.getInt(at+12)),offset=Integer.toUnsignedLong(end.getInt(at+16));
            if(end.getShort(at+4)!=0||end.getShort(at+6)!=0||Short.toUnsignedInt(end.getShort(at+8))!=count||count==65535||count>30000||bytes>8L*1024*1024||offset==0xffffffffL||offset+bytes!=size-length+at)throw new Limit();
            byte[] directory=new byte[(int)bytes];in.seek(offset);in.readFully(directory);ByteBuffer cd=ByteBuffer.wrap(directory).order(ByteOrder.LITTLE_ENDIAN);
            int pos=0,actual=0;while(pos<directory.length){budget(0);if(pos+46>directory.length||cd.getInt(pos)!=0x02014b50||++actual>30000)throw new IOException("zip entries");
                if(cd.getShort(pos+34)!=0)throw new Limit();
                pos+=46+Short.toUnsignedInt(cd.getShort(pos+28))+Short.toUnsignedInt(cd.getShort(pos+30))+Short.toUnsignedInt(cd.getShort(pos+32));
                if(pos>directory.length)throw new IOException("zip entries");}
            if(actual!=count)throw new IOException("zip count");
        }budget(0);
    }
    private static void validatePredicateShape(JsonElement value)throws IOException{
        if(value.isJsonPrimitive()&&value.getAsJsonPrimitive().isString()&&!value.getAsString().isBlank()&&value.getAsString().length()<=512)return;
        if(value.isJsonArray()&&!value.getAsJsonArray().isEmpty()&&value.getAsJsonArray().size()<=32){for(JsonElement item:value.getAsJsonArray()){
            if(!item.isJsonPrimitive()||!item.getAsJsonPrimitive().isString()||item.getAsString().isBlank()||item.getAsString().length()>512)throw new IOException("predicate");}return;}
        throw new IOException("predicate");
    }
    private static void validateJsonDepth(byte[] json)throws Limit{
        int depth=0;boolean string=false,escaped=false;
        for(byte ch:json){if(string){if(escaped)escaped=false;else if(ch==92)escaped=true;else if(ch==34)string=false;}
            else if(ch==34)string=true;else if(ch==123||ch==91){if(++depth>64)throw new Limit();}else if(ch==125||ch==93)depth--;}
    }
    private static boolean validId(String id){return id!=null&&id.matches("[a-z][a-z0-9_-]{1,63}");}
    private static final class Limit extends IOException {}
    static Path save(Report report,Path gameDir)throws IOException{
        Path folder=gameDir.resolve("goonclient/reports");Files.createDirectories(folder);
        Path file=folder.resolve("launch-checkup-"+UUID.randomUUID()+".txt");
        Files.writeString(file,report.text(),StandardCharsets.UTF_8,StandardOpenOption.CREATE_NEW);return file;
    }
}
