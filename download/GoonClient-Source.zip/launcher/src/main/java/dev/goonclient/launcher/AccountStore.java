package dev.goonclient.launcher;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

/**
 * The signed-in account, kept in the user's own AppData folder (like other launchers do).
 * Only Microsoft/Minecraft tokens are stored, never a password.
 */
final class AccountStore {
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

	private final Path file;

	AccountStore(Path gameDir) {
		this.file = gameDir.resolve("account.json");
	}

	MicrosoftAuth.Account load() {
		try {
			return Files.isRegularFile(file) ? GSON.fromJson(Files.readString(file, StandardCharsets.UTF_8), MicrosoftAuth.Account.class) : null;
		} catch (IOException | RuntimeException e) {
			return null;
		}
	}

	void save(MicrosoftAuth.Account account) throws IOException {
		Files.createDirectories(file.getParent());
		Path temp = file.resolveSibling("account.json.tmp");
		Files.writeString(temp, GSON.toJson(account), StandardCharsets.UTF_8);
		Files.move(temp, file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
	}

	void clear() throws IOException {
		Files.deleteIfExists(file);
	}
}
