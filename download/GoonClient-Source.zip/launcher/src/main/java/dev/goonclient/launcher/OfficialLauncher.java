package dev.goonclient.launcher;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * Finds and opens the official Minecraft Launcher, which handles the Microsoft login and starts the game
 * with the "Goon Client" installation this launcher prepared.
 */
final class OfficialLauncher {
	private static final String STORE_PACKAGE = "Microsoft.4297127D64EC6_8wekyb3d8bbwe";

	private OfficialLauncher() {
	}

	/** Returns a description of how it was opened, or null if no launcher was found. */
	static String open() throws IOException {
		for (Path exe : candidates()) {
			if (Files.isRegularFile(exe)) {
				new ProcessBuilder(exe.toString()).directory(exe.getParent().toFile()).start();
				return exe.toString();
			}
		}
		Path packages = Path.of(System.getenv().getOrDefault("LOCALAPPDATA", ""), "Packages", STORE_PACKAGE);
		if (Files.isDirectory(packages)) {
			new ProcessBuilder("explorer.exe", "shell:AppsFolder\\" + STORE_PACKAGE + "!Minecraft").start();
			return "Microsoft Store launcher";
		}
		return null;
	}

	private static List<Path> candidates() {
		List<Path> paths = new ArrayList<>();
		for (String env : new String[]{"ProgramFiles(x86)", "ProgramFiles"}) {
			String dir = System.getenv(env);
			if (dir != null) {
				paths.add(Path.of(dir, "Minecraft Launcher", "MinecraftLauncher.exe"));
			}
		}
		// Xbox app installs go to <drive>:\XboxGames
		for (File root : File.listRoots()) {
			paths.add(root.toPath().resolve("XboxGames").resolve("Minecraft Launcher").resolve("Content").resolve("Minecraft.exe"));
		}
		return paths;
	}
}
