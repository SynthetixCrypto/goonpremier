package dev.goonclient.launcher;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Mojang's library/argument rules ("allow on windows", "disallow on x86", ...) and argument lists. */
final class Rules {
	private static final String OS_NAME = System.getProperty("os.name").toLowerCase(Locale.ROOT);
	private static final String OS_ARCH = System.getProperty("os.arch").toLowerCase(Locale.ROOT);

	private Rules() {
	}

	static boolean isWindows() {
		return OS_NAME.contains("win");
	}

	private static String mojangOsName() {
		if (isWindows()) {
			return "windows";
		}
		return OS_NAME.contains("mac") ? "osx" : "linux";
	}

	private static boolean isArm64() {
		return OS_ARCH.equals("aarch64") || OS_ARCH.equals("arm64");
	}

	/** The natives classifier for this machine, e.g. "natives-windows" or "natives-windows-arm64". */
	static String nativesClassifier() {
		String os = switch (mojangOsName()) {
			case "osx" -> "macos";
			case "windows" -> "windows";
			default -> "linux";
		};
		return "natives-" + os + (isArm64() ? "-arm64" : "");
	}

	/** Mojang's runtime platform key, e.g. "windows-x64". */
	static String runtimePlatform() {
		return switch (mojangOsName()) {
			case "windows" -> isArm64() ? "windows-arm64" : "windows-x64";
			case "osx" -> isArm64() ? "mac-os-arm64" : "mac-os";
			default -> "linux";
		};
	}

	/** True when the rules allow this item here. Rules needing launcher features (demo, quick play...) never match. */
	static boolean allowed(JsonArray rules) {
		if (rules == null || rules.isEmpty()) {
			return true;
		}
		boolean allowed = false;
		for (JsonElement element : rules) {
			JsonObject rule = element.getAsJsonObject();
			boolean matches = !rule.has("features") && (!rule.has("os") || osMatches(rule.getAsJsonObject("os")));
			if (matches) {
				allowed = rule.get("action").getAsString().equals("allow");
			}
		}
		return allowed;
	}

	private static boolean osMatches(JsonObject os) {
		if (os.has("name") && !os.get("name").getAsString().equals(mojangOsName())) {
			return false;
		}
		if (os.has("arch") && os.get("arch").getAsString().equals("x86") != OS_ARCH.equals("x86")) {
			return false;
		}
		if (os.has("versionRange")) {
			// Ranges compare against Windows 10 build 17134 (2018). Java only reports "10.0", so assume a modern Windows.
			JsonObject range = os.getAsJsonObject("versionRange");
			return !range.has("max");
		}
		return true;
	}

	/** Flattens an argument list, keeping plain strings and values whose rules allow them. */
	static List<String> arguments(JsonArray list) {
		List<String> result = new ArrayList<>();
		if (list == null) {
			return result;
		}
		for (JsonElement element : list) {
			if (element.isJsonPrimitive()) {
				result.add(element.getAsString());
			} else {
				JsonObject object = element.getAsJsonObject();
				if (allowed(object.getAsJsonArray("rules"))) {
					JsonElement value = object.get("value");
					if (value.isJsonArray()) {
						value.getAsJsonArray().forEach(v -> result.add(v.getAsString()));
					} else {
						result.add(value.getAsString());
					}
				}
			}
		}
		return result;
	}
}
