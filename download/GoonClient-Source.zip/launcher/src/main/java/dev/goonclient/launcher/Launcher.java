package dev.goonclient.launcher;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;

/**
 * Goon Client Launcher: installs/updates the Goon Client modpack and hands off to the official Minecraft Launcher,
 * which signs you in with Microsoft and starts the game.
 *
 * <pre>
 * --minecraft-dir DIR   official launcher data (default %APPDATA%\.minecraft)
 * --game-dir DIR        where Goon Client's mods/config live (default %APPDATA%\.goonclient)
 * --install             install headlessly and exit (testing)
 * --launch --dev-offline NAME
 *                       install everything and start the game with an offline test session, then exit (testing;
 *                       singleplayer only, real players always sign in with Microsoft)
 * --screenshot DIR      render every page to PNGs and exit (testing)
 * </pre>
 */
public final class Launcher {
	static final int WIDTH = 1000;
	static final int HEIGHT = 620;

	private Launcher() {
	}

	public static void main(String[] args) throws Exception {
		Map<String, String> options = parse(args);
		Draw.loadFonts();
		PackManifest bundled = PackManifest.load();
		String appData = System.getenv().getOrDefault("APPDATA", System.getProperty("user.home"));
		Path minecraftDir = Path.of(options.getOrDefault("minecraft-dir", appData + "/.minecraft"));
		Path gameDir = Path.of(options.getOrDefault("game-dir", appData + "/.goonclient"));
		Settings settings = Settings.load(gameDir);

		if (options.containsKey("check-update")) {
			// Command-line update check: prints what the website offers and downloads it
			Updater.Result result = Updater.check(gameDir, Updater.newestCached(gameDir, bundled), bundled.version());
			System.out.println(result.pack() != null ? "Updated to Goon Client " + result.pack().version()
				: result.launcherNeeded() != null ? "Goon Client " + result.launcherNeeded().version() + " needs a newer launcher"
				: "No update");
			return;
		}
		// A pack update downloaded on an earlier start (works offline too)
		PackManifest pack = Updater.newestCached(gameDir, bundled);

		if (options.containsKey("install")) {
			new Installer(pack, minecraftDir, gameDir, settings).install(new Installer.Listener() {
				private String last = "";

				@Override
				public void update(String status, double progress) {
					if (!status.equals(last)) {
						System.out.printf("[%3d%%] %s%n", Math.round(progress * 100), status);
						last = status;
					}
				}
			}, options.containsKey("repair"));
			return;
		}

		if (options.containsKey("launch") && options.containsKey("dev-offline")) {
			devLaunch(pack, minecraftDir, gameDir, settings, options.get("dev-offline"));
			return;
		}

		BufferedImage background = image("/background.png");
		BufferedImage icon = image("/icon.png");

		if (options.containsKey("screenshot")) {
			screenshots(Path.of(options.get("screenshot")), pack, minecraftDir, gameDir, settings, background, icon);
			System.exit(0);
		}

		SwingUtilities.invokeLater(() -> {
			JFrame frame = new JFrame("Goon Client Launcher");
			frame.setUndecorated(true);
			frame.setBackground(new Color(0, 0, 0, 0));
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			if (icon != null) {
				frame.setIconImages(List.of(icon));
			}
			frame.setContentPane(new LauncherView(frame, pack, bundled.version(), minecraftDir, gameDir, settings, background, icon));
			frame.setSize(WIDTH, HEIGHT);
			frame.setLocationRelativeTo(null);
			frame.setVisible(true);
		});
	}

	private static void devLaunch(PackManifest pack, Path minecraftDir, Path gameDir, Settings settings, String name) throws Exception {
		Installer.Listener print = new Installer.Listener() {
			private String last = "";

			@Override
			public void update(String status, double progress) {
				// Print each step once, not every byte-count update
				String shortStatus = status.replaceAll("\\(.*\\)", "(...)");
				if (!shortStatus.equals(last)) {
					System.out.printf("[%3d%%] %s%n", Math.round(progress * 100), status);
					last = shortStatus;
				}
			}
		};
		new Installer(pack, minecraftDir, gameDir, settings).installPack(print, false);
		List<Path> seeds = java.nio.file.Files.isDirectory(minecraftDir) ? List.of(minecraftDir) : List.of();
		GameFiles.LaunchPlan plan = new GameFiles(pack, gameDir.resolve("game-files"), seeds).prepare(print, false);
		String uuid = java.util.UUID.nameUUIDFromBytes(("OfflinePlayer:" + name).getBytes(java.nio.charset.StandardCharsets.UTF_8))
			.toString().replace("-", "");
		Process game = GameLauncher.launch(plan, new GameLauncher.Session(name, uuid, "0", "legacy"), gameDir, settings, pack.version());
		System.out.println("Started Minecraft, pid " + game.pid() + " (output: " + gameDir.resolve("logs").resolve("launcher-output.log") + ")");
	}

	private static void screenshots(Path dir, PackManifest pack, Path minecraftDir, Path gameDir, Settings settings,
									BufferedImage background, BufferedImage icon) throws Exception {
		Files.createDirectories(dir);
		LauncherView view = new LauncherView(null, pack, pack.version(), minecraftDir, gameDir, settings, background, icon);
		view.setSize(WIDTH, HEIGHT);
		render(view, dir.resolve("launcher-home.png"));
		view.showDemoProgress(LauncherView.Page.HOME, "Downloading sodium-fabric-0.9.2+mc26.3.jar...", 0.42);
		render(view, dir.resolve("launcher-installing.png"));
		view.showDemoProgress(LauncherView.Page.MODS, null, -1);
		render(view, dir.resolve("launcher-mods.png"));
		view.showPage(LauncherView.Page.SETTINGS);
		render(view, dir.resolve("launcher-settings.png"));
		MicrosoftAuth demo = MicrosoftAuth.demo();
		view.showPage(LauncherView.Page.HOME);
		view.showDemoAccount(demo, null, "C4N7-G00N");
		render(view, dir.resolve("launcher-signin.png"));
		view.showDemoAccount(demo, new MicrosoftAuth.Account("Steve", "0", null, null, 0, null), null);
		render(view, dir.resolve("launcher-signed-in.png"));
	}

	private static void render(LauncherView view, Path file) throws Exception {
		BufferedImage image = new BufferedImage(WIDTH, HEIGHT, BufferedImage.TYPE_INT_ARGB);
		Graphics2D g = image.createGraphics();
		// Paint twice so animated values settle
		view.paint(g);
		Thread.sleep(200);
		view.paint(g);
		g.dispose();
		ImageIO.write(image, "png", file.toFile());
		System.out.println("Wrote " + file);
	}

	private static BufferedImage image(String path) {
		try (InputStream in = Launcher.class.getResourceAsStream(path)) {
			return in == null ? null : ImageIO.read(in);
		} catch (Exception e) {
			return null;
		}
	}

	private static Map<String, String> parse(String[] args) {
		Map<String, String> options = new HashMap<>();
		for (int i = 0; i < args.length; i++) {
			if (args[i].startsWith("--")) {
				String key = args[i].substring(2);
				boolean hasValue = i + 1 < args.length && !args[i + 1].startsWith("--");
				options.put(key, hasValue ? args[++i] : "true");
			}
		}
		return options;
	}
}
