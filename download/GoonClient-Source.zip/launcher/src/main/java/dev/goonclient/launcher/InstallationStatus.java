package dev.goonclient.launcher;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashSet;
import java.util.Set;

/** Display-only snapshot. Installation still verifies downloads independently. Never scan from paint. */
record InstallationStatus(PackManifest pack, Set<String> installed, boolean client, boolean official, boolean ready) {
    static InstallationStatus pending(PackManifest pack) {
        return new InstallationStatus(pack, Set.of(), false, false, false);
    }
    static InstallationStatus scan(PackManifest pack, Installer installer, Path gameDir) {
        var installed = new HashSet<String>();
        for (var file : pack.files()) if (installer.isInstalled(file)) installed.add(file.path());
        return new InstallationStatus(pack, Set.copyOf(installed),
            Files.isRegularFile(gameDir.resolve(pack.clientJarPath())), installer.minecraftLauncherFound(), true);
    }
    boolean contains(PackManifest.PackFile file) { return installed.contains(file.path()); }
}
