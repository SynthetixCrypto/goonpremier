package dev.goonclient.launcher;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/** Launcher preferences, stored next to the game files. */
final class Settings {
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

	int memoryGb = 4;
	boolean closeAfterLaunch = true;
	/** Play through the official Minecraft Launcher instead of starting the game directly. */
	boolean useOfficialLauncher = false;
	/** Check goonnation.xyz for a newer pack when the launcher starts. */
	boolean autoUpdate = true;

	static Path file(Path gameDir) {
		return gameDir.resolve("launcher.json");
	}

	static Settings load(Path gameDir) {
		try {
			Path file = file(gameDir);
			if (Files.exists(file)) {
				Settings settings = GSON.fromJson(Files.readString(file, StandardCharsets.UTF_8), Settings.class);
				if (settings != null) {
					settings.memoryGb = Math.max(2, Math.min(16, settings.memoryGb));
					return settings;
				}
			}
		} catch (IOException | RuntimeException ignored) {
			// Corrupt or unreadable: start from defaults
		}
		return new Settings();
	}

	void save(Path gameDir) {
		try {
			Files.createDirectories(gameDir);
			Files.writeString(file(gameDir), GSON.toJson(this), StandardCharsets.UTF_8);
		} catch (IOException ignored) {
			// Settings are a convenience; failing to save them shouldn't stop anything
		}
	}
}
