package dev.goonclient.launcher;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Installs everything needed to start Minecraft + Fabric without the official launcher: version metadata,
 * client jar, libraries, assets, logging config, Mojang's Java runtime and natives. Mirrors the official
 * launcher's folder layout, so files can be reused from an existing .minecraft (read-only).
 */
final class GameFiles {
	private static final String VERSION_MANIFEST = "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json";
	private static final String RUNTIME_MANIFEST = "https://piston-meta.mojang.com/v1/products/java-runtime/2ec0cc96c44e5a76b9c8b7c39df7210883d12871/all.json";
	private static final String ASSETS_URL = "https://resources.download.minecraft.net/";

	/** Everything GameLauncher needs to build the command line. */
	record LaunchPlan(Path java, List<Path> classpath, String mainClass, String versionId, String versionType,
					  JsonObject vanilla, JsonObject fabric, Path assetsRoot, String assetIndex, Path nativesDir,
					  Path loggingConfig) {
	}

	private final PackManifest pack;
	private final Path store;
	private final List<Path> seeds;
	private final Downloader downloader;

	GameFiles(PackManifest pack, Path store, List<Path> seeds) {
		this.pack = pack;
		this.store = store;
		this.seeds = seeds;
		this.downloader = new Downloader(seeds);
	}

	LaunchPlan prepare(Installer.Listener listener, boolean verify) throws IOException, InterruptedException {
		String mc = pack.minecraft();
		listener.update("Getting Minecraft " + mc + " info...", 0.02);
		JsonObject vanilla = vanillaVersion(mc);
		JsonObject fabric = fabricProfile();
		String versionId = fabric.get("id").getAsString();

		// Libraries + client jar
		List<Path> classpath = new ArrayList<>();
		List<Downloader.Item> items = new ArrayList<>();
		Map<String, Downloader.Item> libraries = new LinkedHashMap<>();
		for (JsonElement element : fabric.getAsJsonArray("libraries")) {
			addFabricLibrary(element.getAsJsonObject(), libraries);
		}
		List<Path> nativeJars = new ArrayList<>();
		for (JsonElement element : vanilla.getAsJsonArray("libraries")) {
			addVanillaLibrary(element.getAsJsonObject(), libraries, nativeJars);
		}
		for (Downloader.Item library : libraries.values()) {
			items.add(library);
			classpath.add(library.target());
		}
		JsonObject client = vanilla.getAsJsonObject("downloads").getAsJsonObject("client");
		Path clientJar = store.resolve("versions").resolve(mc).resolve(mc + ".jar");
		items.add(new Downloader.Item(client.get("url").getAsString(), clientJar, client.get("sha1").getAsString(),
			client.get("size").getAsLong(), "versions/" + mc + "/" + mc + ".jar"));
		classpath.add(clientJar);

		// Logging config
		Path loggingConfig = null;
		JsonObject logging = vanilla.has("logging") ? vanilla.getAsJsonObject("logging").getAsJsonObject("client") : null;
		if (logging != null) {
			JsonObject file = logging.getAsJsonObject("file");
			String id = file.get("id").getAsString();
			loggingConfig = store.resolve("assets").resolve("log_configs").resolve(id);
			items.add(new Downloader.Item(file.get("url").getAsString(), loggingConfig, file.get("sha1").getAsString(),
				file.get("size").getAsLong(), "assets/log_configs/" + id));
		}

		listener.update("Downloading Minecraft and libraries...", 0.05);
		downloader.fetchAll(items, verify, (done, total, current) ->
			listener.update("Downloading " + current + "...", 0.05 + 0.25 * fraction(done, total)));

		// Assets
		JsonObject assetIndex = vanilla.getAsJsonObject("assetIndex");
		String indexId = assetIndex.get("id").getAsString();
		Path indexFile = store.resolve("assets").resolve("indexes").resolve(indexId + ".json");
		downloader.fetchAll(List.of(new Downloader.Item(assetIndex.get("url").getAsString(), indexFile,
			assetIndex.get("sha1").getAsString(), assetIndex.get("size").getAsLong(), "assets/indexes/" + indexId + ".json")), verify, (d, t, c) -> { });
		List<Downloader.Item> objects = new ArrayList<>();
		JsonObject index = JsonParser.parseString(Files.readString(indexFile, StandardCharsets.UTF_8)).getAsJsonObject();
		for (Map.Entry<String, JsonElement> entry : index.getAsJsonObject("objects").entrySet()) {
			JsonObject object = entry.getValue().getAsJsonObject();
			String hash = object.get("hash").getAsString();
			String relative = hash.substring(0, 2) + "/" + hash;
			objects.add(new Downloader.Item(ASSETS_URL + relative, store.resolve("assets").resolve("objects").resolve(relative),
				hash, object.get("size").getAsLong(), "assets/objects/" + relative));
		}
		listener.update("Checking game assets...", 0.30);
		downloader.fetchAll(objects, false, (done, total, current) ->
			listener.update("Downloading game assets (" + (done >> 20) + " / " + (total >> 20) + " MB)...", 0.30 + 0.4 * fraction(done, total)));

		// Java
		Path java = installRuntime(vanilla, listener, verify);

		// Natives: LWJGL can load them from the classpath, but extract them too for anything using java.library.path
		listener.update("Preparing native libraries...", 0.95);
		Path nativesDir = store.resolve("natives").resolve(versionId);
		extractNatives(nativeJars, nativesDir.resolve("java"));

		return new LaunchPlan(java, classpath, fabric.get("mainClass").getAsString(), versionId,
			vanilla.has("type") ? vanilla.get("type").getAsString() : "release", vanilla, fabric,
			store.resolve("assets"), indexId, nativesDir, loggingConfig);
	}

	private JsonObject vanillaVersion(String mc) throws IOException, InterruptedException {
		Path file = store.resolve("versions").resolve(mc).resolve(mc + ".json");
		JsonObject manifest = JsonParser.parseString(Downloader.text(VERSION_MANIFEST)).getAsJsonObject();
		for (JsonElement element : manifest.getAsJsonArray("versions")) {
			JsonObject version = element.getAsJsonObject();
			if (version.get("id").getAsString().equals(mc)) {
				downloader.fetchAll(List.of(new Downloader.Item(version.get("url").getAsString(), file,
					version.get("sha1").getAsString(), -1, "versions/" + mc + "/" + mc + ".json")), true, (d, t, c) -> { });
				return JsonParser.parseString(Files.readString(file, StandardCharsets.UTF_8)).getAsJsonObject();
			}
		}
		throw new IOException("Minecraft " + mc + " isn't in Mojang's version list");
	}

	private JsonObject fabricProfile() throws IOException, InterruptedException {
		String id = pack.fabricProfileId();
		Path file = store.resolve("versions").resolve(id).resolve(id + ".json");
		if (!Files.isRegularFile(file)) {
			String url = "https://meta.fabricmc.net/v2/versions/loader/" + pack.minecraft() + "/" + pack.fabricLoader() + "/profile/json";
			Files.createDirectories(file.getParent());
			Files.writeString(file, Downloader.text(url), StandardCharsets.UTF_8);
		}
		return JsonParser.parseString(Files.readString(file, StandardCharsets.UTF_8)).getAsJsonObject();
	}

	private void addFabricLibrary(JsonObject library, Map<String, Downloader.Item> libraries) throws IOException, InterruptedException {
		String name = library.get("name").getAsString();
		String path = mavenPath(name);
		String url = library.get("url").getAsString() + path;
		// Fabric's own loader entry comes without hashes; Maven publishes one next to the jar
		String sha1 = library.has("sha1") ? library.get("sha1").getAsString() : Downloader.text(url + ".sha1").trim();
		long size = library.has("size") ? library.get("size").getAsLong() : -1;
		libraries.put(dedupeKey(name), new Downloader.Item(url, store.resolve("libraries").resolve(path), sha1, size, "libraries/" + path));
	}

	private void addVanillaLibrary(JsonObject library, Map<String, Downloader.Item> libraries, List<Path> nativeJars) {
		if (!Rules.allowed(library.getAsJsonArray("rules"))) {
			return;
		}
		String name = library.get("name").getAsString();
		String classifier = classifier(name);
		if (classifier != null && classifier.startsWith("natives-") && !classifier.equals(Rules.nativesClassifier())) {
			// e.g. skip natives-windows-arm64 on an x64 PC
			return;
		}
		JsonObject artifact = library.getAsJsonObject("downloads").getAsJsonObject("artifact");
		String path = artifact.get("path").getAsString();
		Path target = store.resolve("libraries").resolve(path);
		// A library Fabric already provides (e.g. ASM) keeps Fabric's version
		libraries.putIfAbsent(dedupeKey(name), new Downloader.Item(artifact.get("url").getAsString(), target,
			artifact.get("sha1").getAsString(), artifact.get("size").getAsLong(), "libraries/" + path));
		if (classifier != null && classifier.startsWith("natives-")) {
			nativeJars.add(target);
		}
	}

	private Path installRuntime(JsonObject vanilla, Installer.Listener listener, boolean verify) throws IOException, InterruptedException {
		String component = vanilla.getAsJsonObject("javaVersion").get("component").getAsString();
		String platform = Rules.runtimePlatform();
		JsonArray entries = JsonParser.parseString(Downloader.text(RUNTIME_MANIFEST)).getAsJsonObject()
			.getAsJsonObject(platform).getAsJsonArray(component);
		if (entries == null || entries.isEmpty()) {
			throw new IOException("Mojang has no " + component + " Java runtime for " + platform);
		}
		JsonObject manifestRef = entries.get(0).getAsJsonObject().getAsJsonObject("manifest");
		JsonObject manifest = JsonParser.parseString(Downloader.text(manifestRef.get("url").getAsString())).getAsJsonObject();
		Path root = store.resolve("runtime").resolve(component);
		List<Downloader.Item> files = new ArrayList<>();
		List<Path> executables = new ArrayList<>();
		for (Map.Entry<String, JsonElement> entry : manifest.getAsJsonObject("files").entrySet()) {
			JsonObject file = entry.getValue().getAsJsonObject();
			Path target = root.resolve(entry.getKey());
			switch (file.get("type").getAsString()) {
				case "directory" -> Files.createDirectories(target);
				case "file" -> {
					JsonObject raw = file.getAsJsonObject("downloads").getAsJsonObject("raw");
					files.add(new Downloader.Item(raw.get("url").getAsString(), target, raw.get("sha1").getAsString(),
						raw.get("size").getAsLong(), component + "/" + entry.getKey()));
					if (file.has("executable") && file.get("executable").getAsBoolean()) {
						executables.add(target);
					}
				}
				default -> {
					// Symlinks only appear in the macOS/Linux runtimes
				}
			}
		}
		// Seeds for the runtime are the official launcher's runtime folders, laid out as <component>/<platform>/<component>/...
		listener.update("Checking Java " + vanilla.getAsJsonObject("javaVersion").get("majorVersion").getAsInt() + "...", 0.72);
		new Downloader(runtimeSeeds(component, platform)).fetchAll(files, verify, (done, total, current) ->
			listener.update("Downloading Java (" + (done >> 20) + " / " + (total >> 20) + " MB)...", 0.72 + 0.22 * fraction(done, total)));
		for (Path executable : executables) {
			executable.toFile().setExecutable(true);
		}
		Path java = root.resolve(Rules.isWindows() ? "bin/javaw.exe" : "bin/java");
		if (!Files.isRegularFile(java)) {
			throw new IOException("The Java runtime didn't install correctly (missing " + java + ")");
		}
		return java;
	}

	private List<Path> runtimeSeeds(String component, String platform) {
		List<Path> result = new ArrayList<>();
		for (Path seed : seeds) {
			// runtimeSeeds look up "<component>/<file>", so point at the folder that contains <component>/
			result.add(seed.resolve("runtime").resolve(component).resolve(platform));
		}
		String local = System.getenv("LOCALAPPDATA");
		if (local != null) {
			result.add(Path.of(local, "Packages", "Microsoft.4297127D64EC6_8wekyb3d8bbwe", "LocalCache", "Local", "runtime", component, platform));
		}
		return result;
	}

	private static void extractNatives(List<Path> jars, Path dir) throws IOException {
		Files.createDirectories(dir);
		for (Path jar : jars) {
			try (ZipInputStream zip = new ZipInputStream(Files.newInputStream(jar))) {
				ZipEntry entry;
				while ((entry = zip.getNextEntry()) != null) {
					String name = entry.getName();
					if (entry.isDirectory() || name.startsWith("META-INF/")) {
						continue;
					}
					String lower = name.toLowerCase(Locale.ROOT);
					if (lower.endsWith(".dll") || lower.endsWith(".so") || lower.endsWith(".dylib")) {
						Path target = dir.resolve(name.substring(name.lastIndexOf('/') + 1));
						if (!Files.exists(target)) {
							copy(zip, target);
						}
					}
				}
			}
		}
	}

	private static void copy(InputStream in, Path target) throws IOException {
		Path part = target.resolveSibling(target.getFileName() + ".part");
		Files.copy(in, part, StandardCopyOption.REPLACE_EXISTING);
		Files.move(part, target, StandardCopyOption.REPLACE_EXISTING);
	}

	/** "group:artifact:version[:classifier]" -> "group/path/artifact/version/artifact-version[-classifier].jar" */
	static String mavenPath(String name) {
		String[] parts = name.split(":");
		String file = parts[1] + "-" + parts[2] + (parts.length > 3 ? "-" + parts[3] : "") + ".jar";
		return parts[0].replace('.', '/') + "/" + parts[1] + "/" + parts[2] + "/" + file;
	}

	private static String classifier(String name) {
		String[] parts = name.split(":");
		return parts.length > 3 ? parts[3] : null;
	}

	private static String dedupeKey(String name) {
		String[] parts = name.split(":");
		return parts[0] + ":" + parts[1] + (parts.length > 3 ? ":" + parts[3] : "");
	}

	private static double fraction(long done, long total) {
		return total <= 0 ? 1.0 : Math.min(1.0, done / (double) total);
	}
}
