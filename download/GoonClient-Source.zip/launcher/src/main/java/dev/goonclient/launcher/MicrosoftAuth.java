package dev.goonclient.launcher;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Map;
import java.util.Properties;
import java.util.function.BooleanSupplier;
import java.util.stream.Collectors;

/**
 * Microsoft sign-in for Minecraft: device code flow (you type a code on microsoft.com/link, so this app never sees
 * your password), then Xbox Live, XSTS and Minecraft services.
 *
 * Needs the Application (client) ID of an Azure app that Mojang has approved for the Minecraft API,
 * set as ms_client_id in gradle.properties. Without it, sign-in is off and Play uses the official launcher.
 */
final class MicrosoftAuth {
	private static final String MS = "https://login.microsoftonline.com/consumers/oauth2/v2.0/";
	// Xbox-only scopes: generic offline_access can cause Microsoft consent to target the wrong resource.
	private static final String SCOPE = "XboxLive.SignIn XboxLive.offline_access";

	record DeviceCode(String userCode, String verificationUri, String deviceCode, int interval, long expiresAt) {
		/** microsoft.com/link with the code filled in. */
		String linkWithCode() {
			return verificationUri + (verificationUri.contains("?") ? "&" : "?") + "otc=" + userCode;
		}
	}

	/** A signed-in Minecraft account. The refresh token lets us sign in again without asking. */
	record Account(String name, String uuid, String skinUrl, String minecraftToken, long minecraftExpiresAt, String refreshToken) {
		boolean tokenValid() {
			return minecraftToken != null && System.currentTimeMillis() < minecraftExpiresAt - 60_000;
		}
	}

	static final class AuthException extends IOException {
		AuthException(String message) {
			super(message);
		}
	}

	private final String clientId;

	private MicrosoftAuth(String clientId) {
		this.clientId = clientId;
	}

	/** Only for rendering screenshots of the sign-in UI; it can't sign anyone in. */
	static MicrosoftAuth demo() {
		return new MicrosoftAuth("demo");
	}

	/** The configured sign-in, or null if this build has no approved client ID. */
	static MicrosoftAuth configured() {
		try (InputStream in = MicrosoftAuth.class.getResourceAsStream("/auth.properties")) {
			if (in == null) {
				return null;
			}
			Properties properties = new Properties();
			properties.load(in);
			String id = properties.getProperty("client_id", "").trim();
			return id.isEmpty() ? null : new MicrosoftAuth(id);
		} catch (IOException e) {
			return null;
		}
	}

	DeviceCode startDeviceCode() throws IOException, InterruptedException {
		JsonObject response = postForm(MS + "devicecode", Map.of("client_id", clientId, "scope", SCOPE));
		if (response.has("error")) {
			throw new AuthException("Microsoft refused to start sign-in: " + describe(response));
		}
		return new DeviceCode(
			response.get("user_code").getAsString(),
			response.get("verification_uri").getAsString(),
			response.get("device_code").getAsString(),
			response.has("interval") ? response.get("interval").getAsInt() : 5,
			System.currentTimeMillis() + response.get("expires_in").getAsLong() * 1000);
	}

	/** Waits until the code is entered (or expires / is cancelled), then finishes signing in to Minecraft. */
	Account waitForDeviceCode(DeviceCode code, BooleanSupplier cancelled) throws IOException, InterruptedException {
		int interval = code.interval();
		while (System.currentTimeMillis() < code.expiresAt()) {
			Thread.sleep(interval * 1000L);
			if (cancelled.getAsBoolean()) {
				throw new AuthException("Sign-in cancelled");
			}
			JsonObject response = postForm(MS + "token", Map.of(
				"grant_type", "urn:ietf:params:oauth:grant-type:device_code",
				"client_id", clientId,
				"device_code", code.deviceCode()));
			if (!response.has("error")) {
				return minecraftLogin(response.get("access_token").getAsString(), response.get("refresh_token").getAsString());
			}
			switch (response.get("error").getAsString()) {
				case "authorization_pending" -> {
				}
				case "slow_down" -> interval += 5;
				case "authorization_declined" -> throw new AuthException("Sign-in was declined");
				case "expired_token" -> throw new AuthException("The code expired. Try again.");
				default -> throw new AuthException("Sign-in failed: " + describe(response));
			}
		}
		throw new AuthException("The code expired. Try again.");
	}

	/** Gets a fresh Minecraft token from the saved refresh token, without asking the player again. */
	Account refresh(Account account) throws IOException, InterruptedException {
		JsonObject response = postForm(MS + "token", Map.of(
			"grant_type", "refresh_token",
			"client_id", clientId,
			"refresh_token", account.refreshToken(),
			"scope", SCOPE));
		if (response.has("error")) {
			throw new AuthException("Please sign in again (" + describe(response) + ")");
		}
		return minecraftLogin(response.get("access_token").getAsString(), response.get("refresh_token").getAsString());
	}

	private Account minecraftLogin(String microsoftToken, String refreshToken) throws IOException, InterruptedException {
		// Xbox Live
		JsonObject xbl = postJson("https://user.auth.xboxlive.com/user/authenticate", """
			{"Properties":{"AuthMethod":"RPS","SiteName":"user.auth.xboxlive.com","RpsTicket":"d=%s"},
			 "RelyingParty":"http://auth.xboxlive.com","TokenType":"JWT"}""".formatted(microsoftToken), null);
		String xblToken = xbl.get("Token").getAsString();
		String userHash = xbl.getAsJsonObject("DisplayClaims").getAsJsonArray("xui").get(0).getAsJsonObject().get("uhs").getAsString();

		// XSTS for Minecraft services
		HttpResponse<String> xstsResponse = send(jsonRequest("https://xsts.auth.xboxlive.com/xsts/authorize", """
			{"Properties":{"SandboxId":"RETAIL","UserTokens":["%s"]},
			 "RelyingParty":"rp://api.minecraftservices.com/","TokenType":"JWT"}""".formatted(xblToken), null));
		if (xstsResponse.statusCode() == 401) {
			JsonObject error = JsonParser.parseString(xstsResponse.body()).getAsJsonObject();
			long code = error.has("XErr") ? error.get("XErr").getAsLong() : 0;
			throw new AuthException(switch ((int) (code - 2148916000L)) {
				case 233 -> "This Microsoft account has no Xbox profile yet. Sign in once at xbox.com, then try again.";
				case 235 -> "Xbox Live isn't available in your account's country.";
				case 236, 237 -> "This account needs adult verification on xbox.com first.";
				case 238 -> "This is a child account. An adult needs to add it to a Microsoft family first.";
				default -> "Xbox sign-in failed (" + code + ")";
			});
		}
		JsonObject xsts = parse(xstsResponse, "Xbox sign-in");
		String xstsToken = xsts.get("Token").getAsString();

		// Minecraft
		HttpResponse<String> mcResponse = send(jsonRequest("https://api.minecraftservices.com/authentication/login_with_xbox",
			"{\"identityToken\":\"XBL3.0 x=" + userHash + ";" + xstsToken + "\"}", null));
		if (mcResponse.statusCode() == 403) {
			throw new AuthException("Minecraft rejected this sign-in (403). Check this app's Minecraft API access and try signing in again. "
				+ "Use 'Launch through the Minecraft Launcher' in Settings until it is.");
		}
		JsonObject mc = parse(mcResponse, "Minecraft sign-in");
		String minecraftToken = mc.get("access_token").getAsString();
		long expiresAt = System.currentTimeMillis() + mc.get("expires_in").getAsLong() * 1000;

		HttpResponse<String> profileResponse = send(HttpRequest.newBuilder(URI.create("https://api.minecraftservices.com/minecraft/profile"))
			.header("Authorization", "Bearer " + minecraftToken)
			.timeout(Duration.ofSeconds(30)).GET().build());
		if (profileResponse.statusCode() == 404) {
			throw new AuthException("This Microsoft account doesn't own Minecraft: Java Edition.");
		}
		JsonObject profile = parse(profileResponse, "Minecraft profile");
		String skin = null;
		JsonArray skins = profile.getAsJsonArray("skins");
		if (skins != null && !skins.isEmpty()) {
			skin = skins.get(0).getAsJsonObject().get("url").getAsString();
		}
		return new Account(profile.get("name").getAsString(), profile.get("id").getAsString(), skin, minecraftToken, expiresAt, refreshToken);
	}

	// ---- HTTP helpers --------------------------------------------------------------------------------------

	private static JsonObject postForm(String url, Map<String, String> form) throws IOException, InterruptedException {
		String body = form.entrySet().stream()
			.map(e -> URLEncoder.encode(e.getKey(), StandardCharsets.UTF_8) + "=" + URLEncoder.encode(e.getValue(), StandardCharsets.UTF_8))
			.collect(Collectors.joining("&"));
		HttpResponse<String> response = send(HttpRequest.newBuilder(URI.create(url))
			.header("Content-Type", "application/x-www-form-urlencoded")
			.timeout(Duration.ofSeconds(30))
			.POST(HttpRequest.BodyPublishers.ofString(body)).build());
		return JsonParser.parseString(response.body()).getAsJsonObject();
	}

	private static JsonObject postJson(String url, String json, String bearer) throws IOException, InterruptedException {
		return parse(send(jsonRequest(url, json, bearer)), url);
	}

	private static HttpRequest jsonRequest(String url, String json, String bearer) {
		HttpRequest.Builder builder = HttpRequest.newBuilder(URI.create(url))
			.header("Content-Type", "application/json")
			.header("Accept", "application/json")
			.timeout(Duration.ofSeconds(30))
			.POST(HttpRequest.BodyPublishers.ofString(json));
		if (bearer != null) {
			builder.header("Authorization", "Bearer " + bearer);
		}
		return builder.build();
	}

	private static HttpResponse<String> send(HttpRequest request) throws IOException, InterruptedException {
		return Downloader.HTTP.send(request, HttpResponse.BodyHandlers.ofString());
	}

	private static JsonObject parse(HttpResponse<String> response, String what) throws AuthException {
		if (response.statusCode() / 100 != 2) {
			throw new AuthException(what + " failed (" + response.statusCode() + ")");
		}
		return JsonParser.parseString(response.body()).getAsJsonObject();
	}

	private static String describe(JsonObject error) {
		return error.has("error_description") ? error.get("error_description").getAsString().split("\r?\n")[0] : error.get("error").getAsString();
	}
}
