package dev.goonclient.launcher;

import java.awt.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;
import java.util.List;
import java.util.Random;

/** Original, cached vector scenery. No per-frame image processing or external artwork. */
final class LauncherArt {
    static final List<String> STYLES=List.of("Horizon","Contours","Quiet");
    private LauncherArt(){}
    static String style(String name){return STYLES.contains(name)?name:STYLES.getFirst();}
    static BufferedImage background(LauncherTheme theme,String style,int w,int h){
        var image=new BufferedImage(w,h,BufferedImage.TYPE_INT_RGB);var g=image.createGraphics();Draw.quality(g);
        g.scale(w/1000d,h/620d);Color base=theme.ground(),accent=theme.color();
        g.setPaint(new GradientPaint(0,0,Draw.mix(base,accent,.19f),1000,620,Draw.mix(base,Color.BLACK,.5f)));g.fillRect(0,0,1000,620);
        if(style.equals("Horizon")){
            g.setPaint(new RadialGradientPaint(730,155,430,new float[]{0,1},new Color[]{Draw.alpha(new Color(theme.second()),.18f),Draw.alpha(accent,0)}));g.fillRect(0,0,1000,620);
            var random=new Random(711);g.setColor(Draw.alpha(Draw.mix(accent,Color.WHITE,.7f),.45f));
            for(int i=0;i<60;i++){double x=random.nextDouble()*1000,y=random.nextDouble()*310,r=.6+random.nextDouble()*.7;g.fill(new Ellipse2D.Double(x,y,r,r));}
            g.setColor(Draw.alpha(new Color(theme.second()),.26f));g.fill(new Ellipse2D.Double(763,101,75,75));
            // Distant peaks and a low valley carry the scene behind the glass.
            ridge(g,new double[]{0,350,110,305,190,342,310,215,440,319,545,267,670,349,800,239,920,311,1000,272},Draw.mix(base,accent,.22f));
            ridge(g,new double[]{0,430,145,342,285,433,400,367,528,411,688,313,797,378,912,352,1000,404},Draw.mix(base,accent,.10f));
            ridge(g,new double[]{0,500,190,457,330,507,501,454,661,475,818,425,1000,477},Draw.mix(base,Color.BLACK,.24f));
        }else if(style.equals("Contours")){
            g.setStroke(new BasicStroke(1));
            for(int i=0;i<25;i++){
                var path=new Path2D.Double();double yy=125+i*24;path.moveTo(220,yy);
                path.curveTo(390,yy-190,510,yy+170,670,yy+10);path.curveTo(840,yy-130,890,yy+90,1080,yy-70);
                g.setColor(Draw.alpha(Draw.mix(accent,new Color(theme.second()),i/25f),.13f));g.draw(path);
            }
        }
        g.setPaint(new GradientPaint(0,0,Draw.alpha(base,.06f),0,620,Draw.alpha(base,.73f)));g.fillRect(0,0,1000,620);
        g.dispose();return image;
    }
    private static void ridge(Graphics2D g,double[] points,Color color){var p=new Path2D.Double();p.moveTo(points[0],points[1]);for(int i=2;i<points.length;i+=2)p.lineTo(points[i],points[i+1]);p.lineTo(1000,620);p.lineTo(0,620);p.closePath();g.setColor(color);g.fill(p);}
    static BufferedImage icon(Color accent){
        var image=new BufferedImage(64,64,BufferedImage.TYPE_INT_ARGB);var g=image.createGraphics();Draw.quality(g);mark(g,0,0,64,accent);g.dispose();return image;
    }
    static void mark(Graphics2D graphics,double x,double y,double size,Color accent){
        var g=(Graphics2D)graphics.create();g.translate(x,y);g.scale(size/100,size/100);
        g.setPaint(new GradientPaint(0,0,new Color(0x252C3A),0,100,new Color(0x0F1219)));g.fill(Draw.round(3,3,94,94,19));
        g.setColor(new Color(255,255,255,35));g.setStroke(new BasicStroke(1));g.draw(Draw.round(3.5,3.5,93,93,19));
        float[][] points={{31,20},{70,20},{80,30},{71,39},{65,33},{36,33},{32,37},{32,64},{37,69},{64,69},{68,65},{68,57},{49,57},{49,45},{81,45},{81,70},{69,82},{30,82},{19,71},{19,31}};
        var p=new Path2D.Float();p.moveTo(points[0][0],points[0][1]);for(int i=1;i<points.length;i++)p.lineTo(points[i][0],points[i][1]);p.closePath();g.setColor(accent);g.fill(p);g.dispose();
    }
}
