package dev.goonclient.launcher;

import com.google.gson.JsonObject;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Builds the Java command line from a LaunchPlan and starts Minecraft. */
final class GameLauncher {
	/** Who is playing. For Microsoft accounts the token comes from MicrosoftAuth. */
	record Session(String name, String uuid, String accessToken, String userType) {
	}

	private static final Pattern PLACEHOLDER = Pattern.compile("\\$\\{([a-zA-Z_]+)}");

	private GameLauncher() {
	}

	static Process launch(GameFiles.LaunchPlan plan, Session session, Path gameDir, Settings settings, String launcherVersion) throws IOException {
		Files.createDirectories(gameDir.resolve("logs"));
		Files.createDirectories(plan.nativesDir());
		String classpath = String.join(File.pathSeparator, plan.classpath().stream().map(Path::toString).toList());
		Map<String, String> values = Map.ofEntries(
			Map.entry("auth_player_name", session.name()),
			Map.entry("version_name", plan.versionId()),
			Map.entry("game_directory", gameDir.toAbsolutePath().toString()),
			Map.entry("assets_root", plan.assetsRoot().toAbsolutePath().toString()),
			Map.entry("assets_index_name", plan.assetIndex()),
			Map.entry("auth_uuid", session.uuid()),
			Map.entry("auth_access_token", session.accessToken()),
			Map.entry("clientid", ""),
			Map.entry("auth_xuid", "0"),
			Map.entry("user_type", session.userType()),
			Map.entry("version_type", plan.versionType()),
			Map.entry("natives_directory", plan.nativesDir().toAbsolutePath().toString()),
			Map.entry("launcher_name", "goonclient"),
			Map.entry("launcher_version", launcherVersion),
			Map.entry("classpath", classpath),
			Map.entry("classpath_separator", File.pathSeparator));

		List<String> jvm = new ArrayList<>();
		jvm.add("-Xmx" + settings.memoryGb + "G");
		jvm.add("-Xms" + Math.min(2, settings.memoryGb) + "G");
		// Mojang's recommended flags for this version, minus their memory sizes (we use the launcher setting)
		JsonObject vanillaArgs = plan.vanilla().getAsJsonObject("arguments");
		for (String flag : Rules.arguments(vanillaArgs.getAsJsonArray("default-user-jvm"))) {
			if (!flag.startsWith("-Xmx") && !flag.startsWith("-Xms")) {
				jvm.add(flag);
			}
		}
		jvm.addAll(Rules.arguments(vanillaArgs.getAsJsonArray("jvm")));
		JsonObject fabricArgs = plan.fabric().getAsJsonObject("arguments");
		if (fabricArgs != null) {
			jvm.addAll(Rules.arguments(fabricArgs.getAsJsonArray("jvm")));
		}
		if (plan.loggingConfig() != null) {
			jvm.add("-Dlog4j.configurationFile=" + plan.loggingConfig().toAbsolutePath());
		}

		List<String> game = new ArrayList<>(Rules.arguments(vanillaArgs.getAsJsonArray("game")));
		if (fabricArgs != null) {
			game.addAll(Rules.arguments(fabricArgs.getAsJsonArray("game")));
		}

		// JVM options + main class go through an @argfile: the classpath alone can pass Windows' command-length limit.
		// Game arguments (including the session token) stay on the command line, so the token is never written to disk.
		StringBuilder argfile = new StringBuilder();
		for (String arg : jvm) {
			argfile.append(quote(fill(arg, values))).append('\n');
		}
		argfile.append(plan.mainClass()).append('\n');
		Path argsPath = plan.nativesDir().resolve("launch-args.txt");
		Files.writeString(argsPath, argfile, StandardCharsets.UTF_8);

		List<String> command = new ArrayList<>();
		command.add(plan.java().toAbsolutePath().toString());
		command.add("@" + argsPath.toAbsolutePath());
		for (String arg : game) {
			command.add(fill(arg, values));
		}
		return new ProcessBuilder(command)
			.directory(gameDir.toFile())
			.redirectErrorStream(true)
			.redirectOutput(gameDir.resolve("logs").resolve("launcher-output.log").toFile())
			.start();
	}

	private static String fill(String arg, Map<String, String> values) {
		Matcher matcher = PLACEHOLDER.matcher(arg);
		StringBuilder out = new StringBuilder();
		while (matcher.find()) {
			String value = values.getOrDefault(matcher.group(1), matcher.group(0));
			matcher.appendReplacement(out, Matcher.quoteReplacement(value));
		}
		matcher.appendTail(out);
		return out.toString();
	}

	/** Quotes an argument for a Java @argfile (backslashes and quotes are escapes inside quotes). */
	private static String quote(String arg) {
		return "\"" + arg.replace("\\", "\\\\").replace("\"", "\\\"") + "\"";
	}
}
