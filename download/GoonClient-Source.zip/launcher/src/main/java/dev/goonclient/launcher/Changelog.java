package dev.goonclient.launcher;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** Reads the newest section of a CHANGELOG.md ("[+] added", "[-] changed/removed" lines). */
final class Changelog {
	record Entry(boolean added, String text) {
	}

	private Changelog() {
	}

	/** The launcher's own copy, bundled at build time. */
	static List<Entry> latest() {
		try (InputStream in = Changelog.class.getResourceAsStream("/CHANGELOG.md")) {
			return in == null ? new ArrayList<>() : parse(new String(in.readAllBytes(), StandardCharsets.UTF_8));
		} catch (Exception ignored) {
			// No changelog is fine
			return new ArrayList<>();
		}
	}

	/** The pack's changelog when it has one (an update brings its own), else the launcher's copy. */
	static List<Entry> forPack(PackManifest pack) {
		String text = pack.changelogText();
		List<Entry> entries = text != null ? parse(text) : List.of();
		return entries.isEmpty() ? latest() : entries;
	}

	/** The newest section of a CHANGELOG.md. */
	static List<Entry> parse(String text) {
		List<Entry> entries = new ArrayList<>();
		boolean inSection = false;
		for (String raw : text.split("\n")) {
			String line = raw.strip();
			if (line.startsWith("# ") || line.startsWith("## ")) {
				if (inSection && !entries.isEmpty()) {
					break;
				}
				inSection = true;
			} else if (line.startsWith("[+]") || line.startsWith("[-]")) {
				entries.add(new Entry(line.startsWith("[+]"), clean(line.substring(3))));
			}
		}
		return entries;
	}

	private static String clean(String text) {
		return text.replace("**", "").replace("`", "").strip();
	}
}
