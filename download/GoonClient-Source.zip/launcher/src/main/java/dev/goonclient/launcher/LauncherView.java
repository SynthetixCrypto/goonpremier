package dev.goonclient.launcher;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Desktop;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Shape;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseWheelEvent;
import java.awt.geom.Ellipse2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import javax.swing.Timer;

/** The whole launcher UI, custom-painted to match the in-game Goon Client look. */
final class LauncherView extends JComponent {
	enum Page {
		HOME("Home"), MODS("Mods"), SETTINGS("Settings");

		final String label;

		Page(String label) {
			this.label = label;
		}
	}

	private static final int SIDEBAR = 210;
	private static final int MARGIN = 14;
	private static final Map<String, String> NICE_NAMES = Map.ofEntries(
		Map.entry("Immediatelyfast", "ImmediatelyFast"),
		Map.entry("Xaerominimap", "Xaero's Minimap"),
		Map.entry("Xaeroworldmap", "Xaero's World Map"),
		Map.entry("Ferritecore", "FerriteCore"),
		Map.entry("Entityculling", "EntityCulling"),
		Map.entry("Malilib", "MaLiLib"),
		Map.entry("Modmenu", "Mod Menu"),
		Map.entry("Dynamic Fps", "Dynamic FPS"),
		Map.entry("Reeses", "Reese's"),
		Map.entry(" Api", " API"));

	private final JFrame frame;
	private volatile PackManifest pack;
	/** The launcher's own version (its bundled pack), for telling whether the website needs a newer launcher. */
	private final String launcherVersion;
	/** A downloaded update waiting for the current install or game to finish. */
	private volatile PackManifest pendingPack;
	/** Set when the newest release needs a newer launcher than this one. */
	private volatile Updater.Release launcherUpdate;
	private final Path minecraftDir;
	private final Path gameDir;
	private final Settings settings;
	private volatile Installer installer;
	private MicrosoftAuth auth;
	private final AccountStore accounts;
	private final Path store;
	private final List<Path> seeds;
	private volatile MicrosoftAuth.Account account;
	private volatile BufferedImage face;

	// Sign-in popup
	private volatile boolean loginOpen;
	private volatile boolean loginCancelled;
	private volatile MicrosoftAuth.DeviceCode loginCode;
	private volatile String loginStatus;
	private volatile boolean loginFailed;
	private volatile List<Changelog.Entry> changelog;
	private final BufferedImage backgroundSource;
	private final BufferedImage icon;
	private BufferedImage background;

	private final Map<String, Float> animations = new HashMap<>();
	private final List<Hit> hits = new ArrayList<>();
	private long lastFrame = System.nanoTime();
	private float frameSeconds;
	private Point mouse = new Point(-1, -1);
	private Point dragOffset;
	private boolean draggingMemory;
	private int memoryTrackX;
	private int memoryTrackWidth;
	private float modsScroll;
	private float modsScrollTarget;
	private int modsContentHeight;

	private Page page = Page.HOME;
	private volatile boolean busy;
	private volatile String status;
	private volatile double progress = -1;
	private volatile boolean failed;
	private volatile boolean gameRunning;

	LauncherView(JFrame frame, PackManifest pack, String launcherVersion, Path minecraftDir, Path gameDir, Settings settings,
				 BufferedImage backgroundSource, BufferedImage icon) {
		this.frame = frame;
		this.pack = pack;
		this.launcherVersion = launcherVersion;
		this.minecraftDir = minecraftDir;
		this.gameDir = gameDir;
		this.settings = settings;
		this.installer = new Installer(pack, minecraftDir, gameDir, settings);
		this.changelog = Changelog.forPack(pack);
		this.backgroundSource = backgroundSource;
		this.icon = icon;
		this.auth = MicrosoftAuth.configured();
		this.accounts = new AccountStore(gameDir);
		this.store = gameDir.resolve("game-files");
		// Reuse files the official launcher already downloaded (read only) instead of downloading them again
		this.seeds = Files.isDirectory(minecraftDir) ? List.of(minecraftDir) : List.of();
		this.account = auth != null ? accounts.load() : null;
		loadFace();
		boolean canPlay = directLaunch() || installer.minecraftLauncherFound();
		this.status = canPlay ? null : "Minecraft Launcher not found";
		this.failed = !canPlay;
		setOpaque(false);
		// No network from the screenshot demo (no frame)
		if (settings.autoUpdate && frame != null) {
			checkForUpdates();
		}

		MouseAdapter input = new MouseAdapter() {
			@Override
			public void mouseMoved(MouseEvent e) {
				mouse = e.getPoint();
				boolean overHit = hits.stream().anyMatch(h -> h.contains(e.getX(), e.getY()));
				setCursor(Cursor.getPredefinedCursor(overHit ? Cursor.HAND_CURSOR : Cursor.DEFAULT_CURSOR));
			}

			@Override
			public void mouseExited(MouseEvent e) {
				mouse = new Point(-1, -1);
			}

			@Override
			public void mousePressed(MouseEvent e) {
				if (!SwingUtilities.isLeftMouseButton(e)) {
					return;
				}
				for (int i = hits.size() - 1; i >= 0; i--) {
					Hit hit = hits.get(i);
					if (hit.contains(e.getX(), e.getY())) {
						hit.action.run();
						return;
					}
				}
				if (e.getY() < 46 && frame != null) {
					dragOffset = e.getPoint();
				}
			}

			@Override
			public void mouseDragged(MouseEvent e) {
				mouse = e.getPoint();
				if (draggingMemory) {
					setMemoryFromMouse(e.getX());
				} else if (dragOffset != null && frame != null) {
					Point screen = e.getLocationOnScreen();
					frame.setLocation(screen.x - dragOffset.x, screen.y - dragOffset.y);
				}
			}

			@Override
			public void mouseReleased(MouseEvent e) {
				if (draggingMemory) {
					draggingMemory = false;
					settings.save(gameDir);
				}
				dragOffset = null;
			}

			@Override
			public void mouseWheelMoved(MouseWheelEvent e) {
				if (page == Page.MODS) {
					modsScrollTarget += (float) e.getPreciseWheelRotation() * 40f;
				}
			}
		};
		addMouseListener(input);
		addMouseMotionListener(input);
		addMouseWheelListener(input);
		new Timer(16, e -> repaint()).start();
	}

	// ---- Painting ------------------------------------------------------------------------------------------

	@Override
	protected void paintComponent(Graphics graphics) {
		long now = System.nanoTime();
		frameSeconds = Math.min(0.1f, (now - lastFrame) / 1_000_000_000f);
		lastFrame = now;
		hits.clear();

		Graphics2D g = (Graphics2D) graphics.create();
		Draw.quality(g);
		int w = getWidth();
		int h = getHeight();
		g.setClip(Draw.round(0, 0, w, h, 18));

		drawBackground(g, w, h);
		drawSidebar(g, h);
		switch (page) {
			case HOME -> drawHome(g, w, h);
			case MODS -> drawMods(g, w, h);
			case SETTINGS -> drawSettings(g, w, h);
		}
		drawWindowButtons(g, w);
		if (loginOpen) {
			drawLogin(g, w, h);
		}
		g.dispose();
	}

	private void drawBackground(Graphics2D g, int w, int h) {
		if (background == null || background.getWidth() != w || background.getHeight() != h) {
			background = coverAndBlur(backgroundSource, w, h);
		}
		g.drawImage(background, 0, 0, null);
		g.setPaint(new GradientPaint(0, 0, new Color(8, 9, 12, 110), 0, h, new Color(8, 9, 12, 215)));
		g.fillRect(0, 0, w, h);
		g.setPaint(new GradientPaint(0, 0, new Color(8, 9, 12, 130), w * 0.45f, 0, new Color(8, 9, 12, 0)));
		g.fillRect(0, 0, w, h);
		// A soft accent bloom in the top right, as on the website
		g.setPaint(new java.awt.RadialGradientPaint(w * 0.82f, -h * 0.1f, h * 0.9f, new float[]{0f, 1f},
			new Color[]{Draw.alpha(Draw.ACCENT, 0.22f), Draw.alpha(Draw.ACCENT, 0f)}));
		g.fillRect(0, 0, w, h);
	}

	private static BufferedImage coverAndBlur(BufferedImage source, int w, int h) {
		BufferedImage scaled = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
		Graphics2D g = scaled.createGraphics();
		Draw.quality(g);
		if (source != null) {
			double scale = Math.max(w / (double) source.getWidth(), h / (double) source.getHeight());
			int sw = (int) Math.ceil(source.getWidth() * scale);
			int sh = (int) Math.ceil(source.getHeight() * scale);
			g.drawImage(source, (w - sw) / 2, (h - sh) / 2, sw, sh, null);
		} else {
			g.setPaint(new GradientPaint(0, 0, new Color(0x141518), w, h, new Color(0x0F1012)));
			g.fillRect(0, 0, w, h);
		}
		g.dispose();
		return Draw.blur(scaled, 14);
	}

	private void drawSidebar(Graphics2D g, int h) {
		Draw.glass(g, MARGIN, MARGIN, SIDEBAR - MARGIN, h - MARGIN * 2, 16, 0.62f);
		if (icon != null) {
			g.drawImage(icon, MARGIN + 16, MARGIN + 18, 34, 34, null);
		}
		Draw.wordmark(g, Draw.bold(16f), MARGIN + 58, MARGIN + 36, 1f);
		Draw.text(g, "Launcher", Draw.regular(11.5f), Draw.MUTED, MARGIN + 58, MARGIN + 52);

		int y = MARGIN + 92;
		for (Page p : Page.values()) {
			int x1 = MARGIN + 10;
			int x2 = SIDEBAR - 10;
			boolean selected = p == page;
			boolean hover = inside(x1, y, x2, y + 38);
			float highlight = animate("nav:" + p, selected ? 1f : hover ? 0.5f : 0f);
			if (highlight > 0.01f) {
				g.setColor(Draw.alpha(Color.WHITE, (selected ? 0.08f : 0.05f) * highlight));
				g.fill(Draw.round(x1, y, x2 - x1, 38, 11));
			}
			if (selected) {
				g.setColor(Draw.ACCENT);
				g.fill(Draw.round(x1, y + 11, 3, 16, 1.5));
			}
			Color color = selected ? Draw.TEXT : Draw.mix(Draw.MUTED, Draw.TEXT, highlight);
			Draw.text(g, p.label, selected ? Draw.bold(14f) : Draw.regular(14f), color, x1 + 18, y + 24);
			hits.add(new Hit(x1, y, x2, y + 38, () -> page = p));
			y += 44;
		}

		drawAccount(g, h);
		Draw.text(g, "Goon Client " + pack.version(), Draw.bold(11.5f), Draw.TEXT, MARGIN + 18, h - MARGIN - 34);
		Draw.text(g, "Minecraft " + pack.minecraft() + "  •  Fabric", Draw.regular(11f), Draw.MUTED, MARGIN + 18, h - MARGIN - 18);
	}

	private void drawWindowButtons(Graphics2D g, int w) {
		int cy = 30;
		drawWindowButton(g, w - 32, cy, "close", Draw.BAD, () -> System.exit(0));
		drawWindowButton(g, w - 60, cy, "min", Draw.MUTED, () -> {
			if (frame != null) {
				frame.setState(JFrame.ICONIFIED);
			}
		});
	}

	private void drawWindowButton(Graphics2D g, int cx, int cy, String key, Color hoverColor, Runnable action) {
		boolean hover = inside(cx - 11, cy - 11, cx + 11, cy + 11);
		float h = animate("window:" + key, hover ? 1f : 0f);
		g.setColor(Draw.mix(new Color(255, 255, 255, 22), Draw.alpha(hoverColor, 0.9f), h));
		g.fill(new Ellipse2D.Double(cx - 11, cy - 11, 22, 22));
		g.setColor(Draw.mix(Draw.TEXT, Color.WHITE, h));
		g.setStroke(new BasicStroke(1.6f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
		if (key.equals("close")) {
			g.drawLine(cx - 4, cy - 4, cx + 4, cy + 4);
			g.drawLine(cx - 4, cy + 4, cx + 4, cy - 4);
		} else {
			g.drawLine(cx - 4, cy, cx + 4, cy);
		}
		hits.add(new Hit(cx - 11, cy - 11, cx + 11, cy + 11, action));
	}

	private void drawHome(Graphics2D g, int w, int h) {
		int x = SIDEBAR + 34;
		int cardWidth = 320;
		int cardX = w - MARGIN - cardWidth;

		Draw.text(g, "Welcome back", Draw.regular(15f), Draw.MUTED, x, 104);
		Draw.wordmark(g, Draw.bold(54f), x - 2, 162, 1f);
		Draw.text(g, "PvE client for Minecraft " + pack.minecraft(), Draw.regular(16f), new Color(0xC9CCD2), x, 192);

		int chipX = x;
		for (String chip : new String[]{pack.modCount() + " mods", "Fabric " + pack.fabricLoader(), settings.memoryGb + " GB RAM"}) {
			chipX += drawChip(g, chip, chipX, 212) + 8;
		}
		Updater.Release needed = launcherUpdate;
		if (needed != null) {
			drawLauncherNotice(g, needed, x, 250);
		}

		// Play button
		int bw = 300;
		int bh = 66;
		int by = h - 176;
		boolean hover = !busy && inside(x, by, x + bw, by + bh);
		float hv = animate("play", hover ? 1f : 0f);
		if (!busy) {
			Draw.glow(g, x, by, bw, bh, 18, Draw.ACCENT, 0.5f + hv * 0.7f);
		}
		Color left = busy ? Draw.CONTROL : Draw.mix(Draw.ACCENT, Draw.ACCENT.brighter(), hv);
		Color right = busy ? Draw.CONTROL : Draw.mix(Draw.ACCENT_2, Draw.ACCENT_2.brighter(), hv);
		g.setPaint(new GradientPaint(x, 0, left, x + bw, 0, right));
		g.fill(Draw.round(x, by, bw, bh, 18));
		String label = gameRunning ? "PLAYING" : busy ? "INSTALLING..." : "PLAY";
		Draw.centered(g, label, Draw.bold(busy ? 18f : 24f), busy ? Draw.MUTED : Draw.ON_ACCENT, x + bw / 2.0, by + bh / 2.0);
		if (!busy) {
			hits.add(new Hit(x, by, x + bw, by + bh, this::play));
		}

		// Status + progress
		int sy = by + bh + 26;
		String line = status != null ? status : installedSummary();
		Color statusColor = failed ? Draw.BAD : busy ? Draw.TEXT : Draw.MUTED;
		Draw.text(g, ellipsize(g, line, Draw.regular(13f), cardX - x - 30), Draw.regular(13f), statusColor, x, sy);
		if (progress >= 0) {
			int pw = Math.min(460, cardX - x - 30);
			g.setColor(new Color(255, 255, 255, 28));
			g.fill(Draw.round(x, sy + 12, pw, 6, 3));
			float shown = animate("progress", (float) progress);
			g.setPaint(new GradientPaint(x, 0, Draw.ACCENT, x + pw, 0, Draw.ACCENT_2));
			g.fill(Draw.round(x, sy + 12, Math.max(6, pw * shown), 6, 3));
		}

		drawChangelogCard(g, cardX, 70, cardWidth, h - 70 - MARGIN - 10);
	}

	private int drawChip(Graphics2D g, String text, int x, int y) {
		Font font = Draw.regular(12f);
		int w = Draw.width(g, text, font) + 20;
		Draw.glass(g, x, y, w, 24, 12, 0.55f);
		Draw.text(g, text, font, new Color(0xC9CCD2), x + 10, y + 16);
		return w;
	}

	/** "Goon Client X needs a new launcher" with a link to the download page. */
	private void drawLauncherNotice(Graphics2D g, Updater.Release release, int x, int y) {
		String text = "Goon Client " + release.version() + " needs a new launcher.";
		String link = "Download it";
		Font font = Draw.regular(12.5f);
		Font bold = Draw.bold(12.5f);
		int textWidth = Draw.width(g, text, font);
		int linkWidth = Draw.width(g, link, bold);
		int w = 14 + textWidth + 8 + linkWidth + 14;
		boolean hover = inside(x, y, x + w, y + 28);
		Draw.glass(g, x, y, w, 28, 14, 0.55f);
		g.setColor(Draw.alpha(Draw.WARN, 0.9f));
		g.fill(new Ellipse2D.Double(x + 6, y + 11, 5, 5));
		Draw.text(g, text, font, new Color(0xC9CCD2), x + 16, y + 18);
		Draw.text(g, link, bold, hover ? Draw.TEXT : Draw.ACCENT, x + 16 + textWidth + 8, y + 18);
		if (release.page() != null) {
			hits.add(new Hit(x, y, x + w, y + 28, () -> {
				try {
					Desktop.getDesktop().browse(release.page());
				} catch (IOException | RuntimeException ignored) {
					// No browser: nothing more we can do from here
				}
			}));
		}
	}

	private void drawChangelogCard(Graphics2D g, int x, int y, int w, int h) {
		Draw.glass(g, x, y, w, h, 16, 0.62f);
		Draw.text(g, "What's new", Draw.bold(16f), Draw.TEXT, x + 20, y + 34);
		Draw.text(g, "Goon Client " + pack.version(), Draw.regular(12f), Draw.MUTED, x + 20, y + 52);
		int ty = y + 80;
		Font font = Draw.regular(12.5f);
		FontMetrics metrics = g.getFontMetrics(font);
		for (Changelog.Entry entry : changelog) {
			List<String> lines = wrap(entry.text(), metrics, w - 72);
			if (ty + lines.size() * 17 > y + h - 14) {
				Draw.text(g, "...and more on Discord", Draw.regular(12f), Draw.MUTED, x + 20, ty + 4);
				break;
			}
			Color badge = entry.added() ? Draw.GOOD : Draw.WARN;
			g.setColor(Draw.alpha(badge, 0.18f));
			g.fill(Draw.round(x + 20, ty - 12, 22, 16, 5));
			Draw.centered(g, entry.added() ? "+" : "−", Draw.bold(12f), badge, x + 31, ty - 4);
			for (String text : lines) {
				Draw.text(g, text, font, new Color(0xD5D7DC), x + 52, ty);
				ty += 17;
			}
			ty += 7;
		}
	}

	private void drawMods(Graphics2D g, int w, int h) {
		int x = SIDEBAR + 34;
		int right = w - MARGIN - 20;
		Draw.text(g, "Mods", Draw.bold(30f), Draw.TEXT, x, 92);
		Draw.text(g, pack.modCount() + (pack.bundled().isEmpty() ? " mods, checked against published SHA-512 hashes" : " mods built into one Goon Client jar. Manage features in game."),
			Draw.regular(13f), Draw.MUTED, x, 116);

		int top = 140;
		int bottom = h - MARGIN - 10;
		modsScrollTarget = Math.max(0, Math.min(Math.max(0, modsContentHeight - (bottom - top)), modsScrollTarget));
		modsScroll += (modsScrollTarget - modsScroll) * Math.min(1f, frameSeconds * 14f);

		Shape oldClip = g.getClip();
		g.clip(Draw.round(x - 6, top, right - x + 12, bottom - top, 0));
		int columnWidth = (right - x - 12) / 2;
		List<PackManifest.PackFile> files = pack.bundled().isEmpty() ? pack.files() : pack.bundled();
		int rowHeight = 52;
		int i = 0;
		// One file check per paint: bundled mods live inside the client jar, so they share its state
		boolean goonclientInstalled = Files.exists(gameDir.resolve(pack.clientJarPath()));
		for (PackManifest.PackFile file : files) {
			int cx = x + (i % 2) * (columnWidth + 12);
			int cy = top + (i / 2) * (rowHeight + 10) - Math.round(modsScroll);
			drawModRow(g, file.fileName(), pack.bundled().isEmpty() ? installer.isInstalled(file) : goonclientInstalled, cx, cy, columnWidth, rowHeight);
			i++;
		}
		// Goon Client itself
		int cx = x + (i % 2) * (columnWidth + 12);
		int cy = top + (i / 2) * (rowHeight + 10) - Math.round(modsScroll);
		drawModRow(g, "goonclient-" + pack.version() + ".jar", goonclientInstalled, cx, cy, columnWidth, rowHeight);
		i++;
		modsContentHeight = ((i + 1) / 2) * (rowHeight + 10);
		g.setClip(oldClip);
	}

	private void drawModRow(Graphics2D g, String fileName, boolean installed, int x, int y, int w, int h) {
		String base = fileName.endsWith(".jar") ? fileName.substring(0, fileName.length() - 4) : fileName;
		int split = firstVersionIndex(base);
		String name = prettify(split > 0 ? base.substring(0, split) : base);
		String version = split > 0 ? base.substring(split + 1) : "";
		Draw.glass(g, x, y, w, h, 12, 0.6f);
		Draw.text(g, ellipsize(g, name, Draw.bold(13.5f), w - 120), Draw.bold(13.5f), Draw.TEXT, x + 16, y + 22);
		Draw.text(g, ellipsize(g, version, Draw.regular(11.5f), w - 120), Draw.regular(11.5f), Draw.MUTED, x + 16, y + 39);
		String state = installed ? "Installed" : "Not installed";
		Color color = installed ? Draw.GOOD : Draw.MUTED;
		Font font = Draw.regular(11.5f);
		int sw = Draw.width(g, state, font);
		g.setColor(Draw.alpha(color, 0.14f));
		g.fill(Draw.round(x + w - sw - 40, y + h / 2.0 - 11, sw + 26, 22, 11));
		g.setColor(color);
		g.fill(new Ellipse2D.Double(x + w - sw - 32, y + h / 2.0 - 3, 6, 6));
		Draw.text(g, state, font, color, x + w - sw - 22, y + h / 2f + 4);
	}

	private void drawSettings(Graphics2D g, int w, int h) {
		int x = SIDEBAR + 34;
		int right = w - MARGIN - 20;
		Draw.text(g, "Settings", Draw.bold(30f), Draw.TEXT, x, 92);
		Draw.text(g, "Saved automatically", Draw.regular(13f), Draw.MUTED, x, 116);

		int y = 140;
		// Memory
		settingRow(g, x, y, right, "Memory", "RAM Minecraft can use. 4-6 GB is plenty for this pack.");
		int trackWidth = 220;
		int trackX = right - 24 - trackWidth - 70;
		int trackY = y + 34;
		memoryTrackX = trackX;
		memoryTrackWidth = trackWidth;
		float fraction = (settings.memoryGb - 2) / 14f;
		g.setColor(new Color(255, 255, 255, 30));
		g.fill(Draw.round(trackX, trackY - 2, trackWidth, 5, 2.5));
		g.setPaint(new GradientPaint(trackX, 0, Draw.ACCENT, trackX + trackWidth, 0, Draw.ACCENT_2));
		g.fill(Draw.round(trackX, trackY - 2, Math.max(5, trackWidth * fraction), 5, 2.5));
		int knob = trackX + Math.round(trackWidth * fraction);
		g.setColor(Color.WHITE);
		g.fill(new Ellipse2D.Double(knob - 8, trackY - 8, 16, 16));
		String value = settings.memoryGb + " GB";
		g.setColor(Draw.CONTROL);
		g.fill(Draw.round(right - 24 - 56, trackY - 12, 56, 24, 8));
		Draw.centered(g, value, Draw.bold(13f), Draw.TEXT, right - 24 - 28, trackY);
		hits.add(new Hit(trackX - 10, trackY - 14, trackX + trackWidth + 10, trackY + 14, () -> {
			draggingMemory = true;
			setMemoryFromMouse(mouse.x);
		}));
		y += 74;

		settingRow(g, x, y, right, "Close after starting", "Close this launcher once the game (or the Minecraft Launcher) starts.");
		toggle(g, "close", settings.closeAfterLaunch, right - 24 - 46, y + 22, true, () -> {
			settings.closeAfterLaunch = !settings.closeAfterLaunch;
			settings.save(gameDir);
		});
		y += 74;

		boolean found = installer.minecraftLauncherFound();
		String handoff = auth == null
			? "Microsoft sign-in isn't set up in this build, so Play goes through the official launcher."
			: found ? "Sign in and start through the official launcher instead of directly." : "Official Minecraft Launcher not found.";
		settingRow(g, x, y, right, "Use the official Minecraft Launcher", handoff);
		toggle(g, "official", !directLaunch(), right - 24 - 46, y + 22, auth != null, () -> {
			settings.useOfficialLauncher = !settings.useOfficialLauncher;
			settings.save(gameDir);
		});
		y += 74;

		settingRow(g, x, y, right, "Automatic updates", "Get new Goon Client versions from goonnation.xyz when the launcher starts.");
		toggle(g, "autoupdate", settings.autoUpdate, right - 24 - 46, y + 22, true, () -> {
			settings.autoUpdate = !settings.autoUpdate;
			settings.save(gameDir);
			if (settings.autoUpdate) {
				checkForUpdates();
			}
		});
		y += 74;

		settingRow(g, x, y, right, "Game folder", ellipsize(g, gameDir.toString(), Draw.regular(12.5f), right - x - 170));
		button(g, "Open", right - 24 - 76, y + 20, 76, () -> openFolder(gameDir));
		y += 74;

		// Repair
		settingRow(g, x, y, right, "Repair installation", "Re-checks every file against its checksum and re-downloads anything wrong.");
		if (!busy) {
			button(g, "Repair", right - 24 - 86, y + 20, 86, () -> {
				page = Page.HOME;
				start(true);
			});
		}
	}

	private void settingRow(Graphics2D g, int x, int y, int right, String title, String description) {
		Draw.glass(g, x, y, right - x, 68, 14, 0.6f);
		Draw.text(g, title, Draw.bold(14.5f), Draw.TEXT, x + 20, y + 28);
		// Leave room on the right for the row's control
		Draw.text(g, ellipsize(g, description, Draw.regular(12.5f), right - x - 150), Draw.regular(12.5f), Draw.MUTED, x + 20, y + 48);
	}

	private void button(Graphics2D g, String label, int x, int y, int w, Runnable action) {
		boolean hover = inside(x, y, x + w, y + 28);
		float h = animate("button:" + label, hover ? 1f : 0f);
		g.setColor(Draw.mix(Draw.CONTROL, Draw.ACCENT, h));
		g.fill(Draw.round(x, y, w, 28, 9));
		Draw.centered(g, label, Draw.bold(13f), Draw.mix(Draw.TEXT, Draw.ON_ACCENT, h), x + w / 2.0, y + 14);
		hits.add(new Hit(x, y, x + w, y + 28, action));
	}

	// ---- Actions -------------------------------------------------------------------------------------------

	/** Direct launch needs a configured Microsoft sign-in and the player not preferring the official launcher. */
	private boolean directLaunch() {
		return auth != null && !settings.useOfficialLauncher;
	}

	private void play() {
		if (directLaunch() && account == null) {
			openLogin();
			return;
		}
		start(false);
	}

	private void start(boolean repair) {
		if (busy) {
			return;
		}
		if (pendingPack != null) {
			applyUpdate(pendingPack);
		}
		busy = true;
		failed = false;
		progress = 0;
		status = repair ? "Repairing..." : "Preparing...";
		boolean direct = directLaunch();
		Thread worker = new Thread(() -> {
			try {
				if (direct) {
					launchDirectly(repair);
					return;
				}
				installer.install((text, value) -> {
					status = text;
					progress = value;
				}, repair);
				String opened = OfficialLauncher.open();
				if (opened == null) {
					status = "Installed. Open the Minecraft Launcher, pick \"Goon Client\" and press Play.";
				} else {
					status = "Minecraft Launcher opened. Pick \"Goon Client\" and press Play.";
					if (settings.closeAfterLaunch) {
						Thread.sleep(2500);
						System.exit(0);
					}
				}
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
			} catch (Exception e) {
				failed = true;
				status = e.getMessage() != null ? e.getMessage() : e.toString();
			} finally {
				busy = false;
				if (failed) {
					progress = -1;
				}
			}
		}, "Goon Client installer");
		worker.setDaemon(true);
		worker.start();
	}

	/** Installs the pack and the game, refreshes the sign-in if needed, then starts Minecraft itself. */
	private void launchDirectly(boolean repair) throws IOException, InterruptedException {
		MicrosoftAuth.Account current = account;
		if (current == null) {
			throw new IOException("Sign in with Microsoft first");
		}
		if (!current.tokenValid()) {
			status = "Signing in as " + current.name() + "...";
			current = auth.refresh(current);
			account = current;
			accounts.save(current);
		}
		installer.installPack((text, value) -> {
			status = text;
			progress = value * 0.25;
		}, repair);
		GameFiles.LaunchPlan plan = new GameFiles(pack, store, seeds).prepare((text, value) -> {
			status = text;
			progress = 0.25 + value * 0.7;
		}, repair);
		status = "Starting Goon Client...";
		progress = 0.97;
		GameLauncher.Session session = new GameLauncher.Session(current.name(), current.uuid(), current.minecraftToken(), "msa");
		Process game = GameLauncher.launch(plan, session, gameDir, settings, pack.version());
		watchGame(game);
	}

	/** Reports whether the game made it past startup, then closes the launcher if asked to. */
	private void watchGame(Process game) throws InterruptedException {
		if (game.waitFor(8, java.util.concurrent.TimeUnit.SECONDS)) {
			failed = true;
			status = "Minecraft closed right away (exit code " + game.exitValue() + "). Details: " + gameDir.resolve("logs").resolve("launcher-output.log");
			return;
		}
		progress = 1;
		gameRunning = true;
		status = "Goon Client is running. Have fun!";
		if (settings.closeAfterLaunch) {
			Thread.sleep(1500);
			System.exit(0);
		}
		int exit = game.waitFor();
		gameRunning = false;
		progress = -1;
		status = exit == 0 ? "Game closed." : "Game closed with exit code " + exit + ". Logs: " + gameDir.resolve("logs");
		failed = exit != 0;
	}

	private void openLogin() {
		if (auth == null || loginOpen) {
			return;
		}
		loginOpen = true;
		loginCancelled = false;
		loginFailed = false;
		loginCode = null;
		loginStatus = "Contacting Microsoft...";
		Thread worker = new Thread(() -> {
			try {
				MicrosoftAuth.DeviceCode code = auth.startDeviceCode();
				loginCode = code;
				loginStatus = "Waiting for you to sign in...";
				copyToClipboard(code.userCode());
				MicrosoftAuth.Account signedIn = auth.waitForDeviceCode(code, () -> loginCancelled);
				accounts.save(signedIn);
				account = signedIn;
				loadFace();
				loginOpen = false;
				status = "Signed in as " + signedIn.name() + ". Press Play!";
				failed = false;
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
			} catch (Exception e) {
				if (!loginCancelled) {
					loginFailed = true;
					loginStatus = e.getMessage() != null ? e.getMessage() : e.toString();
				}
			}
		}, "Microsoft sign-in");
		worker.setDaemon(true);
		worker.start();
	}

	private void signOut() {
		try {
			accounts.clear();
		} catch (IOException ignored) {
			// Worst case the file stays; the account is still dropped for this session
		}
		account = null;
		face = null;
		status = null;
	}

	/** Downloads the skin and keeps the 8x8 face (with the hat layer) for the account card. */
	private void loadFace() {
		MicrosoftAuth.Account current = account;
		if (current == null || current.skinUrl() == null) {
			return;
		}
		Thread loader = new Thread(() -> {
			try (var in = Downloader.HTTP.send(Downloader.request(current.skinUrl()),
				java.net.http.HttpResponse.BodyHandlers.ofInputStream()).body()) {
				BufferedImage skin = javax.imageio.ImageIO.read(in);
				BufferedImage head = new BufferedImage(8, 8, BufferedImage.TYPE_INT_ARGB);
				Graphics2D g = head.createGraphics();
				g.drawImage(skin.getSubimage(8, 8, 8, 8), 0, 0, null);
				g.drawImage(skin.getSubimage(40, 8, 8, 8), 0, 0, null);
				g.dispose();
				face = head;
			} catch (Exception ignored) {
				// The initial-letter avatar is fine
			}
		}, "Skin download");
		loader.setDaemon(true);
		loader.start();
	}

	private static void copyToClipboard(String text) {
		try {
			java.awt.Toolkit.getDefaultToolkit().getSystemClipboard().setContents(new java.awt.datatransfer.StringSelection(text), null);
		} catch (Exception ignored) {
			// Headless or clipboard busy: the code is still on screen
		}
	}

	private void drawAccount(Graphics2D g, int h) {
		int x1 = MARGIN + 10;
		int x2 = SIDEBAR - 10;
		int y = h - MARGIN - 104;
		if (auth == null) {
			Draw.text(g, "Sign-in: Minecraft Launcher", Draw.regular(11f), Draw.MUTED, x1 + 8, y + 40);
			return;
		}
		MicrosoftAuth.Account current = account;
		if (current == null) {
			boolean hover = inside(x1, y + 14, x2, y + 50);
			float hv = animate("signin", hover ? 1f : 0f);
			g.setColor(Draw.mix(Draw.alpha(Draw.ACCENT, 0.14f), Draw.alpha(Draw.ACCENT, 0.3f), hv));
			g.fill(Draw.round(x1, y + 14, x2 - x1, 36, 11));
			Draw.centered(g, "Sign in with Microsoft", Draw.bold(12.5f), Draw.ACCENT, (x1 + x2) / 2.0, y + 32);
			hits.add(new Hit(x1, y + 14, x2, y + 50, this::openLogin));
			return;
		}
		Draw.glass(g, x1, y + 6, x2 - x1, 50, 12, 0.5f);
		BufferedImage head = face;
		if (head != null) {
			var smooth = g.getRenderingHint(java.awt.RenderingHints.KEY_INTERPOLATION);
			g.setRenderingHint(java.awt.RenderingHints.KEY_INTERPOLATION, java.awt.RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);
			g.drawImage(head, x1 + 10, y + 15, 32, 32, null);
			g.setRenderingHint(java.awt.RenderingHints.KEY_INTERPOLATION, smooth);
		} else {
			g.setColor(Draw.ACCENT);
			g.fill(Draw.round(x1 + 10, y + 15, 32, 32, 8));
			Draw.centered(g, current.name().substring(0, 1).toUpperCase(Locale.ROOT), Draw.bold(15f), Draw.ON_ACCENT, x1 + 26, y + 31);
		}
		Draw.text(g, ellipsize(g, current.name(), Draw.bold(13f), x2 - x1 - 60), Draw.bold(13f), Draw.TEXT, x1 + 50, y + 28);
		boolean hover = inside(x1 + 50, y + 34, x1 + 110, y + 50);
		Draw.text(g, "Sign out", Draw.regular(11f), hover ? Draw.BAD : Draw.MUTED, x1 + 50, y + 45);
		hits.add(new Hit(x1 + 50, y + 34, x1 + 110, y + 50, this::signOut));
	}

	/** The sign-in popup: shows the code to enter on microsoft.com/link. */
	private void drawLogin(Graphics2D g, int w, int h) {
		// Everything behind the popup stops being clickable
		hits.clear();
		g.setColor(new Color(0, 0, 0, 150));
		g.fillRect(0, 0, w, h);
		int cw = 440;
		int ch = 280;
		int x = (w - cw) / 2;
		int y = (h - ch) / 2;
		Draw.glow(g, x, y, cw, ch, 18, Draw.ACCENT, 0.35f);
		Draw.glass(g, x, y, cw, ch, 18, 0.92f);
		Draw.text(g, "Sign in with Microsoft", Draw.bold(20f), Draw.TEXT, x + 28, y + 46);
		MicrosoftAuth.DeviceCode code = loginCode;
		if (code != null) {
			Draw.text(g, "Go to microsoft.com/link and enter this code:", Draw.regular(13f), Draw.MUTED, x + 28, y + 74);
			g.setColor(new Color(255, 255, 255, 14));
			g.fill(Draw.round(x + 28, y + 90, cw - 56, 64, 14));
			Draw.centered(g, spaced(code.userCode()), Draw.bold(30f), Draw.TEXT, x + cw / 2.0, y + 122);
			Draw.text(g, "Copied to your clipboard", Draw.regular(11.5f), Draw.GOOD, x + 28, y + 172);
			popupButton(g, "Open browser", x + 28, y + ch - 62, 150, true, () -> {
				try {
					Desktop.getDesktop().browse(java.net.URI.create(code.linkWithCode()));
				} catch (Exception ignored) {
					// They can type the address themselves
				}
			});
			popupButton(g, "Copy code", x + 188, y + ch - 62, 110, false, () -> copyToClipboard(code.userCode()));
		}
		String line = loginStatus;
		if (line != null) {
			Draw.text(g, ellipsize(g, line, Draw.regular(12f), cw - 56), Draw.regular(12f), loginFailed ? Draw.BAD : Draw.MUTED,
				x + 28, code == null ? y + 80 : y + 194);
		}
		popupButton(g, loginFailed ? "Close" : "Cancel", x + cw - 28 - 96, y + ch - 62, 96, false, () -> {
			loginCancelled = true;
			loginOpen = false;
		});
	}

	private void popupButton(Graphics2D g, String label, int x, int y, int w, boolean primary, Runnable action) {
		boolean hover = inside(x, y, x + w, y + 36);
		float hv = animate("popup:" + label, hover ? 1f : 0f);
		if (primary) {
			g.setPaint(new GradientPaint(x, 0, Draw.ACCENT, x + w, 0, Draw.ACCENT_2));
		} else {
			g.setColor(Draw.mix(Draw.CONTROL, new Color(0x3A3C42), hv));
		}
		g.fill(Draw.round(x, y, w, 36, 11));
		Draw.centered(g, label, Draw.bold(13f), primary ? Draw.ON_ACCENT : Draw.TEXT, x + w / 2.0, y + 18);
		hits.add(new Hit(x, y, x + w, y + 36, action));
	}

	private static String spaced(String code) {
		return String.join(" ", code.split(""));
	}

	private void toggle(Graphics2D g, String key, boolean value, int x, int y, boolean enabled, Runnable action) {
		float on = animate("toggle:" + key, value ? 1f : 0f);
		Color track = Draw.mix(Draw.CONTROL, Draw.ACCENT, on);
		g.setColor(enabled ? track : Draw.alpha(track, 0.4f));
		g.fill(Draw.round(x, y, 46, 24, 12));
		g.setColor(enabled ? Color.WHITE : new Color(255, 255, 255, 120));
		g.fill(new Ellipse2D.Double(x + 3 + on * 22, y + 3, 18, 18));
		if (enabled) {
			hits.add(new Hit(x, y, x + 46, y + 24, action));
		}
	}

	private void setMemoryFromMouse(int mouseX) {
		float fraction = Math.max(0f, Math.min(1f, (mouseX - memoryTrackX) / (float) Math.max(1, memoryTrackWidth)));
		settings.memoryGb = 2 + Math.round(fraction * 14);
	}

	private static void openFolder(Path dir) {
		try {
			Files.createDirectories(dir);
			Desktop.getDesktop().open(dir.toFile());
		} catch (IOException | UnsupportedOperationException ignored) {
			// Nothing sensible to do if the shell can't open it
		}
	}

	/** For screenshots: show the page as it looks mid-install. */
	void showDemoProgress(Page page, String text, double value) {
		this.page = page;
		this.busy = value >= 0 && value < 1;
		this.failed = false;
		this.status = text;
		this.progress = value;
		animations.put("progress", (float) value);
	}

	void showPage(Page page) {
		this.page = page;
	}

	/** For screenshots: pretend sign-in is configured, optionally signed in and/or showing the code popup. */
	void showDemoAccount(MicrosoftAuth demoAuth, MicrosoftAuth.Account demoAccount, String demoCode) {
		this.auth = demoAuth;
		this.account = demoAccount;
		this.loginOpen = demoCode != null;
		this.loginFailed = false;
		this.loginCode = demoCode == null ? null
			: new MicrosoftAuth.DeviceCode(demoCode, "https://www.microsoft.com/link", "", 5, Long.MAX_VALUE);
		this.loginStatus = demoCode == null ? null : "Waiting for you to sign in...";
		this.status = null;
		this.failed = false;
		this.busy = false;
		this.progress = -1;
	}

	// ---- Helpers -------------------------------------------------------------------------------------------

	/** Looks for a newer pack on the website in the background, so the window opens straight away. */
	private void checkForUpdates() {
		PackManifest current = pack;
		Thread thread = new Thread(() -> {
			Updater.Result result = Updater.check(gameDir, current, launcherVersion);
			if (result.launcherNeeded() != null) {
				launcherUpdate = result.launcherNeeded();
			}
			if (result.pack() != null) {
				SwingUtilities.invokeLater(() -> applyUpdate(result.pack()));
			}
			repaint();
		}, "Goon Client update check");
		thread.setDaemon(true);
		thread.start();
	}

	/** Switches to a downloaded pack, or holds it until the current install or game is done. */
	private void applyUpdate(PackManifest update) {
		if (busy || gameRunning) {
			pendingPack = update;
			return;
		}
		pendingPack = null;
		pack = update;
		installer = new Installer(update, minecraftDir, gameDir, settings);
		changelog = Changelog.forPack(update);
		failed = false;
		status = "Goon Client " + update.version() + " downloaded. Press Play to install it.";
		repaint();
	}

	private String installedSummary() {
		long installed = pack.files().stream().filter(installer::isInstalled).count();
		boolean clientInstalled = Files.exists(gameDir.resolve(pack.clientJarPath()));
		if (installed == pack.files().size() && !clientInstalled) {
			return "Goon Client " + pack.version() + " is ready: press Play to install it.";
		}
		if (installed == pack.files().size()) {
			return "Everything is installed. Press Play to start.";
		}
		return installed == 0 ? "First launch downloads about " + megabytes() + " MB of mods." : "Update available: press Play to install it.";
	}

	private int megabytes() {
		return (int) (pack.files().stream().mapToLong(PackManifest.PackFile::size).sum() >> 20);
	}

	private float animate(String key, float target) {
		float current = animations.getOrDefault(key, target);
		current += (target - current) * Math.min(1f, frameSeconds * 12f);
		if (Math.abs(target - current) < 0.002f) {
			current = target;
		}
		animations.put(key, current);
		return current;
	}

	private boolean inside(int x1, int y1, int x2, int y2) {
		return mouse.x >= x1 && mouse.x < x2 && mouse.y >= y1 && mouse.y < y2;
	}

	private static String ellipsize(Graphics2D g, String text, Font font, int maxWidth) {
		FontMetrics metrics = g.getFontMetrics(font);
		if (metrics.stringWidth(text) <= maxWidth) {
			return text;
		}
		String cut = text;
		while (!cut.isEmpty() && metrics.stringWidth(cut + "...") > maxWidth) {
			cut = cut.substring(0, cut.length() - 1);
		}
		return cut + "...";
	}

	private static List<String> wrap(String text, FontMetrics metrics, int maxWidth) {
		List<String> lines = new ArrayList<>();
		StringBuilder line = new StringBuilder();
		for (String word : text.split(" ")) {
			String candidate = line.isEmpty() ? word : line + " " + word;
			if (metrics.stringWidth(candidate) > maxWidth && !line.isEmpty()) {
				lines.add(line.toString());
				line = new StringBuilder(word);
			} else {
				line = new StringBuilder(candidate);
			}
		}
		if (!line.isEmpty()) {
			lines.add(line.toString());
		}
		return lines;
	}

	/** Index of the '-' or '_' that starts the version part of a jar name, e.g. "sodium-fabric-0.9.2" -> 13. */
	private static int firstVersionIndex(String name) {
		for (int i = 0; i < name.length() - 1; i++) {
			char c = name.charAt(i);
			if ((c == '-' || c == '_') && Character.isDigit(name.charAt(i + 1))) {
				return i;
			}
		}
		return -1;
	}

	private static String prettify(String name) {
		StringBuilder out = new StringBuilder();
		for (String word : name.replace('_', '-').split("-")) {
			// "fabric" is noise in "sodium-fabric", but it is the name in "fabric-api"
			if (word.isEmpty() || (word.equalsIgnoreCase("fabric") && !out.isEmpty()) || word.equalsIgnoreCase("mc")) {
				continue;
			}
			out.append(out.isEmpty() ? "" : " ").append(Character.toUpperCase(word.charAt(0))).append(word.substring(1));
		}
		String pretty = out.isEmpty() ? name : out.toString();
		for (Map.Entry<String, String> fix : NICE_NAMES.entrySet()) {
			pretty = pretty.replace(fix.getKey(), fix.getValue());
		}
		return pretty;
	}

	private record Hit(int x1, int y1, int x2, int y2, Runnable action) {
		boolean contains(int x, int y) {
			return x >= x1 && x < x2 && y >= y1 && y < y2;
		}
	}
}
