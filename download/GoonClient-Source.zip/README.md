# Goon Client

## Current release — 0.17.2 (2026-10-07)

The ClickGUI is one centered glass window with category tabs and a three-column icon-card grid.
Each card has separate **Options** and **Enabled/Disabled** buttons. Search, favorites, Wardrobe, Adventure Log
and **Edit HUD layout** remain accessible. Full descriptions are available on hover when a card must shorten them.
The old dropdown columns and module-layout selector are removed; saved HUD positions and module states are preserved.

The launcher ZIP contains the Windows app and licensing notices. The source archive is a separate build output,
`build/distributions/GoonClient-Source-0.17.2.zip`, and is not put in the installed launcher directory.
When sharing builds, provide the corresponding source separately alongside the launcher download.

The approved Microsoft app remains enabled. Click **Sign in with Microsoft**, finish the device-code screen in
your browser, then **Play**. Turn off **Use the official Minecraft Launcher** for direct launch if you enabled it.
Authenticated play still requires the owner's manual sign-in; dev launch checks use an isolated test account.

### Earlier 0.15.1 additions

Optional Inventory modules: **Item Guard** (drop protection) and **Tool Saver** (mining/melee durability reserve).
Optional Utility modules: **Totem Alerts** (local revival events) and **Server Watch** (delayed world-clock updates).
All four start off. Drop protection excludes creative/spectator; Tool Saver does not protect armour/shields or item-use
wear. Server Watch skips singleplayer and does not claim an exact TPS reading.

Local commands: `/goonclient coords [copy]`, `/goonclient portal [copy]`, `/wp copy <name>`.
Copy writes plain text to your clipboard, never broadcasts it. Portal conversion is a vanilla 8:1 X/Z estimate;
height, portal placement, world borders and custom server rules can differ.

The 0.16.0 HUD editor improvements remain available in both module layouts.


The Combatant HUD port now includes shared GPU backdrop blur. HUD pills, list panels, Inventory, target info,
notifications, hotbar and glass module/settings panels sample one blurred world frame. Outside the panels the world
stays sharp. Settings > Interface > Background blur controls its strength; zero skips the GPU blur work.
Settings > Configs > **Combatant** loads the reference HUD set and default positions. Existing custom positions remain
until a preset is loaded or an element is reset. Source-derived compact/list/inventory/target geometry and Combatant's
original FPS, memory, speed, coordinates and ping icons are attributed in NOTICE.

Goon's code/assets are **GPL-3.0-only**, with the original Combatant notices retained. The launcher ZIP contains LICENSE and NOTICE;
the corresponding `GoonClient-Source-0.17.2.zip` is generated separately. Publish the corresponding source beside the download before
sharing builds. Child mod jars keep their own licenses. This is a free modpack: Xaero's permission requires official
credit links and restricts off-platform monetization. EntityCulling is excluded; players can install it separately from
https://modrinth.com/mod/entityculling. See NOTICE for official Xaero links and exact attribution.

Build inputs for the 22 bundled top-level mods are locked in `pack/mods.lock.json` by Modrinth version ID and SHA-512.
Fabric dependency metadata requires the mod IDs without adding exact version pins. A player's newer compatible copy
can be selected; upstream dependency constraints still apply. Arbitrary newer versions are not guaranteed compatible.
`./gradlew assemble :launcher:installDist :launcher:packageLauncher` produces the combined jar, launcher ZIP and source ZIP.


A PvE client for Minecraft Java **26.3**, built as a client-only Fabric mod and shipped as a modpack together with
performance, shader, map and schematic mods. Release builds now embed those mods in **one Goon Client jar**.

## Glass workspace (0.12.0)

Open the ClickGUI with **Right Shift**. **Settings** opens the common settings window:

- **HUD**: search elements, use their switch, or select the card to open its full settings. **Edit layout** opens the HUD editor.
- **Themes**: apply one of seven global accents.
- **UI**: adjust material/blur/opacity/background under Visual; control custom menus and glass hotbar/chat under Menus.
- **Capes / Setups**: open the wardrobe or your existing saved layouts.

In the HUD editor, select a widget to open its inspector. Drag to move, use Scale to resize, or choose **Preview this element only** to focus on it without changing the other enabled modules. Escape saves and returns. The main-menu editor uses labeled sample data and does not load a world.

The hotbar/chat styling switches are enabled by default and can be turned off independently. They change backgrounds; vanilla item rendering, health/hunger, chat text and click behavior remain in Minecraft's renderer. Release 0.12.0 compiled and its menus were visually captured; actual interactions and live in-world hooks have not been verified.

## For players

**Goon Client Launcher** (recommended): unzip `GoonClient-Launcher-<version>-windows.zip` (extract all of it), run
`Goon Client Launcher.exe` and press **Play**. No Java install needed. Unsigned app, so Windows SmartScreen asks once:
More info, then Run anyway.

**Direct launch** (when the build has an approved Microsoft client ID, see below): sign in once with Microsoft (you type a
code on microsoft.com/link; the launcher never sees your password), then Play installs and starts the game itself:

1. one bundled Goon Client jar into `%APPDATA%\.goonclient\mods`; dependency downloads are checked against published SHA-512 hashes when packaging;
2. Minecraft, libraries, assets and Mojang's Java runtime into `%APPDATA%\.goonclient\game-files`. Files already in your
   official `.minecraft` are reused (hard-linked or copied after a hash check). `.minecraft` is only ever read;
3. starts Minecraft with Mojang's recommended JVM flags and your RAM setting.

**Through the official launcher** (no client ID yet, or the Settings toggle): steps 1 and 2 of the old flow: it installs
the Fabric profile and adds a **Goon Client** installation to the Minecraft Launcher (backing up
`launcher_profiles.json` once), then opens it. Pick **Goon Client** there and press Play.

Updates work the same way: the launcher only downloads what changed, and only removes mods it installed itself.
Settings: RAM, close-after-start, open the game folder, and **Repair** (re-hash everything).

**Or** import `build/distributions/GoonClient-<version>.mrpack` into the **Modrinth App** or **Prism Launcher**.

| Key | Action |
|---|---|
| **Right Shift** | Open the Goon Client menu (or Mod Menu, then Goon Client, then Config) |
| **C** (hold) | Zoom; scroll while zooming to change how far |
| **Left Alt** (hold) | Freelook |
| **H** | Hide/show the Goon Client HUD |
| **J** | Open the Adventure Log |
| *(unbound)* | Add a waypoint where you stand |

All keys can be rebound in Options, Controls, under "Goon Client".

| Command | |
|---|---|
| `/goonclient` | Open the menu |
| `/goonclient log` | Open the Adventure Log |
| `/goonclient loot reset` | Start the Loot Tracker counting again |
| `/wp add <name> [x y z]` | Add a waypoint (here, or at coordinates) |
| `/wp remove <name>` | Remove a waypoint |
| `/wp list` | List waypoints with distances |
| `/wp clear-deaths` | Remove all death waypoints |

### Startup and input repairs (0.11.1)

Fixes the packaged-client startup crash in Xaero World Map 1.46.4 (`modFile` was null). A Goon compatibility
hook resolves Fabric's loaded archive for nested World Map installations; the 23 bundled dependency jars remain
unchanged. Extract the new launcher ZIP and press Play to install the updated client.

ClickGUI now clears unfinished drags and shortcut capture when resized or left for another screen. Typing from
settings returns to the visible search, settings keep their scroll position during the closing fade, and sliders
follow the pointer directly while dragged. The menu fits smaller GUI sizes. Chat reservation follows vanilla's
scaled, whole-row geometry and full background padding.

### Classic glass menu (0.16.0)

Press **Right Shift**. One glass window: a sidebar with **All modules**, the six categories (with enabled/total counts), **Enabled** and **Favorites**, and a grid of module cards. **Left-click** a card to toggle the module, **right-click** (or the cog) for its settings, **middle-click** to favorite it. Scroll anywhere in the menu or drag the scrollbar. The **Edit HUD layout** button at the bottom of the sidebar opens the layout editor.

Use **All / Enabled / Favorites** and type to search across categories. **Ctrl+F** returns to the browser. **Esc** clears a search, returns from settings, then closes the menu. In shortcut capture, Esc cancels that capture first.

**Arrow keys** browse visible module rows, **Enter** toggles the focused row, and **Shift+Enter** opens its settings. Keyboard focus scrolls into view and respects the current search/filter. A pointer click returns to pointer control.

The top **Settings** button opens Interface; **Appearance** opens seven live accent previews and **Glass / Solid** material choices. The Studio pages (Settings) have the same **Edit layout** button on the HUD page. These controls also work from the main menu; the HUD editor uses registry-free previews before a world exists.

See [the modern reference study](docs/MODERN_CLIENT_REFERENCE_REVIEW.md) for pinned repositories, targeted source reading and next feature ideas.

### Modules

| Category | Modules |
|---|---|
| HUD (15 with Xaero) | Minimap, Coordinates, Keystrokes, CPS, Compass, World Time, Notifications, Active Modules, FPS, FPS Graph, Hardware Usage, Ping, Memory, Clock, Speed |
| World (12) | Light Level, Block Info, Block Focus, Breadcrumbs, Nearby Entities, Mining Stats, Waypoint List, Death Tracker, Adventure Log, Spawn Overlay, Chunk Borders, Mob Spawn Range |
| Combat (13) | Armor Status, Potion Effects, Mob Info, Danger Meter, Item Counter, Attack Indicator, Projectile Guide, Shield Status, Boss Prep, Hit Distance, Nutrition, Health Bars, Damage Numbers |
| Inventory (6) | Pickup Notifier, Container Preview, Loot Tracker, Inventory HUD, Tool Info, Item Details |
| Visual (12) | Zoom, Freelook, Fullbright, Custom Crosshair, Item Physics, Time Changer, Hitboxes, Player Tags, Camera Comfort, View Model, Weather Changer, Shaders |
| Utility (8) | Toggle Sprint, Toggle Sneak, Chat Timestamps, Better Chat, Session Stats, Schematics, Discord Presence, Interface |

The **Adventure Log** keeps a diary per world or server in `config/goonclient/adventure/`: deaths (with the death
message), boss kills (Ender Dragon, Wither, Elder Guardian, Warden), valuable pickups (merged per minute), advancements,
trips between dimensions and play sessions. It can screenshot boss kills, rare finds and advancements automatically.
Click an entry in the log to save its location as a waypoint.

World overlays (spawn spots, chunk borders, spawn range rings, health bars, damage numbers) use 26.3's gizmo layer:
`render/WorldRender` adds them each frame in Fabric's `LevelRenderEvents.BEFORE_GIZMOS`.

The **Goon Client main menu** replaces the title screen: dimmed, blurred panorama, a left-aligned column of buttons
and an account card. It can be turned off in Utility, Interface.

HUD elements can be dragged, resized (scroll) and hidden (right-click) in **Edit HUD Layout** (button in the ClickGUI sidebar
and on the Studio HUD page). A dragged panel follows the cursor exactly and snaps to the screen edges, the centre and other
panels (hold **Alt** for no snapping); arrow keys nudge the selected panel (Shift = 5 px), clicking empty space deselects, and the
settings panel can be dragged by its title. Panels keep their distance from the nearest edge at any resolution. Auto-stacking
reserves the configured vanilla chat area unless chat is hidden, along with the existing hotbar and minimap reservations.

**Minimap** is a HUD module when Xaero's Minimap is installed. Open **Right Shift → HUD → Minimap** for its switch,
scale slider, **Edit Layout**, native map/radar/waypoint **Settings**, and placement reset. In Edit HUD, drag the
live map, scroll to resize it, or right-click to hide it; re-enable it in **Elements**. Other panels reserve space for
the map and its native information labels, including after resizing or moving it. Crowded columns can spill sideways.
Xaero's visibility hotkey and Goon's switch stay synchronized; map data and waypoints still come from Xaero.

### Item Details (0.11.0)

Starts **off** in Inventory. Enable it, then hold **Shift** while hovering an item to see durability/percentage, stack capacity and a short first-page book preview. Settings can remove the Shift requirement or enable food values, known-container stack counts and item IDs. AppleSkin already provides food details, so the duplicate food option starts off. Book text respects Minecraft text filtering and is plain text, capped at 256 code points/four short lines. No book click event is executed and no hidden container is queried. Counts use only contents present on the hovered item; these are not previews of unopened world chests. Tool Info also reads enchanted-book stored enchantments.

### Exploration and visual tools (0.10.0)

Nine new modules start **off**. Open **Right Shift**, find their category, then right-click the module row for its options. They use the existing favorites, profiles and shortcut controls.

| Module / category | What it does |
|---|---|
| Block Info / World | Name, XYZ, held-tool suitability, estimated vanilla break time, optional identifier and up to four block-state properties. Only the ordinary crosshair target is inspected. Editable HUD; menu preview requires no world. |
| Block Focus / World | Accent outline/fill of the actual selection shape. Style, width and fill opacity controls. It overlays the ordinary vanilla selection outline. |
| Breadcrumbs / World | Tick-sampled local movement trail, 3–60 second lifetime, point spacing, width and Clear. At most 512 points. Clears on world change, death or a movement jump over eight blocks; nothing saved or shared. |
| Projectile Guide / Combat | Bow while drawing, pearls, eggs, snowballs, splash/lingering potions and XP bottles. Cached each tick, at most 120 simulation steps / 96 m, 64 visible collision candidates. Loaded chunks only. Optional impact label and entity hits. |
| Hitboxes / Visual | Draws actual collision bounds of selected entity categories; no hitbox or reach modification. Distance, width and 4–64 box limit. Visible entities only, with depth testing. |
| Player Tags / Visual | Appends distance and optional reported health/ping to existing native player tags. Preserves team/invisibility decisions and adds details only for line of sight. Health starts off: servers may not expose actual remote health. |
| Camera Comfort / Visual | Scales the frame's hurt tilt and screen distortion, optionally disables walking bob. Original preferences and death animation are preserved; disabling immediately uses vanilla values again. |
| View Model / Visual | Horizontal/vertical/depth offsets, 50–150% scale, mirrored roll, optional offhand transform. Native swings/use animations still run; maps are excluded. No attack/interaction changes. |
| Weather Changer / Visual | Clear, Rain or Server precipitation; rain intensity. Native biome chooses rain/snow/no precipitation. Server weather, sky, rain sounds/particles, lighting and shader weather inputs are not overridden. |

Projectile paths are **estimates**, not aim assistance: no spread sampling, moving-target prediction, bubble-column forces, wind/enchanted/modded physics, deflection, pierce or crossbow rockets. Native 26.3 bow/throwable gravity and drag ordering are used; server behavior can differ. New world drawings do not use always-on-top gizmos. Check your server's mod rules before enabling optional visual tools.

The reference study and source index are documented in [docs/CLIENT_REFERENCE_REVIEW.md](docs/CLIENT_REFERENCE_REVIEW.md). Implementation is original 26.3 code; legacy source, auth code and binaries are not shipped.

### Shortcuts and new survival readouts

Right-click any module row to open its settings. In **Right Shift → module settings → Toggle shortcut**, click the key field and press an unused keyboard key. **Esc** cancels capture, **Delete/Backspace** clears the shortcut, and the **Clear** button removes it. Existing Minecraft and mod key mappings are protected; conflicts name the control already using the key. Shortcuts activate once per press while in a world, with no menu/chat or modifier input. A later conflict disables the shortcut until you choose another key. Bindings are stored separately in `config/goonclient/keybinds.json`, so loading module profiles preserves them.

**Notifications** is on by default: up to three short animated messages for module toggles and effect warnings. Its lifetime is adjustable; position, size and visibility use the regular HUD editor. Repeating a module toggle replaces its prior message.

**Active Modules** starts off. It lists enabled modules with their shortcut keys; by default only bound modules appear. Turn off that filter for a full list and adjust the row limit.

**Tool Info** starts off. It shows your held item's name, remaining durability or stack size, and up to eight enchantments. Long names are shortened to keep the panel compact.

**Potion Effects → Warn before beneficial effects expire** is opt-in, with a 3–30 second threshold. It warns once per effect, clears when the effect disappears and re-arms after a renewal above the threshold. Infinite-duration and harmful effects do not generate expiry warnings. Enable Notifications to see these messages.

### Options, screenshots and performance

**Options** opens the Goon Client settings hub from either menu. Use the cards for video (including Sodium/Iris),
sound, controls, mouse, chat, language, skins, resource packs and accessibility. The detailed Minecraft/mod settings
screens keep their own controls. The hub's FOV slider supports dragging and arrow keys; Tab navigates the cards.
The first-run narrator welcome page is skipped, including on a fresh install. Narrator controls remain in Accessibility.

**Low-resource preset** is in Options and Utility > Interface. It caps view/simulation distance at 8/5 chunks,
entity distance at 75% and frame rate at 90 FPS; disables clouds, entity shadows, smooth lighting, biome blending and
menu blur; reduces particles; uses fast leaves and a solid charcoal menu background. Existing lower distances, frame
caps and minimal particles stay lower. It doesn't switch off Iris shader packs: do that in Video for best results.
**Restore previous** reads the saved settings from `config/goonclient/performance-backup.json`, even after restarting.
Applying again keeps that original backup until you restore it.

**Screenshots** is in the main menu, pause menu and Interface. Browse six captures per page, click for a large preview,
open an image or its folder, or copy its path. **Remove** moves it into `screenshots/.goon-trash`; **Undo remove** restores
it during the same gallery session. After closing the gallery, the files can still be recovered from that folder.
Previews load off-thread and keep at most six reduced-resolution images in GPU memory.

**Hardware Usage** is off by default. CPU is whole-system usage; Game CPU is this Java process as a percentage of total
CPU capacity. GPU frame is Minecraft's GPU render time divided by frame time, not the whole machine's GPU utilization.
Unavailable readings show `N/A`.

**Item Physics** and **Time Changer** are opt-in Visual modules, both off by default. Item Physics only changes how drops
look. Time Changer samples visual environment timelines at your chosen time; server clocks, mob behavior, sleeping,
spawn checks and the World Time HUD still use the real time. Shader packs may supply their own sky effects.

### Bundled mods (pack/mods.txt)

| Purpose | Mods |
|---|---|
| Performance | Sodium, Lithium, FerriteCore, ImmediatelyFast, Dynamic FPS, Krypton |
| Graphics | Iris (shaders), Sodium Extra, Reese's Sodium Options |
| Maps | Xaero's Minimap, Xaero's World Map |
| Schematics | Litematica (+ MaLiLib) |
| Inventory | Mouse Tweaks, Inventory Profiles Next (sorting, locked slots), AppleSkin |
| Menus | Mod Menu, Fabric API |

`pack/overrides/` holds default configs for the bundled mods. For example, it hides Xaero's coordinate line,
because Goon Client shows richer coordinates right under the minimap.

## For development

Everything lives in the project folder:

- **JDK 25**: a portable Microsoft OpenJDK is in `.tools/jdk-25` (git-ignored). Nothing is installed system-wide.
- **Gradle 9.7.1**: downloaded automatically by `gradlew`.
- **Minecraft 26.3, Fabric Loader 0.19.5, Fabric API, Mod Menu, Sodium**: downloaded by Loom. Versions are in `gradle.properties`.

From Git Bash in this folder:

```bash
export JAVA_HOME="$PWD/.tools/jdk-25"
./gradlew runClient                  # play-test (offline dev player, files in run/)
./gradlew runClient -PdevSnapshots   # auto-join "New World", pose a showcase, save run/screenshots/goon-*.png, quit
./gradlew build                      # build/libs/goonclient-<version>.jar
./gradlew mrpack                     # build/distributions/GoonClient-<version>.mrpack
./gradlew :launcher:packageLauncher  # launcher/build/distributions/GoonClient-Launcher-<version>-windows.zip
./gradlew site                       # refresh the website in site/ (downloads, version, changelog)
```

The launcher (`launcher/`, plain Java + Swing, packaged with `jpackage`) bundles the `.mrpack` contents, the UI
font and `CHANGELOG.md` (its "What's new" card) at build time. Test flags, so you never touch your real install:

```bash
launcher/build/install/goonclient-launcher/bin/goonclient-launcher.bat --install --minecraft-dir <fake .minecraft> --game-dir <dir>
launcher/build/install/goonclient-launcher/bin/goonclient-launcher.bat --screenshot <dir>   # renders every page to PNG
```

### Microsoft sign-in (direct launch)

Goon's public application ID `a48c6225-4c33-494d-bf76-51de3f3f46eb` is approved and enabled in this build.
Microsoft accepted a device-code request on October 7; the Xbox/Minecraft token exchange and an authenticated
game session still require a player to complete sign-in. This identifier is public and is not a secret or password.

For developers registering a different application:

Minecraft only accepts sign-ins from launchers whose Azure app Mojang has approved, so this needs your own app:

1. Go to https://portal.azure.com, then **Microsoft Entra ID**, then **App registrations**, then **New registration**.
   Name it "Goon Client". For supported account types, pick **Personal Microsoft accounts only**. No redirect URI.
2. In the new app, open **Authentication**, set **Allow public client flows** to **Yes**, then Save.
3. Copy the **Application (client) ID** from the Overview page.
4. Apply for Minecraft API access with that ID: https://aka.ms/mce-reviewappid. Approval can take a while.
5. Put the ID in `gradle.properties` as `ms_client_id=...` and rebuild with `./gradlew :launcher:packageLauncher`.

Before approval, sign-in reaches Microsoft and Xbox fine but Minecraft answers 403. The launcher says so and you can
keep using the official-launcher toggle. Never use another launcher's client ID.

Developer test (offline singleplayer session, never for players): `--launch --dev-offline NAME --game-dir <dir>`.

### Website (goonnation.xyz)

`site/` is the website: plain HTML/CSS/JS, no build step, hosted on GitHub Pages. `index.html` is the home page,
`privacy.html` explains sign-in and data handling (link it on the Mojang app review form), `CNAME` holds the domain.

For a release, run `./gradlew site`. It copies the launcher and `.mrpack` into `site/download/` under fixed names (so
the download links never change), and updates the version numbers, download sizes and the changelog (generated from
`CHANGELOG.md`, between the `changelog:start/end` markers) in `index.html`. Screenshots are `site/assets/img/shot-*.webp`,
made from `runClient -PdevSnapshots` output. Then push `site/` to the Pages repo.

First-time setup:

1. Make a **public** GitHub repo (e.g. `goonnation.xyz`) and push the *contents* of `site/` to its `main` branch
   (use git, not the web uploader: the launcher zip is over the browser's 25 MB limit).
2. Repo **Settings > Pages**: Source **Deploy from a branch**, branch `main`, folder `/ (root)`. The custom domain fills
   in from `CNAME`.
3. At the domain registrar, add four `A` records for `goonnation.xyz`: `185.199.108.153`, `185.199.109.153`,
   `185.199.110.153`, `185.199.111.153`, and a `CNAME` for `www` pointing to `<github-username>.github.io`.
4. Once the certificate is issued, tick **Enforce HTTPS**. Optionally verify the domain under your GitHub account's
   **Settings > Pages** so nobody else can claim it.

Mod jars dropped into `run/mods/` load in the dev game too. Since 26.1 the game is unobfuscated, so release jars
work in development unchanged; that's how the full pack is tested together.

### Layout

```
src/main/       mod id + helpers, fabric.mod.json, assets (lang, icon, UI font)
src/client/     everything client-side
  module/       Module, settings (Boolean/Number/Mode), ModuleManager
  hud/          HudModule, HudPosition (anchor + offset), TextHudModule, HudRenderer
  gui/          Ui (theme, smooth font, anti-aliased shapes), ClickGuiScreen, HudEditorScreen
  modules/      the modules, by category
  waypoint/     waypoints, saved per world/server in config/goonclient/waypoints/
  tracker/      SessionStats (kills, deaths, blocks, ores, distance, XP, pickups)
  mixin/        Camera (zoom, freelook), MouseHandler, lightmap (fullbright), pickup packet,
                chat timestamps, tooltip image (container preview), boss bar accessor
  dev/          DevSnapshots (only active with -PdevSnapshots)
pack/           modpack mod list and config overrides
```

### UI notes

- The look is Combatant's Noir glass: translucent charcoal panels over a live blur of the world (`GlassUi`,
  `hud/HudRenderUtil`), white text, muted labels and one theme accent (`Ui.accent()`, Noir pink by default). See
  DESIGN.md for the brand (logo, wordmark, capes) and the HUD port.
- Text is drawn by `GoonFont` (Inter, Onest, Comfortaa, Combatant's icon fonts; OFL notices in
  `assets/goonclient/font/OFL-*.txt`). The vanilla-font `goonclient:ui` providers also point at Inter.
- `Ui.roundRect` draws at real screen-pixel resolution with an anti-aliased edge, so corners stay smooth at any GUI scale.
- Text shadows are 1 screen pixel instead of vanilla's 1 GUI pixel, which would double smooth text.

### 26.3 API notes

The Fabric docs target 26.2. These are the 26.3 differences found so far:

- **The game is unobfuscated.** All code uses Mojang's names. There's no mappings line in `build.gradle`, and dependencies use plain `implementation`.
- **SDL3 replaced GLFW.** Use `InputConstants.KEY_*` (they are not GLFW codes, e.g. `KEY_H` is `11`). Key types are `KEYBOARD`/`MOUSE`, and mouse buttons are 1 = left, 3 = right.
- **Screens moved to `Gui`**: `mc.gui.screen()` and `mc.gui.setScreen(...)`. `Minecraft.screen` / `setScreen` no longer exist.
- **Chat**: `player.sendSystemMessage(component)`; `Gui.getChat()` no longer exists.
- **HUD**: `HudElementRegistry`. Elements implement `extractRenderState(GuiGraphicsExtractor, DeltaTracker)`; screens override `extractRenderState` / `extractBackground`.
- **FOV** is computed in `Camera.calculateFov(float)`. Camera rotation is set in `Camera.alignWithEntity` via `setRotation`.
- **Lighting**: `LightmapRenderStateExtractor.extract(LightmapRenderState, float)`.
- **World time uses clocks**: `level.getDefaultClockTime()`.
- **Boss bars**: `mc.gui.hud.getBossOverlay()`.
- **Keybind categories** translate from `key.category.<namespace>.<path>`.
- **World rendering** has two phases: collect data in `LevelExtractionEvents`, draw in `LevelRenderEvents`.

To check an API, run `javap` against the Minecraft jars in `.gradle/loom-cache/minecraftMaven/`.

## Goon wardrobe (0.6.0)

Open Wardrobe from the title menu or ClickGUI. Three original capes equip locally and render in F5.
Friend sharing needs the separate service hosted; setup and account-proof details are in
[cosmetics-service/README.md](cosmetics-service/README.md). Sharing starts off and cosmetics_url is blank,
so no cosmetic networking occurs by default. Built-in IDs only; no skin downloads, HWIDs or passwords.
The source study is documented in [docs/CLIENT_REFERENCE_REVIEW.md](docs/CLIENT_REFERENCE_REVIEW.md).

## Saved setups and new readouts (0.7)

Open **Goon Client → Profiles** (also in Interface settings). Choose Survival, Builder or Boss run and click
**Load setup**. **Undo** restores the previous module settings and HUD placements for the current session.
To make your own, name your current setup and click **Save new**. Up to 32 are stored locally in
`config/goonclient/profiles`; overwrite/delete ask for a second click. Built-ins are read-only templates.
Profiles include Goon modules, settings and HUD positions. Favorites remain global. Minecraft video settings,
Microsoft accounts and cosmetic sharing are separate. Invalid/oversized profile files are skipped with a log entry.

Bookmark a module using the small ribbon beside its settings icon. The **Favorites** and **Enabled** filters
combine with the sidebar category; search spans categories. Hover for the full description. The module settings
page now has Favorite and Reset settings actions. Reset keeps the module's enabled state and HUD position.

Five optional HUDs: **Keystrokes**, **Click Rate**, **Inventory HUD**, **Food & Saturation**, and **Hit Distance**.
They start disabled; enable them in the ClickGUI and place them in HUD Layout. Click Rate counts physical mouse
presses during gameplay, not menu clicks. Saturation may be imprecise on servers and is marked ~. Hit Distance
is a client estimate of the last attack ray, not server-confirmed damage. Inventory HUD is read-only.

Development visual preview: `gradlew.bat runClient -PuiPreview` with Dynamic FPS disabled for captures.
It captures these screens at GUI scales 2 and 3 without joining a world, then restores its temporary settings.
It does not exercise saved-profile actions, in-world click counting or authenticated multiplayer.

## 0.9.0: wardrobe, graphics, schematics and Discord

**Wardrobe:** Main Menu → Wardrobe, or Right Shift → Wardrobe. Nine original Goon capes and the Original cape option. Click a thumbnail to equip; use Previous/Next or scroll over the catalog. Front/Back changes the actual texture preview. F5 shows your cape in game. Share with friends is opt-in and still needs the owner-hosted cosmetics service; this update expands its allowed catalog, so update the backend source when hosting.

**Shaders:** Right Shift → Visual → Shaders. The switch applies the selected Iris pack; Choose shader pack opens Iris with a return path to Goon. If no pack is selected, enabling Shaders opens the picker. Choose a compatible pack first. No third-party shader artwork is bundled. Native Iris changes are reflected in Goon; Iris's saved graphics preference is authoritative at startup.

**Schematics:** Right Shift → Utility → Schematics. Starts OFF. Open Litematica loads/manages blueprints and material lists. Enable Schematics for rendering, then opt into Use schematic tool (stick) only if you want the stick to select/move regions. Schematic pick-block and Easy place have separate controls; Easy place starts OFF. The Goon switches own these corresponding Litematica preferences. While Schematics is off, tool input/rendering, pick-block, easy-place and placement restriction are disabled. This is runtime feature control, not unloading the mod.

**Discord:** Right Shift → Utility → Discord Presence. Starts OFF. Enable it with Discord desktop running and Activity Privacy → Share activity enabled in Discord. View status shows connection/retry information. Activity detail and elapsed time are optional. No OAuth login, passwords, world names, server addresses, coordinates, account names or tokens are sent by this integration. It uses the Goon Client app ID in `gradle.properties`; no brand artwork asset is required. Windows named pipes and Unix domain sockets are supported; Unix support has not been exercised here.

## One-jar distribution

`gradlew.bat assemble :launcher:packageLauncher` writes (assemble includes the bundle; `bundleClient` is available separately):

- `build/libs/goonclient-<version>-all.jar`: Goon plus all dependency mod jars nested inside it.
- `build/libs/goonclient-<version>.jar`: development/thin mod, without dependency jars.
- `build/distributions/GoonClient-<version>.mrpack`: one mod jar plus default configs.
- `launcher/build/distributions/GoonClient-Launcher-<version>-windows.zip`: packaged launcher with the complete pack embedded.

For a manual install, put the **-all.jar** in the mods folder of a clean **Fabric 26.3 / Java 25** installation. Do not also install the same bundled mods separately. This is a Fabric mod jar; it does not replace Mojang's vanilla version jar. The launcher sets up Minecraft and Fabric separately. You can use all Goon features without managing 24 individual mod files.

The archive preserves unmodified child jars, nested dependencies, mixins, assets, authors and license files. `BUNDLED_MODS.txt` and `goon-bundle.json` inside the jar list exact upstream versions, published hashes, licenses, source links and version downloads. Third-party licenses remain their own. Build cache downloads are hash checked before reuse.
