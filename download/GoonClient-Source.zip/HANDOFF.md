# Goon Client: handoff notes

Read this first, then README.md (player docs, build commands, 26.3 API notes).

## Current release - 0.17.3 (2026-10-07)

- Owner retried 0.17.2 and the same browser consent error remained. Correcting scopes alone did not resolve it.
- Found an undocumented browser URL shortcut: DeviceCode.linkWithCode appended ?otc=<userCode> to Microsoft's
  verification_uri. Removed it; verificationLink now returns the API URI exactly. The popup explains manual code
  entry; clipboard copying remains. Microsoft documents verification_uri and says verification_uri_complete is unsupported.
- References: https://learn.microsoft.com/en-us/entra/identity-platform/v2-oauth2-device-code
  and Prism MSADeviceCodeStep.cpp. A Microsoft Q&A user reports this exact error with the otc URL; this supports
  investigating the shortcut but is not proof of Goon's failure cause.
- Own approved app ID and Xbox-specific scopes retained. No account tokens are deleted, no borrowed app IDs used.
- Verification passed: assemble/installDist/site build, compiled launcher exact-URI contract (including preserving
  a server-returned query unchanged), no fabricated otc parameter, Xbox scopes and configured own app retained.
  Installed 0.17.3 Windows EXE launched successfully: both Xaero Stage 3/3, title, no-world HUD drawer/return,
  normal exit and no crash reports. Automated launch muted in isolated scratch game; user's config untouched.
- Completed browser consent and Xbox/XSTS/Minecraft login remain unverified until the owner finishes sign-in
  with a fresh code entered manually. The old prefilled browser tab should be closed. Website updates local only.
  Startup evidence: MCP-919/client-update-0151/evidence/0173-final-installed-exe.
- Evidence and rollback: MCP-919/client-update-0173. Website updates local only; no commit/push.

## Earlier release - 0.17.2 (2026-10-07)

- Owner's actual Microsoft consent attempt failed with first-party application / missing preauthorization error.
- Found scope mismatch: old generic offline_access vs XboxLive.offline_access in Microsoft Xbox docs and Prism
  MSADeviceCodeStep.cpp. MicrosoftAuth now requests XboxLive.SignIn XboxLive.offline_access for device code and refresh.
  This is a likely cause correction, not yet proof of completed account authentication; owner must retry with fresh code.
- References: https://learn.microsoft.com/en-us/xbox/gdk/docs/services/fundamentals/s2s-auth-calls/service-authentication/live-website-authentication
  and https://github.com/PrismLauncher/PrismLauncher/blob/develop/launcher/minecraft/auth/steps/MSADeviceCodeStep.cpp
- Retains 0.17.1 branding and 0.17.0 boxed menu. Source separate; own approved app ID retained; no borrowed IDs or secrets.
- Verification: rebuilt launcher's configured MicrosoftAuth requested the corrected exact scopes; Microsoft issued
  valid device-code metadata. Probe printed no device/user codes, access/refresh tokens or personal account details.
  This checks request acceptance only; the owner still must confirm the browser consent and full login chain.
- 0.17.2 installed after backup; installed EXE game startup passed both Xaero Stage 3/3, title, no-world HUD
  drawer/return, no crash reports and normal exit. Tests muted. Installed launcher reopened for owner to retry
  Sign in with Microsoft and get a new code; existing tokens/account data were not deleted.
- Website updated locally to 0.17.2 downloads/changelog/launcher preview; source remains separate. No Git commit/push.
  Evidence: MCP-919/client-update-0172; startup: client-update-0151/evidence/0172-final-installed-exe.
## Earlier release - 0.17.1 (2026-10-07)

- New original cut-corner G logo: flat theme accent, cleaner dark tile and diagonal shoulders. Shared geometry in
  gui/render/LogoArt.java and marketing/brand/logo.py. Applied to native client UI/cape glyph, launcher icon/Windows
  executable, site marks/favicons/social card and cape banner. Existing boxed menu and website layout retained.
- Website updated locally: fresh real screenshots in all sixteen themes, launcher/main-menu images, 71 module
  count, current release/downloads/changelog, accurate boxed-menu copy. Color picker changes logo and themed captures.
- Source is a separate public download (download/GoonClient-Source.zip), not inside launcher ZIP/installed app.
  releaseSource includes HANDOFF.md and editable marketing/brand sources. GPL notices and approved Microsoft ID retained.
- Verification: muted menuPreview compiled and launched, all 64 real captures (4 per theme) completed, HUD drag
  exactness OK, clean exit. Saved config/options match backup hashes and Dynamic FPS restored.
- Release 0.17.1 installed behind existing desktop shortcut after full backup. Installed Windows EXE startup passed
  both Xaero Stage 3/3, title, no-world HUD drawer/return, no crash reports and normal exit. No authenticated account
  or shader-pack test performed. Owner completes Microsoft sign-in and presses Play for their personal test.
- Site checked at 1440px/375px: no horizontal overflow; Mint changes logo and screenshot URLs. Existing CSS/layout
  retained. Site checkout not committed, pushed or deployed; owner manages publication.
- Evidence/rollback: MCP-919/client-update-0171. Packaged startup: client-update-0151/evidence/0171-final-installed-exe.
  Local-only website preview on 127.0.0.1:8765; updated launcher opened for owner to test.
- Optional -Dgoonclient.brandPreview=true with menuPreview captures sixteen themes in one session and restores saved
  config. Always use the external run-preview.ps1 backup/restore wrapper and keep automated launches muted.

## Earlier release — 0.17.0 (2026-10-07)

- Current owner direction: keep the existing glass style, use one centered box with category tabs/icon cards as in
  their attached examples, not dropdown columns. No Lunar code/assets were used. ClickGuiScreen is now a 440x270
  workspace with three-column 90-unit cards, unique vector icons, separate Options/state buttons, seven category
  tabs, global search, state/favorite filters, Wardrobe/Settings/Log and fixed Edit HUD layout footer.
- Dropdown renderer/scroll branches and Interface's module_layout setting removed, so previous saved values cannot
  force the old layout. Existing module states, bindings, favorites and HUD positions are untouched by migration.
- Corresponding source is a SEPARATE archive in build/distributions. launcher:packageLauncher still builds it but
  no longer adds it to the launcher ZIP. Keep LICENSE, NOTICE and GPL headers. Source must be available alongside
  distributed binaries; owner controls publication. Installed source ZIP is removed during installation; project source and separate release archive remain available.
- Approved Microsoft ID remains enabled; real authenticated login still needs the owner to complete Microsoft's screen.
- First in-world menuPreview launch: compiled, shared blur active, clean exit, editor cursor-drag exactness OK.
  Final devSnapshots confirmation passed: Options opens settings without toggling, state button toggles without opening
  settings, hidden-region clicks and header/footer/outside wheel isolation, exact-top thumb dragging, GUI scales 2/3,
  minimap regressions and safe HUD editing after disconnect. Both dev launches exited cleanly. Static UI scan: no findings.
  Saved options/config match their backup and Dynamic FPS is restored. No new FPS benchmark, shader-pack test or
  authenticated-account test. Final menu capture: MCP-919/client-update-0170/evidence/boxed-menu.png.
- Keep all tests silent. Back up and restore run/config/goonclient, run/options.txt and Dynamic FPS before runClient.
- Website not changed, no Git commit/push or cosmetics deployment. Staging/rollback/evidence: MCP-919/client-update-0170.

- Final launcher ZIP inspection: no source ZIP or Java source; LICENSE/NOTICE retained. Separate source archive built.
  Launcher 0.17.0 installed at C:\Users\Admin\AppData\Local\Programs\Goon Client Launcher after full rollback backup;
  old launcher-0.16.1.jar and installed GoonClient-Source-0.16.1.zip removed. Approved app ID confirmed in installed jar.
  Installed Windows EXE launch passed: both Xaero mods Stage 3/3, Goon title, no-world HUD drawer/return, no crash reports,
  normal exit. Tests muted; no actual Microsoft account login performed. Logs:
  MCP-919/client-update-0151/evidence/0170-final-installed-exe. UI evidence: MCP-919/client-update-0170/evidence.
### Earlier checkpoint — 0.16.1 (2026-10-07)

- Owner supplied the Mojang approval email dated 2026-10-05. Their public application ID
  a48c6225-4c33-494d-bf76-51de3f3f46eb is now enabled as ms_client_id in gradle.properties.
  Older notes below saying approval is pending or the ID must remain blank are historical and superseded.
  Never borrow another launcher's ID. No client secret is used.
- Microsoft device-code endpoint accepted this ID and the existing XboxLive.signin/offline_access scope.
  No user credentials were entered and no tokens were obtained. Xbox/XSTS/Minecraft exchange and authenticated
  multiplayer remain unverified until the owner signs in. A generic API 403 no longer incorrectly says approval is pending.
- ClickGuiScreen: Combatant ModulesMenuScreen dimensions (115/255/14/20/10) adapted to six Goon categories.
  Independent clipped columns, timed hover/checkmark transitions, category icons, global search, scrollbar drag,
  keyboard navigation and discoverable HUD editor. Classic sidebar/cards retained as an Interface module_layout option;
  Studio Visual settings exposes it. Reference headers and NOTICE updated for the GPL adaptation.
- Existing native shared-frame blur is retained; optical Fresnel/refraction/prismatic effects and in-column
  settings transitions are not ported. This is not yet a pixel-identical clone. Module settings remain the Goon popup.
- Silent launches and dev config/options/Dynamic FPS backup/restore rules remain mandatory.
- Verification: initial approved-ID package launch passed (both Xaero Stage 3, title, no-world HUD, clean exit).
  In-world menu tour compiled and ran, shared blur active, editor drag exactness OK. Final correction and package checks
  completed in the devSnapshots tour: GUI scales 2/3 hidden-region clicks and scrolling, exact-top thumb drag,
  toggle progress 1.0, minimap regressions, safe HUD editor after disconnect, clean exit. Saved config/options and
  Dynamic FPS restored. Static UI scan: no findings. No authenticated account or shader-pack test.
  Website, Git commits/pushes and cosmetics hosting were not changed.

- Final packaged Windows EXE installed at C:\Users\Admin\AppData\Local\Programs\Goon Client Launcher;
  old launcher-0.16.0.jar removed after a full installation backup. Installed launcher-0.16.1.jar contains
  the approved app ID. Installed EXE startup check passed: both Xaero Stage 3/3, Goon title, no-world HUD
  drawer/return checks, no crash reports and exit 0. Evidence: MCP-919/client-update-0151/evidence/0161-final-installed-exe.
  Dev snapshots evidence and rollback files: MCP-919/client-update-0161. Final UI screenshot: evidence/combatant-columns.png.
  Player instructions: Sign in with Microsoft in the launcher, then Play. If the optional official-launcher toggle
  is on, turn it off for direct launch. The real authentication chain requires the owner to complete the login.

### Earlier checkpoint — 0.16.0 (2026-10-04)

Owner asked for: a HUD editor that actually drags, the original ClickGUI back (sidebar + cards) on the glass look, an obvious
"edit HUD layout" button, a performance refactor, and silent test launches.

- ClickGUI (gui/ClickGuiScreen): classic workspace. One GlassUi.window, left rail (logo, "All modules", six categories with
  enabled/total counts, Enabled, Favorites, then the primary "Edit HUD layout" and "Adventure Log" buttons), header with search,
  card grid (3 columns at GUI width >= 880, else 2). Card: LMB toggle, RMB settings, MMB favourite, cog opens settings.
  The wheel anywhere in the open menu scrolls the grid. Search is global. The module settings page is unchanged and still uses
  the older px/py/content* fields (dev/ClickGuiChecks has a grid branch and a settings branch).
- Studio HUD page has an accent "Edit layout" button next to search.
- HUD editor (gui/HudEditorScreen): drag starts after 2.5 px; the panel follows the cursor exactly (moveTo -> HudPosition.fromScreen);
  snaps (3.5 units) to screen edges/centre and every other panel, Alt turns it off; arrows nudge (Shift = 5); click empty space
  deselects; picking prefers the selected panel, then the smallest. The inspector opens opposite the selected panel and can be dragged by
  its title. HudModule.renderAt places panels the player moved exactly (HudLayout.place only for default-flow panels); the editor
  chrome reserves no space. NOTE: 26.3 key/mouse modifiers are SDL bits: Alt = 256 (768 with right Alt), not GLFW's 4. Dev checks
  that fake an Alt-drag must send 256.
- Performance (record with `./gradlew runClient -Pprofile=<file.jfr>`, report with `python tools/jfr_top.py <file.jfr> .tools/jdk-25`; the render thread is
  called "main" in dev). Vanilla GuiRenderState compares every new element with the ones already submitted, so cost grows with
  element count: Shapes.drawShadow is one 9-quad element, outlinePx one 8-quad element, tiny round rects 2 elements, InventoryHud
  grid lines one batch; GoonFont uses a boolean[65536] base-set test and per-weight primitive advance caches; BackdropBlur caches its
  chain ids; HudLayout.free is an indexed loop. Sampled result: GUI-intersection samples roughly halved, shadow/outline frames almost
  gone, HudRenderer.extract 102 -> 79 samples. No FPS A/B was measured; these are sampling profiles of the dev tour.
- Silent runs: GoonClient mutes master volume in dev environments (-Dgoonclient.sound=true skips it), run/options.txt keeps
  soundCategory_master:0.0, packaged tests pre-seed <scratch>/options.txt. HARD RULE for every test launch.
- Verification: menuPreview tour ("Editor drag exactness: OK" at the crosshair/hotbar zone), devSnapshots tour (ClickGUI grid checks, minimap
  drag/resize, no-world HUD editor), packaged-launcher startup test: launcher/build/install bat with --dev-offline Tester, scratch
  options.txt pre-seeded with master volume 0 (stayed 0.0), both Xaero mods reached "Stage 3/3", no crash-reports; log noise was only the expected offline
  Realms/auth 401, first-run malilib.json and Perflib messages. Launcher 0.16.0 is installed in %LOCALAPPDATA%/Programs/Goon Client Launcher
  (old launcher-0.15.1.jar removed). The installed EXE itself was not launched this pass; the same jar was tested through the bat.
- Owner to do: push the website (goonpremier), publish the GPL source (GoonClient-Source-0.16.0.zip) before sharing builds,
  redeploy cosmetics-service (nation_noir allow-list), note the icon fonts carry no licence metadata (NOTICE).

## Previous release — 0.15.1 (2026-10-04)

Owner requested more features and a real game launch after each feature change. Existing UI and website are untouched.
The earlier three development additions below are now included with two more utilities:
- Server Watch (Utility, off): observes native ClientboundSetTimePacket after vanilla main-thread handling.
  Warns once per gap, optional recovery; two samples and 10-second join/dimension grace, adaptive normal cadence,
  skips singleplayer/frozen tick state; lifecycle resets. This is a packet-gap warning, not measured TPS/outage proof.
- Local location commands: /goonclient coords [copy], /goonclient portal [copy], /wp copy <name> (multiword names).
  Clipboard/plain local chat only. Vanilla 8:1 portal X/Z estimates, floor for negative Overworld coordinates;
  no conversion for custom dimensions and no guessed portal height. No automatic broadcast.
- Previous pass: Item Guard, Tool Saver, Totem Alerts. All four optional modules start off. Existing saved settings persist.

Verification completed before the release packaging step:
- Baseline launcher startup with the previous three modules passed title, Sodium video navigation, all 36 no-world
  HUD previews, drag/resize/drawer/return checks, both Xaero Stage 3/3 and clean shutdown, with no crash report.
- Server Watch build and full launcher test passed with exit code 0; Location Tools build/test also passed with exit 0.
- One Windows checker false failure reported a missing ExitCode after game exit; retained the process handle,
  reran successfully. No game crash was involved. Scratch logs still contain expected offline-test Realms auth errors;
  first clean run had a nonfatal missing malilib.json message. Do not describe these runs as zero-error logs.
- Logs/screenshots in C:/Users/Admin/Downloads/MCP-919/client-update-0151/evidence/{baseline,server-watch,location-tools}.
  Reusable launch-check.ps1 runs the packaged launcher and existing devStartupSnapshots tour, checks markers and exit.
- Scratch test sessions use --dev-offline Tester only for startup checks; no real-user offline login added.
- Startup tests prove launch/render/menu compatibility, not gameplay correctness of drop cancellation, live multiplayer
  warning cadence or every command. Those behavioral checks remain necessary on a real survival/server session.

Release outputs: build/distributions/GoonClient-0.15.1.mrpack, launcher/build/distributions/GoonClient-Launcher-0.15.1-windows.zip,
corresponding source ZIP inside the launcher distribution, and updated Discord CHANGELOG.md. Final versioned installDist and installed Windows executable checks both passed with game exit code 0.
Installed launcher: %LOCALAPPDATA%/Programs/Goon Client Launcher, backed up to client-update-0151/installed-before.
Actual EXE test uses process detection because the GUI launcher has no console stdout.
Evidence: evidence/release-0151 and evidence/installed-0151.
Additional packaged singleplayer smoke: copied run/saves/New World into scratch saves/SmokeWorld, enabled all four
optional modules for the start, ran the existing menuPreview tour, reached in-game HUD/chat/editor, then exited 0.
Both Xaero mods loaded, HUD blur processed 1,235 frames/5,971 regions without fallback; no crash report.
Original world was only read; scratch module config restored. Evidence/world-0151 contains the actual world log.
The manual Java world run used the packaged classpath/runtime but was launched from MCP-919, so logs/latest.log
was written there; the first evidence copy was corrected to the actual log rather than the previous title-tour log. No site task, commit, push or Microsoft-client-ID change.

Next: verify inventory protection against actual survival drop/mining actions and sorting mods; test Server Watch
on a live multiplayer server; graphical map/banner previews, explicit equipment presets and join/leave notices.
Retain current UI; owner rejected the website redesign. See docs/REFERENCE_FEATURE_PASS_0151.md for targeted sources.

## Previous development — item protections (now included in 0.15.1)

Owner requested more repository-inspired features and explicitly rejected further UI/website redesign.
No gui/hud renderer, branding, website or launcher edits in this pass. This paragraph describes the earlier unreleased pass; release status is superseded above.

Added three original Goon implementations, off by default:
- Inventory > Item Guard: protects enchanted items/books, custom-named stacks and containers with known
  nonempty contents; optional protect-all. Blocks hotbar Q/Ctrl+Q, inventory THROW and carried-item outside
  clicks at MultiPlayerGameMode before prediction/packet send. Normal sorting/moving remains unchanged.
  Creative/spectator bypass protection. Disable the module/change protection settings for deliberate drops.
- Inventory > Tool Saver: configurable 1..100 durability reserve (10 default), separate mining/melee toggles.
  Cancels mining start/continuation and normal/piercing melee attacks with a nearly broken main-hand item.
  No automatic slot switching, repairs or server modifications. Creative/spectator/unbreakable items bypass.
  Does not protect armour, shields, item use, server-side damage or actions initiated outside these vanilla hooks.
- Utility > Totem Alerts: own/other loaded player death-protection events, optional observed session counts,
  local chat and existing Notifications HUD output. UUID caches capped at 128, notices throttled per player,
  reset on enable/disable/join/disconnect. Packet handler hook runs after vanilla main-thread processing.
- Explanatory local chat is optional and rate-limited to one message per module per two seconds.
- Hooks: mixin/ItemSafetyMixin; settings automatically persist via existing ConfigManager.

Source reading and remaining candidates: docs/REFERENCE_FEATURE_PASS_0151.md. Pinned source archives remain
client-update-0110/references; these clients/build scripts were not executed. This is targeted feature research,
not a complete security audit. Original implementations; no new copied source/assets or renderer dependencies.

Verification: 26.3 APIs inspected with javap, including changed dropItem/handleContainerInput/PiercingWeapon paths.
compileClientJava succeeded for the three additions on 2026-10-04. Runtime behavior, inventory prediction and external sorting-mod
compatibility have not been verified in game. No release build, install, source publication, website sync or commit.
Staging/rollback: C:/Users/Admin/Downloads/MCP-919/client-update-0151.

## Prior checkpoint — Combatant source HUD port (0.14.1)

Owner authorized GPL-3.0-only licensing and copying/adapting Combatant HUD source/icons. This supersedes the old
0.13.0 clean-room/no-copied-assets note. Source snapshot 71d8b7173df8642865b502bcf4a0f65bb026a05f. LICENSE,
fabric.mod.json and NOTICE agree; copied/adapted files carry the copyright and modification notices.

Implemented 2026-10-04:
- `gui/render/BackdropBlur`, `mixin/GuiBackdropMixin`, post_effect/hud_blur_1..10.json: native shared frame capture
  before GuiRenderer.prepare(), two GPU blur passes; rounded textured masks, one-pixel antialias fringe, resize cleanup,
  session fallback if shader failure; zero strength skips GPU work. No Combatant renderer dependency.
- `hud/HudRenderUtil`, `TextHudModule`, TargetHud and InventoryHud: source-derived geometry, material helpers;
  `HudIcons` plus five original unchanged PNGs. Goon's fonts/vector list icons/data providers remain.
- GlassUi, hotbar, armor and notification surfaces use the same blurred texture. OptionsMixin prevents global
  background blur for the in-world ClickGUI/Studio; other screens retain their normal fallback.
- `hud/ChatFootprint`: records actual unfocused rendered chat bounds and freezes them while chat is focused;
  empty chat no longer pushes Mob Info toward the crosshair. Minimap collision remains unchanged.
- DevMenuPreview loads the Combatant preset and restores captured config. Shell wrapper separately backs up/restores
  config/goonclient and options.txt and moves Dynamic FPS aside, restoring it after each run.
- Free distribution: Xaero's own modpack permission permits credit-bearing free packs, with monetization conditions;
  the old blanket ARR warning was too broad. Official links/credit in NOTICE. EntityCulling excluded because its page
  forbids redistribution outside CurseForge/Modrinth-hosted packs. Build rejects it even as a transitive dependency.
- 22 top-level mods locked by version ID/SHA-512 in pack/mods.lock.json for reproducible selection. Metadata uses
  wildcard required mod IDs while retaining existing/upstream constraints, allowing compatible external upgrades.
- Launcher ZIP includes source ZIP, LICENSE, NOTICE. Source task excludes all run data/caches/worlds/tokens.

Verified so far: compileClientJava; two complete menuPreview tours with no render crash/blur fallback; exact source
API checks against the 26.3 jars. Final capture has target below the crosshair, clear world outside glass, real cooldown,
potions/inventory/map. Log recorded 1,259 shared captures / 5,931 regions. No performance benchmark claims.
Packaged startup and installation are pending until the release verification entry below is filled.

Exact pass (Claude, same day, after Astra's work above):
- `hud/HudRenderUtil` is now a faithful port: Combatant's resolution-relative scale (HudScale x TextSizing x
  SCALE_MULT 0.68 x 2.37 for compact stats; HudScale x 1.1 x 2 x scale for panels), so the HUD is the same size
  relative to the screen at any GUI scale. Elements push `pose.scale(k)` and then use Combatant's numbers verbatim.
  `Font` holds the MSDF metrics (Combatant sizes are line heights: em = size / lineHeight; ascender offsets) so
  text lands where its TextRenderer puts it. Checked against hud.png: pill widths within 1-2 px (FPS 136/134,
  RAM 288/287, speed 137/135), Potions title/count/row text within 1 px.
- Palettes: Noir neutrals + the theme accent through Combatant's updatePalette formulas (`CompactPalette`,
  `Palette.of(bgAlpha)`); fill alpha x blur alpha (matches measured translucency); vertical gradients
  (`Shapes.gradientRect`), top glint, hollow soft shadow (`Shapes.glow`, innerAlpha .055).
- `TextHudModule`: compact stat (picture icon 12.5/11 | divider | Onest value + Onest Medium unit, `Segment.gap`
  drawn vs reserved gaps for Coordinates), list panel with `Variant` (POTIONS/KEYBINDS/COOLDOWNS: glyph + font,
  min width, offsets, scale, bg/blur alpha, split header). Header rail uses the screenshot's older constants
  (icon 4.5, divider 18, title 22); rows use list_panel.js (divider 14.75, text 18). Clock = round time chip.
- Fonts: `GoonFont.Weight` ONEST, ONEST_MEDIUM, ICONS_NUR, ICONS (+ `drawGradient`). OFL-Onest.txt added.
- Icons: `Icons.drawPicture` loads textures/hud/elements/*.png (now white+alpha) with area-averaged
  downscaling; HudIcons and the grey-mask duplicates were removed. TOGGLE_ON/OFF vector icons.
- TargetHud (112x40 at 3.28, inset 2, face 24, Inter Bold 0.34, 64x4 bar), FeedbackHud (HudNotifier 1.35 scale,
  toggle | pipe | text, progress line, glass + rim), InventoryHud (123x62 at 1.32, 13-unit grid). Hotbar: offhand
  inside the bar with a divider, light rim; armour bar rimmed. `HudRenderUtil.rim` imitates the liquid-glass edge.
- `gui/Themes` accents = Combatant's values (Noir E16B78).
- Icon fonts iconsnur.ttf / icons.ttf have no licence metadata (Glyphter / "Darkyaw"); NOTICE says so. Tell the owner.

0.14.1 (same day): menus matched to the reference images too.
- `GlassUi.window` = SettingsGlassMaterial.workspace (blur, liquid haze, window tint at 30% of 205, glassEdgeSoft,
  rim); without a world (title) the tint carries the panel. Constants CONTROL/CONTROL_HOVER/GLASS_EDGE,
  RAIL_WASH_*, CONTENT_*, NAV_* from SettingsGuiPalette (Noir). `Shapes.gradientRect` has per-corner radii.
- StudioScreen rail wash and Main Settings planes; `Menus.button` (title + pause) is a glass control; pause stats card,
  title What's new/account cards and the Wardrobe window use GlassUi.window.
- HudEditorScreen inspector lists every setting of the element inline (scale, toggles, sliders, inline mode
  options, buttons, Position Reset), scrolls, 252 canvas units max, placed like Combatant's editor.
- Review findings fixed: Discord Windows pipe deadlock (poll length() before reading) and mojibake; crosshair box
  reserved in HUD layout; built-in presets only toggle modules (apply resets only entries with settings); launcher
  streams the changelog from the nested jar and checks the client jar once per paint; Time Changer caches its clock.

Remaining differences: no full Fresnel/distortion shader, OS media widget or server-admin module; time pills
(ring) on Potions/Cooldowns rows use text; Keybinds row icons are Goon's vector icons. Test resizing, resource
reload and shader packs next.
Keep ms_client_id empty until approval. Publish corresponding source with builds. No commit/push/site changes.

## HUD matched to Combatant's hud.png (0.13.1, items 1-4 done)

Reference: `C:/Users/Admin/Downloads/MCP-919/client-update-0110/references/combatant-images/hud.png` (1920x1080). Compare
against `run/screenshots/goon-menu-ingame.png` from `./gradlew runClient -PmenuPreview` after every change. Gaps found:
1. Default layout: FPS + RAM pills side by side top-left; Potions panel below them (left); Keybinds, Cooldowns and
   Inventory panels on the right; speed above coordinates as pills bottom-left; notifications bottom-right; target card
   just below the crosshair; a clock pill top-centre. Xaero's minimap (Combatant has none) moves to the top-right.
2. Panel rows use real icons: mob-effect sprites for potions, module/category icons for keybinds, item icons for cooldowns
   (Goon currently draws an accent dot). Keybinds panel = "Keybinds" (modules with a shortcut, key in accent).
3. New Cooldowns panel: item cooldowns (ender pearl, chorus fruit, wind charge, goat horn, shield) with time left.
4. Armour moves into a glass segment right of the hotbar (four armour icons), like Combatant's hotbar.
Done in 0.13.1: sizes measured at GUI scale 4 (pill 9u, panel title 4.9u, rows 9.4u); defaults moved to the reference
spots; `TextHudModule.Line.withIcon(ItemStack | sprite Identifier | Icons.Icon)`; potions use `Hud.getMobEffectSprite`;
Keybinds = renamed Active Modules (enabled by default); new `CooldownsHud` + `tracker/CooldownTracker` fed by
`mixin/ItemCooldownsMixin`; `ArmorHud` style "Hotbar" (default, right of hotbar); `InventoryHud` thin-line table; Clock on,
Compass and Item Counter off by default; minimap top-right; built-in "Combatant" preset in `ProfileStore.presets()`.
Existing players keep their saved on/off choices: they get the exact set by loading Configs > Combatant.
5. Media/session pill top-centre is out of scope (needs native OS media APIs); Admins panel is server-specific, skip.

## Latest checkpoint — 0.13.0 (Combatant look)

- **Owner request:** "make it look exactly like" Combatant (pivosos2007/combatant-client; reference images in
  `C:/Users/Admin/Downloads/MCP-919/client-update-0110/references/combatant-images`). Combatant is GPL-3.0 and Goon is
  All-Rights-Reserved, so the look was rebuilt with Goon's own code; nothing was copied except the OFL fonts. (Owner later
  said GPL would be fine; not needed so far. Porting Combatant's per-panel blur engine would require going GPL.)
- **Fonts:** `GoonFont.Weight` = REGULAR/MEDIUM/BOLD (Inter 3.019) + ROUNDED (Comfortaa, hints). OFL notices in
  `assets/goonclient/font/OFL-Inter.txt`, `OFL-Comfortaa.txt`. Poppins stays for the launcher. `ui.json` providers use Inter.
- **Icons:** `gui/render/Icons` draws original 24-unit vector line icons with Java2D at screen-pixel size (cached, retired
  safely via `Icons.beginFrame()` from `MinecraftRenderMixin`).
- **Themes:** `gui/Themes` (16 palettes, `Themes.DEFAULT` = Noir). Interface setting id is now `theme` (old
  `accent_color` ignored so everyone starts on Noir); blur is `menu_blur` (default 2, was `blur_strength` 4); new `hints`.
- **Canvas:** menus lay out on `GlassUi.CANVAS_W x CANVAS_H` (676 x 380) via `GlassUi.canvasScale`, i.e. the same screen
  proportions as Combatant at 1080p. Shared pieces in `GlassUi`: `panel` (frosted column), `window` (dark settings window),
  `navigation`/`navigationHit` (clock pill + Modules/Settings switch), `hints`, `searchBox`, `hideHud`/`restoreHud`
  (menus hide the HUD via `Hud.toggle()` while open).
- **Screens:** `ClickGuiScreen` = six frosted columns (icons, checks, hover, per-column scroll), search pill on Ctrl+F or
  typing, module settings as a compact element panel. `StudioScreen` = Settings window with rail pages HUD / INTERFACE ("UI")
  / THEMES / MAIN ("Main Settings") / CONFIGS (replaces ProfileScreen in the rail); Wardrobe still opens `CosmeticsScreen`
  (old style). `HudEditorScreen` = nav + element inspector + hints (E drawer, Ctrl+R reset, Alt+H hints).
- **HUD:** `TextHudModule` draws one-line pills (`icon()`, `valueFirst()`, `Line.rich(Segment...)`) or titled panels
  (`countLabel()` -> "Active: N"). `TargetHud` card (player face via `PlayerFaceExtractor`, mobs via
  `InventoryScreen.extractEntityInInventoryFollowsMouse` with pose-converted screen coords). `FeedbackHud` pills,
  `InventoryHud` titled grid, `HotbarStyle` glass, new `ExperienceBarStyleMixin` (XP track) and `ChatInputStyleMixin`.
  `reserveVanillaChat` always uses the unfocused chat size and reserves the input line while chat is open.
- **Verified:** compile; `runClient -PmenuPreview` (new `dev/DevMenuPreview`: in-world ClickGUI, every Settings page,
  module settings, HUD scene, chat, HUD editor -> `run/screenshots/goon-menu-*.png`, all inspected); full
  `runClient -PdevSnapshots` tour completed (34 shots, no crash; `ClickGuiChecks` now warns instead of throwing because its
  coordinates assume the old list layout). Packaged-launcher startup test: see release notes below.
- **Not done / next:** Wardrobe (`CosmeticsScreen`) and `GoonTitleScreen`/`GoonPauseScreen` keep the 0.12 layout (they do
  pick up Inter + the theme accent). Combatant's per-panel blur is approximated by a light full-screen blur + tint.
  `ClickGuiChecks` should be rewritten for the column layout. Website screenshots not regenerated (site owner-managed).

## Latest checkpoint — 0.12.1 (startup crash fix)

- **Owner report:** pressing Play opened nothing; the game crashed in the launcher. Every packaged start since 0.11.0
  crashed (`%APPDATA%/.goonclient/crash-reports`): `NullPointerException: ... "modFile" is null` in Xaero's Minimap
  `HudMod.loadClient`. Cause: Xaero's `FabricPlatformHelper.getModFile` only handles PATH origins; embedded in the
  combined jar the minimap has a NESTED origin, so it got null. 0.11.1 had fixed this for the World Map only.
- **Fix:** `compat/NestedModFiles.locate(modId)` resolves the archive Fabric loaded a nested mod from (shared by
  `mixin/xaero/XaeroWorldMapFileMixin` and the new `mixin/xaero/XaeroMinimapFileMixin` on
  `xaero.common.platform.services.FabricPlatformHelper.getModFile`). Version 0.12.1.
- **Verified (real packaged startup, Mojang runtime):** `goonclient-launcher.bat --launch --dev-offline` into a fresh
  scratch game dir: installed `goonclient-0.12.1-all.jar`, both Xaero mods reached Stage 3/3, game reached the Goon
  main menu (window captured), no crash report. Not verified: joining a world/server with 0.12.1.
- **Rule from this:** never ship a release without the packaged-launcher startup test. Every 0.9-0.12 note said it was
  skipped, and that's how a crash-on-launch shipped. Any embedded mod that reads its own jar path can break the same way.
- Fixed launcher installed for the owner at `%LOCALAPPDATA%/Programs/Goon Client Launcher` (Desktop/Start Menu
  shortcut "Goon Client"). Site not updated (still owner-managed).

## Previous checkpoint — 0.12.0

- Owner asked to rebuild the full visual family shown in Combatant's screenshots. Inspected all seven images (modules, themes, main settings, configs, HUD browser, HUD inspector, live HUD) from the pinned snapshot already downloaded. Original native implementation; no reference artwork/code/native renderer imported.
- New `gui/StudioScreen` unifies HUD cards, searchable seven-accent theme previews and Interface settings with a compact side rail. Cards open real module settings; switches enable the real HUD modules. AppearanceScreen is now a thin entry point to the theme page. Config/wardrobe navigation uses existing functional screens.
- Shared `GlassUi` lightens the frosted material across columns, studio, saved setups and HUD editing. Top-level workspace navigation is Modules/Settings; HUD elements are in the bottom dock. Per-column clipping, shortcut/reset protection and all 0.11.1 transient-input repairs remain.
- HUD editor has a right-side selected-element inspector: enabled switch, temporary isolated preview (does not disable other modules), exact scale drag, reset position and full module settings. Inspector/drawer reserve space; their backgrounds consume input. Hints sit above the native hotbar. Resize/removal clears dragging; config saves when navigating away. No-world previews still use registry-free samples.
- Text HUDs use compact bordered surfaces and a title/divider for multirow panels with backgrounds enabled; one-line counters stay compact. No-world text samples include matching title geometry. Existing specialized HUD modules keep their data/renderers.
- Added Interface switches `glass_hotbar` / `glass_chat` (default on). HotbarStyleMixin wraps only native hotbar background/selection/offhand sprites; items/counts/attack indicators/health/hunger/XP stay vanilla. Selection slides between slots. ChatSurfaceMixin wraps only black background fills on drawing helpers, preserving the supplied fade alpha, native text, tags, clickable text and scrollbars. These hooks were implemented against the actual 26.3 source signatures (RenderPipeline now lives in com.mojang.renderpearl.api.pipeline).
- `compileClientJava` and two bounded visual-only `runClient -PuiPreview` passes succeeded. The final pass produced nine captures under `run/screenshots/goon-0120-*`: columns, HUD browser, themes, Interface, profiles, inspector, and scale-3 browser/themes/inspector. Main-menu HUD editor rendered at scales 2 and 3 without crashing. No world joined; no automated tests/assertions, actual pointer interaction exercise, gameplay/performance measurements, packaged-client startup or authenticated multiplayer verification. Chat/hotbar hooks and HUD placement with live game data still need an in-world check when the owner requests verification.
- Visual route: set JAVA_TOOL_OPTIONS to `-Dfabric.debug.disableModIds=dynamic_fps -Dgoonclient.studioPreview=true`; `runClient -PuiPreview --offline --no-daemon`. It restores the captured config/GUI scale and exits. No production auth/offline changes.
- Static Impeccable detector ran once on the new GUI source and returned no findings; not a native UI test. `assemble :launcher:packageLauncher --offline --no-daemon` succeeded (20 tasks, 12 executed). Exported build/libs/goonclient-0.12.0-all.jar (30,740,584 bytes), build/distributions/GoonClient-0.12.0.mrpack (30,720,326 bytes), launcher/build/distributions/GoonClient-Launcher-0.12.0-windows.zip (60,108,843 bytes). Archive metadata reports 0.12.0, 23 nested jars and the new StudioScreen class. Packaged runtime is still unverified.
- Source/staging backups: `C:/Users/Admin/Downloads/MCP-919/client-update-0120`. Preserve the 0.11.1 Xaero nested-jar fix. 66 modules; 23 embedded upstream dependencies. Website unchanged; no commits/pushes.
- This is Goon's implementation of the reference's visual language, not pixel parity with every feature: existing profile workflow retained, shader scenery depends on the installed shader pack/world, external music/provider controls and server-specific staff/media widgets are not implemented. The compact hotbar keeps native geometry instead of moving vanilla HUD controls. New studio controls are pointer-first; full keyboard traversal is still a follow-up.

## Previous checkpoint — 0.11.1

- Confirmed the user's installed 0.11.0 crash in `%APPDATA%/.goonclient/crash-reports/crash-2026-10-03_20.55.11-client.txt`: `WorldMapFabric.fetchModFile` returns null for Fabric `ModOrigin.Kind.NESTED`; `WorldMap.loadClient` dereferences it. Inspected the shipped 1.46.4 bytecode. Development runs with loose jars do not exercise this path.
- Added `XaeroWorldMapFileMixin`, gated specifically on `xaeroworldmap`, to resolve the actual local archive behind Fabric's loaded root only for nested origins. Ordinary PATH handling remains upstream. The combined release jar still embeds 23 unmodified dependencies.
- ClickGUI cancels stale drags/capture/hit boxes on resize and screen removal, saves changes on child-screen navigation, blocks input during close, returns to search when typing from settings, keeps outgoing settings scroll during fade, and snaps dragged sliders to the pointer. Tiny GUI sizes retain the minimum virtual workspace.
- Corrected chat reservation to use vanilla's whole-row height, scaled baseline and complete right padding. Existing hidden-chat, no-world, hotbar and minimap guards remain.
- Version is now 0.11.1. `assemble :launcher:packageLauncher --offline --no-daemon` succeeded (20 actionable tasks, 14 executed). No tests or game launch were run; the user's original instruction prohibits tests unless requested. A successful build alone does not prove the runtime mixin or interactions.
- Reliable build command: set `JAVA_HOME=C:/Users/Admin/Synthetix/.tools/jdk-25` and `GRADLE_USER_HOME=C:/Users/Admin/.gradle`, then run `gradlew.bat assemble :launcher:packageLauncher --offline --no-daemon` with access to the JDK/cache. Project-local Gradle user home lacks the Loom plugin. `mrpack` still accesses Modrinth directly even with Gradle `--offline`.
- The preceding 0.11.0 continuation DID compile and package successfully at 20:53 on 2026-10-03 after the sandbox JDK access issue was resolved. Earlier notes below describe the initial failed attempts. That package was subsequently confirmed to crash in the installed game as described above.

## Previous checkpoint — 0.11.0

### Continuation update — 2026-10-03

- ClickGUI now consumes wheel input while open. Wheel movement changes only the hovered category or the active settings viewport; headers, collapsed panels, transitions and gaps do not pass wheel input onward.
- HUD layout now reserves a conservative vanilla chat rectangle based on chat visibility, width, focused/unfocused height, scale and line spacing. The shared layout path keeps this in HUD editor previews and skips it safely without a world or when chat is hidden; existing minimap and main-menu safeguards remain.
- Verification: no tests were added or run. Compilation could not be confirmed: the wrapper bootstrap and direct JDK 25 Gradle build hit a sandbox AccessDeniedException loading java.security; the only reachable compile command used Gradle's cached executable but the Gradle task still failed at security initialization. Existing 0.11.0 artifacts predate these edits. Live GUI interactions and in-world HUD collision remain unverified.

- Owner prioritized `pivosos2007/combatant-client` UI and requested continuing until approximately 10% of the five-hour usage allowance remains (90% used). No automated tests were authorized/run during this update.
- Native ClickGUI redesigned as six floating frosted category panels, compact top nav, bottom tools dock and centered settings window. Independent per-category scroll, clipped visible rows and input, thumb drag snapping, category collapse, retained search/filters/favorites/profiles/shortcuts. Left toggle / right settings / middle favorite. Category panels are not draggable/reorderable. No imported Combatant code, assets or renderer.
- `gui/AppearanceScreen.java` is a seven-accent preview gallery backed by Interface settings; `menu_material` adds Glass/Solid. Interface enable is restored when a choice is made; config marked dirty and saved on exit. Colors remain global Goon accents.
- First visual pass exposed shortened names at GUI scale 3; final pass wraps labels, uses antialiased round state-check strokes, preserves explicit paragraph breaks in help and caps the screen's wrapping cache at 256. Filter changes release active column drag.
- `compileClientJava` and two `runClient -PuiPreview` passes succeeded. `-Dgoonclient.glassPreview=true` selects the new visual-only route, `-Dfabric.debug.disableModIds=dynamic_fps` keeps thin development rendering responsive. Six final captures are `run/screenshots/goon-0110-{columns,settings,appearance}[-scale3].png`; final column and appearance captures inspected. Config and GUI scale restored by the route. No world joined, no automated assertions, gameplay/performance measurement, real mouse-flow exercise, packaged launcher startup or authenticated multiplayer verification. Do not treat older 0.8 assertions as evidence for the new browser.
- Later additions: `inventory/ItemDetails` (off, Shift required) uses Fabric ItemTooltipCallback and native hovered-stack components for remaining durability/percentage, stack capacity and optional food/container counts/IDs. First-page written/writable book preview respects `isTextFilteringEnabled`, emits plain text only, caps text at 256 code points/four lines. Known-container scan capped at 64 entries; no world inventory request. Tool Info falls back to STORED_ENCHANTMENTS and clamps remaining durability.
- Added filtered-row keyboard focus: arrows browse categories/rows, Enter toggles, Shift+Enter opens settings, collapsed focused category expands and scroll target brings focus into view. Pointer clicks clear focus; filter/search changes clear focus/drag. These later changes compile but were not part of the six menu captures; their runtime behavior is unverified. No further visual polish loop was run.
- Module count is now 66 with Xaero. Combined jar packaging still embeds 23 unchanged dependencies; no added runtime GUI/native/web server dependency. Microsoft approval pending; `ms_client_id` blank. Friend cosmetic service remains unhosted. Website owner-managed at 0.5.1; no site task/push/deployment.
- New review: `docs/MODERN_CLIENT_REFERENCE_REVIEW.md` inventories 13 pinned snapshots (duplicate Tenite removed; uranometrical profile resolved to Constellar/Bridge/Aurora). Recognized text files were indexed programmatically; exact targeted manual excerpts are listed. Not an all-file manual or binary security audit. No reference clients/build scripts executed. Stage, source archives and backups: `C:/Users/Admin/Downloads/MCP-919/client-update-0110`.
- Final source review: Enter validates that focused rows still satisfy the filter (prevents toggling an invisible row after disabling it in Enabled view); keyboard navigation releases thumb drag; pointer scrolling clears focus. Settings content controls accept only left click; settings wheel input waits for the page transition to finish. Appearance caches its Interface settings instead of repeatedly scanning the module registry and respects Glass/Solid/opacity itself. Book preview bounds UTF-16 input before further string scans while preserving surrogate pairs. These later refinements compile; no further visual pass or interaction assertions were run.
- Static UI detector ran once on finalized initial menu/appearance surfaces and returned no findings; this does not establish native UI correctness or cover later keyboard/item behavior.
- Player docs and Discord CHANGELOG current. Final release packaging completed: `assemble :launcher:packageLauncher` succeeded after the final source-review fixes, with no tests. Archive metadata read shows version 0.11.0, 23 nested jars, zero external pack downloads, one combined mod override and new AppearanceScreen/ItemDetails classes. Outputs: `build/libs/goonclient-0.11.0-all.jar` (30,718,072 bytes), `build/distributions/GoonClient-0.11.0.mrpack` (30,698,746 bytes), `launcher/build/distributions/GoonClient-Launcher-0.11.0-windows.zip` (60,087,484 bytes). Combined-jar/packaged-launcher runtime remains unverified. Discord CHANGELOG is 1,471 characters.

## Immediate next work

Actual source is `C:/Users/Admin/Synthetix`, not the old MCP workspace. Read README, this checkpoint and `docs/MODERN_CLIENT_REFERENCE_REVIEW.md` before changing code. Current release: 0.11.0; 66 modules when Xaero is loaded. Stage scripts are historical implementation records, not an idempotent updater: do not rerun prepare/refine/details/keyboard/harden over the completed project.

If the owner requests verification, prioritize actual mouse/keyboard interaction of the new category browser (wheel isolation, thumb drag, collapse, filtering after toggles, shortcut capture and return from Appearance), then Item Details with filtered books/enchanted books in a disposable world. Captures only demonstrate static menu rendering; never claim automated input or gameplay coverage from them. Follow session instructions about not adding/running tests unless requested.

Next requested development candidates: native scrolling item tooltips and graphical banner/book previews, scoreboard customization, nickname privacy for recording, persisted category layout/order. Cosmetic backend hosting/two-account sharing and approved Microsoft login remain separate unfinished work. Website update/publishing is owner-managed. Do not import reference auth/HWID code, execute old installers or borrow IDs. Preserve upstream nested jars and notices. Commit/push only when requested.

## What this is

Goon Client is a PvE client for **Minecraft Java 26.3**, built as a client-only **Fabric** mod, shipped as a modpack
(.mrpack) with performance/map/inventory mods, plus a custom Windows launcher and a website. The owner plays with friends
on servers. Display name "Goon Client", mod id `goonclient`, Java package `dev.goonclient`.

- Project folder: `C:\Users\Admin\Synthetix` (old name; leave it).
- Website repo checkout: `C:\Users\Admin\Downloads\goonpremier` (GitHub Pages repo `SynthetixCrypto/goonpremier`, domain goonnation.xyz).
  The owner commits and pushes it themselves. `./gradlew site` writes into it (path in `gradle.properties` `site_dir`).
- Current version: **0.10.0** (`gradle.properties` `version`).

## Where the last session stopped (2026-10-03)

- **0.10.0 implementation:** nine original modules after broader study of all four legacy archives: BlockInfo, BlockFocus, Breadcrumbs, ProjectileGuide, Hitboxes, PlayerTags, CameraComfort, ViewModel, WeatherChanger. 65 modules with Xaero. All off by default, using existing module settings/profiles/favorites/shortcuts. Actual old source is not imported. Index of 5,322 custom-directory Java files (including helpers/duplicates), selected manifest and modernization matrix in docs/CLIENT_REFERENCE_REVIEW.md. This is automated indexing plus targeted source study, not a full manual audit.
- **0.10.0 architecture:** weather wraps ClientLevel.getRainLevel only inside WeatherEffectRenderer.extractRenderState; camera changes GameRenderer.extractOptions output; ViewModel WrapMethod around FirstPersonHandsAndItemsRenderer.submitArmWithItem restores PoseStack with finally and excludes maps. PlayerTags decorates existing AvatarRenderer nameTag and requires line of sight. World features use WorldRender/normal-depth gizmos. Block Info has registry-free HudPreview before the first world. Trail has 512-point bound and clears world/death/jump; trajectories capped to 120 steps, 96 m, 64 visible candidates and loaded chunks, no crossbows/spread/wind/enchantment/server prediction.
- **0.10.0 status:** client/launcher compilation and `assemble :launcher:packageLauncher` succeeded. Two visual-only startup/menu captures completed with 65 modules at GUI scales 2/3: new module cards, projectile/view-model/camera settings and registry-free Block Info HUD preview. No world or external account entered, no observed mixin-startup crash. Original settings/favorites restored; all nine additions are off in saved dev config. Captures `run/screenshots/goon-0100-*.png`. Card descriptions shortened after first pass; conservative trajectory chunk guard and loaded-world/no-target HUD sample added by source review. The last HUD sample-only change compiled/packaged but was not exercised in-world. Static UI detector on three new module classes returned no findings. No automated tests added/run, no performance benchmark, combined-jar startup or authenticated multiplayer. Runtime ballistics, occlusion, weather changes, held-item poses and server tag visibility remain unverified. Friend cosmetics service still unhosted and Microsoft app approval still pending. Website remains at 0.5.1 and owner-controlled; no site task, commit/push or deployment.
- **0.10.0 artifacts:** all.jar 30,706,140 bytes, mrpack 30,687,376 bytes, Windows launcher ZIP 60,075,891 bytes. Archive metadata read: version 0.10.0, 23 nested mod jars, zero external mrpack downloads, one all.jar mod override. min_launcher_version stays 0.9.0 because the package index format did not change. CHANGELOG.md is Discord-ready (1323 characters). Source/reference-index backups and implementation scripts in `C:/Users/Admin/Downloads/MCP-919/client-update-0100`; actual product remains Synthetix.

- **0.9.0 implementation:** 56 registered modules with Xaero installed. Added original Discord IPC implementation (`social/DiscordPresence`), opt-in `DiscordRpc` module and connection/status screen. Own application ID 1556053885729243229 is baked from `discord_application_id`; activity is generic, no IP/coordinates/accounts/tokens. Dedicated daemon scheduling + reader, bounded frames, READY/SET_ACTIVITY acknowledgements, ping/pong, reconnect and disable/exit clear; no external RPC/native dependency. Live Discord presence has not been verified.
- **0.9.0 graphics/building:** Iris API compile-only integration + synchronized Shaders switch and native pack selector. Iris preferences own startup graphics state; enabling without a selected pack opens the picker. Litematica/MaLiLib compile-only integration + Schematics (off), stick tool (off), pick-block (on only with master), easy-place (off). Master enforces render/tool/pick/easy switches every tick including when disabled; off also clears placement restriction. Optional InputHandler mixin releases keyboard/mouse/scroll input when off; guarded by GoonMixinPlugin. These controls own the corresponding native config values. No shader pack bundled.
- **0.9.0 wardrobe:** stable catalog now none + nine capes (six new). Generated 1024×512 antialiased Java2D textures with correct 64×32 vanilla UV scaling, front/back faces, geometric G crest, cloth weave, contrasting seams and unique lower motifs. Texture cache finite; linear sampler. Wardrobe paginates six entries/page, scroll/page controls and actual texture thumbnails/front/back preview; local equip preserved. Server CAPES allowlist matches client. Backend remains unhosted; update it before serving new IDs. No hats/wings/emotes added.
- **0.9.0 distribution:** mrpack task resolves dependencies, downloads/cache-verifies published SHA-512, and builds `goonclient-0.9.0-all.jar` using Fabric nested-jars metadata. Child archives remain unchanged, catalog + licensing/source notices included. .mrpack contains zero external download entries and one all.jar override plus configs; custom index goonclient.bundledMods catalog feeds launcher count/list. Launcher keeps archive compatibility and identifies actual clientJarPath; installation removes only prior managed mods. min_launcher_version raised to 0.9.0 for bundled-index changes. Thin jar remains a development output. Website remains owner-managed at 0.5.1; no site task/commit/push.
- **0.9.0 build status:** client and launcher compile successfully. Release packaging succeeded: -all.jar ≈29 MB, .mrpack ≈29 MB, launcher ZIP ≈57 MB. Default assemble now depends on mrpack; bundleClient is an alias. Visual-only main-menu capture completed with 56 modules: wardrobe page 1/2, GUI scales 2/3, schematics settings and Discord status inspected. No crash observed. Captures run/screenshots/goon-090-*.png; no world entered and cosmetic choice restored. No live RPC connection was attempted. Combined jar startup has not been exercised; nested child mod IDs are explicitly required in the release metadata. UI detector returned no findings. No automated tests or authenticated multiplayer run for this update; do not carry older 0.8.0 assertions forward as evidence for 0.9.0. Runtime shader switching, Litematica input suppression and friend sharing remain unverified.

- **0.8.0:** ModuleBindings + KeyboardHandlerMixin add per-module SDL keyboard shortcuts, global `keybinds.json` outside profiles, one PRESS edge, gameplay/menu/overlay/modifier/debug guards and conflicts against registered controls and other modules. Every ClickGUI card opens settings; shortcut capture cancels with Esc, clears with Delete/Backspace and exposes conflicts without leaving capture. Keys appear on cards. FeedbackHud provides bounded, deduplicated monotonic animated notifications (on by default), ActiveModulesHud and ToolInfoHud default off. Potion expiry alerts are opt-in with adjustable 3–30 s threshold and renewal/removal re-arm. Fixed InventoryHud non-hotbar column lookup (`9 + row*9 + col`) after reproducing nine repeated icons with distinct actual items. Registered count: 53.
- **0.8.0 checks:** `runClient -PupdateChecks` uses only `run-update-checks`, a disposable copy of the filming world. It exercises the real keyboard mixin and shortcut assignment/conflict/persistence/menu/repeat/release/modifier/window guards, GUI capture/cancel/clear, clipping/wheel isolation at scale 3, and notification/potion dedupe/re-arm. Final run logged all assertions passed. UI inspected at scales 2/3. Mixed inventory stacks, local enchanted pickaxe and potion readouts used in live screenshots. Fresh-menu previews use `runClient -PuiPreview`, without a world. Check screenshots: `run-update-checks/screenshots/goon-080-*.png`; main-menu images: `run/screenshots/goon-080-*.png`. Updated reference review, player docs and Discord changelog. Website publishing is still owner-managed; these update tasks do not authenticate multiplayer or deploy cosmetics.

- **0.8.0 release:** assemble/mrpack/launcher packaging succeeded. Jar: build/libs/goonclient-0.8.0.jar (662,521 bytes); pack: build/distributions/GoonClient-0.8.0.mrpack (636,074 bytes, 23 dependency mods + Goon); launcher: launcher/build/distributions/GoonClient-Launcher-0.8.0-windows.zip (30,014,921 bytes). Version metadata, new class entries, embedded pack mod and launcher ZIP integrity verified. Fresh-main-menu preview completed successfully; final inventory grid and editor/new-panels screenshots inspected. Discord changelog is 1,214 characters. Website remains at 0.5.1, no commit/push/deployment. No packaged-launcher execution or authenticated multiplayer test in this round.

- **Showcase V2 (2026-10-03):** `marketing/showcase-v2` contains the 44.8-second 1080p60 master, 720p sharing copy, poster and editable source (assets + 560 frames). Uses the owner's supplied `Introducing Tenacity 5.0.mp3` (Elastic by Joey Purp). Seven freshly staged moving scenes: explore/combat/build/cave/farm/overlay/cape; beat-aligned UI and color reveals. Master decoded all 2,688 frames; representative frames inspected. Added opt-in `DevFilmCapture`, `GoonClient` init call and Loom `-PfilmCapture` run configuration. Filming is restricted to `run-cinematic`, an isolated copy of the dev world; original world preserved. Select scenes using `-Dgoonclient.filmScenes=build,cape`. No release/version/website changes, commits or deployment. Cosmetics service remains unhosted; footage demonstrates local equipping. Inventory HUD appeared to repeat the first item's icon in staged captures; investigate separately before treating inventory rendering as fully verified.
- **Showcase video (2026-10-03):** marketing/showcase-v1 contains a 40-second 1080p60 MP4, 720p sharing copy, poster and editable source ZIP. Original 96 BPM score; real Goon captures animated with perspective, typography and cape artwork. Inspired by the user's Tenacity video reference; no reference footage/music reused. Master fully decoded: 2,400 frames, 40.00 s, H.264/AAC stereo; peak audio -2.2 dB. Storyboards and an encoded frame were visually inspected. This is a motion-graphics film from screenshots, not a live gameplay recording. No website publishing or client changes were made for this task.

- **0.7.0:** Added original equivalents of reference-client profiles, keystrokes/CPS and saturation. Also added local Inventory HUD and Hit Distance. Registered module count is now 50; all five new readouts start off.
- **Profiles:** config/ProfileStore.java + gui/ProfileScreen.java. Built-ins Survival/Builder/Boss run and 32 named snapshots, atomic save (with fallback), random safe filenames, bounded file loading, validation, apply rollback and session Undo. No accounts/cosmetics/video settings in snapshots. Favorites are kept globally. ConfigManager now exposes capture/apply; live apply runs module enable/disable hooks, resets settings and untouched HUD positions before applying saved values.
- **UI:** persistent bookmarks, fixed All/Enabled/Favorites filter strip, full custom-font hover help, two-click settings reset, settings-icon hit priority fixed. Profile manager in ClickGUI footer and Interface. Editor reserves toolbar/hint bounds to prevent ordinary default panels landing behind controls.
- **Modules:** InputHuds.Keystrokes follows bound key labels/pressed state; Cps uses tracker/ClickHistory (256-event rings, monotonic one-second window, raw MouseHandler.onButton edges only during gameplay). NutritionHud uses local food/saturation (~ estimate). InventoryHud reads local slots 9–35, optional 0–8 hotbar. HitDistance records AttackEntityCallback client ray point (attempted hit; no reach change). Native-free previews remain safe before item components are bound.
- **Review and limits:** compile passed and two visual-only capture passes completed. All seven final screenshots were reviewed at 1600x900 with actual GUI scales 2 and 3: profiles, favorites/enabled filters, inventory settings and the fresh main-menu HUD preview. This capture does not join a world, exercise profile actions or authenticate. No new automated tests were added or run for 0.7. In-world readouts, profile save/load/overwrite/delete/undo flows and authenticated multiplayer remain unverified for this release.
- **0.7.0 release:** assemble :mrpack :launcher:installDist :launcher:packageLauncher succeeded. Outputs: build/libs/goonclient-0.7.0.jar (626,617 bytes), build/distributions/GoonClient-0.7.0.mrpack (601,520 bytes, 23 dependency mods + Goon), launcher/build/distributions/GoonClient-Launcher-0.7.0-windows.zip (29,980,388 bytes). Package metadata and new class entries were inspected. The packaged launcher was not launched for 0.7.0. Visual captures are run/screenshots/goon-070-*.png. Website remains at 0.5.1; site task was not run and nothing was committed, pushed or deployed. Cosmetics service remains unhosted and cosmetics_url/ms_client_id remain blank.

- **0.6.0:** ClickGUI header/content nested clipping, two-axis input clipping, inactive-page hit suppression,
  pointer inverse for the panel opening transform, pre-animation/resize scroll clamping, draggable scrollbar, card-relative
  ripples. Added Wardrobe above existing HUD Layout/Log footer buttons; existing navigation is preserved.
- **0.6.0 cosmetics:** Three original built-in capes, wardrobe at title/ClickGUI/Interface, local equip/F5 render via
  AvatarCosmeticsMixin on AvatarRenderer.extractRenderState (Avatar is the generic erasure; mannequins are excluded).
  Immutable PlayerSkin cape replacement preserves body, elytra, model/security and native CapeLayer behavior.
  Cosmetics service is in cosmetics-service/ (Node 22+, no third-party dependencies, Railway-ready Dockerfile).
  Backend uses one-use Mojang session proof + short-lived service token, UUID-bound selection, optional friend allowlist,
  bounded requests/rates and serialized atomic persistence. Game tokens go only to Mojang through authlib.
  Client sharing is opt-in; cosmetics_url is empty by default. Existing per-device cosmetics.json service_url overrides the bundled default;
  change or remove that field when switching services. See cosmetics-service/README.md before hosting.
  Service has NOT been deployed and real two-account sharing is NOT verified. No offline production auth exists.
- **0.6.0 main-menu HUD crash:** Reproduced fresh startup failure (ArmorHud.samples ItemStack constructor: Components not bound yet). HudModule now uses registry-free HudPreview before any world/player exists; this bypasses sample ItemStacks and native minimap rendering. Live world renderers are preserved. Xaero size/visibility/render also guard missing world/player; editor uses a menu backdrop and labels Preview. TargetHud clears stale targets outside worlds.
- **0.6.0 verification:** compileClientJava, full dev tour, hidden input/wheel isolation and scrollbar drag assertions,
  GUI scales 2/3, settings scroll, wardrobe and third-person cape captures passed. Screens visually inspected.
  Five service test groups cover proof, replay/impersonation rejection, expiry, friend list, rates, concurrent save,
  restart persistence, removal and malformed IDs/names. Fresh-start HUD test enables all 26 HUD modules before any world exists; move/resize/drawer/return assertions passed and test settings were restored. The full live-world tour also passed after this fix, including the editor after disconnect.
- **0.6.0 release:** \gradlew.bat build :launcher:installDist :launcher:packageLauncher succeeded. Outputs:
  build/libs/goonclient-0.6.0.jar, build/distributions/GoonClient-0.6.0.mrpack (23 dependency mods + Goon),
  launcher/build/distributions/GoonClient-Launcher-0.6.0-windows.zip (29,938,885 bytes).
  Packaged launcher startup/HUD/Options checks passed in the existing isolated test folder
  C:/Users/Admin/AppData/Local/Temp/opencode/goon-051-launch-test. Installed mod SHA-256 matches the release jar.
  Auth/Realms errors are expected with the developer-only dummy session; this is not a Microsoft or multiplayer test.
  Fresh menu previews intentionally use text/schematic artwork rather than ItemStack icons until a world loads;
  preview dimensions approximate item panels. Enabling all 26 panels on a small window can exhaust layout space.
  Source service tests: 5 groups passed. The cosmetics service remains undeployed; cosmetics_url is blank.
  Website remains at 0.5.1: site task was NOT run and nothing was committed/pushed/deployed this session.
  Changelog and this handoff are current. Current chat is rooted in MCP-919 but all product edits are in Synthetix.
- **Reference review:** docs/CLIENT_REFERENCE_REVIEW.md contains exact pinned commits, scan scope and architecture lessons.
  Four archives/CSV inventories live in C:/Users/Admin/Downloads/MCP-919/client-reference-review.
  284,405 entries inventoried; 209,999 recognized text files pattern-scanned (837,360,481 bytes), 74,406 other files
  inventoried. Targeted manual reading is documented; not a line-by-line audit or binary safety verdict.
  Found explicit Discord HWID/Windows-name logging in Mystra/Shadow.java and native HWID/auth hooks in both Badlion
  wrappers. None of this code/artwork was copied or executed. Repo provenance is unverified.

- **0.5.1 minimap integration:** Xaero is now an optional Goon HUD module, with one native render owned by Goon,
  live editor dragging/resizing/hiding, ClickGUI settings, and two-way visibility synchronization. Native Change Position
  opens Goon's editor; native settings Back/Esc return to ClickGUI. HUD placement reserves measured map bounds, native
  info text, and the hotbar; crowded columns spill sideways. The final Mint tour verifies actual rendered-size ratios
  at 50%, 140% and 200%, layout config reload, hiding, GUI scales 2/3, enlarged maps and native settings navigation.
  `XaeroAutoSizeMixin` strips Goon's multiplier from native automatic area selection so auto sizing can't cancel resizing.
- **0.5.1 checks:** full seven-accent tours and all contact sheets reviewed; Mint rerun after the auto-size fix.
  Native coordinate/biome labels tested enabled, then restored. A standalone layout check passed 1,500 randomized
  cases against exhaustive grid search, plus full-column overflow. Optional-mod startup and Options/Video navigation
  passed with Xaero's Minimap removed; the dev world didn't autojoin during the removal test, so that check used title
  startup mode. Packaged clean startup also passed. This does not establish authenticated multiplayer.
- **0.5.1 is built and ready for the owner's release commit/push:** `compileClientJava build site` passed. Final
  packaged jar matched the installed test jar byte-for-byte; startup/Options/Video navigation passed again after the
  auto-size fix. ZIP integrity, update hash/size/version, all linked assets, unique IDs, JS syntax and `git diff --check`
  passed. Changelog: 895 characters. Dynamic FPS and Xaero restored; temporary HTTP server stopped.
- **0.5.1 website:** downloads/changelog/update manifest refreshed, new Minimap tab, 182 WebPs across 13 tabs × 7
  accents × 2 sizes. Screenshots/logs: `...\opencode\goon-051-release-shots`; clean launch: `...\opencode\goon-051-launch-test`.
  Owner commits/pushes. Browser tooling was disconnected; site verification used asset/HTML/JS and archive checks.
- The website checkout was clean before 0.5.1 work (the owner committed the prior release).
- **0.5.0 is built and ready for the owner's release commit/push.** Owner requested removing the narrator welcome screen and a custom Goon Options menu.
  Both implemented, plus the low-resource preset, screenshot manager, Hardware Usage, Item Physics and Time Changer.
  Site checkout was clean when checked during this session (owner appears to have committed the previous 0.4.0 files).
  The owner pushes it. Pushing `latest.json` is what makes 0.4.0+ launchers update themselves.
- **Verified:** DevSnapshots tour (all shots looked right, including `goon-tools`, `goon-chat`, `goon-title`,
  `goon-title-custom`); launcher updater end to end against a local fake 0.4.1 (download, SHA-512 reject, offline
  reuse, install swapped `goonclient-0.3.0.jar` for the new jar); launcher screenshot mode (new Settings row fits).
- **0.4.0 real-launcher startup test passed:** clean scratch install at
  `C:\Users\Admin\AppData\Local\Temp\opencode\goon-040-launch-test`, Mojang Java 25, Fabric + full pack,
  Goon title window visually captured. Offline-test auth 401 and optional mod warnings; no startup crash.
- **0.5.0 feature checks so far:** compile + repeated full DevSnapshots tours. Preset applies/restores video settings;
  gallery previews/removes/undoes a temporary image byte-for-byte; CPU and GPU frame readings populated;
  items visibly lie on the ground; visual night then real daylight restored, with real client time still 1119 ticks.
- **0.5.0 packaged startup passed:** `compileClientJava build site` succeeded. Fresh launcher install at
  `C:\Users\Admin\AppData\Local\Temp\opencode\goon-050-video-launch` reached Goon title directly with onboarding off,
  opened Goon Options, activated Video by keyboard, opened Reese's Sodium Options with Iris controls, returned to
  Goon Options and exited. All three startup captures visually inspected. Offline-test auth warnings are expected;
  this verifies startup and menu navigation, not authenticated multiplayer.
- **Release checks complete:** all seven accent tours succeeded (20 captures each), every capture reviewed via contact
  sheets, and 168 WebPs exported (12 gallery tabs × 7 accents × 2 sizes). Mint ran last; Dynamic FPS restored.
  The site has new Options, Low-resource preset and Screenshots tabs and 0.5.0 downloads. Verified all linked assets,
  tab/image correspondence, unique HTML IDs, JS syntax, mrpack ZIP integrity, bundled mod bytes, manifest version,
  size and SHA-512. `git diff --check` passed. Changelog is 1355 characters. Site edits remain uncommitted for owner.
  Screenshot review still shows the documented crowded-HUD fallback (Loot Tracker can overlap the minimap when
  too many panels are enabled); this isn't a new auto-layout fix. Custom-image shots exercised the empty-folder fallback.

## Build and test

Toolchain is local: portable JDK 25 in `.tools/jdk-25`. From Git Bash in the project folder:

```bash
export JAVA_HOME="$PWD/.tools/jdk-25"
./gradlew compileClientJava           # fast compile check
./gradlew runClient                   # play-test (dev world "New World", files in run/)
./gradlew runClient -PdevSnapshots    # scripted UI tour: screenshots to run/screenshots/goon-*.png, then quits
./gradlew build site                  # mod jar, .mrpack, launcher zip, and refresh the website files
./gradlew genSources                  # decompiled Minecraft 26.3 sources (use these to check APIs!)
```

- `-PdevSnapshots` is driven by `src/client/java/dev/goonclient/client/dev/DevSnapshots.java` (tick-numbered steps:
  poses a showcase, opens the ClickGUI/settings/HUD editor/log/pause/title and screenshots each). Before running it,
  move `run/mods/dynamic-fps-*.jar` out of `run/mods` (it throttles an unfocused window to 0 FPS) and put it back after.
  It now waits for screenshot-write callbacks before advancing, and calls the vanilla FPS tracker's input notification
  to avoid AFK throttling. It also tests gallery removal/undo using a temporary copy, never a player's original image.
- Run `genSources` and `compileClientJava` separately: combining them in one invocation hits Loom/Gradle's implicit
  dependency validation. Separate invocations pass.
- Real-game test with the real launcher and Mojang's Java runtime:
  `launcher/build/install/goonclient-launcher/bin/goonclient-launcher.bat --launch --dev-offline Tester --game-dir <scratch dir> --minecraft-dir %APPDATA%\.minecraft`
  then read `<scratch dir>/logs/launcher-output.log`.
  For an automated **clean-start** check, set
  `JAVA_TOOL_OPTIONS=-Dgoonclient.devStartupSnapshots=true -Dfabric.debug.disableModIds=dynamic_fps` before that
  command. Dev-only mode asserts the title opens directly with onboarding off, captures `goon-startup-title.png` and
  `goon-startup-options.png` and `goon-startup-video.png`, tests Video -> back, then enters HUD editing with all 26 modules enabled before any world is loaded. It checks minimap preview drag/resize, restores state and takes `goon-startup-hud-editor.png` / `goon-startup-hud-elements.png`, checks return navigation, then exits. Use a fresh scratch directory
  without options.txt. Dynamic FPS is disabled for this automated unfocused test only.

## Hard rules (owner agreed to these)

- **Never** use another launcher's Microsoft/Azure client ID and never ship offline-mode login for real players.
  Sign-in needs the owner's own Azure app (client ID parked as a comment in `gradle.properties`) approved by Mojang;
  until then `ms_client_id` stays empty and Play hands off to the official Minecraft Launcher.
- Don't decompile or copy Lunar Client. Public client repos (e.g. bastianleicht/badlion-src) are fine as
  inspiration only, not copy-paste, and most are 1.8.9 OpenGL code that doesn't port to 26.3 anyway.
- Design system "Graphite + Mint" (owner picked it): neutral charcoal surfaces, hairline borders, white text, grey
  labels, ONE accent colour (Mint `#3DDC97` by default) used only for state (on, selected, progress). No gradients,
  no coloured glows. Tokens live in `gui/Ui.java`.
- Server-unfair features stay opt-in and default off. Health bars must stay depth-tested (no seeing mobs through walls).

## Architecture (src/client/java/dev/goonclient/client/)

- `GoonClient` (entrypoint), `GoonKeys` (Right Shift menu, H hide HUD, C zoom, Left Alt freelook, J log),
  `GoonCommands` (`/goonclient`, `/goonclient log`, `/goonclient loot reset`, `/wp ...`), `GoonChat`.
- `module/` Module, ModuleManager (44 modules plus optional Minimap), settings: Boolean/Number/Mode/Button(action row).
- `config/ConfigManager` saves `config/goonclient/modules.json` (enabled, settings, and HUD positions only for panels
  the player moved, so changed defaults reach everyone else).
- `hud/` HudModule (anchor + offset `HudPosition`, scale), TextHudModule (label/value columns), HudRenderer (one Fabric HUD layer).
  **Auto-layout (0.5.1):** each frame `HudModule.beginLayout(width, height)` reserves vanilla's hotbar/survival bars.
  `layoutOrder()` places native obstacles first, moved panels next, unmoved permanent panels, then transient ones.
  `HudLayout` searches vertical gaps first, then neighboring columns; even moved panels yield to hard obstacles.
  The HUD editor uses the same solver. `MinimapHud` measures Xaero's session before layout and renders in absolute
  coordinates; `XaeroInfoMixin` reserves transformed native label rectangles before the other modules draw.
  Optional `mixin/xaero/` hooks are gated by `GoonMixinPlugin`; Xaero is compileOnly. `XaeroCompat` bridges native
  session/render/settings APIs and reflectively accesses nested XaeroLib config APIs for visibility synchronization.
- `modules/` by category; world drawing modules implement `render/WorldRender.Renderable` (26.3 "gizmos":
  `Gizmos.line/rect/billboardText` inside `LevelRenderEvents.BEFORE_GIZMOS`).
- `tracker/` SessionStats, LootTracker, AdventureLog (per-world JSON in `config/goonclient/adventure/`).
- `gui/render/` **our own renderer** (added in 0.3.0):
  - `GoonFont`: Java2D glyph atlases rasterised at the exact screen-pixel size, uploaded as `SmoothTexture` (linear
    sampler), one `blit` per glyph. Sizes are GUI units; the current pose scale is respected.
  - `Shapes`: rounded rects from cached anti-aliased corner textures + fills, hairline outlines, 9-slice shadows.
  - `Px`: GUI-unit to screen-pixel conversion.
  - `QuadBatch`: many quads of one texture as one GUI element (text runs, rounded rects, `Shapes.rects` for graphs).
- `gui/Ui.java`: theme tokens + helpers (`text`, `bold`, `roundRect`, `roundOutline`, `toggleSwitch`, `animate`, ...).
  All screens and HUD modules draw through it.
- Screens: `ClickGuiScreen` (Right Shift menu), `HudEditorScreen`, `GoonTitleScreen` (main menu),
  `GoonPauseScreen` (pause menu), `AdventureLogScreen`, shared bits in `Menus`. Full-screen menus lay out in a virtual
  space via `Ui.menuScale(width, height)` (>= 640x380 units) and divide mouse coords by that scale.
- **0.5.0 screens:** `GoonOptionsScreen` replaces every vanilla `OptionsScreen` via `GuiMixin`, preserves its parent,
  and links to the native/mod detailed settings (Sodium/Iris included). `OptionsMixin` clears `onboardAccessibility`
  after Options construction, so fresh installs skip the narrator welcome without changing narrator preferences.
  `PerformanceScreen` / `config/PerformancePreset` use a durable selective JSON backup; restore suppresses vanilla's
  bulk graphics-preset callback so exact saved values survive. `ScreenshotScreen` owns up to six `ScreenshotImage`
  textures; one daemon decoder, bounded subsampling, explicit texture release, move-to-trash + session undo.
  `compat/SodiumCompat` calls Sodium's settings factory reflectively (runtime-only optional dependency), since Sodium's
  own vanilla OptionsScreen hook does not run on our replacement hub. Reese's replaces that factory in the bundled pack.
- **0.5.0 visuals/HUD:** HardwareUsage samples CPU once/sec, MinecraftRenderMixin requests vanilla GPU timer recording
  only while enabled in a world. GPU is frame load, not Task Manager utilization. ItemPhysics passes grounded/liquid/yaw
  through render state and adjusts pose only. TimeChanger wraps only client visual timeline clocks for OVERWORLD;
  real clocks and gameplay attributes never change. Both visual modules default off.
- Font atlas eviction/rebuild now defers texture release until the next render frame, after queued draws have consumed it.
- Mixins (`goonclient.client.mixins.json`): GuiMixin swaps vanilla TitleScreen/PauseScreen for ours (toggles in the
  Interface module), Camera/MouseHandler (zoom, freelook, MixinExtras @WrapOperation), lightmap (fullbright),
  pickup packet, chat timestamps, tooltip (shulker preview), boss bar + death screen accessors, advancement toast.
- `launcher/`: Swing launcher (jpackage). Installs the pack, launches the game directly or via the official launcher.
  **Auto-update (0.4.0):** `Updater` reads `<site_url>/download/latest.json` (written by `./gradlew site`: version,
  mrpack URL, SHA-512, size, `minLauncher`) in the background on start, downloads a newer .mrpack into
  `<game dir>/updates/`, verifies size + SHA-512, then `PackManifest.fromArchive` re-checks it (only Modrinth/GitHub
  download hosts, no `..`/absolute paths). Next start loads the cached pack instantly (`Updater.newestCached`), even
  offline. If `minLauncher` is newer than the launcher's own bundled version it shows "needs a new launcher" instead.
  Settings has an "Automatic updates" toggle. Test: `JAVA_OPTS=-Dgoonclient.updateUrl=http://localhost:PORT/latest.json`
  with `goonclient-launcher.bat --check-update --game-dir <scratch>` (plain http is allowed for localhost only).
- `pack/mods.txt` + `pack/overrides/`: modpack definition; `./gradlew mrpack` resolves stable Modrinth builds.

## 26.3 gotchas (verify against `genSources` output before using any API)

- Screens: `mc.gui.screen()` / `mc.gui.setScreen()`. Chat: `mc.gui.hud.getChat()`, `player.sendSystemMessage`.
- Drawing: `GuiGraphicsExtractor` (`fill`, `blit(RenderPipelines.GUI_TEXTURED, id, x, y, u, v, w, h, texW, texH, color)`,
  `pose()` is a `Matrix3x2fStack`, `enableScissor`). Textures use samplers: `RenderSystem.getSamplerCache().getClampToEdge(FilterMode.LINEAR)`.
- Entity type constants are in `EntityTypes` (not `EntityType`). Input: `KeyEvent`, `CharacterEvent`, `MouseButtonEvent`.
- Camera: `mc.gameRenderer.mainCamera()`; partial tick: `mc.getDeltaTracker().getGameTimeDeltaPartialTick(false)`.
- Disconnect like vanilla: `mc.disconnectFromWorld(ClientLevel.DEFAULT_QUIT_MESSAGE)`.

## Open problems reported by the owner

1. **"Whenever you tick something it doesn't go fully" + UI feels buggy.** Cause: `Ui.animate` was exponential
   smoothing with low speeds, so the tail of every animation crawled for over a second. **Fixed in 0.3.1:**
   `Ui.animate` is now a fixed-length ease-out tween (about 0.1-0.25 s, from `speed`) that always lands exactly on the
   target. Still worth checking in game that every click toggles exactly once and nothing double-fires.
2. **Performance ("slow").** **Improved in 0.3.2:** `gui/render/QuadBatch` submits a whole string (and a whole
   rounded rect) as ONE GUI element instead of one per glyph / seven per rect. Measured with VSync off and no FPS cap
   (dev window 1600x900): 280 FPS in game with every HUD panel + health bars + damage numbers, 351 FPS with the ClickGUI
   open. If a player still reports slowness, check their Dynamic FPS settings and hardware before touching the renderer.
   `DevSnapshots` logs "Dev fps" lines and a toggle check ("Dev toggle animation after 250 ms: 1.0").
3. **HUD ignores the minimap.** **Reworked in 0.5.1:** replaced the old 30%-height approximation with a real Minimap
   HUD module. Map data, radar and waypoints remain Xaero's; placement, scale and visibility integrate with Goon.
   `ConfigManager.load` migrates both earlier untouched left-column defaults. Enlarged maps follow the Goon anchor.

## Known smaller issues

- Vanilla chat (bottom left) isn't part of the HUD auto-stacking, so a tall left-column panel (Loot Tracker) can sit
  under chat lines at small GUI sizes. Reserving the chat box only while it shows messages would make panels move.
- Health bars over mobs in water get tinted (water draws after gizmos). Drawing on top would show mobs through walls: don't.
- Players upgrading from 0.1.0 keep Mob Info at its old spot until HUD editor > Reset All.
- `DevSnapshots` edits the dev world (gear, effects, husks); it's dev-only. It also logs every HUD panel's rectangle
  ("Dev rect ...") at the `tools` shot, handy for checking the auto-stacking.
- At extremely crowded GUI sizes, the layout prioritizes keeping the map and hotbar clear; ordinary panels can still
  overlap if no fully free rectangle fits. Native chat remains outside the solver.

## Still to build (from the owner's wish list)

Done in 0.4.0: FPS graph (`modules/hud/FrameGraph`), Boss Prep HUD (`modules/combat/BossPrep`).

Also done in 0.4.0: menu backgrounds (`gui/render/Backdrop` via `mixin/ScreenMixin` on `Screen.extractPanorama`, so every
menu that would show the panorama uses it; Interface `menu_background` = Goon (animated light, twinkling pixels, grain,
mouse parallax) / Custom image (newest .png/.jpg in `config/goonclient/backgrounds`, decoded off-thread, rescanned every
second) / Panorama (vanilla)), launcher auto-update (pack only; the launcher itself still updates by downloading the zip), Better
Chat (`UtilityModules.BetterChat` + `mixin/ChatComponentMixin`: repeats replace the previous line with "(xN)",
`@ModifyConstant` raises vanilla's 100-message cap to 1000).

Done in 0.5.0: low-resource preset, screenshot manager, CPU/GPU frame usage, item physics, visual time changer,
custom Options hub and skipping narrator onboarding. Better Chat was already done in 0.4.0.

Done in 0.5.1: Minimap ClickGUI/HUD integration and measured map/info-label collision reservation.

Still open: vanilla chat reservation in HUD auto-stacking, in-game Microsoft
account screen (only after Mojang approves the owner's app). Detailed vanilla settings subpages still use vanilla/mod
UI; the Options landing menu is custom Goon Client.

## Release checklist

1. Bump `version` in `gradle.properties` (raise `min_launcher_version` only if the launcher itself changed in a way old
   launchers can't handle), write `CHANGELOG.md` (Discord post, `[+]` new / `[-]` changed, under 2000 chars;
   it's also bundled into the mod for the main menu's "What's new" and into the launcher).
2. `./gradlew build site`, run the DevSnapshots tour and the real-launcher test above, look at every screenshot.
3. Website images: every client screenshot exists once per accent colour, because the site's colour swatches swap them
   (`assets/js/site.js` `showShots`). Render each set with `./gradlew runClient -PdevSnapshots -PdevAccent=<Mint|Sky|Violet|Rose|Amber|Red|White>`
   (Mint last, so the dev config ends on the default), then convert `goon-<key>.png` to `assets/img/shot-<key>-1600.webp` /
   `-800.webp` for Mint and `shot-<key>-<accent>-1600.webp` / `-800.webp` (lower-case accent) for the others. Keys:
     hud, tools, menu, settings, editor, minimap-settings, overlays, log, pause, title, options, performance, screenshots.
    A new screenshot tab needs all 7 sets. Current release capture archives and their review sheets are at
     `C:\Users\Admin\AppData\Local\Temp\opencode\goon-051-release-shots\<Accent>`; the temporary exporter is
    `...\opencode\goon-export-shots.py` (takes source directory and accent, writes 800/1600 WebPs).
4. The owner commits/pushes the site repo and posts the changelog. Pushing `download/latest.json` is what makes every
   launcher (0.4.0 or newer) pick up the release by itself.


